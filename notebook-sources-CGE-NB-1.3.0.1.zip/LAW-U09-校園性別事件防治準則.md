# LAW-U09｜校園性別事件防治準則

資料集：CGE-NB-1.3.0.1；編製日：2026-09-09。此日期不是法律查核日。

## 來源與版本

- source_id：U09
- filename：校園性別事件防治準則.json
- path：sources/uploaded/校園性別事件防治準則.json
- sha256：0c5db487f2ce8397f0002971a163842e0da71a6e0dcd6f0340a23311a282510d
- regulation_id：tw-campus-gender-incident-prevention-standards
- name：校園性別事件防治準則
- version：{"id": "tw-campus-gender-incident-prevention-standards-20240306", "label": "修正日期：民國 113 年 03 月 06 日", "promulgationDate": "2024-03-06", "effectiveDate": "2024-03-08", "effectiveDateNote": "依第41條，本準則自中華民國一百十三年三月八日施行，即2024-03-08。", "status": "effective"}
- article_count：41
- source_kind：user_uploaded_ai_normalized_json
- review_status：core_rules_checked_not_full_diff
- review_notes：["第7條plainText尾端夾入第四章章名；structure漏列該章，不能用章節中繼資料判定條文效力。"]
- official_source_ids：["W02"]
- normalization_warnings：["來源 PDF未載明主管機關，authority 依規範填「未提供」。", "來源 PDF未印出官方法規代碼，code 依規範填「UNKNOWN」。"]
- processed_at：2026-07-22T00:00:00Z
- authoritative_current_full_text：False

- id：tw-campus-gender-incident-prevention-standards
- code：UNKNOWN
- name：校園性別事件防治準則
- shortName：校園性別事件防治準則
- jurisdiction：TW
- authority：未提供
- aliases：["校園性侵害性騷擾或性霸凌防治準則"]
- version：{"id": "tw-campus-gender-incident-prevention-standards-20240306", "label": "修正日期：民國 113 年 03 月 06 日", "promulgationDate": "2024-03-06", "effectiveDate": "2024-03-08", "effectiveDateNote": "依第41條，本準則自中華民國一百十三年三月八日施行，即2024-03-08。", "status": "effective"}
- structure：[{"id": "chapter-1", "type": "chapter", "label": "第 一 章 總則", "parentId": null, "sortOrder": 0}, {"id": "chapter-2", "type": "chapter", "label": "第 二 章 校園安全規劃", "parentId": null, "sortOrder": 1}, {"id": "chapter-3", "type": "chapter", "label": "第 三 章 校內外教學與活動及人際互動注意事項", "parentId": null, "sortOrder": 2}, {"id": "chapter-4", "type": "chapter", "label": "第 五 章 校園性別事件之處理機制、程序及救濟方法", "parentId": null, "sortOrder": 3}, {"id": "chapter-5", "type": "chapter", "label": "第 六 章 附則", "parentId": null, "sortOrder": 4}]
- legalConcepts：[{"id": "gender-equity-campus-framework", "name": "校園性別事件處理法律框架", "description": "彙整校園性侵害、性騷擾及性霸凌事件之防治、調查與處理程序所涉之法規，包含性別平等教育法及其授權訂定之準則與學校校內規定。", "aliases": ["校園性別事件"], "tags": ["校園", "性別事件", "性平教育"], "role": "procedural", "sortOrder": 2}, {"id": "child-youth-protection-framework", "name": "兒童及少年保護法律框架", "description": "彙整兒童及少年之福利、權益保障與性剝削防制所涉之法規。", "aliases": ["兒少保護"], "tags": ["兒童", "少年", "保護"], "role": "related", "sortOrder": 3}, {"id": "sexual-harassment-prevention-framework", "name": "性騷擾防治法律框架", "description": "彙整我國性騷擾之定義、防治義務、申訴調查程序與相關罰則所涉之法規；並涵蓋依場域與當事人身分關係而分流適用之性別平等工作法與性別平等教育法。", "aliases": ["性騷擾防治"], "tags": ["性騷擾", "防治", "申訴"], "role": "related", "sortOrder": 4}, {"id": "stalking-harassment-prevention-framework", "name": "跟蹤騷擾防制法律框架", "description": "彙整跟蹤騷擾行為之定義、書面告誡、保護令與相關罰則所涉之法規。", "aliases": ["跟騷防制"], "tags": ["跟蹤騷擾", "保護令"], "role": "related", "sortOrder": 5}, {"id": "teacher-employment-framework", "name": "教師任用與聘任法律框架", "description": "彙整各級學校教師之資格、任用、聘任、解聘與不適任處理所涉之法規。", "aliases": ["教師任用"], "tags": ["教師", "任用", "聘任"], "role": "related", "sortOrder": 6}]
- crossRegulationLinks：[{"conceptId": "gender-equity-campus-framework", "sourceArticleId": "article-1", "label": "引用性別平等教育法", "relationType": "application", "conditionText": "本準則依性別平等教育法（以下簡稱本法）第二十一條第一項及第三十三條第三項規定訂定之。", "targetRegulationId": "tw-gender-equity-education-act", "targetRegulationNames": ["性別平等教育法"], "targetArticleNumber": "21", "triggerTerms": ["本準則依"], "linkMode": "automatic", "id": "link-tw-campus-gender-incident-prevention-standards-cite-1", "sortOrder": 0}, {"conceptId": "gender-equity-campus-framework", "sourceArticleId": "article-7", "label": "引用性別平等工作法", "relationType": "application", "conditionText": "1   學生於校外為實習生，實習期間遭受性騷擾時，依性別平等工作法第二條第五項規定辦理；事件之一方為實習場域之實習指導人員者，並適用本法之規定。", "targetRegulationId": "tw-gender-equality-employment-act", "targetRegulationNames": ["性別平等工作法"], "targetArticleNumber": "2", "triggerTerms": ["擾時，依"], "linkMode": "automatic", "id": "link-tw-campus-gender-incident-prevention-standards-cite-2", "sortOrder": 1}, {"conceptId": "teacher-employment-framework", "sourceArticleId": "article-17", "label": "引用教師法", "relationType": "application", "conditionText": "3   前項校長、教職員工適用教師法、教育人員任用條例、公務人員相關法律或陸海空軍相關法律者，其解聘、停聘、免職、撤職、停職或退伍，依各該法律規定辦理；其未解聘、免職、撤職或退伍者，應調離學校現職。", "targetRegulationId": "tw-teachers-act", "targetRegulationNames": ["教師法"], "targetArticleNumber": null, "triggerTerms": ["員工適用"], "linkMode": "automatic", "id": "link-tw-campus-gender-incident-prevention-standards-cite-3", "sortOrder": 2}, {"conceptId": "teacher-employment-framework", "sourceArticleId": "article-17", "label": "引用教育人員任用條例", "relationType": "application", "conditionText": "3   前項校長、教職員工適用教師法、教育人員任用條例、公務人員相關法律或陸海空軍相關法律者，其解聘、停聘、免職、撤職、停職或退伍，依各該法律規定辦理；其未解聘、免職、撤職或退伍者，應調離學校現職。", "targetRegulationId": "tw-educational-personnel-employment-act", "targetRegulationNames": ["教育人員任用條例"], "targetArticleNumber": null, "triggerTerms": ["教師法、"], "linkMode": "automatic", "id": "link-tw-campus-gender-incident-prevention-standards-cite-4", "sortOrder": 3}, {"conceptId": "gender-equity-campus-framework", "sourceArticleId": "article-22", "label": "引用刑法", "relationType": "application", "conditionText": "一、違反刑法妨害性自主罪章、妨害性隱私及不實性影像罪章，經緩起訴處分確定或有罪判決確定。", "targetRegulationId": "tw-criminal-code", "targetRegulationNames": ["刑法"], "targetArticleNumber": null, "triggerTerms": ["一、違反"], "linkMode": "automatic", "id": "link-tw-campus-gender-incident-prevention-standards-cite-5", "sortOrder": 4}, {"conceptId": "gender-equity-campus-framework", "sourceArticleId": "article-22", "label": "引用性別平等工作法", "relationType": "application", "conditionText": "二、違反本法、性別平等工作法、性騷擾防治法、跟蹤騷擾防制法、兒童及少年性剝削防制條例或其他性別平等相關法規，經依法調查或有關機關查證屬實。", "targetRegulationId": "tw-gender-equality-employment-act", "targetRegulationNames": ["性別平等工作法"], "targetArticleNumber": null, "triggerTerms": ["反本法、"], "linkMode": "automatic", "id": "link-tw-campus-gender-incident-prevention-standards-cite-6", "sortOrder": 5}, {"conceptId": "sexual-harassment-prevention-framework", "sourceArticleId": "article-22", "label": "引用性騷擾防治法", "relationType": "application", "conditionText": "二、違反本法、性別平等工作法、性騷擾防治法、跟蹤騷擾防制法、兒童及少年性剝削防制條例或其他性別平等相關法規，經依法調查或有關機關查證屬實。", "targetRegulationId": "tw-sexual-harassment-prevention-act", "targetRegulationNames": ["性騷擾防治法"], "targetArticleNumber": null, "triggerTerms": ["工作法、"], "linkMode": "automatic", "id": "link-tw-campus-gender-incident-prevention-standards-cite-7", "sortOrder": 6}, {"conceptId": "stalking-harassment-prevention-framework", "sourceArticleId": "article-22", "label": "引用跟蹤騷擾防制法", "relationType": "application", "conditionText": "二、違反本法、性別平等工作法、性騷擾防治法、跟蹤騷擾防制法、兒童及少年性剝削防制條例或其他性別平等相關法規，經依法調查或有關機關查證屬實。", "targetRegulationId": "tw-stalking-harassment-prevention-act", "targetRegulationNames": ["跟蹤騷擾防制法"], "targetArticleNumber": null, "triggerTerms": ["防治法、"], "linkMode": "automatic", "id": "link-tw-campus-gender-incident-prevention-standards-cite-8", "sortOrder": 7}, {"conceptId": "child-youth-protection-framework", "sourceArticleId": "article-22", "label": "引用兒童及少年性剝削防制條例", "relationType": "application", "conditionText": "二、違反本法、性別平等工作法、性騷擾防治法、跟蹤騷擾防制法、兒童及少年性剝削防制條例或其他性別平等相關法規，經依法調查或有關機關查證屬實。", "targetRegulationId": "tw-child-youth-sexual-exploitation-prevention-act", "targetRegulationNames": ["兒童及少年性剝削防制條例"], "targetArticleNumber": null, "triggerTerms": ["防制法、"], "linkMode": "automatic", "id": "link-tw-campus-gender-incident-prevention-standards-cite-9", "sortOrder": 8}, {"conceptId": "gender-equity-campus-framework", "sourceArticleId": "article-24", "label": "引用行政程序法", "relationType": "application", "conditionText": "十、當事人申請閱覽、抄寫、複印或攝影有關資料或卷宗，應依行政程序法規定辦理。", "targetRegulationId": "tw-administrative-procedure-act", "targetRegulationNames": ["行政程序法"], "targetArticleNumber": null, "triggerTerms": ["宗，應依"], "linkMode": "automatic", "id": "link-tw-campus-gender-incident-prevention-standards-cite-10", "sortOrder": 9}, {"conceptId": "gender-equity-campus-framework", "sourceArticleId": "article-25", "label": "引用刑法", "relationType": "penalty", "conditionText": "2   依前項規定負保密義務者洩密時，應依刑法或其他相關法規處罰。", "targetRegulationId": "tw-criminal-code", "targetRegulationNames": ["刑法"], "targetArticleNumber": null, "triggerTerms": ["時，應依"], "linkMode": "automatic", "id": "link-tw-campus-gender-incident-prevention-standards-cite-11", "sortOrder": 10}, {"conceptId": "teacher-employment-framework", "sourceArticleId": "article-37", "label": "引用教育人員任用條例", "relationType": "application", "conditionText": "2   主管機關知悉現任公、私立學校校長涉有校園性別事件，於其申請退休或資遣時，應由主管機關分別依教育人員任用條例、公務員懲戒法或私立學校法等規定辦理。", "targetRegulationId": "tw-educational-personnel-employment-act", "targetRegulationNames": ["教育人員任用條例"], "targetArticleNumber": null, "triggerTerms": ["關分別依"], "linkMode": "automatic", "id": "link-tw-campus-gender-incident-prevention-standards-cite-12", "sortOrder": 11}]
- definedTerms：[{"id": "tw-campus-gender-incident-prevention-standards-term-1", "name": "實習場域之實習指導人員", "aliases": [], "definition": "教導或提供學生專業知能、提供實務訓練及指導學生實務操作訓練之人員。", "definitionArticleId": "article-7", "definitionText": "2   前項所稱實習場域之實習指導人員，指教導或提供學生專業知能、提供實務訓練及指導學生實務操作訓練之人員。", "scope": "regulation", "targetRegulationNames": [], "sortOrder": 0}]

正規化概念、跨法連結與處理狀態不是獨立法源；下面逐條保留來源plainText，未以本次日期重寫。

## U09-A1｜第 1 條

本準則依性別平等教育法（以下簡稱本法）第二十一條第一項及第三十三條第三項規定訂定之。

來源條目欄位（正規化資料）：
- id：article-1
- articleNumber：1
- displayNumber：第 1 條
- title：None
- structureId：chapter-1
- metadata：{"source": "全國法規資料庫 校園性別事件防治準則（PDF：法規-校園性別事件防治準則.pdf）", "lastModified": "2024-03-06"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": null,
    "text": "本準則依性別平等教育法（以下簡稱本法）第二十一條第一項及第三十三條第三項規定訂定之。"
  }
]
```

## U09-A2｜第 2 條

學校應積極推動校園性別事件防治教育，並採取下列措施：
一、針對性別平等教育委員會（以下簡稱性平會）及負責校園性別事件處置相關單位人員，每年定期辦理相關之在職進修活動。
二、鼓勵前款人員參加校內外校園性別事件處置研習活動，並予以公差登記及經費補助。
三、利用多元管道，公告周知本準則所規範之事項，並納入教職員工聘約及學生手冊。
四、鼓勵校園性別事件被害人或檢舉人儘早申請調查或檢舉，以利蒐證及調查處理。

來源條目欄位（正規化資料）：
- id：article-2
- articleNumber：2
- displayNumber：第 2 條
- title：None
- structureId：chapter-1
- metadata：{"source": "全國法規資料庫 校園性別事件防治準則（PDF：法規-校園性別事件防治準則.pdf）", "lastModified": "2024-03-06"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": null,
    "text": "學校應積極推動校園性別事件防治教育，並採取下列措施："
  },
  {
    "type": "item",
    "number": "一",
    "text": "一、針對性別平等教育委員會（以下簡稱性平會）及負責校園性別事件處置相關單位人員，每年定期辦理相關之在職進修活動。"
  },
  {
    "type": "item",
    "number": "二",
    "text": "二、鼓勵前款人員參加校內外校園性別事件處置研習活動，並予以公差登記及經費補助。"
  },
  {
    "type": "item",
    "number": "三",
    "text": "三、利用多元管道，公告周知本準則所規範之事項，並納入教職員工聘約及學生手冊。"
  },
  {
    "type": "item",
    "number": "四",
    "text": "四、鼓勵校園性別事件被害人或檢舉人儘早申請調查或檢舉，以利蒐證及調查處理。"
  }
]
```

## U09-A3｜第 3 條

1   學校或主管機關應蒐集校園性別事件防治與救濟等資訊，並於處理事件時，主動提供予相關人員。
2   前項資訊應包括下列事項：
一、校園性別事件之界定、類型及相關法規。
二、被害人之權益保障及學校所提供之必要協助。
三、申請調查、申復及救濟之機制。
四、相關之主管機關及權責單位。
五、提供資源協助之團體及網絡。
六、其他該校或主管機關性平會認為必要之事項。

來源條目欄位（正規化資料）：
- id：article-3
- articleNumber：3
- displayNumber：第 3 條
- title：None
- structureId：chapter-1
- metadata：{"source": "全國法規資料庫 校園性別事件防治準則（PDF：法規-校園性別事件防治準則.pdf）", "lastModified": "2024-03-06"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   學校或主管機關應蒐集校園性別事件防治與救濟等資訊，並於處理事件時，主動提供予相關人員。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   前項資訊應包括下列事項："
  },
  {
    "type": "item",
    "number": "一",
    "text": "一、校園性別事件之界定、類型及相關法規。"
  },
  {
    "type": "item",
    "number": "二",
    "text": "二、被害人之權益保障及學校所提供之必要協助。"
  },
  {
    "type": "item",
    "number": "三",
    "text": "三、申請調查、申復及救濟之機制。"
  },
  {
    "type": "item",
    "number": "四",
    "text": "四、相關之主管機關及權責單位。"
  },
  {
    "type": "item",
    "number": "五",
    "text": "五、提供資源協助之團體及網絡。"
  },
  {
    "type": "item",
    "number": "六",
    "text": "六、其他該校或主管機關性平會認為必要之事項。"
  }
]
```

## U09-A4｜第 4 條

1   學校為防治校園性別事件，應採取下列措施改善校園危險空間：
一、依空間配置、管理與保全、標示系統、求救系統與安全路線、照明與空間穿透性及其他空間安全要素等，定期檢討校園空間與設施之規劃與使用情形及檢視校園整體安全。
二、記錄校園內曾經發生校園性別事件之空間，並依實際需要繪製校園安全地圖。
2   前項第一款檢討校園空間與設施之規劃，應考量學生之身心功能或語言文化差異之特殊性，提供符合其需要之安全規劃及說明方式；其範圍，應包括校園內所設之宿舍、衛浴設備、校車等。

來源條目欄位（正規化資料）：
- id：article-4
- articleNumber：4
- displayNumber：第 4 條
- title：None
- structureId：chapter-2
- metadata：{"source": "全國法規資料庫 校園性別事件防治準則（PDF：法規-校園性別事件防治準則.pdf）", "lastModified": "2024-03-06"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   學校為防治校園性別事件，應採取下列措施改善校園危險空間："
  },
  {
    "type": "item",
    "number": "一",
    "text": "一、依空間配置、管理與保全、標示系統、求救系統與安全路線、照明與空間穿透性及其他空間安全要素等，定期檢討校園空間與設施之規劃與使用情形及檢視校園整體安全。"
  },
  {
    "type": "item",
    "number": "二",
    "text": "二、記錄校園內曾經發生校園性別事件之空間，並依實際需要繪製校園安全地圖。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   前項第一款檢討校園空間與設施之規劃，應考量學生之身心功能或語言文化差異之特殊性，提供符合其需要之安全規劃及說明方式；其範圍，應包括校園內所設之宿舍、衛浴設備、校車等。"
  }
]
```

## U09-A5｜第 5 條

1   學校應定期舉行校園空間安全檢視說明會，邀集專業空間設計者、教職員工生及其他校園使用者參與。
2   前項檢視說明會，學校得採電子化會議方式召開，並應將檢視成果及相關紀錄公告周知。
3   學校檢視校園危險空間改善進度，應列為性平會每學期工作報告事項。

來源條目欄位（正規化資料）：
- id：article-5
- articleNumber：5
- displayNumber：第 5 條
- title：None
- structureId：chapter-2
- metadata：{"source": "全國法規資料庫 校園性別事件防治準則（PDF：法規-校園性別事件防治準則.pdf）", "lastModified": "2024-03-06"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   學校應定期舉行校園空間安全檢視說明會，邀集專業空間設計者、教職員工生及其他校園使用者參與。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   前項檢視說明會，學校得採電子化會議方式召開，並應將檢視成果及相關紀錄公告周知。"
  },
  {
    "type": "paragraph",
    "number": "3",
    "text": "3   學校檢視校園危險空間改善進度，應列為性平會每學期工作報告事項。"
  }
]
```

## U09-A6｜第 6 條

學校校長及教職員工生於進行校內外教學與活動、執行職務及人際互動時，應尊重多元性別差異，消除性別歧視。

來源條目欄位（正規化資料）：
- id：article-6
- articleNumber：6
- displayNumber：第 6 條
- title：None
- structureId：chapter-3
- metadata：{"source": "全國法規資料庫 校園性別事件防治準則（PDF：法規-校園性別事件防治準則.pdf）", "lastModified": "2024-03-06"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": null,
    "text": "學校校長及教職員工生於進行校內外教學與活動、執行職務及人際互動時，應尊重多元性別差異，消除性別歧視。"
  }
]
```

## U09-A7｜第 7 條

1   學生於校外為實習生，實習期間遭受性騷擾時，依性別平等工作法第二條第五項規定辦理；事件之一方為實習場域之實習指導人員者，並適用本法之規定。
2   前項所稱實習場域之實習指導人員，指教導或提供學生專業知能、提供實務訓練及指導學生實務操作訓練之人員。
3   學校知悉實習生為性侵害、性騷擾或性霸凌事件被害人，而非屬本法適用範圍者，得依本法第二十五條第三項規定辦理。
4   學校知悉實習生為校園性別事件被害人，應採取立即有效之糾正及補救措施。第 四 章 校長及教職員工與性或性別有關專業倫理及主動迴避陳報事項

來源條目欄位（正規化資料）：
- id：article-7
- articleNumber：7
- displayNumber：第 7 條
- title：None
- structureId：chapter-3
- metadata：{"source": "全國法規資料庫 校園性別事件防治準則（PDF：法規-校園性別事件防治準則.pdf）", "lastModified": "2024-03-06"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   學生於校外為實習生，實習期間遭受性騷擾時，依性別平等工作法第二條第五項規定辦理；事件之一方為實習場域之實習指導人員者，並適用本法之規定。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   前項所稱實習場域之實習指導人員，指教導或提供學生專業知能、提供實務訓練及指導學生實務操作訓練之人員。"
  },
  {
    "type": "paragraph",
    "number": "3",
    "text": "3   學校知悉實習生為性侵害、性騷擾或性霸凌事件被害人，而非屬本法適用範圍者，得依本法第二十五條第三項規定辦理。"
  },
  {
    "type": "paragraph",
    "number": "4",
    "text": "4   學校知悉實習生為校園性別事件被害人，應採取立即有效之糾正及補救措施。第 四 章 校長及教職員工與性或性別有關專業倫理及主動迴避陳報事項"
  }
]
```

## U09-A8｜第 8 條

1   校長或教職員工與未成年學生，在與性或性別有關之人際互動上，不得發展以性行為或情感為基礎等有違專業倫理之關係。
2   校長或教職員工於執行教學、指導、訓練、評鑑、管理、輔導學生或提供學生工作機會而有地位、知識、年齡、體力、身分、族群、或資源之不對等權勢關係時，與成年學生在與性或性別有關之人際互動上，不得發展以性行為或情感為基礎等有違專業倫理之關係。
3   校長或教職員工發現其與學生之關係有違反前二項專業倫理之虞，應主動迴避及陳報學校或學校主管機關處理。

來源條目欄位（正規化資料）：
- id：article-8
- articleNumber：8
- displayNumber：第 8 條
- title：None
- structureId：chapter-3
- metadata：{"source": "全國法規資料庫 校園性別事件防治準則（PDF：法規-校園性別事件防治準則.pdf）", "lastModified": "2024-03-06"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   校長或教職員工與未成年學生，在與性或性別有關之人際互動上，不得發展以性行為或情感為基礎等有違專業倫理之關係。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   校長或教職員工於執行教學、指導、訓練、評鑑、管理、輔導學生或提供學生工作機會而有地位、知識、年齡、體力、身分、族群、或資源之不對等權勢關係時，與成年學生在與性或性別有關之人際互動上，不得發展以性行為或情感為基礎等有違專業倫理之關係。"
  },
  {
    "type": "paragraph",
    "number": "3",
    "text": "3   校長或教職員工發現其與學生之關係有違反前二項專業倫理之虞，應主動迴避及陳報學校或學校主管機關處理。"
  }
]
```

## U09-A9｜第 9 條

校長或教職員工生應尊重他人與自己之性或身體之自主，避免不受歡迎之追求行為，並不得以強制或暴力手段處理與性或性別有關之衝突。

來源條目欄位（正規化資料）：
- id：article-9
- articleNumber：9
- displayNumber：第 9 條
- title：None
- structureId：chapter-3
- metadata：{"source": "全國法規資料庫 校園性別事件防治準則（PDF：法規-校園性別事件防治準則.pdf）", "lastModified": "2024-03-06"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": null,
    "text": "校長或教職員工生應尊重他人與自己之性或身體之自主，避免不受歡迎之追求行為，並不得以強制或暴力手段處理與性或性別有關之衝突。"
  }
]
```

## U09-A10｜第 10 條

本法第三條第三款所定校園性別事件，包括不同學校間所發生者。

來源條目欄位（正規化資料）：
- id：article-10
- articleNumber：10
- displayNumber：第 10 條
- title：None
- structureId：chapter-4
- metadata：{"source": "全國法規資料庫 校園性別事件防治準則（PDF：法規-校園性別事件防治準則.pdf）", "lastModified": "2024-03-06"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": null,
    "text": "本法第三條第三款所定校園性別事件，包括不同學校間所發生者。"
  }
]
```

## U09-A11｜第 11 條

1   校園性別事件之被害人、其法定代理人或實際照顧者（以下簡稱申請人）、檢舉人，得以書面向行為人於行為發生時所屬之學校（以下簡稱事件管轄學校）申請調查或檢舉。但行為人現為或曾為學校校長者，應向行為發生時之學校所屬主管機關（以下簡稱事件管轄機關）申請調查或檢舉。
2   前項事件管轄學校，於行為人在兼任學校所為者，為該兼任學校。
3   事件管轄學校依國民教育法、高級中等教育法、私立學校法或其他教育法令規定合併者，由合併後存續或新設之學校為事件管轄學校。事件管轄學校已停辦者，由行為人現所屬學校為事件管轄學校，但行為人無現所屬學校者，由行為時學校之主管機關為事件管轄機關。
4   本準則中華民國一百十三年三月八日修正生效前，依修正前第十條第一項但書規定，已由學校首長現職學校且非行為發生時之學校所屬主管機關調查處理，尚未依本法第三十六條第三項規定終結者，應於本準則修正生效後，依第一項及第十六條第一項規定辦理。

來源條目欄位（正規化資料）：
- id：article-11
- articleNumber：11
- displayNumber：第 11 條
- title：None
- structureId：chapter-4
- metadata：{"source": "全國法規資料庫 校園性別事件防治準則（PDF：法規-校園性別事件防治準則.pdf）", "lastModified": "2024-03-06"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   校園性別事件之被害人、其法定代理人或實際照顧者（以下簡稱申請人）、檢舉人，得以書面向行為人於行為發生時所屬之學校（以下簡稱事件管轄學校）申請調查或檢舉。但行為人現為或曾為學校校長者，應向行為發生時之學校所屬主管機關（以下簡稱事件管轄機關）申請調查或檢舉。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   前項事件管轄學校，於行為人在兼任學校所為者，為該兼任學校。"
  },
  {
    "type": "paragraph",
    "number": "3",
    "text": "3   事件管轄學校依國民教育法、高級中等教育法、私立學校法或其他教育法令規定合併者，由合併後存續或新設之學校為事件管轄學校。事件管轄學校已停辦者，由行為人現所屬學校為事件管轄學校，但行為人無現所屬學校者，由行為時學校之主管機關為事件管轄機關。"
  },
  {
    "type": "paragraph",
    "number": "4",
    "text": "4   本準則中華民國一百十三年三月八日修正生效前，依修正前第十條第一項但書規定，已由學校首長現職學校且非行為發生時之學校所屬主管機關調查處理，尚未依本法第三十六條第三項規定終結者，應於本準則修正生效後，依第一項及第十六條第一項規定辦理。"
  }
]
```

## U09-A12｜第 12 條

1   事件管轄學校與行為人現所屬學校不同者，應以書面通知行為人現所屬學校派代表參與調查，被通知之學校不得拒絕。
2   前項事件管轄學校完成調查屬實者，應將調查報告及處理建議移送行為人現所屬學校依第三十一條規定處理。

來源條目欄位（正規化資料）：
- id：article-12
- articleNumber：12
- displayNumber：第 12 條
- title：None
- structureId：chapter-4
- metadata：{"source": "全國法規資料庫 校園性別事件防治準則（PDF：法規-校園性別事件防治準則.pdf）", "lastModified": "2024-03-06"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   事件管轄學校與行為人現所屬學校不同者，應以書面通知行為人現所屬學校派代表參與調查，被通知之學校不得拒絕。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   前項事件管轄學校完成調查屬實者，應將調查報告及處理建議移送行為人現所屬學校依第三十一條規定處理。"
  }
]
```

## U09-A13｜第 13 條

1   第十一條第二項之情形，事件管轄學校應以書面通知行為人現所屬專任學校派代表參與調查，被通知之學校不得拒絕。
2   前項事件管轄學校完成調查屬實者，應將調查報告及處理建議移送行為人現所屬專任學校依第三十一條規定處理。

來源條目欄位（正規化資料）：
- id：article-13
- articleNumber：13
- displayNumber：第 13 條
- title：None
- structureId：chapter-4
- metadata：{"source": "全國法規資料庫 校園性別事件防治準則（PDF：法規-校園性別事件防治準則.pdf）", "lastModified": "2024-03-06"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   第十一條第二項之情形，事件管轄學校應以書面通知行為人現所屬專任學校派代表參與調查，被通知之學校不得拒絕。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   前項事件管轄學校完成調查屬實者，應將調查報告及處理建議移送行為人現所屬專任學校依第三十一條規定處理。"
  }
]
```

## U09-A14｜第 14 條

1   行為人於行為發生時，同時具有校長、教師、職員、工友或學生二種以上不同身分者，以其與被害人互動時之身分，定其受調查之身分及事件管轄學校或機關。
2   無法判斷行為人於行為發生時之身分，或於學制轉銜期間，尚未確定行為人就讀學校者，以受理申請調查或檢舉之學校為事件管轄學校，相關學校應派代表參與調查。但於申請調查或檢舉時，行為人及被害人已具學生身分，由行為人所屬學校為事件管轄學校。

來源條目欄位（正規化資料）：
- id：article-14
- articleNumber：14
- displayNumber：第 14 條
- title：None
- structureId：chapter-4
- metadata：{"source": "全國法規資料庫 校園性別事件防治準則（PDF：法規-校園性別事件防治準則.pdf）", "lastModified": "2024-03-06"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   行為人於行為發生時，同時具有校長、教師、職員、工友或學生二種以上不同身分者，以其與被害人互動時之身分，定其受調查之身分及事件管轄學校或機關。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   無法判斷行為人於行為發生時之身分，或於學制轉銜期間，尚未確定行為人就讀學校者，以受理申請調查或檢舉之學校為事件管轄學校，相關學校應派代表參與調查。但於申請調查或檢舉時，行為人及被害人已具學生身分，由行為人所屬學校為事件管轄學校。"
  }
]
```

## U09-A15｜第 15 條

行為人二人以上，分屬不同學校者，以先受理申請調查或檢舉之行為人所屬學校為事件管轄學校，相關學校應派代表參與調查。

來源條目欄位（正規化資料）：
- id：article-15
- articleNumber：15
- displayNumber：第 15 條
- title：None
- structureId：chapter-4
- metadata：{"source": "全國法規資料庫 校園性別事件防治準則（PDF：法規-校園性別事件防治準則.pdf）", "lastModified": "2024-03-06"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": null,
    "text": "行為人二人以上，分屬不同學校者，以先受理申請調查或檢舉之行為人所屬學校為事件管轄學校，相關學校應派代表參與調查。"
  }
]
```

## U09-A16｜第 16 條

1   接獲申請調查或檢舉之學校或主管機關無管轄權者，應將該案件於七個工作日內移送其他有管轄權者，並通知當事人。
2   學制轉銜期間申請調查或檢舉之事件，管轄權有爭議時，由其共同上級機關決定之，無共同上級機關時，由各該上級機關協議定之。

來源條目欄位（正規化資料）：
- id：article-16
- articleNumber：16
- displayNumber：第 16 條
- title：None
- structureId：chapter-4
- metadata：{"source": "全國法規資料庫 校園性別事件防治準則（PDF：法規-校園性別事件防治準則.pdf）", "lastModified": "2024-03-06"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   接獲申請調查或檢舉之學校或主管機關無管轄權者，應將該案件於七個工作日內移送其他有管轄權者，並通知當事人。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   學制轉銜期間申請調查或檢舉之事件，管轄權有爭議時，由其共同上級機關決定之，無共同上級機關時，由各該上級機關協議定之。"
  }
]
```

## U09-A17｜第 17 條

1   依本法第二十二條第一項規定為通報時，除有調查必要、基於公共安全考量或法規另有特別規定者外，對於當事人及檢舉人之姓名或其他足以辨識其身分之資料，應予以保密。
2   校長、教職員工偽造、變造、湮滅或隱匿他人所犯有終身或議決一年至四年不得聘任、任用、進用或運用之校園性侵害以外校園性別事件之證據，必要時應依相關法規予以解聘、免職、終止契約關係或終止運用關係；他人為學生，所犯校園性騷擾或性霸凌事件情節相當者，準用之。
3   前項校長、教職員工適用教師法、教育人員任用條例、公務人員相關法律或陸海空軍相關法律者，其解聘、停聘、免職、撤職、停職或退伍，依各該法律規定辦理；其未解聘、免職、撤職或退伍者，應調離學校現職。

來源條目欄位（正規化資料）：
- id：article-17
- articleNumber：17
- displayNumber：第 17 條
- title：None
- structureId：chapter-4
- metadata：{"source": "全國法規資料庫 校園性別事件防治準則（PDF：法規-校園性別事件防治準則.pdf）", "lastModified": "2024-03-06"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   依本法第二十二條第一項規定為通報時，除有調查必要、基於公共安全考量或法規另有特別規定者外，對於當事人及檢舉人之姓名或其他足以辨識其身分之資料，應予以保密。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   校長、教職員工偽造、變造、湮滅或隱匿他人所犯有終身或議決一年至四年不得聘任、任用、進用或運用之校園性侵害以外校園性別事件之證據，必要時應依相關法規予以解聘、免職、終止契約關係或終止運用關係；他人為學生，所犯校園性騷擾或性霸凌事件情節相當者，準用之。"
  },
  {
    "type": "paragraph",
    "number": "3",
    "text": "3   前項校長、教職員工適用教師法、教育人員任用條例、公務人員相關法律或陸海空軍相關法律者，其解聘、停聘、免職、撤職、停職或退伍，依各該法律規定辦理；其未解聘、免職、撤職或退伍者，應調離學校現職。"
  }
]
```

## U09-A18｜第 18 條

1   校園性別事件之申請人或檢舉人得以書面、言詞或電子郵件申請調查或檢舉；其以言詞或電子郵件為之者，受理申請調查或檢舉之事件管轄學校或機關應作成紀錄，經向申請人或檢舉人朗讀或使閱覽，確認其內容無誤後，由其簽名或蓋章。
2   前項書面或言詞、電子郵件作成之紀錄，應載明下列事項：
一、申請人或檢舉人姓名、身分證明文件字號、服務或就學之單位及職稱、住居所、聯絡電話及申請調查日期。
二、申請人申請調查者，應載明被害人之出生年月日。
三、申請人委任代理人代為申請調查者，應檢附委任書，並載明其姓名、身分證明文件字號、住居所、聯絡電話。
四、申請調查或檢舉之事實內容。如有相關證據，亦應記載或附卷。
3   學校或主管機關知悉疑似校園性別事件有下列情形，應由所設性平會評估該事件對學生受教權及校園安全之影響，經會議決議以檢舉案形式啟動調查程序，以釐清事實，採取必要之措施維護學生之權益與校園安全：
一、二人以上被害人。
二、二人以上行為人。
三、行為人為校長或教職員工。
四、涉及校園安全議題。
五、其他經性平會認有以檢舉案形式啟動調查之必要者。

來源條目欄位（正規化資料）：
- id：article-18
- articleNumber：18
- displayNumber：第 18 條
- title：None
- structureId：chapter-4
- metadata：{"source": "全國法規資料庫 校園性別事件防治準則（PDF：法規-校園性別事件防治準則.pdf）", "lastModified": "2024-03-06"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   校園性別事件之申請人或檢舉人得以書面、言詞或電子郵件申請調查或檢舉；其以言詞或電子郵件為之者，受理申請調查或檢舉之事件管轄學校或機關應作成紀錄，經向申請人或檢舉人朗讀或使閱覽，確認其內容無誤後，由其簽名或蓋章。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   前項書面或言詞、電子郵件作成之紀錄，應載明下列事項："
  },
  {
    "type": "item",
    "number": "一",
    "text": "一、申請人或檢舉人姓名、身分證明文件字號、服務或就學之單位及職稱、住居所、聯絡電話及申請調查日期。"
  },
  {
    "type": "item",
    "number": "二",
    "text": "二、申請人申請調查者，應載明被害人之出生年月日。"
  },
  {
    "type": "item",
    "number": "三",
    "text": "三、申請人委任代理人代為申請調查者，應檢附委任書，並載明其姓名、身分證明文件字號、住居所、聯絡電話。"
  },
  {
    "type": "item",
    "number": "四",
    "text": "四、申請調查或檢舉之事實內容。如有相關證據，亦應記載或附卷。"
  },
  {
    "type": "paragraph",
    "number": "3",
    "text": "3   學校或主管機關知悉疑似校園性別事件有下列情形，應由所設性平會評估該事件對學生受教權及校園安全之影響，經會議決議以檢舉案形式啟動調查程序，以釐清事實，採取必要之措施維護學生之權益與校園安全："
  },
  {
    "type": "item",
    "number": "一",
    "text": "一、二人以上被害人。"
  },
  {
    "type": "item",
    "number": "二",
    "text": "二、二人以上行為人。"
  },
  {
    "type": "item",
    "number": "三",
    "text": "三、行為人為校長或教職員工。"
  },
  {
    "type": "item",
    "number": "四",
    "text": "四、涉及校園安全議題。"
  },
  {
    "type": "item",
    "number": "五",
    "text": "五、其他經性平會認有以檢舉案形式啟動調查之必要者。"
  }
]
```

## U09-A19｜第 19 條

1   校園性別事件管轄學校或機關接獲申請調查或檢舉時，其收件單位如下：
一、專科以上學校：學生事務處或學校指定之專責單位。
二、高級中等以下學校：學生事務處或教導處。
三、主管機關：負責性平會之業務單位。
2   前項收件單位收件後，除有本法第三十二條第二項所定事由外，應於三日內將申請人或檢舉人所提事證資料交付性平會調查處理。
3   前項本法第三十二條第二項所定事由，必要時得由性平會指派委員三人以上組成小組認定之。學校並得於防治規定中明定前述小組之工作權責範圍。

來源條目欄位（正規化資料）：
- id：article-19
- articleNumber：19
- displayNumber：第 19 條
- title：None
- structureId：chapter-4
- metadata：{"source": "全國法規資料庫 校園性別事件防治準則（PDF：法規-校園性別事件防治準則.pdf）", "lastModified": "2024-03-06"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   校園性別事件管轄學校或機關接獲申請調查或檢舉時，其收件單位如下："
  },
  {
    "type": "item",
    "number": "一",
    "text": "一、專科以上學校：學生事務處或學校指定之專責單位。"
  },
  {
    "type": "item",
    "number": "二",
    "text": "二、高級中等以下學校：學生事務處或教導處。"
  },
  {
    "type": "item",
    "number": "三",
    "text": "三、主管機關：負責性平會之業務單位。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   前項收件單位收件後，除有本法第三十二條第二項所定事由外，應於三日內將申請人或檢舉人所提事證資料交付性平會調查處理。"
  },
  {
    "type": "paragraph",
    "number": "3",
    "text": "3   前項本法第三十二條第二項所定事由，必要時得由性平會指派委員三人以上組成小組認定之。學校並得於防治規定中明定前述小組之工作權責範圍。"
  }
]
```

## U09-A20｜第 20 條

1   經媒體報導之校園性別事件，應視同檢舉，學校或主管機關應主動將事件交由所設之性平會調查處理。疑似被害人不願配合調查時，學校或主管機關仍應提供必要之輔導或協助。
2   學校處理霸凌事件，發現有疑似校園性別事件者，視同檢舉，由學校防制霸凌因應小組移請性平會依前條規定辦理。

來源條目欄位（正規化資料）：
- id：article-20
- articleNumber：20
- displayNumber：第 20 條
- title：None
- structureId：chapter-4
- metadata：{"source": "全國法規資料庫 校園性別事件防治準則（PDF：法規-校園性別事件防治準則.pdf）", "lastModified": "2024-03-06"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   經媒體報導之校園性別事件，應視同檢舉，學校或主管機關應主動將事件交由所設之性平會調查處理。疑似被害人不願配合調查時，學校或主管機關仍應提供必要之輔導或協助。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   學校處理霸凌事件，發現有疑似校園性別事件者，視同檢舉，由學校防制霸凌因應小組移請性平會依前條規定辦理。"
  }
]
```

## U09-A21｜第 21 條

1   事件管轄學校或機關應於接獲申請調查或檢舉後二十日內，以書面通知申請人、被害人或檢舉人是否受理。不受理之書面通知應依本法第三十二條第三項規定敘明理由，並告知申請人、被害人或檢舉人申復之期限及受理單位。
2   申請人、被害人或檢舉人於前項之期限內，未收到通知或接獲不受理通知之次日起二十日內，得以書面具明理由，向事件管轄學校或機關提出申復；其以言詞為之者，事件管轄學校或機關應作成紀錄，經向申請人、被害人或檢舉人朗讀或使閱覽，確認其內容無誤後，由其簽名或蓋章。
3   前項不受理之申復以一次為限。
4   事件管轄學校或機關接獲申復後，應將申請調查或檢舉案交性平會重新討論受理事宜，並於二十日內以書面通知申復人申復結果。申復有理由者，性平會應依法調查處理。

來源條目欄位（正規化資料）：
- id：article-21
- articleNumber：21
- displayNumber：第 21 條
- title：None
- structureId：chapter-4
- metadata：{"source": "全國法規資料庫 校園性別事件防治準則（PDF：法規-校園性別事件防治準則.pdf）", "lastModified": "2024-03-06"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   事件管轄學校或機關應於接獲申請調查或檢舉後二十日內，以書面通知申請人、被害人或檢舉人是否受理。不受理之書面通知應依本法第三十二條第三項規定敘明理由，並告知申請人、被害人或檢舉人申復之期限及受理單位。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   申請人、被害人或檢舉人於前項之期限內，未收到通知或接獲不受理通知之次日起二十日內，得以書面具明理由，向事件管轄學校或機關提出申復；其以言詞為之者，事件管轄學校或機關應作成紀錄，經向申請人、被害人或檢舉人朗讀或使閱覽，確認其內容無誤後，由其簽名或蓋章。"
  },
  {
    "type": "paragraph",
    "number": "3",
    "text": "3   前項不受理之申復以一次為限。"
  },
  {
    "type": "paragraph",
    "number": "4",
    "text": "4   事件管轄學校或機關接獲申復後，應將申請調查或檢舉案交性平會重新討論受理事宜，並於二十日內以書面通知申復人申復結果。申復有理由者，性平會應依法調查處理。"
  }
]
```

## U09-A22｜第 22 條

1   事件管轄學校或機關之性平會處理校園性別事件時，得成立調查小組調查之。調查小組以三人或五人為原則，其成員之組成，依本法第三十三條第三項及第四項規定。
2   有下列情形之一者，不得擔任前項調查小組成員：
一、違反刑法妨害性自主罪章、妨害性隱私及不實性影像罪章，經緩起訴處分確定或有罪判決確定。
二、違反本法、性別平等工作法、性騷擾防治法、跟蹤騷擾防制法、兒童及少年性剝削防制條例或其他性別平等相關法規，經依法調查或有關機關查證屬實。
3   校園性別事件當事人之輔導人員、事件管轄學校或機關性平會會務權責主管及承辦人員，應迴避該事件之調查工作；參與校園性別事件之調查及處理人員，亦應迴避對該當事人之輔導工作。
4   學校或主管機關針對擔任調查小組之成員，應予公差（假）登記；其交通費或相關費用，由事件管轄學校或機關，及派員參與調查之學校支應。

來源條目欄位（正規化資料）：
- id：article-22
- articleNumber：22
- displayNumber：第 22 條
- title：None
- structureId：chapter-4
- metadata：{"source": "全國法規資料庫 校園性別事件防治準則（PDF：法規-校園性別事件防治準則.pdf）", "lastModified": "2024-03-06"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   事件管轄學校或機關之性平會處理校園性別事件時，得成立調查小組調查之。調查小組以三人或五人為原則，其成員之組成，依本法第三十三條第三項及第四項規定。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   有下列情形之一者，不得擔任前項調查小組成員："
  },
  {
    "type": "item",
    "number": "一",
    "text": "一、違反刑法妨害性自主罪章、妨害性隱私及不實性影像罪章，經緩起訴處分確定或有罪判決確定。"
  },
  {
    "type": "item",
    "number": "二",
    "text": "二、違反本法、性別平等工作法、性騷擾防治法、跟蹤騷擾防制法、兒童及少年性剝削防制條例或其他性別平等相關法規，經依法調查或有關機關查證屬實。"
  },
  {
    "type": "paragraph",
    "number": "3",
    "text": "3   校園性別事件當事人之輔導人員、事件管轄學校或機關性平會會務權責主管及承辦人員，應迴避該事件之調查工作；參與校園性別事件之調查及處理人員，亦應迴避對該當事人之輔導工作。"
  },
  {
    "type": "paragraph",
    "number": "4",
    "text": "4   學校或主管機關針對擔任調查小組之成員，應予公差（假）登記；其交通費或相關費用，由事件管轄學校或機關，及派員參與調查之學校支應。"
  }
]
```

## U09-A23｜第 23 條

1   本法第三十三條第三項所定具校園性別事件調查專業素養之專家學者，應符合下列資格之一：
一、持有中央或直轄市、縣（市）主管機關校園性別事件調查知能高階培訓結業證書，且經中央或直轄市、縣（市）主管機關所設性平會核可並納入調查專業人才庫者。
二、曾調查處理校園性別事件有具體績效，且經中央或直轄市、縣（市）主管機關所設性平會核可並納入調查專業人才庫者。
2   前項第一款之校園性別事件調查知能培訓，應由中央或直轄市、縣（市）主管機關所設性平會負責規劃，其內容應包括下列課程：
一、性侵害、性騷擾、性霸凌或校長及教職員工違反與性或性別有關之專業倫理行為基本概念及相關法規。
二、性別平等意識。
三、校園性別事件調查知能。
四、校園性別事件處理程序及行政協調。
五、校園性別事件之懲處及救濟。
六、其他由性平會建議之課程。
3   中央或直轄市、縣（市）主管機關應定期辦理校園性別事件調查專業人員培訓，建立專業人才庫，並定期更新維護專業人才庫之資訊，提供各級學校或主管機關為延聘之參考。
4   前項調查專業人員，經檢舉有違反客觀、公正、專業之原則，或有其他不適任情形，致其認定事實顯有偏頗，並由中央或直轄市、縣（市）主管機關所設性平會審查確認者，應自調查專業人才庫移除之。
5   本準則中華民國一百十三年三月八日修正生效前，經中央或直轄市、縣（市）主管機關所設性平會核可並納入調查專業人才庫者，自本準則修正生效之日起，當然納入原調查專業人才庫。

來源條目欄位（正規化資料）：
- id：article-23
- articleNumber：23
- displayNumber：第 23 條
- title：None
- structureId：chapter-4
- metadata：{"source": "全國法規資料庫 校園性別事件防治準則（PDF：法規-校園性別事件防治準則.pdf）", "lastModified": "2024-03-06"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   本法第三十三條第三項所定具校園性別事件調查專業素養之專家學者，應符合下列資格之一："
  },
  {
    "type": "item",
    "number": "一",
    "text": "一、持有中央或直轄市、縣（市）主管機關校園性別事件調查知能高階培訓結業證書，且經中央或直轄市、縣（市）主管機關所設性平會核可並納入調查專業人才庫者。"
  },
  {
    "type": "item",
    "number": "二",
    "text": "二、曾調查處理校園性別事件有具體績效，且經中央或直轄市、縣（市）主管機關所設性平會核可並納入調查專業人才庫者。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   前項第一款之校園性別事件調查知能培訓，應由中央或直轄市、縣（市）主管機關所設性平會負責規劃，其內容應包括下列課程："
  },
  {
    "type": "item",
    "number": "一",
    "text": "一、性侵害、性騷擾、性霸凌或校長及教職員工違反與性或性別有關之專業倫理行為基本概念及相關法規。"
  },
  {
    "type": "item",
    "number": "二",
    "text": "二、性別平等意識。"
  },
  {
    "type": "item",
    "number": "三",
    "text": "三、校園性別事件調查知能。"
  },
  {
    "type": "item",
    "number": "四",
    "text": "四、校園性別事件處理程序及行政協調。"
  },
  {
    "type": "item",
    "number": "五",
    "text": "五、校園性別事件之懲處及救濟。"
  },
  {
    "type": "item",
    "number": "六",
    "text": "六、其他由性平會建議之課程。"
  },
  {
    "type": "paragraph",
    "number": "3",
    "text": "3   中央或直轄市、縣（市）主管機關應定期辦理校園性別事件調查專業人員培訓，建立專業人才庫，並定期更新維護專業人才庫之資訊，提供各級學校或主管機關為延聘之參考。"
  },
  {
    "type": "paragraph",
    "number": "4",
    "text": "4   前項調查專業人員，經檢舉有違反客觀、公正、專業之原則，或有其他不適任情形，致其認定事實顯有偏頗，並由中央或直轄市、縣（市）主管機關所設性平會審查確認者，應自調查專業人才庫移除之。"
  },
  {
    "type": "paragraph",
    "number": "5",
    "text": "5   本準則中華民國一百十三年三月八日修正生效前，經中央或直轄市、縣（市）主管機關所設性平會核可並納入調查專業人才庫者，自本準則修正生效之日起，當然納入原調查專業人才庫。"
  }
]
```

## U09-A24｜第 24 條

事件管轄學校或機關調查處理校園性別事件時，應依下列方式辦理：
一、行為人應親自出席接受調查；當事人為未成年者，接受調查時得由法定代理人或實際照顧者陪同。
二、當事人持有各級主管機關核發之身心障礙證明或有效特殊教育學生鑑定證明者，調查小組成員應有具備特殊教育專業者。
三、行為人與被害人、檢舉人或受邀協助調查之人有權力不對等之情形者，應避免其對質。
四、就行為人、被害人、檢舉人或受邀協助調查之人之姓名及其他足以辨識身分之資料，應予保密。但有調查之必要或基於公共安全考量者，不在此限。
五、依本法第三十三條第五項規定以書面通知當事人、相關人員或單位配合調查及提供資料時，應記載調查目的、時間、地點及不到場所生之效果。
六、前款通知應載明當事人不得私下聯繫或運用網際網路、通訊軟體或其他管道散布事件之資訊。
七、事件管轄學校或機關所屬人員不得以任何名義對案情進行瞭解或調查，且不得要求當事人提交自述或切結文件。
八、基於調查之必要，得於不違反保密義務之範圍內另作成書面資料，交由行為人、被害人或受邀協助調查之人閱覽或告以要旨。
九、申請人撤回申請調查時，為釐清相關法律責任，事件管轄學校或機關得經所設之性平會決議，或經行為人請求，繼續調查處理。學校所屬主管機關認情節重大者，應命事件管轄學校繼續調查處理。
十、當事人申請閱覽、抄寫、複印或攝影有關資料或卷宗，應依行政程序法規定辦理。
十一、當事人調查訪談過程紀錄，得以錄音輔助，必要時得以錄影輔助；訪談紀錄應向當事人朗讀或使閱覽，確認其內容無誤後，由其簽名或蓋章。

來源條目欄位（正規化資料）：
- id：article-24
- articleNumber：24
- displayNumber：第 24 條
- title：None
- structureId：chapter-4
- metadata：{"source": "全國法規資料庫 校園性別事件防治準則（PDF：法規-校園性別事件防治準則.pdf）", "lastModified": "2024-03-06"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": null,
    "text": "事件管轄學校或機關調查處理校園性別事件時，應依下列方式辦理："
  },
  {
    "type": "item",
    "number": "一",
    "text": "一、行為人應親自出席接受調查；當事人為未成年者，接受調查時得由法定代理人或實際照顧者陪同。"
  },
  {
    "type": "item",
    "number": "二",
    "text": "二、當事人持有各級主管機關核發之身心障礙證明或有效特殊教育學生鑑定證明者，調查小組成員應有具備特殊教育專業者。"
  },
  {
    "type": "item",
    "number": "三",
    "text": "三、行為人與被害人、檢舉人或受邀協助調查之人有權力不對等之情形者，應避免其對質。"
  },
  {
    "type": "item",
    "number": "四",
    "text": "四、就行為人、被害人、檢舉人或受邀協助調查之人之姓名及其他足以辨識身分之資料，應予保密。但有調查之必要或基於公共安全考量者，不在此限。"
  },
  {
    "type": "item",
    "number": "五",
    "text": "五、依本法第三十三條第五項規定以書面通知當事人、相關人員或單位配合調查及提供資料時，應記載調查目的、時間、地點及不到場所生之效果。"
  },
  {
    "type": "item",
    "number": "六",
    "text": "六、前款通知應載明當事人不得私下聯繫或運用網際網路、通訊軟體或其他管道散布事件之資訊。"
  },
  {
    "type": "item",
    "number": "七",
    "text": "七、事件管轄學校或機關所屬人員不得以任何名義對案情進行瞭解或調查，且不得要求當事人提交自述或切結文件。"
  },
  {
    "type": "item",
    "number": "八",
    "text": "八、基於調查之必要，得於不違反保密義務之範圍內另作成書面資料，交由行為人、被害人或受邀協助調查之人閱覽或告以要旨。"
  },
  {
    "type": "item",
    "number": "九",
    "text": "九、申請人撤回申請調查時，為釐清相關法律責任，事件管轄學校或機關得經所設之性平會決議，或經行為人請求，繼續調查處理。學校所屬主管機關認情節重大者，應命事件管轄學校繼續調查處理。"
  },
  {
    "type": "item",
    "number": "十",
    "text": "十、當事人申請閱覽、抄寫、複印或攝影有關資料或卷宗，應依行政程序法規定辦理。"
  },
  {
    "type": "item",
    "number": "十一",
    "text": "十一、當事人調查訪談過程紀錄，得以錄音輔助，必要時得以錄影輔助；訪談紀錄應向當事人朗讀或使閱覽，確認其內容無誤後，由其簽名或蓋章。"
  }
]
```

## U09-A25｜第 25 條

1   依前條第四款規定負有保密義務者，包括參與處理校園性別事件之所有人員。
2   依前項規定負保密義務者洩密時，應依刑法或其他相關法規處罰。
3   學校或主管機關就記載有當事人、檢舉人、證人姓名之原始文書應予封存，不得供閱覽或提供予偵查、審判機關以外之人。但法律另有規定者，不在此限。
4   除原始文書外，調查處理校園性別事件人員對外所另行製作之文書，應將當事人、檢舉人、證人之真實姓名及其他足以辨識身分之資料刪除，並以代號為之。

來源條目欄位（正規化資料）：
- id：article-25
- articleNumber：25
- displayNumber：第 25 條
- title：None
- structureId：chapter-4
- metadata：{"source": "全國法規資料庫 校園性別事件防治準則（PDF：法規-校園性別事件防治準則.pdf）", "lastModified": "2024-03-06"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   依前條第四款規定負有保密義務者，包括參與處理校園性別事件之所有人員。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   依前項規定負保密義務者洩密時，應依刑法或其他相關法規處罰。"
  },
  {
    "type": "paragraph",
    "number": "3",
    "text": "3   學校或主管機關就記載有當事人、檢舉人、證人姓名之原始文書應予封存，不得供閱覽或提供予偵查、審判機關以外之人。但法律另有規定者，不在此限。"
  },
  {
    "type": "paragraph",
    "number": "4",
    "text": "4   除原始文書外，調查處理校園性別事件人員對外所另行製作之文書，應將當事人、檢舉人、證人之真實姓名及其他足以辨識身分之資料刪除，並以代號為之。"
  }
]
```

## U09-A26｜第 26 條

1   為保障校園性別事件當事人之受教權或工作權，事件管轄學校或機關於必要時得依本法第二十四條規定，採取下列處置，並報主管機關備查：
一、彈性處理當事人之出缺勤紀錄或成績考核，並積極協助其課業或職務，得不受請假、教師及學生成績考核相關規定之限制。
二、尊重被害人之意願，減低當事人雙方互動之機會，並得依被害人之申請或由性平會評估該事件對學生受教權及校園安全之影響，中止當事人雙方執行教學、指導、訓練、評鑑、管理、輔導學生或提供學生工作機會之關係，或命行為人迴避。
三、避免報復情事。
四、預防、減低行為人再度加害之可能。
五、其他性平會認為必要之處置。
2   當事人非事件管轄學校之人員時，應通知當事人所屬學校，依前項規定處理。
3   前二項必要之處置，應經性平會決議通過後執行。

來源條目欄位（正規化資料）：
- id：article-26
- articleNumber：26
- displayNumber：第 26 條
- title：None
- structureId：chapter-4
- metadata：{"source": "全國法規資料庫 校園性別事件防治準則（PDF：法規-校園性別事件防治準則.pdf）", "lastModified": "2024-03-06"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   為保障校園性別事件當事人之受教權或工作權，事件管轄學校或機關於必要時得依本法第二十四條規定，採取下列處置，並報主管機關備查："
  },
  {
    "type": "item",
    "number": "一",
    "text": "一、彈性處理當事人之出缺勤紀錄或成績考核，並積極協助其課業或職務，得不受請假、教師及學生成績考核相關規定之限制。"
  },
  {
    "type": "item",
    "number": "二",
    "text": "二、尊重被害人之意願，減低當事人雙方互動之機會，並得依被害人之申請或由性平會評估該事件對學生受教權及校園安全之影響，中止當事人雙方執行教學、指導、訓練、評鑑、管理、輔導學生或提供學生工作機會之關係，或命行為人迴避。"
  },
  {
    "type": "item",
    "number": "三",
    "text": "三、避免報復情事。"
  },
  {
    "type": "item",
    "number": "四",
    "text": "四、預防、減低行為人再度加害之可能。"
  },
  {
    "type": "item",
    "number": "五",
    "text": "五、其他性平會認為必要之處置。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   當事人非事件管轄學校之人員時，應通知當事人所屬學校，依前項規定處理。"
  },
  {
    "type": "paragraph",
    "number": "3",
    "text": "3   前二項必要之處置，應經性平會決議通過後執行。"
  }
]
```

## U09-A27｜第 27 條

1   事件管轄學校或機關應依本法第二十五條第一項規定，視當事人之身心狀況，主動轉介至各相關機構，以提供必要之協助。但事件管轄學校或機關就該事件仍應依本法為調查處理。
2   當事人非事件管轄學校之人員時，應通知當事人所屬學校，依前項規定提供必要之協助。

來源條目欄位（正規化資料）：
- id：article-27
- articleNumber：27
- displayNumber：第 27 條
- title：None
- structureId：chapter-4
- metadata：{"source": "全國法規資料庫 校園性別事件防治準則（PDF：法規-校園性別事件防治準則.pdf）", "lastModified": "2024-03-06"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   事件管轄學校或機關應依本法第二十五條第一項規定，視當事人之身心狀況，主動轉介至各相關機構，以提供必要之協助。但事件管轄學校或機關就該事件仍應依本法為調查處理。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   當事人非事件管轄學校之人員時，應通知當事人所屬學校，依前項規定提供必要之協助。"
  }
]
```

## U09-A28｜第 28 條

1   事件管轄學校或機關依本法第二十五條第一項規定，於必要時，應對當事人提供下列適當協助：
一、心理諮商與輔導。
二、法律協助。
三、課業協助。
四、經濟協助。
五、社會福利資源轉介服務。
六、其他性平會認為必要之保護措施或協助。
2   當事人非事件管轄學校之人員時，應通知當事人所屬學校，依前項規定提供適當協助。
3   前二項協助得委請醫師、臨床心理師、諮商心理師、社會工作師或律師等專業人員為之，其所需費用，學校或主管機關應編列預算支應之。

來源條目欄位（正規化資料）：
- id：article-28
- articleNumber：28
- displayNumber：第 28 條
- title：None
- structureId：chapter-4
- metadata：{"source": "全國法規資料庫 校園性別事件防治準則（PDF：法規-校園性別事件防治準則.pdf）", "lastModified": "2024-03-06"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   事件管轄學校或機關依本法第二十五條第一項規定，於必要時，應對當事人提供下列適當協助："
  },
  {
    "type": "item",
    "number": "一",
    "text": "一、心理諮商與輔導。"
  },
  {
    "type": "item",
    "number": "二",
    "text": "二、法律協助。"
  },
  {
    "type": "item",
    "number": "三",
    "text": "三、課業協助。"
  },
  {
    "type": "item",
    "number": "四",
    "text": "四、經濟協助。"
  },
  {
    "type": "item",
    "number": "五",
    "text": "五、社會福利資源轉介服務。"
  },
  {
    "type": "item",
    "number": "六",
    "text": "六、其他性平會認為必要之保護措施或協助。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   當事人非事件管轄學校之人員時，應通知當事人所屬學校，依前項規定提供適當協助。"
  },
  {
    "type": "paragraph",
    "number": "3",
    "text": "3   前二項協助得委請醫師、臨床心理師、諮商心理師、社會工作師或律師等專業人員為之，其所需費用，學校或主管機關應編列預算支應之。"
  }
]
```

## U09-A29｜第 29 條

1   性平會之調查處理，不受該事件司法程序是否進行及處理結果之影響。
2   前項之調查程序，不因行為人喪失原身分而中止。

來源條目欄位（正規化資料）：
- id：article-29
- articleNumber：29
- displayNumber：第 29 條
- title：None
- structureId：chapter-4
- metadata：{"source": "全國法規資料庫 校園性別事件防治準則（PDF：法規-校園性別事件防治準則.pdf）", "lastModified": "2024-03-06"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   性平會之調查處理，不受該事件司法程序是否進行及處理結果之影響。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   前項之調查程序，不因行為人喪失原身分而中止。"
  }
]
```

## U09-A30｜第 30 條

1   基於尊重專業判斷及避免重複詢問原則，事件管轄學校或機關對於與校園性別事件有關之事實認定，應依據性平會之調查報告。
2   性平會召開會議審議調查報告認定校園性別事件屬實，依其事實認定對學校或主管機關提出改變身分之處理建議者，由學校或主管機關檢附經性平會審議通過之調查報告，通知行為人限期提出書面陳述意見。
3   前項行為人不於期限內提出書面陳述意見者，視為放棄陳述之機會；有書面陳述意見者，性平會應再次召開會議審酌其書面陳述意見，除發現調查程序有重大瑕疵或有足以影響原調查認定之新事實、新證據情形外，不得重新調查。
4   學校或主管機關決定議處之權責單位，於審議議處時，除有本法第三十七條第三項所定之情形外，不得要求性平會重新調查，亦不得自行調查。
5   前項審議議處依相關法規應給予行為人陳述答辯意見時，應檢附經性平會審議通過之調查報告。
6   第四項議處決定前，權責單位應通知被害人、其法定代理人或實際照顧者限期以書面或言詞提出陳述意見；其以言詞為之者，權責單位應作成紀錄，經向被害人、其法定代理人或實際照顧者朗讀或使閱覽，確認其內容無誤後，由其簽名或蓋章；未於期限內提出書面陳述意見者，視為放棄陳述之機會；有書面陳述意見者，決定議處之權責單位應審酌其書面陳述意見。

來源條目欄位（正規化資料）：
- id：article-30
- articleNumber：30
- displayNumber：第 30 條
- title：None
- structureId：chapter-4
- metadata：{"source": "全國法規資料庫 校園性別事件防治準則（PDF：法規-校園性別事件防治準則.pdf）", "lastModified": "2024-03-06"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   基於尊重專業判斷及避免重複詢問原則，事件管轄學校或機關對於與校園性別事件有關之事實認定，應依據性平會之調查報告。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   性平會召開會議審議調查報告認定校園性別事件屬實，依其事實認定對學校或主管機關提出改變身分之處理建議者，由學校或主管機關檢附經性平會審議通過之調查報告，通知行為人限期提出書面陳述意見。"
  },
  {
    "type": "paragraph",
    "number": "3",
    "text": "3   前項行為人不於期限內提出書面陳述意見者，視為放棄陳述之機會；有書面陳述意見者，性平會應再次召開會議審酌其書面陳述意見，除發現調查程序有重大瑕疵或有足以影響原調查認定之新事實、新證據情形外，不得重新調查。"
  },
  {
    "type": "paragraph",
    "number": "4",
    "text": "4   學校或主管機關決定議處之權責單位，於審議議處時，除有本法第三十七條第三項所定之情形外，不得要求性平會重新調查，亦不得自行調查。"
  },
  {
    "type": "paragraph",
    "number": "5",
    "text": "5   前項審議議處依相關法規應給予行為人陳述答辯意見時，應檢附經性平會審議通過之調查報告。"
  },
  {
    "type": "paragraph",
    "number": "6",
    "text": "6   第四項議處決定前，權責單位應通知被害人、其法定代理人或實際照顧者限期以書面或言詞提出陳述意見；其以言詞為之者，權責單位應作成紀錄，經向被害人、其法定代理人或實際照顧者朗讀或使閱覽，確認其內容無誤後，由其簽名或蓋章；未於期限內提出書面陳述意見者，視為放棄陳述之機會；有書面陳述意見者，決定議處之權責單位應審酌其書面陳述意見。"
  }
]
```

## U09-A31｜第 31 條

1   校園性別事件經事件管轄學校或機關所設性平會調查屬實後，事件管轄學校或機關應依本法第二十六條第一項規定，對行為人予以申誡、記過、解聘、停聘、不續聘、免職、終止契約關係、終止運用關係或其他適當之懲處。其他機關依相關法律或法規有議處權限者，事件管轄學校或機關應將該事件移送其他權責機關議處；其經證實有誣告之事實者，並應依法對申請人或檢舉人為適當之懲處。
2   本法第二十六條第二項對行為人所為處置，應由該懲處之學校或主管機關命行為人為之，執行時並應採取必要之措施，以確保行為人之配合遵守；處置之性質、執行方式、執行期間及不配合執行之法律效果，應載明於處理結果之書面通知中。
3   前項處置應由該懲處之學校或主管機關性平會討論決定下列事項之性質、執行單位或人員、執行方式、執行期間及費用之支應事宜：
一、行為人接受心理諮商與輔導。
二、行為人經被害人、其法定代理人或實際照顧者之同意，向被害人道歉。
三、八小時之性別平等教育相關課程。
四、其他符合教育目的之措施。
4   前項第四款之措施，必要時，得考量行為人為學生，融入學校之課程教學或宣導活動執行並記錄之。
5   依本法第二十六條第二項第二款規定命行為人接受八小時之性別平等教育相關課程，應由學校所屬主管機關規劃。

來源條目欄位（正規化資料）：
- id：article-31
- articleNumber：31
- displayNumber：第 31 條
- title：None
- structureId：chapter-4
- metadata：{"source": "全國法規資料庫 校園性別事件防治準則（PDF：法規-校園性別事件防治準則.pdf）", "lastModified": "2024-03-06"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   校園性別事件經事件管轄學校或機關所設性平會調查屬實後，事件管轄學校或機關應依本法第二十六條第一項規定，對行為人予以申誡、記過、解聘、停聘、不續聘、免職、終止契約關係、終止運用關係或其他適當之懲處。其他機關依相關法律或法規有議處權限者，事件管轄學校或機關應將該事件移送其他權責機關議處；其經證實有誣告之事實者，並應依法對申請人或檢舉人為適當之懲處。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   本法第二十六條第二項對行為人所為處置，應由該懲處之學校或主管機關命行為人為之，執行時並應採取必要之措施，以確保行為人之配合遵守；處置之性質、執行方式、執行期間及不配合執行之法律效果，應載明於處理結果之書面通知中。"
  },
  {
    "type": "paragraph",
    "number": "3",
    "text": "3   前項處置應由該懲處之學校或主管機關性平會討論決定下列事項之性質、執行單位或人員、執行方式、執行期間及費用之支應事宜："
  },
  {
    "type": "item",
    "number": "一",
    "text": "一、行為人接受心理諮商與輔導。"
  },
  {
    "type": "item",
    "number": "二",
    "text": "二、行為人經被害人、其法定代理人或實際照顧者之同意，向被害人道歉。"
  },
  {
    "type": "item",
    "number": "三",
    "text": "三、八小時之性別平等教育相關課程。"
  },
  {
    "type": "item",
    "number": "四",
    "text": "四、其他符合教育目的之措施。"
  },
  {
    "type": "paragraph",
    "number": "4",
    "text": "4   前項第四款之措施，必要時，得考量行為人為學生，融入學校之課程教學或宣導活動執行並記錄之。"
  },
  {
    "type": "paragraph",
    "number": "5",
    "text": "5   依本法第二十六條第二項第二款規定命行為人接受八小時之性別平等教育相關課程，應由學校所屬主管機關規劃。"
  }
]
```

## U09-A32｜第 32 條

1   事件管轄學校或機關將處理結果，以書面通知申請人、被害人及行為人時，應一併提供調查報告，並告知申復之期限及受理之學校或機關。
2   前項處理結果，內容包括事實認定、處置措施及議處結果。
3   申請人、被害人或行為人對事件管轄學校或機關處理之結果不服者，得於收到書面通知次日起三十日內，以書面具明理由向事件管轄學校或機關申復；其以言詞為之者，受理之學校或機關應作成紀錄，經向申請人、被害人或行為人朗讀或使閱覽，確認其內容無誤後，由其簽名或蓋章。
4   學校或主管機關接獲申復後，依下列程序處理：
一、由學校或主管機關指定之專責單位收件後，應即組成審議小組，並於三十日內作成附理由之決定，以書面通知申復人申復結果。
二、前款審議小組應包括性別平等教育相關專家學者、法律專業人員三人或五人，其小組成員中，女性人數比例應占成員總數二分之一以上，具校園性別事件調查專業素養之專家學者人數比例於學校應占成員總數三分之一以上，於主管機關應占成員總數二分之一以上。
三、原性平會委員及原調查小組成員不得擔任審議小組成員。
四、審議小組召開會議時由小組成員推舉召集人，並主持會議。
五、審議會議進行時，得視需要給予申復人陳述意見之機會，並得邀所設性平會相關委員或調查小組成員列席說明。
六、申復有理由時，將申復決定通知相關權責單位，由其重為決定。有本法第三十七條第三項所定調查程序有重大瑕疵或有足以影響原調查認定之新事實、新證據時，得要求性平會重新調查。
七、前款申復決定送達申復人前，申復人得準用前項規定撤回申復。
5   本法第三十七條第三項及本準則第三十條第三項所定調查程序有重大瑕疵，指有下列情形之一者：
一、性平會或調查小組組織不適法。
二、未給予當事人任一方陳述意見之機會。
三、有應迴避而未迴避之情形。
四、有應調查之證據而未調查。
五、有證據取捨瑕疵而影響事實認定。
六、其他足以影響事實認定之重大瑕疵。

來源條目欄位（正規化資料）：
- id：article-32
- articleNumber：32
- displayNumber：第 32 條
- title：None
- structureId：chapter-4
- metadata：{"source": "全國法規資料庫 校園性別事件防治準則（PDF：法規-校園性別事件防治準則.pdf）", "lastModified": "2024-03-06"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   事件管轄學校或機關將處理結果，以書面通知申請人、被害人及行為人時，應一併提供調查報告，並告知申復之期限及受理之學校或機關。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   前項處理結果，內容包括事實認定、處置措施及議處結果。"
  },
  {
    "type": "paragraph",
    "number": "3",
    "text": "3   申請人、被害人或行為人對事件管轄學校或機關處理之結果不服者，得於收到書面通知次日起三十日內，以書面具明理由向事件管轄學校或機關申復；其以言詞為之者，受理之學校或機關應作成紀錄，經向申請人、被害人或行為人朗讀或使閱覽，確認其內容無誤後，由其簽名或蓋章。"
  },
  {
    "type": "paragraph",
    "number": "4",
    "text": "4   學校或主管機關接獲申復後，依下列程序處理："
  },
  {
    "type": "item",
    "number": "一",
    "text": "一、由學校或主管機關指定之專責單位收件後，應即組成審議小組，並於三十日內作成附理由之決定，以書面通知申復人申復結果。"
  },
  {
    "type": "item",
    "number": "二",
    "text": "二、前款審議小組應包括性別平等教育相關專家學者、法律專業人員三人或五人，其小組成員中，女性人數比例應占成員總數二分之一以上，具校園性別事件調查專業素養之專家學者人數比例於學校應占成員總數三分之一以上，於主管機關應占成員總數二分之一以上。"
  },
  {
    "type": "item",
    "number": "三",
    "text": "三、原性平會委員及原調查小組成員不得擔任審議小組成員。"
  },
  {
    "type": "item",
    "number": "四",
    "text": "四、審議小組召開會議時由小組成員推舉召集人，並主持會議。"
  },
  {
    "type": "item",
    "number": "五",
    "text": "五、審議會議進行時，得視需要給予申復人陳述意見之機會，並得邀所設性平會相關委員或調查小組成員列席說明。"
  },
  {
    "type": "item",
    "number": "六",
    "text": "六、申復有理由時，將申復決定通知相關權責單位，由其重為決定。有本法第三十七條第三項所定調查程序有重大瑕疵或有足以影響原調查認定之新事實、新證據時，得要求性平會重新調查。"
  },
  {
    "type": "item",
    "number": "七",
    "text": "七、前款申復決定送達申復人前，申復人得準用前項規定撤回申復。"
  },
  {
    "type": "paragraph",
    "number": "5",
    "text": "5   本法第三十七條第三項及本準則第三十條第三項所定調查程序有重大瑕疵，指有下列情形之一者："
  },
  {
    "type": "item",
    "number": "一",
    "text": "一、性平會或調查小組組織不適法。"
  },
  {
    "type": "item",
    "number": "二",
    "text": "二、未給予當事人任一方陳述意見之機會。"
  },
  {
    "type": "item",
    "number": "三",
    "text": "三、有應迴避而未迴避之情形。"
  },
  {
    "type": "item",
    "number": "四",
    "text": "四、有應調查之證據而未調查。"
  },
  {
    "type": "item",
    "number": "五",
    "text": "五、有證據取捨瑕疵而影響事實認定。"
  },
  {
    "type": "item",
    "number": "六",
    "text": "六、其他足以影響事實認定之重大瑕疵。"
  }
]
```

## U09-A33｜第 33 條

1   行為人為校長，申請人或被害人依本法第三十七條第一項但書向學校主管機關申復時，依前條第三項規定辦理。
2   行為人為學校教職員工，申請人或被害人依本法第三十七條第一項但書向學校主管機關申復時，準用前條第四項規定處理，並得邀事件管轄學校性平會相關委員或調查小組成員代表列席說明。
3   前項申請人或被害人向學校主管機關申復時，倘行為人向學校申復，學校應即報請主管機關併案審議。
4   審議結果發現學校之處理結果，有違法或不當時，由主管機關所設性平會審議下列處理建議：
一、改核學校處理結果之必要性。
二、交回學校依法處理之理由。
三、追究相關人員責任之處置。

來源條目欄位（正規化資料）：
- id：article-33
- articleNumber：33
- displayNumber：第 33 條
- title：None
- structureId：chapter-4
- metadata：{"source": "全國法規資料庫 校園性別事件防治準則（PDF：法規-校園性別事件防治準則.pdf）", "lastModified": "2024-03-06"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   行為人為校長，申請人或被害人依本法第三十七條第一項但書向學校主管機關申復時，依前條第三項規定辦理。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   行為人為學校教職員工，申請人或被害人依本法第三十七條第一項但書向學校主管機關申復時，準用前條第四項規定處理，並得邀事件管轄學校性平會相關委員或調查小組成員代表列席說明。"
  },
  {
    "type": "paragraph",
    "number": "3",
    "text": "3   前項申請人或被害人向學校主管機關申復時，倘行為人向學校申復，學校應即報請主管機關併案審議。"
  },
  {
    "type": "paragraph",
    "number": "4",
    "text": "4   審議結果發現學校之處理結果，有違法或不當時，由主管機關所設性平會審議下列處理建議："
  },
  {
    "type": "item",
    "number": "一",
    "text": "一、改核學校處理結果之必要性。"
  },
  {
    "type": "item",
    "number": "二",
    "text": "二、交回學校依法處理之理由。"
  },
  {
    "type": "item",
    "number": "三",
    "text": "三、追究相關人員責任之處置。"
  }
]
```

## U09-A34｜第 34 條

1   事件管轄學校或機關依本法第二十八條第一項規定建立之檔案資料，應指定專責單位或人員保存二十五年；其以電子儲存媒體儲存者，必要時得採電子簽章或加密方式處理之。
2   依前項規定所建立之檔案資料，分為原始檔案與報告檔案。
3   前項原始檔案內容包括下列資料：
一、事件發生之時間、樣態。
二、事件相關當事人（包括檢舉人、被害人、行為人）。
三、事件處理人員、流程及紀錄。
四、事件處理所製作之文書、訪談過程之錄音檔案、取得之證據及其他相關資料。
五、行為人之姓名、職稱或學籍資料等。
六、調查小組提交之調查報告初稿及性平會之會議紀錄。
4   第二項報告檔案為經性平會議決通過之調查報告；其內容應包括下列事項：
一、申請調查事件之案由，包括當事人或檢舉之敘述。
二、調查訪談過程紀錄，包括日期及對象。
三、被申請調查人、申請調查人、證人與相關人士之陳述及答辯。
四、相關物證之查驗。
五、事實認定及理由。
六、處理建議。
5   第一項建立之檔案資料銷毀方式，得準用機關檔案保存年限及銷毀辦法第十三條規定辦理。

來源條目欄位（正規化資料）：
- id：article-34
- articleNumber：34
- displayNumber：第 34 條
- title：None
- structureId：chapter-4
- metadata：{"source": "全國法規資料庫 校園性別事件防治準則（PDF：法規-校園性別事件防治準則.pdf）", "lastModified": "2024-03-06"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   事件管轄學校或機關依本法第二十八條第一項規定建立之檔案資料，應指定專責單位或人員保存二十五年；其以電子儲存媒體儲存者，必要時得採電子簽章或加密方式處理之。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   依前項規定所建立之檔案資料，分為原始檔案與報告檔案。"
  },
  {
    "type": "paragraph",
    "number": "3",
    "text": "3   前項原始檔案內容包括下列資料："
  },
  {
    "type": "item",
    "number": "一",
    "text": "一、事件發生之時間、樣態。"
  },
  {
    "type": "item",
    "number": "二",
    "text": "二、事件相關當事人（包括檢舉人、被害人、行為人）。"
  },
  {
    "type": "item",
    "number": "三",
    "text": "三、事件處理人員、流程及紀錄。"
  },
  {
    "type": "item",
    "number": "四",
    "text": "四、事件處理所製作之文書、訪談過程之錄音檔案、取得之證據及其他相關資料。"
  },
  {
    "type": "item",
    "number": "五",
    "text": "五、行為人之姓名、職稱或學籍資料等。"
  },
  {
    "type": "item",
    "number": "六",
    "text": "六、調查小組提交之調查報告初稿及性平會之會議紀錄。"
  },
  {
    "type": "paragraph",
    "number": "4",
    "text": "4   第二項報告檔案為經性平會議決通過之調查報告；其內容應包括下列事項："
  },
  {
    "type": "item",
    "number": "一",
    "text": "一、申請調查事件之案由，包括當事人或檢舉之敘述。"
  },
  {
    "type": "item",
    "number": "二",
    "text": "二、調查訪談過程紀錄，包括日期及對象。"
  },
  {
    "type": "item",
    "number": "三",
    "text": "三、被申請調查人、申請調查人、證人與相關人士之陳述及答辯。"
  },
  {
    "type": "item",
    "number": "四",
    "text": "四、相關物證之查驗。"
  },
  {
    "type": "item",
    "number": "五",
    "text": "五、事實認定及理由。"
  },
  {
    "type": "item",
    "number": "六",
    "text": "六、處理建議。"
  },
  {
    "type": "paragraph",
    "number": "5",
    "text": "5   第一項建立之檔案資料銷毀方式，得準用機關檔案保存年限及銷毀辦法第十三條規定辦理。"
  }
]
```

## U09-A35｜第 35 條

學校或主管機關於取得本法第二十九條第三項所定事件相關事證資訊，經通知當事人陳述意見後，應提交性平會查證審議。

來源條目欄位（正規化資料）：
- id：article-35
- articleNumber：35
- displayNumber：第 35 條
- title：None
- structureId：chapter-4
- metadata：{"source": "全國法規資料庫 校園性別事件防治準則（PDF：法規-校園性別事件防治準則.pdf）", "lastModified": "2024-03-06"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": null,
    "text": "學校或主管機關於取得本法第二十九條第三項所定事件相關事證資訊，經通知當事人陳述意見後，應提交性平會查證審議。"
  }
]
```

## U09-A36｜第 36 條

1   事件管轄學校或機關依本法第二十八條第二項及第三項規定為通報時，其通報內容應限於行為人經查證屬實之校園性別事件時間、樣態、行為人姓名、職稱或學籍資料。
2   前項事件管轄學校或機關應視實際需要，將輔導、防治教育或相關處置措施及其他必要之資訊，提供予次一就讀或服務之學校。
3   事件管轄學校或機關就行為人追蹤輔導後，評估無再犯情事者，得於第一項通報內容註記行為人之改過現況。

來源條目欄位（正規化資料）：
- id：article-36
- articleNumber：36
- displayNumber：第 36 條
- title：None
- structureId：chapter-4
- metadata：{"source": "全國法規資料庫 校園性別事件防治準則（PDF：法規-校園性別事件防治準則.pdf）", "lastModified": "2024-03-06"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   事件管轄學校或機關依本法第二十八條第二項及第三項規定為通報時，其通報內容應限於行為人經查證屬實之校園性別事件時間、樣態、行為人姓名、職稱或學籍資料。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   前項事件管轄學校或機關應視實際需要，將輔導、防治教育或相關處置措施及其他必要之資訊，提供予次一就讀或服務之學校。"
  },
  {
    "type": "paragraph",
    "number": "3",
    "text": "3   事件管轄學校或機關就行為人追蹤輔導後，評估無再犯情事者，得於第一項通報內容註記行為人之改過現況。"
  }
]
```

## U09-A37｜第 37 條

1   各學校知悉涉有校園性別事件之聘任或任用之教職員、公務人員或軍職人員提出退休（伍）或資遣申請時，應依下列規定辦理：
一、召開教師評審委員會、教練評審委員會、性平會、考績委員會、人事評審會或依法令組成之相關委員會，就其涉及校園性別事件之違失情節，詳慎審酌是否應依法令作成解聘、停聘或不續聘之決議後，依其身分別適用之法令循程序報請主管機關核准或依校內程序辦理；或依公務員懲戒法規定，移送懲戒或送請監察院審查，及應否依相關法律核予停職或免職。
二、經召開教師評審委員會、教練評審委員會、性平會、考績委員會、人事評審會或依法令組成之相關委員會審酌後，認為有須依法令作成解聘、停聘或不續聘之決議或依公務員懲戒法規定移送懲戒或送請監察院審查或依相關法律核予停職或免職而不受理其申請退休（伍）或資遣時，應書面通知當事人並敘明理由；如認無須依法令作成解聘、停聘或不續聘之決議或依公務員懲戒法規定移送懲戒或送請監察院審查或依相關法律核予停職或免職而仍受理其申請退休（伍）或資遣時，應於彙送退休（伍）或資遣案審（核）定權責機關（構）之函內，敘明理由並檢同相關審查資料。
三、前二款所定程序，各學校應自收受涉有校園性別事件之所屬教職員、公務人員或軍職人員退休（伍）或資遣案之日起二個月內處理終結；必要時，得延長一次，並於原處理期間屆滿前，將延長之事由通知申請人。
2   主管機關知悉現任公、私立學校校長涉有校園性別事件，於其申請退休或資遣時，應由主管機關分別依教育人員任用條例、公務員懲戒法或私立學校法等規定辦理。

來源條目欄位（正規化資料）：
- id：article-37
- articleNumber：37
- displayNumber：第 37 條
- title：None
- structureId：chapter-4
- metadata：{"source": "全國法規資料庫 校園性別事件防治準則（PDF：法規-校園性別事件防治準則.pdf）", "lastModified": "2024-03-06"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   各學校知悉涉有校園性別事件之聘任或任用之教職員、公務人員或軍職人員提出退休（伍）或資遣申請時，應依下列規定辦理："
  },
  {
    "type": "item",
    "number": "一",
    "text": "一、召開教師評審委員會、教練評審委員會、性平會、考績委員會、人事評審會或依法令組成之相關委員會，就其涉及校園性別事件之違失情節，詳慎審酌是否應依法令作成解聘、停聘或不續聘之決議後，依其身分別適用之法令循程序報請主管機關核准或依校內程序辦理；或依公務員懲戒法規定，移送懲戒或送請監察院審查，及應否依相關法律核予停職或免職。"
  },
  {
    "type": "item",
    "number": "二",
    "text": "二、經召開教師評審委員會、教練評審委員會、性平會、考績委員會、人事評審會或依法令組成之相關委員會審酌後，認為有須依法令作成解聘、停聘或不續聘之決議或依公務員懲戒法規定移送懲戒或送請監察院審查或依相關法律核予停職或免職而不受理其申請退休（伍）或資遣時，應書面通知當事人並敘明理由；如認無須依法令作成解聘、停聘或不續聘之決議或依公務員懲戒法規定移送懲戒或送請監察院審查或依相關法律核予停職或免職而仍受理其申請退休（伍）或資遣時，應於彙送退休（伍）或資遣案審（核）定權責機關（構）之函內，敘明理由並檢同相關審查資料。"
  },
  {
    "type": "item",
    "number": "三",
    "text": "三、前二款所定程序，各學校應自收受涉有校園性別事件之所屬教職員、公務人員或軍職人員退休（伍）或資遣案之日起二個月內處理終結；必要時，得延長一次，並於原處理期間屆滿前，將延長之事由通知申請人。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   主管機關知悉現任公、私立學校校長涉有校園性別事件，於其申請退休或資遣時，應由主管機關分別依教育人員任用條例、公務員懲戒法或私立學校法等規定辦理。"
  }
]
```

## U09-A38｜第 38 條

1   學校應依本準則內容，訂定校園性別事件防治規定，並將第八條及第九條規定納入校長及教職員工聘約及學生手冊。
2   前項規定之內容，應包括下列事項：
一、校園安全規劃。
二、校內外教學與活動及人際互動注意事項。
三、校園性別事件防治之政策宣示。
四、校園性別事件之界定及樣態。
五、校園性別事件之申請調查或檢舉之收件單位、電話、電子郵件等資訊及程序。
六、校園性別事件之調查及處理程序。
七、校園性別事件之申復及救濟程序。
八、禁止報復之警示。
九、隱私之保密。
十、其他校園性別事件防治相關事項。

來源條目欄位（正規化資料）：
- id：article-38
- articleNumber：38
- displayNumber：第 38 條
- title：None
- structureId：chapter-5
- metadata：{"source": "全國法規資料庫 校園性別事件防治準則（PDF：法規-校園性別事件防治準則.pdf）", "lastModified": "2024-03-06"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   學校應依本準則內容，訂定校園性別事件防治規定，並將第八條及第九條規定納入校長及教職員工聘約及學生手冊。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   前項規定之內容，應包括下列事項："
  },
  {
    "type": "item",
    "number": "一",
    "text": "一、校園安全規劃。"
  },
  {
    "type": "item",
    "number": "二",
    "text": "二、校內外教學與活動及人際互動注意事項。"
  },
  {
    "type": "item",
    "number": "三",
    "text": "三、校園性別事件防治之政策宣示。"
  },
  {
    "type": "item",
    "number": "四",
    "text": "四、校園性別事件之界定及樣態。"
  },
  {
    "type": "item",
    "number": "五",
    "text": "五、校園性別事件之申請調查或檢舉之收件單位、電話、電子郵件等資訊及程序。"
  },
  {
    "type": "item",
    "number": "六",
    "text": "六、校園性別事件之調查及處理程序。"
  },
  {
    "type": "item",
    "number": "七",
    "text": "七、校園性別事件之申復及救濟程序。"
  },
  {
    "type": "item",
    "number": "八",
    "text": "八、禁止報復之警示。"
  },
  {
    "type": "item",
    "number": "九",
    "text": "九、隱私之保密。"
  },
  {
    "type": "item",
    "number": "十",
    "text": "十、其他校園性別事件防治相關事項。"
  }
]
```

## U09-A39｜第 39 條

高級中等以下學校調查處理校園性別事件及對當事人實施教育輔導所需之經費，得向學校所屬主管機關申請補助。

來源條目欄位（正規化資料）：
- id：article-39
- articleNumber：39
- displayNumber：第 39 條
- title：None
- structureId：chapter-5
- metadata：{"source": "全國法規資料庫 校園性別事件防治準則（PDF：法規-校園性別事件防治準則.pdf）", "lastModified": "2024-03-06"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": null,
    "text": "高級中等以下學校調查處理校園性別事件及對當事人實施教育輔導所需之經費，得向學校所屬主管機關申請補助。"
  }
]
```

## U09-A40｜第 40 條

1   事件管轄學校於校園性別事件調查處理完成，調查報告經性平會議決後，應將處理情形、處理程序之檢核情形、調查報告及性平會之會議紀錄報所屬主管機關。申請人、被害人及行為人提出申復之事件，並應於申復審議完成後，將申復審議結果報所屬主管機關。
2   學校所屬主管機關應依本法第四條、第五條及第十一條規定，定期對學校進行督導考核；並將第四條、第五條之校園安全規劃、校園危險空間改善情形，及學校防治與調查處理校園性別事件之成效列入定期考核事項。

來源條目欄位（正規化資料）：
- id：article-40
- articleNumber：40
- displayNumber：第 40 條
- title：None
- structureId：chapter-5
- metadata：{"source": "全國法規資料庫 校園性別事件防治準則（PDF：法規-校園性別事件防治準則.pdf）", "lastModified": "2024-03-06"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   事件管轄學校於校園性別事件調查處理完成，調查報告經性平會議決後，應將處理情形、處理程序之檢核情形、調查報告及性平會之會議紀錄報所屬主管機關。申請人、被害人及行為人提出申復之事件，並應於申復審議完成後，將申復審議結果報所屬主管機關。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   學校所屬主管機關應依本法第四條、第五條及第十一條規定，定期對學校進行督導考核；並將第四條、第五條之校園安全規劃、校園危險空間改善情形，及學校防治與調查處理校園性別事件之成效列入定期考核事項。"
  }
]
```

## U09-A41｜第 41 條

本準則自中華民國一百十三年三月八日施行。

來源條目欄位（正規化資料）：
- id：article-41
- articleNumber：41
- displayNumber：第 41 條
- title：None
- structureId：chapter-5
- metadata：{"source": "全國法規資料庫 校園性別事件防治準則（PDF：法規-校園性別事件防治準則.pdf）", "lastModified": "2024-03-06"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": null,
    "text": "本準則自中華民國一百十三年三月八日施行。"
  }
]
```

## 來源其他資料

- schemaVersion：1.3.0
- processing：{"normalizedBy": "ai", "processedAt": "2026-07-22T00:00:00Z", "sourceType": "document", "warnings": ["來源 PDF未載明主管機關，authority 依規範填「未提供」。", "來源 PDF未印出官方法規代碼，code 依規範填「UNKNOWN」。"]}