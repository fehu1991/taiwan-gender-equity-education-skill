# LAW-U04｜性侵害犯罪防治法

資料集：CGE-NB-1.3.0.1；編製日：2026-09-09。此日期不是法律查核日。

## 來源與版本

- source_id：U04
- filename：性侵害犯罪防治法.json
- path：sources/uploaded/性侵害犯罪防治法.json
- sha256：af75a572b52509dbdea64db3bf847cee1834a82b0a2df16a0a8e86189199f0a6
- regulation_id：tw-sexual-assault-crime-prevention-act
- name：性侵害犯罪防治法
- version：{"id": "tw-sexual-assault-crime-prevention-act-20230215", "label": "修正日期：民國 112 年 02 月 15 日", "promulgationDate": "2023-02-15", "effectiveDate": "2023-02-17", "effectiveDateNote": "本版本施行條文明定自公布（發布）日施行，依中央法規標準法第13條，自公布（發布）之日起算至第三日起發生效力，故施行日為公布（發布）日之後二日。 另依第56條，第13條自公布後六個月施行，即2023-08-15施行。", "status": "effective"}
- article_count：56
- source_kind：user_uploaded_ai_normalized_json
- review_status：attachment_reference_not_full_current_audit
- review_notes：[]
- official_source_ids：[]
- normalization_warnings：["來源 PDF未印出官方法規代碼，code 依規範填「UNKNOWN」。"]
- processed_at：2026-07-22T00:00:00Z
- authoritative_current_full_text：False

- id：tw-sexual-assault-crime-prevention-act
- code：UNKNOWN
- name：性侵害犯罪防治法
- shortName：性侵害犯罪防治法
- jurisdiction：TW
- authority：衛生福利部
- aliases：["性侵害防治法"]
- version：{"id": "tw-sexual-assault-crime-prevention-act-20230215", "label": "修正日期：民國 112 年 02 月 15 日", "promulgationDate": "2023-02-15", "effectiveDate": "2023-02-17", "effectiveDateNote": "本版本施行條文明定自公布（發布）日施行，依中央法規標準法第13條，自公布（發布）之日起算至第三日起發生效力，故施行日為公布（發布）日之後二日。 另依第56條，第13條自公布後六個月施行，即2023-08-15施行。", "status": "effective"}
- structure：[{"id": "chapter-1", "type": "chapter", "label": "第 一 章 總則", "parentId": null, "sortOrder": 0}, {"id": "chapter-2", "type": "chapter", "label": "第 二 章 預防及通報", "parentId": null, "sortOrder": 1}, {"id": "chapter-3", "type": "chapter", "label": "第 三 章 被害人保護", "parentId": null, "sortOrder": 2}, {"id": "chapter-4", "type": "chapter", "label": "第 四 章 加害人處遇", "parentId": null, "sortOrder": 3}, {"id": "chapter-5", "type": "chapter", "label": "第 五 章 罰則", "parentId": null, "sortOrder": 4}, {"id": "chapter-6", "type": "chapter", "label": "第 六 章 附則", "parentId": null, "sortOrder": 5}]
- legalConcepts：[{"id": "sexual-assault-prevention-framework", "name": "性侵害犯罪防治法律框架", "description": "彙整性侵害犯罪之防治、被害人保護與加害人處遇所涉之法規。", "aliases": ["性侵害防治"], "tags": ["性侵害", "被害人保護"], "role": "primary", "sortOrder": 0}, {"id": "intimate-image-abuse-protection-framework", "name": "性影像（不實性影像及性隱私影像）防治法律框架", "description": "彙整妨害性隱私及不實性影像罪（性影像犯罪）之定義、被害人保護命令、網路業者下架及資料保存義務，以及少年、家庭暴力、性侵害、性剝削等被害人依各該法所受性影像相關保護所涉之法規。", "aliases": ["性影像防治", "數位性暴力防制"], "tags": ["性影像", "深偽", "數位性暴力"], "role": "supporting", "sortOrder": 1}, {"id": "child-youth-protection-framework", "name": "兒童及少年保護法律框架", "description": "彙整兒童及少年之福利、權益保障與性剝削防制所涉之法規。", "aliases": ["兒少保護"], "tags": ["兒童", "少年", "保護"], "role": "related", "sortOrder": 2}, {"id": "sexual-harassment-prevention-framework", "name": "性騷擾防治法律框架", "description": "彙整我國性騷擾之定義、防治義務、申訴調查程序與相關罰則所涉之法規；並涵蓋依場域與當事人身分關係而分流適用之性別平等工作法與性別平等教育法。", "aliases": ["性騷擾防治"], "tags": ["性騷擾", "防治", "申訴"], "role": "related", "sortOrder": 3}]
- crossRegulationLinks：[{"id": "link-tw-sexual-assault-crime-prevention-act-1", "conceptId": "sexual-assault-prevention-framework", "sourceArticleId": null, "label": "授權訂定施行細則", "relationType": "authorization", "conditionText": "本法施行細則，由中央主管機關定之。", "targetRegulationId": "tw-sexual-assault-crime-prevention-act-enforcement-rules", "targetRegulationNames": ["性侵害犯罪防治法施行細則"], "targetArticleNumber": null, "triggerTerms": ["施行細則"], "linkMode": "automatic", "sortOrder": 0}, {"conceptId": "sexual-assault-prevention-framework", "sourceArticleId": "article-2", "label": "引用刑法", "relationType": "application", "conditionText": "一、性侵害犯罪：指觸犯刑法第二百二十一條至第二百二十七條、第二百二十八條、第二百二十九條、第三百三十二條第二項第二款、第三百三十四條第二項第二款、第三百四十八條第二項第一款及其特別法之罪。", "targetRegulationId": "tw-criminal-code", "targetRegulationNames": ["刑法"], "targetArticleNumber": "221", "triggerTerms": ["：指觸犯"], "linkMode": "automatic", "id": "link-tw-sexual-assault-crime-prevention-act-cite-2", "sortOrder": 1}, {"conceptId": "sexual-harassment-prevention-framework", "sourceArticleId": "article-7", "label": "引用性騷擾防治法", "relationType": "application", "conditionText": "1   犯性騷擾防治法第二十五條第一項之罪及犯刑法第三百十九條之二第一項之罪，經判決有罪確定者，準用第三十一條、第三十三條至第三十五條、第四十二條及第四十三條規定。", "targetRegulationId": "tw-sexual-harassment-prevention-act", "targetRegulationNames": ["性騷擾防治法"], "targetArticleNumber": "25", "triggerTerms": ["   犯"], "linkMode": "automatic", "id": "link-tw-sexual-assault-crime-prevention-act-cite-3", "sortOrder": 2}, {"conceptId": "sexual-assault-prevention-framework", "sourceArticleId": "article-7", "label": "引用刑法", "relationType": "application", "conditionText": "1   犯性騷擾防治法第二十五條第一項之罪及犯刑法第三百十九條之二第一項之罪，經判決有罪確定者，準用第三十一條、第三十三條至第三十五條、第四十二條及第四十三條規定。", "targetRegulationId": "tw-criminal-code", "targetRegulationNames": ["刑法"], "targetArticleNumber": "319", "triggerTerms": ["之罪及犯"], "linkMode": "automatic", "id": "link-tw-sexual-assault-crime-prevention-act-cite-4", "sortOrder": 3}, {"conceptId": "sexual-assault-prevention-framework", "sourceArticleId": "article-17", "label": "引用刑事訴訟法", "relationType": "application", "conditionText": "1   對於被害人之驗傷及採證，除依刑事訴訟法之規定或被害人無意識或無法表意者外，應經被害人之同意，並依下列規定辦理：", "targetRegulationId": "tw-code-criminal-procedure", "targetRegulationNames": ["刑事訴訟法"], "targetArticleNumber": null, "triggerTerms": ["證，除依"], "linkMode": "automatic", "id": "link-tw-sexual-assault-crime-prevention-act-cite-5", "sortOrder": 4}, {"conceptId": "sexual-assault-prevention-framework", "sourceArticleId": "article-20", "label": "引用刑事訴訟法", "relationType": "application", "conditionText": "1   前條專業人士辦理協助詢（訊）問事務，依其性質，準用刑事訴訟法第十二章第二節、第三節規定。", "targetRegulationId": "tw-code-criminal-procedure", "targetRegulationNames": ["刑事訴訟法"], "targetArticleNumber": null, "triggerTerms": ["質，準用"], "linkMode": "automatic", "id": "link-tw-sexual-assault-crime-prevention-act-cite-6", "sortOrder": 5}, {"conceptId": "sexual-assault-prevention-framework", "sourceArticleId": "article-22", "label": "引用刑事訴訟法", "relationType": "application", "conditionText": "犯罪嫌疑人、被告或少年事件之少年為心智障礙者，於刑事案件偵查、審判程序或少年事件處理程序中，除適用刑事訴訟法或少年事件處理法有關規定外，認有必要時，得準用第十九條規定。", "targetRegulationId": "tw-code-criminal-procedure", "targetRegulationNames": ["刑事訴訟法"], "targetArticleNumber": null, "triggerTerms": ["，除適用"], "linkMode": "automatic", "id": "link-tw-sexual-assault-crime-prevention-act-cite-7", "sortOrder": 6}, {"conceptId": "child-youth-protection-framework", "sourceArticleId": "article-22", "label": "引用少年事件處理法", "relationType": "application", "conditionText": "犯罪嫌疑人、被告或少年事件之少年為心智障礙者，於刑事案件偵查、審判程序或少年事件處理程序中，除適用刑事訴訟法或少年事件處理法有關規定外，認有必要時，得準用第十九條規定。", "targetRegulationId": "tw-juvenile-justice-act", "targetRegulationNames": ["少年事件處理法"], "targetArticleNumber": null, "triggerTerms": ["訴訟法或"], "linkMode": "automatic", "id": "link-tw-sexual-assault-crime-prevention-act-cite-8", "sortOrder": 7}, {"conceptId": "sexual-assault-prevention-framework", "sourceArticleId": "article-24", "label": "引用刑事訴訟法", "relationType": "application", "conditionText": "偵查或審判時，檢察官或法院得依職權或依聲請指定或選任相關領域之專家證人，提供專業意見。其經傳喚到庭陳述之意見，得為證據，並準用刑事訴訟法第一百六十三條至第一百七十一條、第一百七十五條及第一百九十九條規定。", "targetRegulationId": "tw-code-criminal-procedure", "targetRegulationNames": ["刑事訴訟法"], "targetArticleNumber": "163", "triggerTerms": ["，並準用"], "linkMode": "automatic", "id": "link-tw-sexual-assault-crime-prevention-act-cite-9", "sortOrder": 8}, {"conceptId": "sexual-assault-prevention-framework", "sourceArticleId": "article-31", "label": "引用刑法", "relationType": "application", "conditionText": "六、經法院依第三十八條第一項但書及第六項規定或刑法第九十一條之一第二項但書規定裁定停止強制治療。", "targetRegulationId": "tw-criminal-code", "targetRegulationNames": ["刑法"], "targetArticleNumber": "91", "triggerTerms": ["項規定或"], "linkMode": "automatic", "id": "link-tw-sexual-assault-crime-prevention-act-cite-10", "sortOrder": 9}, {"conceptId": "sexual-harassment-prevention-framework", "sourceArticleId": "article-31", "label": "引用性騷擾防治法", "relationType": "application", "conditionText": "5   犯性騷擾防治法第二十五條第一項之罪經判處拘役或罰金確定，依第七條第一項準用本條第一項規定，於判決確定時執行之。", "targetRegulationId": "tw-sexual-harassment-prevention-act", "targetRegulationNames": ["性騷擾防治法"], "targetArticleNumber": "25", "triggerTerms": ["   犯"], "linkMode": "automatic", "id": "link-tw-sexual-assault-crime-prevention-act-cite-11", "sortOrder": 10}, {"conceptId": "child-youth-protection-framework", "sourceArticleId": "article-31", "label": "引用少年事件處理法", "relationType": "application", "conditionText": "6   第一項至第三項規定對於有性侵害犯罪行為，經法院依少年事件處理法裁定保護處分確定且認有必要者，得準用之。", "targetRegulationId": "tw-juvenile-justice-act", "targetRegulationNames": ["少年事件處理法"], "targetArticleNumber": null, "triggerTerms": ["經法院依"], "linkMode": "automatic", "id": "link-tw-sexual-assault-crime-prevention-act-cite-12", "sortOrder": 11}, {"conceptId": "sexual-assault-prevention-framework", "sourceArticleId": "article-36", "label": "引用刑法", "relationType": "application", "conditionText": "加害人依第三十一條第一項及第四項接受身心治療、輔導或教育，經第三十三條評估小組評估認有再犯之風險者，直轄市、縣（市）主管機關得檢具相關評估報告，送請檢察官依刑法第九十一條之一規定聲請強制治療或繼續施以強制治療。", "targetRegulationId": "tw-criminal-code", "targetRegulationNames": ["刑法"], "targetArticleNumber": "91", "triggerTerms": ["檢察官依"], "linkMode": "automatic", "id": "link-tw-sexual-assault-crime-prevention-act-cite-13", "sortOrder": 12}, {"conceptId": "sexual-assault-prevention-framework", "sourceArticleId": "article-37", "label": "引用刑法", "relationType": "application", "conditionText": "1   加害人於徒刑執行期滿前，接受身心治療、輔導或教育後，經矯正機關評估小組評估認有再犯之風險，而不適用刑法第九十一條之一規定者，矯正機關得檢具相關評估報告，送請檢察官聲請法院裁定命其進入醫療機構或其他指定處所，施以強制治療。", "targetRegulationId": "tw-criminal-code", "targetRegulationNames": ["刑法"], "targetArticleNumber": "91", "triggerTerms": ["而不適用"], "linkMode": "automatic", "id": "link-tw-sexual-assault-crime-prevention-act-cite-14", "sortOrder": 13}, {"conceptId": "sexual-assault-prevention-framework", "sourceArticleId": "article-40", "label": "引用刑事訴訟法", "relationType": "application", "conditionText": "1   第三十七條及第三十八條之聲請、停止、延長及裁定事項，除本法另有規定外，準用刑事訴訟法相關規定。", "targetRegulationId": "tw-code-criminal-procedure", "targetRegulationNames": ["刑事訴訟法"], "targetArticleNumber": "31", "triggerTerms": ["外，準用"], "linkMode": "automatic", "id": "link-tw-sexual-assault-crime-prevention-act-cite-15", "sortOrder": 14}, {"conceptId": "sexual-assault-prevention-framework", "sourceArticleId": "article-41", "label": "引用刑法", "relationType": "application", "conditionText": "1   犯刑法第二百二十一條、第二百二十二條、第二百二十四條之一、第二百二十五條第一項、第二百二十六條、第二百二十六條之一、第三百三十二條第二項第二款、第三百三十四條第二項第二款、第三百四十八條第二項第一款或其特別法之罪之加害人，有第三十一條第一項各款情形之一者，應定期向警察機關辦理身分、就學、工作、車籍之異動或其他相關資料之登記、報到；其登記、報到期間為七年。", "targetRegulationId": "tw-criminal-code", "targetRegulationNames": ["刑法"], "targetArticleNumber": "221", "triggerTerms": ["   犯"], "linkMode": "automatic", "id": "link-tw-sexual-assault-crime-prevention-act-cite-16", "sortOrder": 15}, {"conceptId": "sexual-harassment-prevention-framework", "sourceArticleId": "article-51", "label": "引用性騷擾防治法", "relationType": "application", "conditionText": "二、犯性騷擾防治法第二十五條第一項之罪及犯刑法第三百十九條之二第一項之罪經假釋、緩刑或有期徒刑易服社會勞動者。", "targetRegulationId": "tw-sexual-harassment-prevention-act", "targetRegulationNames": ["性騷擾防治法"], "targetArticleNumber": "25", "triggerTerms": ["\n二、犯"], "linkMode": "automatic", "id": "link-tw-sexual-assault-crime-prevention-act-cite-17", "sortOrder": 16}, {"conceptId": "sexual-assault-prevention-framework", "sourceArticleId": "article-51", "label": "引用刑法", "relationType": "application", "conditionText": "二、犯性騷擾防治法第二十五條第一項之罪及犯刑法第三百十九條之二第一項之罪經假釋、緩刑或有期徒刑易服社會勞動者。", "targetRegulationId": "tw-criminal-code", "targetRegulationNames": ["刑法"], "targetArticleNumber": "319", "triggerTerms": ["之罪及犯"], "linkMode": "automatic", "id": "link-tw-sexual-assault-crime-prevention-act-cite-18", "sortOrder": 17}, {"conceptId": "sexual-assault-prevention-framework", "sourceArticleId": "article-54", "label": "引用刑法", "relationType": "application", "conditionText": "2   前項情形，由原執行檢察署之檢察官或直轄市、縣（市）主管機關於第三十六條至第四十條修正施行後六月內，向該案犯罪事實最後裁判之法院，依第三十八條第一項或刑法第九十一條之一第二項規定，聲請裁定強制治療之期間。", "targetRegulationId": "tw-criminal-code", "targetRegulationNames": ["刑法"], "targetArticleNumber": "91", "triggerTerms": ["第一項或"], "linkMode": "automatic", "id": "link-tw-sexual-assault-crime-prevention-act-cite-19", "sortOrder": 18}]
- definedTerms：[{"id": "sexual-assault-crime", "name": "性侵害犯罪", "aliases": [], "definition": "指觸犯刑法第二百二十一條至第二百二十七條、第二百二十八條、第二百二十九條、第三百三十二條第二項第二款、第三百三十四條第二項第二款、第三百四十八條第二項第一款及其特別法之罪。", "definitionArticleId": "article-2", "definitionText": "一、性侵害犯罪：指觸犯刑法第二百二十一條至第二百二十七條、第二百二十八條、第二百二十九條、第三百三十二條第二項第二款、第三百三十四條第二項第二款、第三百四十八條第二項第一款及其特別法之罪。", "scope": "regulation", "targetRegulationNames": [], "sortOrder": 0}, {"id": "tw-sexual-assault-crime-prevention-act-term-2", "name": "加害人", "aliases": [], "definition": "指觸犯前款各罪經判決有罪確定之人。", "definitionArticleId": "article-2", "definitionText": "二、加害人：指觸犯前款各罪經判決有罪確定之人。", "scope": "regulation", "targetRegulationNames": [], "sortOrder": 1}, {"id": "tw-sexual-assault-crime-prevention-act-term-3", "name": "被害人", "aliases": [], "definition": "指遭受性侵害或疑似遭受性侵害之人。", "definitionArticleId": "article-2", "definitionText": "三、被害人：指遭受性侵害或疑似遭受性侵害之人。", "scope": "regulation", "targetRegulationNames": [], "sortOrder": 2}, {"id": "tw-sexual-assault-crime-prevention-act-term-4", "name": "專業人士", "aliases": [], "definition": "指因學識、技術、經驗、訓練或教育而就兒童或心智障礙性侵害案件協助詢（訊）問具有專業能力之人。", "definitionArticleId": "article-2", "definitionText": "四、專業人士：指因學識、技術、經驗、訓練或教育而就兒童或心智障礙性侵害案件協助詢（訊）問具有專業能力之人。", "scope": "regulation", "targetRegulationNames": [], "sortOrder": 3}, {"id": "competent-authority", "name": "主管機關", "aliases": [], "definition": "在中央為衛生福利部；在直轄市為直轄市政府；在縣（市）為縣（市）政府。", "definitionArticleId": "article-3", "definitionText": "本法所稱主管機關：在中央為衛生福利部；在直轄市為直轄市政府；在縣（市）為縣（市）政府。", "scope": "regulation", "targetRegulationNames": [], "sortOrder": 4}]

正規化概念、跨法連結與處理狀態不是獨立法源；下面逐條保留來源plainText，未以本次日期重寫。

## U04-A1｜第 1 條

為防治性侵害犯罪及保護被害人權益，特制定本法。

來源條目欄位（正規化資料）：
- id：article-1
- articleNumber：1
- displayNumber：第 1 條
- title：None
- structureId：chapter-1
- metadata：{"source": "全國法規資料庫 性侵害犯罪防治法（PDF：法規-性侵害犯罪防治法.pdf）", "lastModified": "2023-02-15"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": null,
    "text": "為防治性侵害犯罪及保護被害人權益，特制定本法。"
  }
]
```

## U04-A2｜第 2 條

本法用詞，定義如下：
一、性侵害犯罪：指觸犯刑法第二百二十一條至第二百二十七條、第二百二十八條、第二百二十九條、第三百三十二條第二項第二款、第三百三十四條第二項第二款、第三百四十八條第二項第一款及其特別法之罪。
二、加害人：指觸犯前款各罪經判決有罪確定之人。
三、被害人：指遭受性侵害或疑似遭受性侵害之人。
四、專業人士：指因學識、技術、經驗、訓練或教育而就兒童或心智障礙性侵害案件協助詢（訊）問具有專業能力之人。

來源條目欄位（正規化資料）：
- id：article-2
- articleNumber：2
- displayNumber：第 2 條
- title：None
- structureId：chapter-1
- metadata：{"source": "全國法規資料庫 性侵害犯罪防治法（PDF：法規-性侵害犯罪防治法.pdf）", "lastModified": "2023-02-15"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": null,
    "text": "本法用詞，定義如下："
  },
  {
    "type": "item",
    "number": "一",
    "text": "一、性侵害犯罪：指觸犯刑法第二百二十一條至第二百二十七條、第二百二十八條、第二百二十九條、第三百三十二條第二項第二款、第三百三十四條第二項第二款、第三百四十八條第二項第一款及其特別法之罪。"
  },
  {
    "type": "item",
    "number": "二",
    "text": "二、加害人：指觸犯前款各罪經判決有罪確定之人。"
  },
  {
    "type": "item",
    "number": "三",
    "text": "三、被害人：指遭受性侵害或疑似遭受性侵害之人。"
  },
  {
    "type": "item",
    "number": "四",
    "text": "四、專業人士：指因學識、技術、經驗、訓練或教育而就兒童或心智障礙性侵害案件協助詢（訊）問具有專業能力之人。"
  }
]
```

## U04-A3｜第 3 條

本法所稱主管機關：在中央為衛生福利部；在直轄市為直轄市政府；在縣（市）為縣（市）政府。

來源條目欄位（正規化資料）：
- id：article-3
- articleNumber：3
- displayNumber：第 3 條
- title：None
- structureId：chapter-1
- metadata：{"source": "全國法規資料庫 性侵害犯罪防治法（PDF：法規-性侵害犯罪防治法.pdf）", "lastModified": "2023-02-15"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": null,
    "text": "本法所稱主管機關：在中央為衛生福利部；在直轄市為直轄市政府；在縣（市）為縣（市）政府。"
  }
]
```

## U04-A4｜第 4 條

本法所定事項，主管機關及目的事業主管機關權責事項如下：
一、社政主管機關：被害人保護、扶助與定期公布性侵害相關統計資料及其他相關事宜。
二、衛生主管機關：被害人驗傷、採證、身心治療與加害人身心治療、輔導或教育及其他相關事宜。
三、教育主管機關：各級學校、幼兒園性侵害防治教育、被害人與其子女就學權益之維護及其他相關事宜。
四、勞動主管機關：被害人職業訓練、就業服務、勞動權益維護及其他相關事宜。
五、警政主管機關：被害人安全維護、性侵害犯罪調查、資料統計、加害人登記、報到、查訪、查閱及其他相關事宜。
六、法務主管機關：性侵害犯罪偵查、矯正、徒刑執行期間治療及其他相關事宜。
七、移民主管機關：臺灣地區無戶籍國民、外國人、無國籍人民、大陸地區人民、香港或澳門居民因遭受性侵害致逾期停留、居留者，協助其在臺居留或定居權益維護，配合協助辦理後續送返事宜；加害人為臺灣地區無戶籍國民、外國人、大陸地區人民、香港或澳門居民，配合協助辦理後續遣返及其他相關事宜。
八、文化主管機關：出版品違反本法規定之處理及其他相關事宜。
九、通訊傳播主管機關：廣播、電視及其他由該機關依法管理之媒體違反本法規定之處理及其他相關事宜。
十、戶政主管機關：提供被害人與其未成年子女身分、戶籍資料及其他相關事宜。
十一、其他性侵害防治措施，由相關目的事業主管機關依其權責辦理。

來源條目欄位（正規化資料）：
- id：article-4
- articleNumber：4
- displayNumber：第 4 條
- title：None
- structureId：chapter-1
- metadata：{"source": "全國法規資料庫 性侵害犯罪防治法（PDF：法規-性侵害犯罪防治法.pdf）", "lastModified": "2023-02-15"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": null,
    "text": "本法所定事項，主管機關及目的事業主管機關權責事項如下："
  },
  {
    "type": "item",
    "number": "一",
    "text": "一、社政主管機關：被害人保護、扶助與定期公布性侵害相關統計資料及其他相關事宜。"
  },
  {
    "type": "item",
    "number": "二",
    "text": "二、衛生主管機關：被害人驗傷、採證、身心治療與加害人身心治療、輔導或教育及其他相關事宜。"
  },
  {
    "type": "item",
    "number": "三",
    "text": "三、教育主管機關：各級學校、幼兒園性侵害防治教育、被害人與其子女就學權益之維護及其他相關事宜。"
  },
  {
    "type": "item",
    "number": "四",
    "text": "四、勞動主管機關：被害人職業訓練、就業服務、勞動權益維護及其他相關事宜。"
  },
  {
    "type": "item",
    "number": "五",
    "text": "五、警政主管機關：被害人安全維護、性侵害犯罪調查、資料統計、加害人登記、報到、查訪、查閱及其他相關事宜。"
  },
  {
    "type": "item",
    "number": "六",
    "text": "六、法務主管機關：性侵害犯罪偵查、矯正、徒刑執行期間治療及其他相關事宜。"
  },
  {
    "type": "item",
    "number": "七",
    "text": "七、移民主管機關：臺灣地區無戶籍國民、外國人、無國籍人民、大陸地區人民、香港或澳門居民因遭受性侵害致逾期停留、居留者，協助其在臺居留或定居權益維護，配合協助辦理後續送返事宜；加害人為臺灣地區無戶籍國民、外國人、大陸地區人民、香港或澳門居民，配合協助辦理後續遣返及其他相關事宜。"
  },
  {
    "type": "item",
    "number": "八",
    "text": "八、文化主管機關：出版品違反本法規定之處理及其他相關事宜。"
  },
  {
    "type": "item",
    "number": "九",
    "text": "九、通訊傳播主管機關：廣播、電視及其他由該機關依法管理之媒體違反本法規定之處理及其他相關事宜。"
  },
  {
    "type": "item",
    "number": "十",
    "text": "十、戶政主管機關：提供被害人與其未成年子女身分、戶籍資料及其他相關事宜。"
  },
  {
    "type": "item",
    "number": "十一",
    "text": "十一、其他性侵害防治措施，由相關目的事業主管機關依其權責辦理。"
  }
]
```

## U04-A5｜第 5 條

1   中央主管機關應辦理下列事項：
一、規劃、推動、監督與訂定性侵害防治政策及相關法規。
二、督導有關性侵害防治事項之執行。
三、協調各級政府建立性侵害案件處理程序、防治及醫療網絡。
四、推展性侵害防治之宣導及教育。
五、被害人個案資料與加害人身心治療、輔導或教育資料之建立、彙整、統計及管理。
六、其他性侵害防治有關事項。
2   中央主管機關辦理前項事項，應遴聘（派）學者專家、民間團體及相關機關代表提供諮詢；其中學者專家、民間團體代表之人數，不得少於總數二分之一。任一性別人數不得少於總數五分之二。
3   第一項第五款資料之範圍、來源、管理、使用及其他相關事項之辦法，由中央主管機關定之。

來源條目欄位（正規化資料）：
- id：article-5
- articleNumber：5
- displayNumber：第 5 條
- title：None
- structureId：chapter-1
- metadata：{"source": "全國法規資料庫 性侵害犯罪防治法（PDF：法規-性侵害犯罪防治法.pdf）", "lastModified": "2023-02-15"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   中央主管機關應辦理下列事項："
  },
  {
    "type": "item",
    "number": "一",
    "text": "一、規劃、推動、監督與訂定性侵害防治政策及相關法規。"
  },
  {
    "type": "item",
    "number": "二",
    "text": "二、督導有關性侵害防治事項之執行。"
  },
  {
    "type": "item",
    "number": "三",
    "text": "三、協調各級政府建立性侵害案件處理程序、防治及醫療網絡。"
  },
  {
    "type": "item",
    "number": "四",
    "text": "四、推展性侵害防治之宣導及教育。"
  },
  {
    "type": "item",
    "number": "五",
    "text": "五、被害人個案資料與加害人身心治療、輔導或教育資料之建立、彙整、統計及管理。"
  },
  {
    "type": "item",
    "number": "六",
    "text": "六、其他性侵害防治有關事項。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   中央主管機關辦理前項事項，應遴聘（派）學者專家、民間團體及相關機關代表提供諮詢；其中學者專家、民間團體代表之人數，不得少於總數二分之一。任一性別人數不得少於總數五分之二。"
  },
  {
    "type": "paragraph",
    "number": "3",
    "text": "3   第一項第五款資料之範圍、來源、管理、使用及其他相關事項之辦法，由中央主管機關定之。"
  }
]
```

## U04-A6｜第 6 條

1   直轄市、縣（市）主管機關應整合所屬警政、教育、衛生、社政、勞政、新聞、戶政與其他相關機關、單位之業務及人力，設立性侵害防治中心，並協調相關機關辦理下列事項：
一、提供二十四小時電話專線服務。
二、提供被害人二十四小時緊急救援。
三、協助被害人就醫診療、驗傷及採證。
四、協助被害人心理治療、輔導、緊急安置與法律諮詢及服務。
五、協調醫療機構成立專門處理性侵害案件之醫療小組。
六、提供加害人身心治療、輔導或教育。
七、辦理加害人登記、報到、查訪及查閱。
八、轉介加害人接受更生輔導。
九、推廣性侵害防治教育、訓練及宣導。
十、召開加害人再犯預防跨網絡會議。
十一、其他有關性侵害防治及保護事項。
2   前項性侵害防治中心得與家庭暴力防治中心合併設立，並應配置社會工作、警察、衛生及其他相關專業人員；其組織，由直轄市、縣（市）主管機關定之。

來源條目欄位（正規化資料）：
- id：article-6
- articleNumber：6
- displayNumber：第 6 條
- title：None
- structureId：chapter-1
- metadata：{"source": "全國法規資料庫 性侵害犯罪防治法（PDF：法規-性侵害犯罪防治法.pdf）", "lastModified": "2023-02-15"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   直轄市、縣（市）主管機關應整合所屬警政、教育、衛生、社政、勞政、新聞、戶政與其他相關機關、單位之業務及人力，設立性侵害防治中心，並協調相關機關辦理下列事項："
  },
  {
    "type": "item",
    "number": "一",
    "text": "一、提供二十四小時電話專線服務。"
  },
  {
    "type": "item",
    "number": "二",
    "text": "二、提供被害人二十四小時緊急救援。"
  },
  {
    "type": "item",
    "number": "三",
    "text": "三、協助被害人就醫診療、驗傷及採證。"
  },
  {
    "type": "item",
    "number": "四",
    "text": "四、協助被害人心理治療、輔導、緊急安置與法律諮詢及服務。"
  },
  {
    "type": "item",
    "number": "五",
    "text": "五、協調醫療機構成立專門處理性侵害案件之醫療小組。"
  },
  {
    "type": "item",
    "number": "六",
    "text": "六、提供加害人身心治療、輔導或教育。"
  },
  {
    "type": "item",
    "number": "七",
    "text": "七、辦理加害人登記、報到、查訪及查閱。"
  },
  {
    "type": "item",
    "number": "八",
    "text": "八、轉介加害人接受更生輔導。"
  },
  {
    "type": "item",
    "number": "九",
    "text": "九、推廣性侵害防治教育、訓練及宣導。"
  },
  {
    "type": "item",
    "number": "十",
    "text": "十、召開加害人再犯預防跨網絡會議。"
  },
  {
    "type": "item",
    "number": "十一",
    "text": "十一、其他有關性侵害防治及保護事項。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   前項性侵害防治中心得與家庭暴力防治中心合併設立，並應配置社會工作、警察、衛生及其他相關專業人員；其組織，由直轄市、縣（市）主管機關定之。"
  }
]
```

## U04-A7｜第 7 條

1   犯性騷擾防治法第二十五條第一項之罪及犯刑法第三百十九條之二第一項之罪，經判決有罪確定者，準用第三十一條、第三十三條至第三十五條、第四十二條及第四十三條規定。
2   刑法第三百十九條之一至第三百十九條之四案件，準用第八條、第九條、第十二條、第十三條、第十五條、第十六條、第十八條至第二十八條規定。
3   以刑法第三百十九條之一至第三百十九條之三之性影像，犯刑法第三百零四條、第三百零五條、第三百四十六條之罪者，準用第八條、第九條、第十二條、第十五條、第十六條、第十八條至第二十八條規定。

來源條目欄位（正規化資料）：
- id：article-7
- articleNumber：7
- displayNumber：第 7 條
- title：None
- structureId：chapter-1
- metadata：{"source": "全國法規資料庫 性侵害犯罪防治法（PDF：法規-性侵害犯罪防治法.pdf）", "lastModified": "2023-02-15"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   犯性騷擾防治法第二十五條第一項之罪及犯刑法第三百十九條之二第一項之罪，經判決有罪確定者，準用第三十一條、第三十三條至第三十五條、第四十二條及第四十三條規定。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   刑法第三百十九條之一至第三百十九條之四案件，準用第八條、第九條、第十二條、第十三條、第十五條、第十六條、第十八條至第二十八條規定。"
  },
  {
    "type": "paragraph",
    "number": "3",
    "text": "3   以刑法第三百十九條之一至第三百十九條之三之性影像，犯刑法第三百零四條、第三百零五條、第三百四十六條之罪者，準用第八條、第九條、第十二條、第十五條、第十六條、第十八條至第二十八條規定。"
  }
]
```

## U04-A8｜第 8 條

主管機關及目的事業主管機關應就其權責範圍，依性侵害防治之需要，尊重多元文化差異，主動規劃預防、宣導、教育及其他必要措施；對涉及相關機關之防治業務，並應全力配合。

來源條目欄位（正規化資料）：
- id：article-8
- articleNumber：8
- displayNumber：第 8 條
- title：None
- structureId：chapter-2
- metadata：{"source": "全國法規資料庫 性侵害犯罪防治法（PDF：法規-性侵害犯罪防治法.pdf）", "lastModified": "2023-02-15"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": null,
    "text": "主管機關及目的事業主管機關應就其權責範圍，依性侵害防治之需要，尊重多元文化差異，主動規劃預防、宣導、教育及其他必要措施；對涉及相關機關之防治業務，並應全力配合。"
  }
]
```

## U04-A9｜第 9 條

1   高級中等以下學校每學期應實施性侵害防治教育課程，至少二小時。
2   前項性侵害防治教育課程，應包括：
一、他人性自主之尊重。
二、性侵害犯罪之認識。
三、性侵害危機之處理。
四、性侵害防範之技巧。
五、其他與性侵害防治有關之教育。
3   幼兒園應實施性侵害防治教育宣導。
4   機關、部隊、學校、機構或僱用人之組織成員、受僱人或受服務人數達三十人以上者，應定期舉辦或督促所屬人員參與性侵害防治教育訓練。

來源條目欄位（正規化資料）：
- id：article-9
- articleNumber：9
- displayNumber：第 9 條
- title：None
- structureId：chapter-2
- metadata：{"source": "全國法規資料庫 性侵害犯罪防治法（PDF：法規-性侵害犯罪防治法.pdf）", "lastModified": "2023-02-15"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   高級中等以下學校每學期應實施性侵害防治教育課程，至少二小時。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   前項性侵害防治教育課程，應包括："
  },
  {
    "type": "item",
    "number": "一",
    "text": "一、他人性自主之尊重。"
  },
  {
    "type": "item",
    "number": "二",
    "text": "二、性侵害犯罪之認識。"
  },
  {
    "type": "item",
    "number": "三",
    "text": "三、性侵害危機之處理。"
  },
  {
    "type": "item",
    "number": "四",
    "text": "四、性侵害防範之技巧。"
  },
  {
    "type": "item",
    "number": "五",
    "text": "五、其他與性侵害防治有關之教育。"
  },
  {
    "type": "paragraph",
    "number": "3",
    "text": "3   幼兒園應實施性侵害防治教育宣導。"
  },
  {
    "type": "paragraph",
    "number": "4",
    "text": "4   機關、部隊、學校、機構或僱用人之組織成員、受僱人或受服務人數達三十人以上者，應定期舉辦或督促所屬人員參與性侵害防治教育訓練。"
  }
]
```

## U04-A10｜第 10 條

1   法院、檢察署、司法警察機關及醫療機構，應由經專業訓練之專責人員處理性侵害案件。
2   前項經專業訓練之專責人員每年應至少接受性侵害防治專業訓練課程六小時。
3   第一項之機關應適時辦理教育訓練，以充實調查、偵查或審理兒童或心智障礙者性侵害案件之司法警察、司法警察官、檢察事務官、檢察官或法官之辦案專業素養；相關教育訓練至少包含接受兒童或心智障礙者性侵害案件詢（訊）問訓練課程。
4   第一項醫療機構，應經中央主管機關指定，並設置處理性侵害案件醫療小組。

來源條目欄位（正規化資料）：
- id：article-10
- articleNumber：10
- displayNumber：第 10 條
- title：None
- structureId：chapter-2
- metadata：{"source": "全國法規資料庫 性侵害犯罪防治法（PDF：法規-性侵害犯罪防治法.pdf）", "lastModified": "2023-02-15"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   法院、檢察署、司法警察機關及醫療機構，應由經專業訓練之專責人員處理性侵害案件。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   前項經專業訓練之專責人員每年應至少接受性侵害防治專業訓練課程六小時。"
  },
  {
    "type": "paragraph",
    "number": "3",
    "text": "3   第一項之機關應適時辦理教育訓練，以充實調查、偵查或審理兒童或心智障礙者性侵害案件之司法警察、司法警察官、檢察事務官、檢察官或法官之辦案專業素養；相關教育訓練至少包含接受兒童或心智障礙者性侵害案件詢（訊）問訓練課程。"
  },
  {
    "type": "paragraph",
    "number": "4",
    "text": "4   第一項醫療機構，應經中央主管機關指定，並設置處理性侵害案件醫療小組。"
  }
]
```

## U04-A11｜第 11 條

1   醫事人員、社會工作人員、教育人員、保育人員、教保服務人員、警察人員、勞政人員、司法人員、移民業務人員、矯正人員、村（里）幹事人員、私立就業服務機構及其從業人員，於執行職務時，知有疑似性侵害犯罪情事者，應立即向當地直轄市、縣（市）主管機關通報，至遲不得超過二十四小時。
2   前項通報內容、通報人員之姓名、住居所及其他足資識別其身分之資訊，除法律另有規定外，應予保密。
3   直轄市、縣（市）主管機關於接獲第一項通報時，應即派員評估被害人需求及提供服務。

來源條目欄位（正規化資料）：
- id：article-11
- articleNumber：11
- displayNumber：第 11 條
- title：None
- structureId：chapter-2
- metadata：{"source": "全國法規資料庫 性侵害犯罪防治法（PDF：法規-性侵害犯罪防治法.pdf）", "lastModified": "2023-02-15"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   醫事人員、社會工作人員、教育人員、保育人員、教保服務人員、警察人員、勞政人員、司法人員、移民業務人員、矯正人員、村（里）幹事人員、私立就業服務機構及其從業人員，於執行職務時，知有疑似性侵害犯罪情事者，應立即向當地直轄市、縣（市）主管機關通報，至遲不得超過二十四小時。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   前項通報內容、通報人員之姓名、住居所及其他足資識別其身分之資訊，除法律另有規定外，應予保密。"
  },
  {
    "type": "paragraph",
    "number": "3",
    "text": "3   直轄市、縣（市）主管機關於接獲第一項通報時，應即派員評估被害人需求及提供服務。"
  }
]
```

## U04-A12｜第 12 條

直轄市、縣（市）主管機關接獲前條第一項規定之通報後，知悉行為人為兒童或少年者，應依相關法規轉介各該權責機關提供教育、心理諮商或輔導、法律諮詢或其他服務。

來源條目欄位（正規化資料）：
- id：article-12
- articleNumber：12
- displayNumber：第 12 條
- title：None
- structureId：chapter-2
- metadata：{"source": "全國法規資料庫 性侵害犯罪防治法（PDF：法規-性侵害犯罪防治法.pdf）", "lastModified": "2023-02-15"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": null,
    "text": "直轄市、縣（市）主管機關接獲前條第一項規定之通報後，知悉行為人為兒童或少年者，應依相關法規轉介各該權責機關提供教育、心理諮商或輔導、法律諮詢或其他服務。"
  }
]
```

## U04-A13｜第 13 條

1   網際網路平臺提供者、網際網路應用服務提供者及網際網路接取服務提供者，透過網路內容防護機構、主管機關、警察機關或其他機關，知有性侵害犯罪嫌疑情事，應先行限制瀏覽或移除與犯罪有關之網頁資料。
2   前項犯罪網頁資料與嫌疑人之個人資料及網路使用紀錄資料，應保留一百八十日，以提供司法及警察機關調查。

來源條目欄位（正規化資料）：
- id：article-13
- articleNumber：13
- displayNumber：第 13 條
- title：None
- structureId：chapter-2
- metadata：{"source": "全國法規資料庫 性侵害犯罪防治法（PDF：法規-性侵害犯罪防治法.pdf）", "lastModified": "2023-02-15"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   網際網路平臺提供者、網際網路應用服務提供者及網際網路接取服務提供者，透過網路內容防護機構、主管機關、警察機關或其他機關，知有性侵害犯罪嫌疑情事，應先行限制瀏覽或移除與犯罪有關之網頁資料。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   前項犯罪網頁資料與嫌疑人之個人資料及網路使用紀錄資料，應保留一百八十日，以提供司法及警察機關調查。"
  }
]
```

## U04-A14｜第 14 條

1   醫療機構對於被害人，不得無故拒絕診療及開立驗傷診斷書。
2   醫療機構對被害人診療時，應有護理人員陪同，並應保護被害人之隱私，提供安全及合適之就醫環境。
3   第一項驗傷診斷書之格式，由中央主管機關定之。

來源條目欄位（正規化資料）：
- id：article-14
- articleNumber：14
- displayNumber：第 14 條
- title：None
- structureId：chapter-3
- metadata：{"source": "全國法規資料庫 性侵害犯罪防治法（PDF：法規-性侵害犯罪防治法.pdf）", "lastModified": "2023-02-15"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   醫療機構對於被害人，不得無故拒絕診療及開立驗傷診斷書。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   醫療機構對被害人診療時，應有護理人員陪同，並應保護被害人之隱私，提供安全及合適之就醫環境。"
  },
  {
    "type": "paragraph",
    "number": "3",
    "text": "3   第一項驗傷診斷書之格式，由中央主管機關定之。"
  }
]
```

## U04-A15｜第 15 條

1   因職務或業務上知悉或持有被害人姓名、出生年月日、住居所及其他足資識別其身分之資料者，除法律另有規定外，應予保密。
2   警察人員於必要時應採取保護被害人之安全措施。
3   行政機關及司法機關所公示之文書，不得揭露被害人之姓名、出生年月日、住居所及其他足資識別被害人身分之資訊。

來源條目欄位（正規化資料）：
- id：article-15
- articleNumber：15
- displayNumber：第 15 條
- title：None
- structureId：chapter-3
- metadata：{"source": "全國法規資料庫 性侵害犯罪防治法（PDF：法規-性侵害犯罪防治法.pdf）", "lastModified": "2023-02-15"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   因職務或業務上知悉或持有被害人姓名、出生年月日、住居所及其他足資識別其身分之資料者，除法律另有規定外，應予保密。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   警察人員於必要時應採取保護被害人之安全措施。"
  },
  {
    "type": "paragraph",
    "number": "3",
    "text": "3   行政機關及司法機關所公示之文書，不得揭露被害人之姓名、出生年月日、住居所及其他足資識別被害人身分之資訊。"
  }
]
```

## U04-A16｜第 16 條

1   宣傳品、出版品、廣播、電視、網際網路或其他媒體，不得報導或記載有被害人之姓名或其他足資識別身分之資訊。但有下列情形之一者，不在此限：
一、被害人為成年人，經本人同意。但心智障礙者、受監護宣告或輔助宣告者，應以其可理解方式提供資訊。受監護宣告者並應取得其監護人同意。
二、檢察官或法院依法認為有必要。
2   前項第一款但書規定之監護人為同意時，應尊重受監護宣告者之意願。
3   第一項第一款但書所定監護人為該性侵害犯罪嫌疑人或被告時，不得報導或記載有被害人之姓名或其他足資識別身分之資訊。
4   第一項以外之任何人，不得以媒體或其他方法公開或揭露被害人之姓名及其他足資識別身分之資訊。

來源條目欄位（正規化資料）：
- id：article-16
- articleNumber：16
- displayNumber：第 16 條
- title：None
- structureId：chapter-3
- metadata：{"source": "全國法規資料庫 性侵害犯罪防治法（PDF：法規-性侵害犯罪防治法.pdf）", "lastModified": "2023-02-15"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   宣傳品、出版品、廣播、電視、網際網路或其他媒體，不得報導或記載有被害人之姓名或其他足資識別身分之資訊。但有下列情形之一者，不在此限："
  },
  {
    "type": "item",
    "number": "一",
    "text": "一、被害人為成年人，經本人同意。但心智障礙者、受監護宣告或輔助宣告者，應以其可理解方式提供資訊。受監護宣告者並應取得其監護人同意。"
  },
  {
    "type": "item",
    "number": "二",
    "text": "二、檢察官或法院依法認為有必要。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   前項第一款但書規定之監護人為同意時，應尊重受監護宣告者之意願。"
  },
  {
    "type": "paragraph",
    "number": "3",
    "text": "3   第一項第一款但書所定監護人為該性侵害犯罪嫌疑人或被告時，不得報導或記載有被害人之姓名或其他足資識別身分之資訊。"
  },
  {
    "type": "paragraph",
    "number": "4",
    "text": "4   第一項以外之任何人，不得以媒體或其他方法公開或揭露被害人之姓名及其他足資識別身分之資訊。"
  }
]
```

## U04-A17｜第 17 條

1   對於被害人之驗傷及採證，除依刑事訴訟法之規定或被害人無意識或無法表意者外，應經被害人之同意，並依下列規定辦理：
一、被害人為心智障礙者、受監護宣告或輔助宣告者，應以其可理解方式提供資訊。受監護宣告者並應取得其監護人同意。
二、被害人為未滿十二歲者，應經其法定代理人同意。
2   前項第一款之監護人為同意時，應尊重受監護宣告者之意願。
3   第一項第二款之法定代理人同意時，應以兒童之最佳利益為優先考量，並依其心智成熟程度權衡其意見。
4   第一項第一款及第二款所定監護人或法定代理人不明、通知顯有困難或為該性侵害犯罪之嫌疑人時，得逕行驗傷及採證。
5   第一項採證，應將所取得之證物保全於證物袋，司法警察機關應即送請內政部警政署鑑驗。證物鑑驗報告應依法妥善保存。
6   告訴乃論之性侵害犯罪案件，於未提出告訴或自訴前，司法警察機關應將證物送交犯罪發生地之直轄市、縣（市）主管機關保管；除因未能知悉犯罪嫌疑人者外，於保管六個月後得將該證物逕行銷毀。

來源條目欄位（正規化資料）：
- id：article-17
- articleNumber：17
- displayNumber：第 17 條
- title：None
- structureId：chapter-3
- metadata：{"source": "全國法規資料庫 性侵害犯罪防治法（PDF：法規-性侵害犯罪防治法.pdf）", "lastModified": "2023-02-15"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   對於被害人之驗傷及採證，除依刑事訴訟法之規定或被害人無意識或無法表意者外，應經被害人之同意，並依下列規定辦理："
  },
  {
    "type": "item",
    "number": "一",
    "text": "一、被害人為心智障礙者、受監護宣告或輔助宣告者，應以其可理解方式提供資訊。受監護宣告者並應取得其監護人同意。"
  },
  {
    "type": "item",
    "number": "二",
    "text": "二、被害人為未滿十二歲者，應經其法定代理人同意。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   前項第一款之監護人為同意時，應尊重受監護宣告者之意願。"
  },
  {
    "type": "paragraph",
    "number": "3",
    "text": "3   第一項第二款之法定代理人同意時，應以兒童之最佳利益為優先考量，並依其心智成熟程度權衡其意見。"
  },
  {
    "type": "paragraph",
    "number": "4",
    "text": "4   第一項第一款及第二款所定監護人或法定代理人不明、通知顯有困難或為該性侵害犯罪之嫌疑人時，得逕行驗傷及採證。"
  },
  {
    "type": "paragraph",
    "number": "5",
    "text": "5   第一項採證，應將所取得之證物保全於證物袋，司法警察機關應即送請內政部警政署鑑驗。證物鑑驗報告應依法妥善保存。"
  },
  {
    "type": "paragraph",
    "number": "6",
    "text": "6   告訴乃論之性侵害犯罪案件，於未提出告訴或自訴前，司法警察機關應將證物送交犯罪發生地之直轄市、縣（市）主管機關保管；除因未能知悉犯罪嫌疑人者外，於保管六個月後得將該證物逕行銷毀。"
  }
]
```

## U04-A18｜第 18 條

1   被害人之法定代理人、配偶、直系或三親等內旁系血親、家長、家屬、醫師、心理師、輔導人員、社會工作人員或其信賴之人，經被害人同意後，得於偵查或審判時，陪同被害人在場，並得陳述意見。
2   前項得陪同在場之人為性侵害犯罪嫌疑人、被告，或檢察官、檢察事務官、司法警察官或司法警察認其在場，有礙偵查程序之進行時，不適用之。
3   被害人為兒童或少年時，除顯無必要者外，直轄市、縣（市）主管機關應指派社會工作人員於偵查或審判時陪同在場，並得陳述意見。

來源條目欄位（正規化資料）：
- id：article-18
- articleNumber：18
- displayNumber：第 18 條
- title：None
- structureId：chapter-3
- metadata：{"source": "全國法規資料庫 性侵害犯罪防治法（PDF：法規-性侵害犯罪防治法.pdf）", "lastModified": "2023-02-15"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   被害人之法定代理人、配偶、直系或三親等內旁系血親、家長、家屬、醫師、心理師、輔導人員、社會工作人員或其信賴之人，經被害人同意後，得於偵查或審判時，陪同被害人在場，並得陳述意見。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   前項得陪同在場之人為性侵害犯罪嫌疑人、被告，或檢察官、檢察事務官、司法警察官或司法警察認其在場，有礙偵查程序之進行時，不適用之。"
  },
  {
    "type": "paragraph",
    "number": "3",
    "text": "3   被害人為兒童或少年時，除顯無必要者外，直轄市、縣（市）主管機關應指派社會工作人員於偵查或審判時陪同在場，並得陳述意見。"
  }
]
```

## U04-A19｜第 19 條

1   兒童或心智障礙之被害人於偵查或審判中，經司法警察、司法警察官、檢察事務官、檢察官或法官認有必要時，應由具相關專業人士在場協助詢（訊）問。
2   前項專業人士應於詢（訊）問前，評估被害人之溝通能力及需求，並向司法警察、司法警察官、檢察事務官、檢察官或法官說明其評估之結果及相關建議。
3   專業人士依第一項規定協助詢（訊）問時，如司法警察、司法警察官、檢察事務官、檢察官、法官、被告或其辯護人提出不適當問題或被害人無法適當回答之問題，專業人士得為適當建議。必要時，偵查中經司法警察、司法警察官、檢察事務官或檢察官之許可，審判中經法官之許可，得由專業人士直接對被害人進行詢問。
4   專業人士於協助詢（訊）問時，司法警察、司法警察官、檢察事務官、檢察官、法官、被告或其辯護人，得透過單面鏡、聲音影像相互傳送之科技設備，或適當隔離措施為之。
5   偵查或審判中，兒童或心智障礙被害人受專業人士評估及專業人士直接對被害人進行詢問之過程，應全程錄音錄影。

來源條目欄位（正規化資料）：
- id：article-19
- articleNumber：19
- displayNumber：第 19 條
- title：None
- structureId：chapter-3
- metadata：{"source": "全國法規資料庫 性侵害犯罪防治法（PDF：法規-性侵害犯罪防治法.pdf）", "lastModified": "2023-02-15"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   兒童或心智障礙之被害人於偵查或審判中，經司法警察、司法警察官、檢察事務官、檢察官或法官認有必要時，應由具相關專業人士在場協助詢（訊）問。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   前項專業人士應於詢（訊）問前，評估被害人之溝通能力及需求，並向司法警察、司法警察官、檢察事務官、檢察官或法官說明其評估之結果及相關建議。"
  },
  {
    "type": "paragraph",
    "number": "3",
    "text": "3   專業人士依第一項規定協助詢（訊）問時，如司法警察、司法警察官、檢察事務官、檢察官、法官、被告或其辯護人提出不適當問題或被害人無法適當回答之問題，專業人士得為適當建議。必要時，偵查中經司法警察、司法警察官、檢察事務官或檢察官之許可，審判中經法官之許可，得由專業人士直接對被害人進行詢問。"
  },
  {
    "type": "paragraph",
    "number": "4",
    "text": "4   專業人士於協助詢（訊）問時，司法警察、司法警察官、檢察事務官、檢察官、法官、被告或其辯護人，得透過單面鏡、聲音影像相互傳送之科技設備，或適當隔離措施為之。"
  },
  {
    "type": "paragraph",
    "number": "5",
    "text": "5   偵查或審判中，兒童或心智障礙被害人受專業人士評估及專業人士直接對被害人進行詢問之過程，應全程錄音錄影。"
  }
]
```

## U04-A20｜第 20 條

1   前條專業人士辦理協助詢（訊）問事務，依其性質，準用刑事訴訟法第十二章第二節、第三節規定。
2   前條專業人士之資格、條件、酬勞支給、提出說明或建議方式及其他相關事項之辦法，由中央主管機關會商相關機關定之。

來源條目欄位（正規化資料）：
- id：article-20
- articleNumber：20
- displayNumber：第 20 條
- title：None
- structureId：chapter-3
- metadata：{"source": "全國法規資料庫 性侵害犯罪防治法（PDF：法規-性侵害犯罪防治法.pdf）", "lastModified": "2023-02-15"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   前條專業人士辦理協助詢（訊）問事務，依其性質，準用刑事訴訟法第十二章第二節、第三節規定。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   前條專業人士之資格、條件、酬勞支給、提出說明或建議方式及其他相關事項之辦法，由中央主管機關會商相關機關定之。"
  }
]
```

## U04-A21｜第 21 條

前二條規定，於少年保護事件及少年刑事案件之被害人為兒童或心智障礙者時，準用之。

來源條目欄位（正規化資料）：
- id：article-21
- articleNumber：21
- displayNumber：第 21 條
- title：None
- structureId：chapter-3
- metadata：{"source": "全國法規資料庫 性侵害犯罪防治法（PDF：法規-性侵害犯罪防治法.pdf）", "lastModified": "2023-02-15"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": null,
    "text": "前二條規定，於少年保護事件及少年刑事案件之被害人為兒童或心智障礙者時，準用之。"
  }
]
```

## U04-A22｜第 22 條

犯罪嫌疑人、被告或少年事件之少年為心智障礙者，於刑事案件偵查、審判程序或少年事件處理程序中，除適用刑事訴訟法或少年事件處理法有關規定外，認有必要時，得準用第十九條規定。

來源條目欄位（正規化資料）：
- id：article-22
- articleNumber：22
- displayNumber：第 22 條
- title：None
- structureId：chapter-3
- metadata：{"source": "全國法規資料庫 性侵害犯罪防治法（PDF：法規-性侵害犯罪防治法.pdf）", "lastModified": "2023-02-15"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": null,
    "text": "犯罪嫌疑人、被告或少年事件之少年為心智障礙者，於刑事案件偵查、審判程序或少年事件處理程序中，除適用刑事訴訟法或少年事件處理法有關規定外，認有必要時，得準用第十九條規定。"
  }
]
```

## U04-A23｜第 23 條

1   法院對被害人之訊問或詰問，得依聲請或依職權於法庭外為之，或利用聲音、影像傳送之科技設備或其他適當隔離措施，將被害人與被告或法官隔離。
2   傳喚到庭作證之被害人為兒童、少年或心智障礙、身心創傷者，其因當庭詰問致有不能自由或完全陳述之虞時，法院應採取前項之隔離措施。
3   法院因當事人或辯護人詰問被害人不當而禁止其詰問者，得以訊問代之。
4   被告或其辯護人不得詰問或提出有關被害人與被告以外之人之性經驗證據。但法院認有必要者，不在此限。

來源條目欄位（正規化資料）：
- id：article-23
- articleNumber：23
- displayNumber：第 23 條
- title：None
- structureId：chapter-3
- metadata：{"source": "全國法規資料庫 性侵害犯罪防治法（PDF：法規-性侵害犯罪防治法.pdf）", "lastModified": "2023-02-15"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   法院對被害人之訊問或詰問，得依聲請或依職權於法庭外為之，或利用聲音、影像傳送之科技設備或其他適當隔離措施，將被害人與被告或法官隔離。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   傳喚到庭作證之被害人為兒童、少年或心智障礙、身心創傷者，其因當庭詰問致有不能自由或完全陳述之虞時，法院應採取前項之隔離措施。"
  },
  {
    "type": "paragraph",
    "number": "3",
    "text": "3   法院因當事人或辯護人詰問被害人不當而禁止其詰問者，得以訊問代之。"
  },
  {
    "type": "paragraph",
    "number": "4",
    "text": "4   被告或其辯護人不得詰問或提出有關被害人與被告以外之人之性經驗證據。但法院認有必要者，不在此限。"
  }
]
```

## U04-A24｜第 24 條

偵查或審判時，檢察官或法院得依職權或依聲請指定或選任相關領域之專家證人，提供專業意見。其經傳喚到庭陳述之意見，得為證據，並準用刑事訴訟法第一百六十三條至第一百七十一條、第一百七十五條及第一百九十九條規定。

來源條目欄位（正規化資料）：
- id：article-24
- articleNumber：24
- displayNumber：第 24 條
- title：None
- structureId：chapter-3
- metadata：{"source": "全國法規資料庫 性侵害犯罪防治法（PDF：法規-性侵害犯罪防治法.pdf）", "lastModified": "2023-02-15"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": null,
    "text": "偵查或審判時，檢察官或法院得依職權或依聲請指定或選任相關領域之專家證人，提供專業意見。其經傳喚到庭陳述之意見，得為證據，並準用刑事訴訟法第一百六十三條至第一百七十一條、第一百七十五條及第一百九十九條規定。"
  }
]
```

## U04-A25｜第 25 條

被告或其辯護人於審判時，對被害人有任何性別歧視之陳述或舉止者，法院應即時予以制止。

來源條目欄位（正規化資料）：
- id：article-25
- articleNumber：25
- displayNumber：第 25 條
- title：None
- structureId：chapter-3
- metadata：{"source": "全國法規資料庫 性侵害犯罪防治法（PDF：法規-性侵害犯罪防治法.pdf）", "lastModified": "2023-02-15"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": null,
    "text": "被告或其辯護人於審判時，對被害人有任何性別歧視之陳述或舉止者，法院應即時予以制止。"
  }
]
```

## U04-A26｜第 26 條

1   被害人於審判時有下列情形之一，其於檢察事務官、司法警察官或司法警察調查時所為之陳述，經證明具有可信之特別情況，且為證明犯罪事實之存否所必要者，得為證據：
一、因性侵害致身心創傷無法陳述。
二、因身心壓力於訊問或詰問時無法為完全陳述或拒絕陳述。
三、依第十九條規定接受詢（訊）問之陳述。
2   被害人於偵查中，依第十九條第三項後段規定接受專業人士直接詢問所為之陳述，除顯有不可信之情況外，得為證據。

來源條目欄位（正規化資料）：
- id：article-26
- articleNumber：26
- displayNumber：第 26 條
- title：None
- structureId：chapter-3
- metadata：{"source": "全國法規資料庫 性侵害犯罪防治法（PDF：法規-性侵害犯罪防治法.pdf）", "lastModified": "2023-02-15"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   被害人於審判時有下列情形之一，其於檢察事務官、司法警察官或司法警察調查時所為之陳述，經證明具有可信之特別情況，且為證明犯罪事實之存否所必要者，得為證據："
  },
  {
    "type": "item",
    "number": "一",
    "text": "一、因性侵害致身心創傷無法陳述。"
  },
  {
    "type": "item",
    "number": "二",
    "text": "二、因身心壓力於訊問或詰問時無法為完全陳述或拒絕陳述。"
  },
  {
    "type": "item",
    "number": "三",
    "text": "三、依第十九條規定接受詢（訊）問之陳述。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   被害人於偵查中，依第十九條第三項後段規定接受專業人士直接詢問所為之陳述，除顯有不可信之情況外，得為證據。"
  }
]
```

## U04-A27｜第 27 條

1   性侵害犯罪之案件，審判不得公開。但被害人為成年人，經本人同意，且法院認有必要者，不在此限。
2   前項被害人為心智障礙者、受監護宣告或輔助宣告者，應以其可理解方式提供資訊，受監護宣告者並應取得其監護人同意。監護人為同意時，應尊重受監護宣告者之意願。
3   第二項所定監護人為該性侵害犯罪之被告時，審判不得公開。

來源條目欄位（正規化資料）：
- id：article-27
- articleNumber：27
- displayNumber：第 27 條
- title：None
- structureId：chapter-3
- metadata：{"source": "全國法規資料庫 性侵害犯罪防治法（PDF：法規-性侵害犯罪防治法.pdf）", "lastModified": "2023-02-15"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   性侵害犯罪之案件，審判不得公開。但被害人為成年人，經本人同意，且法院認有必要者，不在此限。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   前項被害人為心智障礙者、受監護宣告或輔助宣告者，應以其可理解方式提供資訊，受監護宣告者並應取得其監護人同意。監護人為同意時，應尊重受監護宣告者之意願。"
  },
  {
    "type": "paragraph",
    "number": "3",
    "text": "3   第二項所定監護人為該性侵害犯罪之被告時，審判不得公開。"
  }
]
```

## U04-A28｜第 28 條

1   直轄市、縣（市）主管機關得依被害人之申請，核發下列補助：
一、非屬全民健康保險給付範圍之醫療費用、驗傷與採證費用及心理復健費用。
二、訴訟費用及律師費用。
三、其他費用。
2   前項補助對象、條件、金額及其他相關事項之自治法規，由直轄市、縣（市）主管機關定之。

來源條目欄位（正規化資料）：
- id：article-28
- articleNumber：28
- displayNumber：第 28 條
- title：None
- structureId：chapter-3
- metadata：{"source": "全國法規資料庫 性侵害犯罪防治法（PDF：法規-性侵害犯罪防治法.pdf）", "lastModified": "2023-02-15"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   直轄市、縣（市）主管機關得依被害人之申請，核發下列補助："
  },
  {
    "type": "item",
    "number": "一",
    "text": "一、非屬全民健康保險給付範圍之醫療費用、驗傷與採證費用及心理復健費用。"
  },
  {
    "type": "item",
    "number": "二",
    "text": "二、訴訟費用及律師費用。"
  },
  {
    "type": "item",
    "number": "三",
    "text": "三、其他費用。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   前項補助對象、條件、金額及其他相關事項之自治法規，由直轄市、縣（市）主管機關定之。"
  }
]
```

## U04-A29｜第 29 條

1   加害人應接受司法警察機關對其照相、採取指紋及採樣去氧核醣核酸，不得拒絕。
2   中央警政主管機關應建立加害人之相片、指紋、去氧核醣核酸紀錄及個人基本資料。
3   前項資料應予保密，非依法律規定，不得提供。
4   第一項照相、採取指紋、採樣去氧核醣核酸之方式與第二項資料之內容、管理及其他相關事項之辦法，由中央警政主管機關定之。

來源條目欄位（正規化資料）：
- id：article-29
- articleNumber：29
- displayNumber：第 29 條
- title：None
- structureId：chapter-4
- metadata：{"source": "全國法規資料庫 性侵害犯罪防治法（PDF：法規-性侵害犯罪防治法.pdf）", "lastModified": "2023-02-15"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   加害人應接受司法警察機關對其照相、採取指紋及採樣去氧核醣核酸，不得拒絕。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   中央警政主管機關應建立加害人之相片、指紋、去氧核醣核酸紀錄及個人基本資料。"
  },
  {
    "type": "paragraph",
    "number": "3",
    "text": "3   前項資料應予保密，非依法律規定，不得提供。"
  },
  {
    "type": "paragraph",
    "number": "4",
    "text": "4   第一項照相、採取指紋、採樣去氧核醣核酸之方式與第二項資料之內容、管理及其他相關事項之辦法，由中央警政主管機關定之。"
  }
]
```

## U04-A30｜第 30 條

為防治跨國性侵害犯罪，中央目的事業主管機關必要時，得依法律、條約、協定或協議，提供加害人之個人資料。

來源條目欄位（正規化資料）：
- id：article-30
- articleNumber：30
- displayNumber：第 30 條
- title：None
- structureId：chapter-4
- metadata：{"source": "全國法規資料庫 性侵害犯罪防治法（PDF：法規-性侵害犯罪防治法.pdf）", "lastModified": "2023-02-15"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": null,
    "text": "為防治跨國性侵害犯罪，中央目的事業主管機關必要時，得依法律、條約、協定或協議，提供加害人之個人資料。"
  }
]
```

## U04-A31｜第 31 條

1   加害人有下列情形之一，經評估認有施以身心治療、輔導或教育之必要者，直轄市、縣（市）主管機關應令其接受身心治療、輔導或教育：
一、有期徒刑、保安處分或第三十七條、第三十八條所定之強制治療執行完畢。但有期徒刑經易服社會勞動者，於准易服社會勞動時起執行之。
二、假釋。
三、緩刑。
四、免刑。
五、赦免。
六、經法院依第三十八條第一項但書及第六項規定或刑法第九十一條之一第二項但書規定裁定停止強制治療。
2   前項規定，對於犯罪後經驅逐或限令出境者，不適用之。
3   第一項之執行期間為三年以下。執行期間屆滿前，經評估認有繼續執行之必要者，直轄市、縣（市）主管機關得延長之，最長不得逾一年；其無繼續執行之必要者，得停止其處分之執行。
4   前項經評估認無繼續執行之必要者，於其登記、報到期間，經評估認有施以身心治療、輔導或教育之必要，直轄市、縣（市）主管機關應令其再接受身心治療、輔導或教育；其執行期間應予併計，且不得逾前項執行期間之規定。
5   犯性騷擾防治法第二十五條第一項之罪經判處拘役或罰金確定，依第七條第一項準用本條第一項規定，於判決確定時執行之。
6   第一項至第三項規定對於有性侵害犯罪行為，經法院依少年事件處理法裁定保護處分確定且認有必要者，得準用之。

來源條目欄位（正規化資料）：
- id：article-31
- articleNumber：31
- displayNumber：第 31 條
- title：None
- structureId：chapter-4
- metadata：{"source": "全國法規資料庫 性侵害犯罪防治法（PDF：法規-性侵害犯罪防治法.pdf）", "lastModified": "2023-02-15"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   加害人有下列情形之一，經評估認有施以身心治療、輔導或教育之必要者，直轄市、縣（市）主管機關應令其接受身心治療、輔導或教育："
  },
  {
    "type": "item",
    "number": "一",
    "text": "一、有期徒刑、保安處分或第三十七條、第三十八條所定之強制治療執行完畢。但有期徒刑經易服社會勞動者，於准易服社會勞動時起執行之。"
  },
  {
    "type": "item",
    "number": "二",
    "text": "二、假釋。"
  },
  {
    "type": "item",
    "number": "三",
    "text": "三、緩刑。"
  },
  {
    "type": "item",
    "number": "四",
    "text": "四、免刑。"
  },
  {
    "type": "item",
    "number": "五",
    "text": "五、赦免。"
  },
  {
    "type": "item",
    "number": "六",
    "text": "六、經法院依第三十八條第一項但書及第六項規定或刑法第九十一條之一第二項但書規定裁定停止強制治療。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   前項規定，對於犯罪後經驅逐或限令出境者，不適用之。"
  },
  {
    "type": "paragraph",
    "number": "3",
    "text": "3   第一項之執行期間為三年以下。執行期間屆滿前，經評估認有繼續執行之必要者，直轄市、縣（市）主管機關得延長之，最長不得逾一年；其無繼續執行之必要者，得停止其處分之執行。"
  },
  {
    "type": "paragraph",
    "number": "4",
    "text": "4   前項經評估認無繼續執行之必要者，於其登記、報到期間，經評估認有施以身心治療、輔導或教育之必要，直轄市、縣（市）主管機關應令其再接受身心治療、輔導或教育；其執行期間應予併計，且不得逾前項執行期間之規定。"
  },
  {
    "type": "paragraph",
    "number": "5",
    "text": "5   犯性騷擾防治法第二十五條第一項之罪經判處拘役或罰金確定，依第七條第一項準用本條第一項規定，於判決確定時執行之。"
  },
  {
    "type": "paragraph",
    "number": "6",
    "text": "6   第一項至第三項規定對於有性侵害犯罪行為，經法院依少年事件處理法裁定保護處分確定且認有必要者，得準用之。"
  }
]
```

## U04-A32｜第 32 條

性侵害犯罪經緩起訴處分確定者，經直轄市、縣（市）主管機關評估小組評估認有施以身心治療、輔導或教育之必要，應令其接受身心治療、輔導或教育。

來源條目欄位（正規化資料）：
- id：article-32
- articleNumber：32
- displayNumber：第 32 條
- title：None
- structureId：chapter-4
- metadata：{"source": "全國法規資料庫 性侵害犯罪防治法（PDF：法規-性侵害犯罪防治法.pdf）", "lastModified": "2023-02-15"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": null,
    "text": "性侵害犯罪經緩起訴處分確定者，經直轄市、縣（市）主管機關評估小組評估認有施以身心治療、輔導或教育之必要，應令其接受身心治療、輔導或教育。"
  }
]
```

## U04-A33｜第 33 條

1   第三十一條第一項、第三項至第六項及前條之評估，由直轄市、縣（市）主管機關成立評估小組辦理。但服徒刑之成年受刑人由監獄、少年受刑人及受感化教育少年由少年矯正學校成立評估小組辦理。
2   前項評估小組之組成與其辦理第三十一條第一項、第三項、第四項及前條評估之內容、基準、程序與身心治療、輔導或教育之內容、程序、期間及其他相關事項之辦法，由中央主管機關會同法務主管機關定之。

來源條目欄位（正規化資料）：
- id：article-33
- articleNumber：33
- displayNumber：第 33 條
- title：None
- structureId：chapter-4
- metadata：{"source": "全國法規資料庫 性侵害犯罪防治法（PDF：法規-性侵害犯罪防治法.pdf）", "lastModified": "2023-02-15"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   第三十一條第一項、第三項至第六項及前條之評估，由直轄市、縣（市）主管機關成立評估小組辦理。但服徒刑之成年受刑人由監獄、少年受刑人及受感化教育少年由少年矯正學校成立評估小組辦理。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   前項評估小組之組成與其辦理第三十一條第一項、第三項、第四項及前條評估之內容、基準、程序與身心治療、輔導或教育之內容、程序、期間及其他相關事項之辦法，由中央主管機關會同法務主管機關定之。"
  }
]
```

## U04-A34｜第 34 條

1   觀護人對於付保護管束之加害人，得採取下列一款或數款之處遇方式：
一、實施約談、訪視，並得進行團體活動或問卷等輔助行為。
二、有事實足認其有再犯之虞或需加強輔導及管束者，得密集實施約談、訪視；必要時，並得請警察機關派員定期或不定期查訪。
三、有事實可疑為施用毒品者，得命其接受尿液採驗。
四、無一定之居住處所，或其居住處所不利保護管束之執行者，得報請檢察官許可，命其居住於指定之處所。
五、有於特定時間犯罪之習性，或有事實足認其有再犯之虞時，得報請檢察官許可，命其於監控時段內，未經許可，不得外出。
六、報請檢察官許可，對其實施測謊。
七、報請檢察官許可，對其實施科技設備監控。
八、有固定犯罪模式，或有事實足認其有再犯之虞時，得報請檢察官許可，禁止其接近特定場所或對象。
九、轉介相關機構或團體為適當處遇。
十、其他必要處遇。
2   少年保護官對於依第三十一條第六項規定接受身心治療、輔導或教育之少年，除前項第四款至第八款外，於與少年保護事件性質不相違反者，得採取前項一款或數款之處遇方式。
3   第一項第三款尿液採驗之執行方式、程序、期間、次數、檢驗機構、項目及其他相關事項之辦法；第六款之測謊、第七款之科技設備監控，其實施機關（構）、人員、方式、程序及其他相關事項之辦法，由法務主管機關會商相關機關定之。

來源條目欄位（正規化資料）：
- id：article-34
- articleNumber：34
- displayNumber：第 34 條
- title：None
- structureId：chapter-4
- metadata：{"source": "全國法規資料庫 性侵害犯罪防治法（PDF：法規-性侵害犯罪防治法.pdf）", "lastModified": "2023-02-15"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   觀護人對於付保護管束之加害人，得採取下列一款或數款之處遇方式："
  },
  {
    "type": "item",
    "number": "一",
    "text": "一、實施約談、訪視，並得進行團體活動或問卷等輔助行為。"
  },
  {
    "type": "item",
    "number": "二",
    "text": "二、有事實足認其有再犯之虞或需加強輔導及管束者，得密集實施約談、訪視；必要時，並得請警察機關派員定期或不定期查訪。"
  },
  {
    "type": "item",
    "number": "三",
    "text": "三、有事實可疑為施用毒品者，得命其接受尿液採驗。"
  },
  {
    "type": "item",
    "number": "四",
    "text": "四、無一定之居住處所，或其居住處所不利保護管束之執行者，得報請檢察官許可，命其居住於指定之處所。"
  },
  {
    "type": "item",
    "number": "五",
    "text": "五、有於特定時間犯罪之習性，或有事實足認其有再犯之虞時，得報請檢察官許可，命其於監控時段內，未經許可，不得外出。"
  },
  {
    "type": "item",
    "number": "六",
    "text": "六、報請檢察官許可，對其實施測謊。"
  },
  {
    "type": "item",
    "number": "七",
    "text": "七、報請檢察官許可，對其實施科技設備監控。"
  },
  {
    "type": "item",
    "number": "八",
    "text": "八、有固定犯罪模式，或有事實足認其有再犯之虞時，得報請檢察官許可，禁止其接近特定場所或對象。"
  },
  {
    "type": "item",
    "number": "九",
    "text": "九、轉介相關機構或團體為適當處遇。"
  },
  {
    "type": "item",
    "number": "十",
    "text": "十、其他必要處遇。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   少年保護官對於依第三十一條第六項規定接受身心治療、輔導或教育之少年，除前項第四款至第八款外，於與少年保護事件性質不相違反者，得採取前項一款或數款之處遇方式。"
  },
  {
    "type": "paragraph",
    "number": "3",
    "text": "3   第一項第三款尿液採驗之執行方式、程序、期間、次數、檢驗機構、項目及其他相關事項之辦法；第六款之測謊、第七款之科技設備監控，其實施機關（構）、人員、方式、程序及其他相關事項之辦法，由法務主管機關會商相關機關定之。"
  }
]
```

## U04-A35｜第 35 條

前條付保護管束且經實施科技設備監控之加害人，故意拆除、損壞、隱匿、阻斷科技監控設備，經檢察署通報警察機關，司法警察官或司法警察得強制其到檢察署或檢察官指定之處所，由檢察署派員回復科技監控設備正常運作，相關機關並依法令規定為後續處理。

來源條目欄位（正規化資料）：
- id：article-35
- articleNumber：35
- displayNumber：第 35 條
- title：None
- structureId：chapter-4
- metadata：{"source": "全國法規資料庫 性侵害犯罪防治法（PDF：法規-性侵害犯罪防治法.pdf）", "lastModified": "2023-02-15"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": null,
    "text": "前條付保護管束且經實施科技設備監控之加害人，故意拆除、損壞、隱匿、阻斷科技監控設備，經檢察署通報警察機關，司法警察官或司法警察得強制其到檢察署或檢察官指定之處所，由檢察署派員回復科技監控設備正常運作，相關機關並依法令規定為後續處理。"
  }
]
```

## U04-A36｜第 36 條

加害人依第三十一條第一項及第四項接受身心治療、輔導或教育，經第三十三條評估小組評估認有再犯之風險者，直轄市、縣（市）主管機關得檢具相關評估報告，送請檢察官依刑法第九十一條之一規定聲請強制治療或繼續施以強制治療。

來源條目欄位（正規化資料）：
- id：article-36
- articleNumber：36
- displayNumber：第 36 條
- title：None
- structureId：chapter-4
- metadata：{"source": "全國法規資料庫 性侵害犯罪防治法（PDF：法規-性侵害犯罪防治法.pdf）", "lastModified": "2023-02-15"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": null,
    "text": "加害人依第三十一條第一項及第四項接受身心治療、輔導或教育，經第三十三條評估小組評估認有再犯之風險者，直轄市、縣（市）主管機關得檢具相關評估報告，送請檢察官依刑法第九十一條之一規定聲請強制治療或繼續施以強制治療。"
  }
]
```

## U04-A37｜第 37 條

1   加害人於徒刑執行期滿前，接受身心治療、輔導或教育後，經矯正機關評估小組評估認有再犯之風險，而不適用刑法第九十一條之一規定者，矯正機關得檢具相關評估報告，送請檢察官聲請法院裁定命其進入醫療機構或其他指定處所，施以強制治療。
2   加害人依第三十一條第一項及第四項接受身心治療、輔導或教育後，經評估認有再犯之風險，而不適用刑法第九十一條之一規定者，由檢察官或直轄市、縣（市）主管機關檢具相關評估報告聲請法院裁定命其進入醫療機構或其他指定處所，施以強制治療。
3   依前二項規定經法院裁定施以強制治療之加害人，於徒刑執行期滿或接獲法院裁定後，直轄市、縣（市）主管機關應逕移強制治療處所接續治療，必要時得協調相關機關協助移送。

來源條目欄位（正規化資料）：
- id：article-37
- articleNumber：37
- displayNumber：第 37 條
- title：None
- structureId：chapter-4
- metadata：{"source": "全國法規資料庫 性侵害犯罪防治法（PDF：法規-性侵害犯罪防治法.pdf）", "lastModified": "2023-02-15"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   加害人於徒刑執行期滿前，接受身心治療、輔導或教育後，經矯正機關評估小組評估認有再犯之風險，而不適用刑法第九十一條之一規定者，矯正機關得檢具相關評估報告，送請檢察官聲請法院裁定命其進入醫療機構或其他指定處所，施以強制治療。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   加害人依第三十一條第一項及第四項接受身心治療、輔導或教育後，經評估認有再犯之風險，而不適用刑法第九十一條之一規定者，由檢察官或直轄市、縣（市）主管機關檢具相關評估報告聲請法院裁定命其進入醫療機構或其他指定處所，施以強制治療。"
  },
  {
    "type": "paragraph",
    "number": "3",
    "text": "3   依前二項規定經法院裁定施以強制治療之加害人，於徒刑執行期滿或接獲法院裁定後，直轄市、縣（市）主管機關應逕移強制治療處所接續治療，必要時得協調相關機關協助移送。"
  }
]
```

## U04-A38｜第 38 條

1   前條強制治療之執行期間為五年以下；其執行期間屆滿前，經評估認其再犯風險未顯著降低，而有繼續強制治療之必要者，檢察官或直轄市、縣（市）主管機關得向法院聲請許可延長之，第一次延長期間為三年以下，第二次以後每次延長期間為一年以下。但執行中，檢察官或直轄市、縣（市）主管機關認無繼續執行之必要者，得向法院聲請裁定停止強制治療。
2   停止強制治療之執行後有前條第一項或第二項情形之一者，法院得令入相當處所，繼續施以強制治療。
3   前項強制治療之期間，應與停止強制治療前已執行之期間合併計算。
4   前三項執行或延長期間內，應每年至少評估一次有無繼續強制治療之必要。
5   強制治療處所應於第一項之執行或延長期間屆滿前三個月，檢具治療、評估等結果通知強制治療受處分人及檢察官或直轄市、縣（市）主管機關。
6   強制治療受處分人於收受前項通知後，得自行向法院聲請裁定停止強制治療之執行。
7   直轄市、縣（市）主管機關於收受第五項通知後，認強制治療受處分人無繼續強制治療之必要，或收受第一項但書或前項停止強制治療執行之裁定後，應召開轉銜會議，安排強制治療受處分人身心治療、輔導或教育及登記、報到事宜，並提供就學、就業、家庭支持及其他照顧服務。

來源條目欄位（正規化資料）：
- id：article-38
- articleNumber：38
- displayNumber：第 38 條
- title：None
- structureId：chapter-4
- metadata：{"source": "全國法規資料庫 性侵害犯罪防治法（PDF：法規-性侵害犯罪防治法.pdf）", "lastModified": "2023-02-15"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   前條強制治療之執行期間為五年以下；其執行期間屆滿前，經評估認其再犯風險未顯著降低，而有繼續強制治療之必要者，檢察官或直轄市、縣（市）主管機關得向法院聲請許可延長之，第一次延長期間為三年以下，第二次以後每次延長期間為一年以下。但執行中，檢察官或直轄市、縣（市）主管機關認無繼續執行之必要者，得向法院聲請裁定停止強制治療。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   停止強制治療之執行後有前條第一項或第二項情形之一者，法院得令入相當處所，繼續施以強制治療。"
  },
  {
    "type": "paragraph",
    "number": "3",
    "text": "3   前項強制治療之期間，應與停止強制治療前已執行之期間合併計算。"
  },
  {
    "type": "paragraph",
    "number": "4",
    "text": "4   前三項執行或延長期間內，應每年至少評估一次有無繼續強制治療之必要。"
  },
  {
    "type": "paragraph",
    "number": "5",
    "text": "5   強制治療處所應於第一項之執行或延長期間屆滿前三個月，檢具治療、評估等結果通知強制治療受處分人及檢察官或直轄市、縣（市）主管機關。"
  },
  {
    "type": "paragraph",
    "number": "6",
    "text": "6   強制治療受處分人於收受前項通知後，得自行向法院聲請裁定停止強制治療之執行。"
  },
  {
    "type": "paragraph",
    "number": "7",
    "text": "7   直轄市、縣（市）主管機關於收受第五項通知後，認強制治療受處分人無繼續強制治療之必要，或收受第一項但書或前項停止強制治療執行之裁定後，應召開轉銜會議，安排強制治療受處分人身心治療、輔導或教育及登記、報到事宜，並提供就學、就業、家庭支持及其他照顧服務。"
  }
]
```

## U04-A39｜第 39 條

前三條強制治療之聲請、停止與延長程序、執行機關（構）、處所、執行程序、方式、經費來源、評估小組之組成及其他相關事項之辦法，由法務主管機關會同中央主管機關定之。

來源條目欄位（正規化資料）：
- id：article-39
- articleNumber：39
- displayNumber：第 39 條
- title：None
- structureId：chapter-4
- metadata：{"source": "全國法規資料庫 性侵害犯罪防治法（PDF：法規-性侵害犯罪防治法.pdf）", "lastModified": "2023-02-15"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": null,
    "text": "前三條強制治療之聲請、停止與延長程序、執行機關（構）、處所、執行程序、方式、經費來源、評估小組之組成及其他相關事項之辦法，由法務主管機關會同中央主管機關定之。"
  }
]
```

## U04-A40｜第 40 條

1   第三十七條及第三十八條之聲請、停止、延長及裁定事項，除本法另有規定外，準用刑事訴訟法相關規定。
2   加害人有下列情形之一，且未經選任辯護人者，法院應指定公設辯護人或律師為其辯護，並準用刑事訴訟法第三十一條第二項及第四項規定：
一、身心障礙，致無法為完全之陳述。
二、其他經法院認有必要。
3   刑事訴訟法第三十五條規定，於前項情形，準用之。
4   法院受理第三十七條及第三十八條之聲請，除顯無必要者外，應指定期日傳喚加害人，並通知聲請人、辯護人、輔佐人。
5   前項期日，聲請人得到場陳述意見。但法院認有必要者，聲請人應到場陳述聲請理由或提出必要之證據。
6   法院應給予到場加害人、辯護人、輔佐人陳述意見之機會。但經合法傳喚、通知無正當理由不到場，或陳明不願到場者，不在此限。

來源條目欄位（正規化資料）：
- id：article-40
- articleNumber：40
- displayNumber：第 40 條
- title：None
- structureId：chapter-4
- metadata：{"source": "全國法規資料庫 性侵害犯罪防治法（PDF：法規-性侵害犯罪防治法.pdf）", "lastModified": "2023-02-15"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   第三十七條及第三十八條之聲請、停止、延長及裁定事項，除本法另有規定外，準用刑事訴訟法相關規定。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   加害人有下列情形之一，且未經選任辯護人者，法院應指定公設辯護人或律師為其辯護，並準用刑事訴訟法第三十一條第二項及第四項規定："
  },
  {
    "type": "item",
    "number": "一",
    "text": "一、身心障礙，致無法為完全之陳述。"
  },
  {
    "type": "item",
    "number": "二",
    "text": "二、其他經法院認有必要。"
  },
  {
    "type": "paragraph",
    "number": "3",
    "text": "3   刑事訴訟法第三十五條規定，於前項情形，準用之。"
  },
  {
    "type": "paragraph",
    "number": "4",
    "text": "4   法院受理第三十七條及第三十八條之聲請，除顯無必要者外，應指定期日傳喚加害人，並通知聲請人、辯護人、輔佐人。"
  },
  {
    "type": "paragraph",
    "number": "5",
    "text": "5   前項期日，聲請人得到場陳述意見。但法院認有必要者，聲請人應到場陳述聲請理由或提出必要之證據。"
  },
  {
    "type": "paragraph",
    "number": "6",
    "text": "6   法院應給予到場加害人、辯護人、輔佐人陳述意見之機會。但經合法傳喚、通知無正當理由不到場，或陳明不願到場者，不在此限。"
  }
]
```

## U04-A41｜第 41 條

1   犯刑法第二百二十一條、第二百二十二條、第二百二十四條之一、第二百二十五條第一項、第二百二十六條、第二百二十六條之一、第三百三十二條第二項第二款、第三百三十四條第二項第二款、第三百四十八條第二項第一款或其特別法之罪之加害人，有第三十一條第一項各款情形之一者，應定期向警察機關辦理身分、就學、工作、車籍之異動或其他相關資料之登記、報到；其登記、報到期間為七年。
2   犯刑法第二百二十四條、第二百二十五條第二項、第二百二十七條、第二百二十八條之罪之加害人，有第三十一條第一項各款情形之一者，亦適用前項之規定；其登記、報到期間為五年。
3   前二項規定，對於犯罪後經驅逐或限令出境者或犯罪時未滿十八歲者，不適用之。
4   第一項、第二項加害人於登記、報到期間，應定期或不定期接受警察機關查訪；其登記內容有變更者，應於變更之七日內辦理資料異動。
5   犯性侵害犯罪經外國、大陸地區、香港或澳門法院有罪判決確定後，於未經我國法院重新判決確定前，準用前項查訪規定。

來源條目欄位（正規化資料）：
- id：article-41
- articleNumber：41
- displayNumber：第 41 條
- title：None
- structureId：chapter-4
- metadata：{"source": "全國法規資料庫 性侵害犯罪防治法（PDF：法規-性侵害犯罪防治法.pdf）", "lastModified": "2023-02-15"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   犯刑法第二百二十一條、第二百二十二條、第二百二十四條之一、第二百二十五條第一項、第二百二十六條、第二百二十六條之一、第三百三十二條第二項第二款、第三百三十四條第二項第二款、第三百四十八條第二項第一款或其特別法之罪之加害人，有第三十一條第一項各款情形之一者，應定期向警察機關辦理身分、就學、工作、車籍之異動或其他相關資料之登記、報到；其登記、報到期間為七年。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   犯刑法第二百二十四條、第二百二十五條第二項、第二百二十七條、第二百二十八條之罪之加害人，有第三十一條第一項各款情形之一者，亦適用前項之規定；其登記、報到期間為五年。"
  },
  {
    "type": "paragraph",
    "number": "3",
    "text": "3   前二項規定，對於犯罪後經驅逐或限令出境者或犯罪時未滿十八歲者，不適用之。"
  },
  {
    "type": "paragraph",
    "number": "4",
    "text": "4   第一項、第二項加害人於登記、報到期間，應定期或不定期接受警察機關查訪；其登記內容有變更者，應於變更之七日內辦理資料異動。"
  },
  {
    "type": "paragraph",
    "number": "5",
    "text": "5   犯性侵害犯罪經外國、大陸地區、香港或澳門法院有罪判決確定後，於未經我國法院重新判決確定前，準用前項查訪規定。"
  }
]
```

## U04-A42｜第 42 條

1   性侵害犯罪經緩起訴處分確定者，其接受身心治療、輔導或教育期間，應定期向警察機關辦理身分、就學、工作、車籍之異動或其他相關資料之登記、報到。
2   前項人員於登記、報到期間，應定期或不定期接受警察機關查訪；其登記內容有變更者，應於變更後七日內辦理資料異動。
3   前二項規定，於犯罪時未滿十八歲者，不適用之。

來源條目欄位（正規化資料）：
- id：article-42
- articleNumber：42
- displayNumber：第 42 條
- title：None
- structureId：chapter-4
- metadata：{"source": "全國法規資料庫 性侵害犯罪防治法（PDF：法規-性侵害犯罪防治法.pdf）", "lastModified": "2023-02-15"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   性侵害犯罪經緩起訴處分確定者，其接受身心治療、輔導或教育期間，應定期向警察機關辦理身分、就學、工作、車籍之異動或其他相關資料之登記、報到。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   前項人員於登記、報到期間，應定期或不定期接受警察機關查訪；其登記內容有變更者，應於變更後七日內辦理資料異動。"
  },
  {
    "type": "paragraph",
    "number": "3",
    "text": "3   前二項規定，於犯罪時未滿十八歲者，不適用之。"
  }
]
```

## U04-A43｜第 43 條

1   為維護公共利益及社會安全目的，前二條登記、報到期間之登記事項，得提供特定人員查閱。
2   前二條登記、報到之程序、方式、查訪頻率與前項查閱之範圍、內容、執行機關、查閱人員之資格、條件、查閱程序及其他應遵行事項之辦法，由中央警政主管機關會商中央各目的事業主管機關定之。

來源條目欄位（正規化資料）：
- id：article-43
- articleNumber：43
- displayNumber：第 43 條
- title：None
- structureId：chapter-4
- metadata：{"source": "全國法規資料庫 性侵害犯罪防治法（PDF：法規-性侵害犯罪防治法.pdf）", "lastModified": "2023-02-15"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   為維護公共利益及社會安全目的，前二條登記、報到期間之登記事項，得提供特定人員查閱。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   前二條登記、報到之程序、方式、查訪頻率與前項查閱之範圍、內容、執行機關、查閱人員之資格、條件、查閱程序及其他應遵行事項之辦法，由中央警政主管機關會商中央各目的事業主管機關定之。"
  }
]
```

## U04-A44｜第 44 條

第三十七條第一項、第二項之加害人經通知依指定期日到場接受強制治療而未按時到場者，處一年以下有期徒刑、拘役、科或併科新臺幣十萬元以下罰金。

來源條目欄位（正規化資料）：
- id：article-44
- articleNumber：44
- displayNumber：第 44 條
- title：None
- structureId：chapter-5
- metadata：{"source": "全國法規資料庫 性侵害犯罪防治法（PDF：法規-性侵害犯罪防治法.pdf）", "lastModified": "2023-02-15"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": null,
    "text": "第三十七條第一項、第二項之加害人經通知依指定期日到場接受強制治療而未按時到場者，處一年以下有期徒刑、拘役、科或併科新臺幣十萬元以下罰金。"
  }
]
```

## U04-A45｜第 45 條

違反第十一條第二項保密規定者，處新臺幣六萬元以上六十萬元以下罰鍰。

來源條目欄位（正規化資料）：
- id：article-45
- articleNumber：45
- displayNumber：第 45 條
- title：None
- structureId：chapter-5
- metadata：{"source": "全國法規資料庫 性侵害犯罪防治法（PDF：法規-性侵害犯罪防治法.pdf）", "lastModified": "2023-02-15"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": null,
    "text": "違反第十一條第二項保密規定者，處新臺幣六萬元以上六十萬元以下罰鍰。"
  }
]
```

## U04-A46｜第 46 條

有下列情形之一，而無正當理由者，由目的事業主管機關處新臺幣六萬元以上六十萬元以下罰鍰，並令其限期改善；屆期未改善者，得按次處罰，並得令其限制接取：
一、違反第十三條第一項規定，未先行限制瀏覽、移除。
二、違反第十三條第二項規定，未保留一百八十日，或未將資料提供司法或警察機關調查。
三、違反依第七條第二項準用第十三條第一項規定，未先行限制瀏覽、移除。
四、違反依第七條第二項準用第十三條第二項規定，未保留一百八十日，或未將資料提供司法或警察機關調查。

來源條目欄位（正規化資料）：
- id：article-46
- articleNumber：46
- displayNumber：第 46 條
- title：None
- structureId：chapter-5
- metadata：{"source": "全國法規資料庫 性侵害犯罪防治法（PDF：法規-性侵害犯罪防治法.pdf）", "lastModified": "2023-02-15"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": null,
    "text": "有下列情形之一，而無正當理由者，由目的事業主管機關處新臺幣六萬元以上六十萬元以下罰鍰，並令其限期改善；屆期未改善者，得按次處罰，並得令其限制接取："
  },
  {
    "type": "item",
    "number": "一",
    "text": "一、違反第十三條第一項規定，未先行限制瀏覽、移除。"
  },
  {
    "type": "item",
    "number": "二",
    "text": "二、違反第十三條第二項規定，未保留一百八十日，或未將資料提供司法或警察機關調查。"
  },
  {
    "type": "item",
    "number": "三",
    "text": "三、違反依第七條第二項準用第十三條第一項規定，未先行限制瀏覽、移除。"
  },
  {
    "type": "item",
    "number": "四",
    "text": "四、違反依第七條第二項準用第十三條第二項規定，未保留一百八十日，或未將資料提供司法或警察機關調查。"
  }
]
```

## U04-A47｜第 47 條

違反第十五條第一項保密規定者，或違反依第七條第二項、第三項準用第十五條第一項保密規定者，處新臺幣六萬元以上六十萬元以下罰鍰。

來源條目欄位（正規化資料）：
- id：article-47
- articleNumber：47
- displayNumber：第 47 條
- title：None
- structureId：chapter-5
- metadata：{"source": "全國法規資料庫 性侵害犯罪防治法（PDF：法規-性侵害犯罪防治法.pdf）", "lastModified": "2023-02-15"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": null,
    "text": "違反第十五條第一項保密規定者，或違反依第七條第二項、第三項準用第十五條第一項保密規定者，處新臺幣六萬元以上六十萬元以下罰鍰。"
  }
]
```

## U04-A48｜第 48 條

1   廣播、電視事業違反第十六條第一項或第三項規定，或違反依第七條第二項、第三項準用第十六條第一項或第三項規定者，由目的事業主管機關處新臺幣六萬元以上六十萬元以下罰鍰，並令其限期改正；屆期未改正者，得按次處罰。
2   前項以外之宣傳品、出版品、網際網路或其他媒體業者違反第十六條第一項或第三項規定，或違反依第七條第二項、第三項準用第十六條第一項或第三項規定者，由目的事業主管機關處負責人新臺幣六萬元以上六十萬元以下罰鍰，並得沒入第十六條規定之物品、令其限期移除內容、下架或其他必要之處置；屆期不履行者，得按次處罰至履行為止。
3   前二項規定，於被害人死亡，經目的事業主管機關權衡為維護治安、安定人心、澄清視聽、防止危險擴大或其他社會公益，認有報導或揭露必要者，不罰。
4   第一項及第二項以外之任何人違反第十六條第四項規定，或違反依第七條第二項、第三項準用第十六條第四項規定，而無正當理由者，處新臺幣二萬元以上十萬元以下罰鍰。
5   宣傳品、出版品、網際網路或其他媒體無負責人或負責人對行為人之行為不具監督關係者，第二項之處罰對象為行為人。

來源條目欄位（正規化資料）：
- id：article-48
- articleNumber：48
- displayNumber：第 48 條
- title：None
- structureId：chapter-5
- metadata：{"source": "全國法規資料庫 性侵害犯罪防治法（PDF：法規-性侵害犯罪防治法.pdf）", "lastModified": "2023-02-15"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   廣播、電視事業違反第十六條第一項或第三項規定，或違反依第七條第二項、第三項準用第十六條第一項或第三項規定者，由目的事業主管機關處新臺幣六萬元以上六十萬元以下罰鍰，並令其限期改正；屆期未改正者，得按次處罰。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   前項以外之宣傳品、出版品、網際網路或其他媒體業者違反第十六條第一項或第三項規定，或違反依第七條第二項、第三項準用第十六條第一項或第三項規定者，由目的事業主管機關處負責人新臺幣六萬元以上六十萬元以下罰鍰，並得沒入第十六條規定之物品、令其限期移除內容、下架或其他必要之處置；屆期不履行者，得按次處罰至履行為止。"
  },
  {
    "type": "paragraph",
    "number": "3",
    "text": "3   前二項規定，於被害人死亡，經目的事業主管機關權衡為維護治安、安定人心、澄清視聽、防止危險擴大或其他社會公益，認有報導或揭露必要者，不罰。"
  },
  {
    "type": "paragraph",
    "number": "4",
    "text": "4   第一項及第二項以外之任何人違反第十六條第四項規定，或違反依第七條第二項、第三項準用第十六條第四項規定，而無正當理由者，處新臺幣二萬元以上十萬元以下罰鍰。"
  },
  {
    "type": "paragraph",
    "number": "5",
    "text": "5   宣傳品、出版品、網際網路或其他媒體無負責人或負責人對行為人之行為不具監督關係者，第二項之處罰對象為行為人。"
  }
]
```

## U04-A49｜第 49 條

違反第十四條第一項規定者，由直轄市、縣（市）主管機關處新臺幣一萬元以上五萬元以下罰鍰。

來源條目欄位（正規化資料）：
- id：article-49
- articleNumber：49
- displayNumber：第 49 條
- title：None
- structureId：chapter-5
- metadata：{"source": "全國法規資料庫 性侵害犯罪防治法（PDF：法規-性侵害犯罪防治法.pdf）", "lastModified": "2023-02-15"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": null,
    "text": "違反第十四條第一項規定者，由直轄市、縣（市）主管機關處新臺幣一萬元以上五萬元以下罰鍰。"
  }
]
```

## U04-A50｜第 50 條

1   第三十一條第一項、第四項之加害人、性侵害犯罪經緩起訴處分確定者、依第七條第一項準用第三十一條第一項及第四十二條第一項、第二項規定者，有下列情形之一，由直轄市、縣（市）主管機關處新臺幣一萬元以上五萬元以下罰鍰，並令其限期履行：
一、經直轄市、縣（市）主管機關通知，無正當理由不到場或拒絕接受評估、身心治療、輔導或教育，或接受之時數不足。
二、未依第四十一條第一項、第二項、第四項或第四十二條第一項、第二項規定，定期辦理登記、報到、資料異動或接受查訪。
2   依第四十一條第五項準用同條第四項規定受查訪者，有前項第二款規定情形時，依前項規定處罰。
3   依前二項規定令其限期履行，屆期仍不履行者，處一年以下有期徒刑、拘役或科或併科新臺幣十萬元以下罰金。
4   受前三項處分者於執行完畢後，仍應依第三十一條、第三十二條、第四十一條及第四十二條規定辦理。

來源條目欄位（正規化資料）：
- id：article-50
- articleNumber：50
- displayNumber：第 50 條
- title：None
- structureId：chapter-5
- metadata：{"source": "全國法規資料庫 性侵害犯罪防治法（PDF：法規-性侵害犯罪防治法.pdf）", "lastModified": "2023-02-15"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   第三十一條第一項、第四項之加害人、性侵害犯罪經緩起訴處分確定者、依第七條第一項準用第三十一條第一項及第四十二條第一項、第二項規定者，有下列情形之一，由直轄市、縣（市）主管機關處新臺幣一萬元以上五萬元以下罰鍰，並令其限期履行："
  },
  {
    "type": "item",
    "number": "一",
    "text": "一、經直轄市、縣（市）主管機關通知，無正當理由不到場或拒絕接受評估、身心治療、輔導或教育，或接受之時數不足。"
  },
  {
    "type": "item",
    "number": "二",
    "text": "二、未依第四十一條第一項、第二項、第四項或第四十二條第一項、第二項規定，定期辦理登記、報到、資料異動或接受查訪。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   依第四十一條第五項準用同條第四項規定受查訪者，有前項第二款規定情形時，依前項規定處罰。"
  },
  {
    "type": "paragraph",
    "number": "3",
    "text": "3   依前二項規定令其限期履行，屆期仍不履行者，處一年以下有期徒刑、拘役或科或併科新臺幣十萬元以下罰金。"
  },
  {
    "type": "paragraph",
    "number": "4",
    "text": "4   受前三項處分者於執行完畢後，仍應依第三十一條、第三十二條、第四十一條及第四十二條規定辦理。"
  }
]
```

## U04-A51｜第 51 條

1   直轄市、縣（市）主管機關對於下列各款之人為前條第一項之處分後，應即通知該管檢察官：
一、假釋、緩刑或有期徒刑經易服社會勞動之加害人。
二、犯性騷擾防治法第二十五條第一項之罪及犯刑法第三百十九條之二第一項之罪經假釋、緩刑或有期徒刑易服社會勞動者。
三、性侵害犯罪經緩起訴處分確定者。
2   該管檢察官接獲前項通知後，得通知原執行監獄典獄長報請法務部撤銷假釋，或向法院聲請撤銷緩刑之宣告，或依職權撤銷緩起訴處分及易服社會勞動。

來源條目欄位（正規化資料）：
- id：article-51
- articleNumber：51
- displayNumber：第 51 條
- title：None
- structureId：chapter-6
- metadata：{"source": "全國法規資料庫 性侵害犯罪防治法（PDF：法規-性侵害犯罪防治法.pdf）", "lastModified": "2023-02-15"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   直轄市、縣（市）主管機關對於下列各款之人為前條第一項之處分後，應即通知該管檢察官："
  },
  {
    "type": "item",
    "number": "一",
    "text": "一、假釋、緩刑或有期徒刑經易服社會勞動之加害人。"
  },
  {
    "type": "item",
    "number": "二",
    "text": "二、犯性騷擾防治法第二十五條第一項之罪及犯刑法第三百十九條之二第一項之罪經假釋、緩刑或有期徒刑易服社會勞動者。"
  },
  {
    "type": "item",
    "number": "三",
    "text": "三、性侵害犯罪經緩起訴處分確定者。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   該管檢察官接獲前項通知後，得通知原執行監獄典獄長報請法務部撤銷假釋，或向法院聲請撤銷緩刑之宣告，或依職權撤銷緩起訴處分及易服社會勞動。"
  }
]
```

## U04-A52｜第 52 條

1   第四十四條、第五十條第三項之被告或判決有罪確定之加害人逃亡、藏匿經通緝者，該管警察機關得將其身分相關資訊刊載於機關網站、報紙或以其他方法公開之；其經拘提、逮捕、已死亡或顯無必要時，該管警察機關應即停止公告。
2   前項規定，於犯罪時未滿十八歲者，不適用之。

來源條目欄位（正規化資料）：
- id：article-52
- articleNumber：52
- displayNumber：第 52 條
- title：None
- structureId：chapter-6
- metadata：{"source": "全國法規資料庫 性侵害犯罪防治法（PDF：法規-性侵害犯罪防治法.pdf）", "lastModified": "2023-02-15"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   第四十四條、第五十條第三項之被告或判決有罪確定之加害人逃亡、藏匿經通緝者，該管警察機關得將其身分相關資訊刊載於機關網站、報紙或以其他方法公開之；其經拘提、逮捕、已死亡或顯無必要時，該管警察機關應即停止公告。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   前項規定，於犯罪時未滿十八歲者，不適用之。"
  }
]
```

## U04-A53｜第 53 條

本法規定於軍法機關戰時辦理現役軍人犯性侵害犯罪案件，準用之。

來源條目欄位（正規化資料）：
- id：article-53
- articleNumber：53
- displayNumber：第 53 條
- title：None
- structureId：chapter-6
- metadata：{"source": "全國法規資料庫 性侵害犯罪防治法（PDF：法規-性侵害犯罪防治法.pdf）", "lastModified": "2023-02-15"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": null,
    "text": "本法規定於軍法機關戰時辦理現役軍人犯性侵害犯罪案件，準用之。"
  }
]
```

## U04-A54｜第 54 條

1   第三十六條至第四十條修正施行前，受強制治療之宣告者，於修正施行後，應繼續執行。
2   前項情形，由原執行檢察署之檢察官或直轄市、縣（市）主管機關於第三十六條至第四十條修正施行後六月內，向該案犯罪事實最後裁判之法院，依第三十八條第一項或刑法第九十一條之一第二項規定，聲請裁定強制治療之期間。
3   前項聲請，如法院裁定時，其強制治療已執行累計逾五年者，視為依第三十八條第一項後段或刑法第九十一條之一第二項後段規定為第一次許可延長之聲請；已執行逾八年者，視為第二次許可延長之聲請。
4   有下列情形之一，由該案犯罪事實最後裁判之法院，依第三十八條第一項、第二項或刑法第九十一條之一第二項、第三項規定裁定之，並適用前項規定：
一、第三十六條至第四十條修正施行前，受法院停止治療執行之裁定，於修正施行後，經聲請繼續施以強制治療者。
二、第一項或第二項之情形，法院於第三十六條至第四十條修正施行後為停止治療執行之裁定，經聲請繼續施以強制治療者。

來源條目欄位（正規化資料）：
- id：article-54
- articleNumber：54
- displayNumber：第 54 條
- title：None
- structureId：chapter-6
- metadata：{"source": "全國法規資料庫 性侵害犯罪防治法（PDF：法規-性侵害犯罪防治法.pdf）", "lastModified": "2023-02-15"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   第三十六條至第四十條修正施行前，受強制治療之宣告者，於修正施行後，應繼續執行。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   前項情形，由原執行檢察署之檢察官或直轄市、縣（市）主管機關於第三十六條至第四十條修正施行後六月內，向該案犯罪事實最後裁判之法院，依第三十八條第一項或刑法第九十一條之一第二項規定，聲請裁定強制治療之期間。"
  },
  {
    "type": "paragraph",
    "number": "3",
    "text": "3   前項聲請，如法院裁定時，其強制治療已執行累計逾五年者，視為依第三十八條第一項後段或刑法第九十一條之一第二項後段規定為第一次許可延長之聲請；已執行逾八年者，視為第二次許可延長之聲請。"
  },
  {
    "type": "paragraph",
    "number": "4",
    "text": "4   有下列情形之一，由該案犯罪事實最後裁判之法院，依第三十八條第一項、第二項或刑法第九十一條之一第二項、第三項規定裁定之，並適用前項規定："
  },
  {
    "type": "item",
    "number": "一",
    "text": "一、第三十六條至第四十條修正施行前，受法院停止治療執行之裁定，於修正施行後，經聲請繼續施以強制治療者。"
  },
  {
    "type": "item",
    "number": "二",
    "text": "二、第一項或第二項之情形，法院於第三十六條至第四十條修正施行後為停止治療執行之裁定，經聲請繼續施以強制治療者。"
  }
]
```

## U04-A55｜第 55 條

本法施行細則，由中央主管機關定之。

來源條目欄位（正規化資料）：
- id：article-55
- articleNumber：55
- displayNumber：第 55 條
- title：None
- structureId：chapter-6
- metadata：{"source": "全國法規資料庫 性侵害犯罪防治法（PDF：法規-性侵害犯罪防治法.pdf）", "lastModified": "2023-02-15"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": null,
    "text": "本法施行細則，由中央主管機關定之。"
  }
]
```

## U04-A56｜第 56 條

本法除第十三條自公布後六個月施行外，其餘自公布日施行。

來源條目欄位（正規化資料）：
- id：article-56
- articleNumber：56
- displayNumber：第 56 條
- title：None
- structureId：chapter-6
- metadata：{"source": "全國法規資料庫 性侵害犯罪防治法（PDF：法規-性侵害犯罪防治法.pdf）", "lastModified": "2023-02-15"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": null,
    "text": "本法除第十三條自公布後六個月施行外，其餘自公布日施行。"
  }
]
```

## 來源其他資料

- schemaVersion：1.3.0
- processing：{"normalizedBy": "ai", "processedAt": "2026-07-22T00:00:00Z", "sourceType": "document", "warnings": ["來源 PDF未印出官方法規代碼，code 依規範填「UNKNOWN」。"]}