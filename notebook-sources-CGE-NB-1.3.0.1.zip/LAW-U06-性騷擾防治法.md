# LAW-U06｜性騷擾防治法

資料集：CGE-NB-1.3.0.1；編製日：2026-09-09。此日期不是法律查核日。

## 來源與版本

- source_id：U06
- filename：性騷擾防治法.json
- path：sources/uploaded/性騷擾防治法.json
- sha256：28f2b233b33015045e10bd248d4e5509ac8f7771e575a68f5489229965ed5905
- regulation_id：tw-sexual-harassment-prevention-act
- name：性騷擾防治法
- version：{"id": "tw-sexual-harassment-prevention-act-20230816", "label": "修正日期：民國 112 年 08 月 16 日", "promulgationDate": "2023-08-16", "effectiveDate": "2023-08-18", "effectiveDateNote": "本版本施行條文明定自公布（發布）日施行，依中央法規標準法第13條，自公布（發布）之日起算至第三日起發生效力，故施行日為公布（發布）日之後二日。 另依第34條，第7條第2項、第3項、第14條至第24條、第27條、第28條第2項及第30條自中華民國一百十三年三月八日（2024-03-08）施行。", "status": "effective"}
- article_count：34
- source_kind：user_uploaded_ai_normalized_json
- review_status：attachment_reference_not_full_current_audit
- review_notes：[]
- official_source_ids：[]
- normalization_warnings：["來源 PDF未印出官方法規代碼，code 依規範填「UNKNOWN」。"]
- processed_at：2026-07-22T00:00:00Z
- authoritative_current_full_text：False

- id：tw-sexual-harassment-prevention-act
- code：UNKNOWN
- name：性騷擾防治法
- shortName：性騷擾防治法
- jurisdiction：TW
- authority：衛生福利部
- aliases：["性騷法"]
- version：{"id": "tw-sexual-harassment-prevention-act-20230816", "label": "修正日期：民國 112 年 08 月 16 日", "promulgationDate": "2023-08-16", "effectiveDate": "2023-08-18", "effectiveDateNote": "本版本施行條文明定自公布（發布）日施行，依中央法規標準法第13條，自公布（發布）之日起算至第三日起發生效力，故施行日為公布（發布）日之後二日。 另依第34條，第7條第2項、第3項、第14條至第24條、第27條、第28條第2項及第30條自中華民國一百十三年三月八日（2024-03-08）施行。", "status": "effective"}
- structure：[{"id": "chapter-1", "type": "chapter", "label": "第 一 章 總則", "parentId": null, "sortOrder": 0}, {"id": "chapter-2", "type": "chapter", "label": "第 二 章 性騷擾之防治及責任", "parentId": null, "sortOrder": 1}, {"id": "chapter-3", "type": "chapter", "label": "第 三 章 被害人保護", "parentId": null, "sortOrder": 2}, {"id": "chapter-4", "type": "chapter", "label": "第 四 章 申訴及調查程序", "parentId": null, "sortOrder": 3}, {"id": "chapter-5", "type": "chapter", "label": "第 五 章 調解程序", "parentId": null, "sortOrder": 4}, {"id": "chapter-6", "type": "chapter", "label": "第 六 章 罰則", "parentId": null, "sortOrder": 5}, {"id": "chapter-7", "type": "chapter", "label": "第 七 章 附則", "parentId": null, "sortOrder": 6}]
- legalConcepts：[{"id": "sexual-harassment-prevention-framework", "name": "性騷擾防治法律框架", "description": "彙整我國性騷擾之定義、防治義務、申訴調查程序與相關罰則所涉之法規；並涵蓋依場域與當事人身分關係而分流適用之性別平等工作法與性別平等教育法。", "aliases": ["性騷擾防治"], "tags": ["性騷擾", "防治", "申訴"], "role": "primary", "sortOrder": 0}]
- crossRegulationLinks：[{"id": "link-tw-sexual-harassment-prevention-act-1", "conceptId": "sexual-harassment-prevention-framework", "sourceArticleId": "article-1", "label": "場域分流適用", "relationType": "exception", "conditionText": "性騷擾事件之處理及防治依本法規定；但依事件發生之場域及當事人之身分關係，性別平等教育法別有規定其處理及防治事項者，適用該法之規定。", "targetRegulationId": "tw-gender-equity-education-act", "targetRegulationNames": ["性別平等教育法"], "targetArticleNumber": null, "triggerTerms": ["性別平等教育法"], "linkMode": "automatic", "sortOrder": 0}, {"id": "link-tw-sexual-harassment-prevention-act-2", "conceptId": "sexual-harassment-prevention-framework", "sourceArticleId": "article-1", "label": "場域分流適用", "relationType": "exception", "conditionText": "性騷擾事件之處理及防治依本法規定；但依事件發生之場域及當事人之身分關係，性別平等工作法別有規定其處理及防治事項者，適用該法之規定。", "targetRegulationId": "tw-gender-equality-employment-act", "targetRegulationNames": ["性別平等工作法"], "targetArticleNumber": null, "triggerTerms": ["性別平等工作法"], "linkMode": "automatic", "sortOrder": 1}, {"id": "link-tw-sexual-harassment-prevention-act-3", "conceptId": "sexual-harassment-prevention-framework", "sourceArticleId": "article-2", "label": "定義之排除", "relationType": "exclusion", "conditionText": "本法所稱性騷擾以「性侵害犯罪以外」之行為為限；行為構成性侵害犯罪者，依性侵害犯罪防治法及刑法相關規定處理。", "targetRegulationId": "tw-sexual-assault-crime-prevention-act", "targetRegulationNames": ["性侵害犯罪防治法"], "targetArticleNumber": null, "triggerTerms": ["性侵害犯罪"], "linkMode": "automatic", "sortOrder": 2}, {"id": "link-tw-sexual-harassment-prevention-act-4", "conceptId": "sexual-harassment-prevention-framework", "sourceArticleId": "article-7", "label": "授權訂定防治準則", "relationType": "authorization", "conditionText": "為預防及處理性騷擾事件，中央主管機關應訂定性騷擾防治之準則。", "targetRegulationId": "tw-sexual-harassment-prevention-standards", "targetRegulationNames": ["性騷擾防治準則"], "targetArticleNumber": null, "triggerTerms": ["準則"], "linkMode": "automatic", "sortOrder": 3}, {"id": "link-tw-sexual-harassment-prevention-act-5", "conceptId": "sexual-harassment-prevention-framework", "sourceArticleId": null, "label": "授權訂定施行細則", "relationType": "authorization", "conditionText": "本法施行細則，由中央主管機關定之。", "targetRegulationId": "tw-sexual-harassment-prevention-act-enforcement-rules", "targetRegulationNames": ["性騷擾防治法施行細則"], "targetArticleNumber": null, "triggerTerms": ["施行細則"], "linkMode": "automatic", "sortOrder": 4}, {"conceptId": "sexual-harassment-prevention-framework", "sourceArticleId": "article-23", "label": "引用民事訴訟法", "relationType": "application", "conditionText": "4   民事訴訟法第五百零二條及強制執行法第十八條第二項規定，於第二項情形準用之。", "targetRegulationId": "tw-code-civil-procedure", "targetRegulationNames": ["民事訴訟法"], "targetArticleNumber": "502", "triggerTerms": ["4   "], "linkMode": "automatic", "id": "link-tw-sexual-harassment-prevention-act-cite-6", "sortOrder": 5}, {"conceptId": "sexual-harassment-prevention-framework", "sourceArticleId": "article-23", "label": "引用強制執行法", "relationType": "application", "conditionText": "4   民事訴訟法第五百零二條及強制執行法第十八條第二項規定，於第二項情形準用之。", "targetRegulationId": "tw-compulsory-enforcement-act", "targetRegulationNames": ["強制執行法"], "targetArticleNumber": "18", "triggerTerms": ["零二條及"], "linkMode": "automatic", "id": "link-tw-sexual-harassment-prevention-act-cite-7", "sortOrder": 6}]
- definedTerms：[{"id": "sexual-harassment", "name": "性騷擾", "aliases": [], "definition": "性侵害犯罪以外，對他人實施違反其意願而與性或性別有關之行為，且有下列情形之一：\n一、以明示或暗示之方式，或以歧視、侮辱之言行，或以他法，而有損害他人人格尊嚴，或造成使人心生畏怖、感受敵意或冒犯之情境，或不當影響其工作、教育、訓練、服務、計畫、活動或正常生活之進行。\n二、以該他人順服或拒絕該行為，作為自己或他人獲得、喪失或減損其學習、工作、訓練、服務、計畫、活動有關權益之條件。", "definitionArticleId": "article-2", "definitionText": "1   本法所稱性騷擾，指性侵害犯罪以外，對他人實施違反其意願而與性或性別有關之行為，且有下列情形之一：\n一、以明示或暗示之方式，或以歧視、侮辱之言行，或以他法，而有損害他人人格尊嚴，或造成使人心生畏怖、感受敵意或冒犯之情境，或不當影響其工作、教育、訓練、服務、計畫、活動或正常生活之進行。\n二、以該他人順服或拒絕該行為，作為自己或他人獲得、喪失或減損其學習、工作、訓練、服務、計畫、活動有關權益之條件。", "scope": "regulation", "targetRegulationNames": [], "sortOrder": 0}, {"id": "authority-based-sexual-harassment", "name": "權勢性騷擾", "aliases": [], "definition": "對於因教育、訓練、醫療、公務、業務、求職或其他相類關係受自己監督、照護、指導之人，利用權勢或機會為性騷擾。", "definitionArticleId": "article-2", "definitionText": "2   本法所稱權勢性騷擾，指對於因教育、訓練、醫療、公務、業務、求職或其他相類關係受自己監督、照護、指導之人，利用權勢或機會為性騷擾。", "scope": "regulation", "targetRegulationNames": [], "sortOrder": 1}, {"id": "military-unit", "name": "部隊", "aliases": [], "definition": "國防部所屬單位。", "definitionArticleId": "article-3", "definitionText": "1   本法所稱部隊，指國防部所屬單位。", "scope": "regulation", "targetRegulationNames": [], "sortOrder": 2}, {"id": "school", "name": "學校", "aliases": [], "definition": "公私立各級學校、軍事學校、預備學校、警察各級學校及少年矯正學校。", "definitionArticleId": "article-3", "definitionText": "2   本法所稱學校，指公私立各級學校、軍事學校、預備學校、警察各級學校及少年矯正學校。", "scope": "regulation", "targetRegulationNames": [], "sortOrder": 3}, {"id": "institution", "name": "機構", "aliases": [], "definition": "法人、合夥、設有代表人或管理人之非法人團體及其他組織。", "definitionArticleId": "article-3", "definitionText": "3   本法所稱機構，指法人、合夥、設有代表人或管理人之非法人團體及其他組織。", "scope": "regulation", "targetRegulationNames": [], "sortOrder": 4}, {"id": "competent-authority", "name": "主管機關", "aliases": [], "definition": "在中央為衛生福利部；在直轄市為直轄市政府；在縣（市）為縣（市）政府。", "definitionArticleId": "article-4", "definitionText": "本法所稱主管機關：在中央為衛生福利部；在直轄市為直轄市政府；在縣（市）為縣（市）政府。", "scope": "regulation", "targetRegulationNames": [], "sortOrder": 5}]

正規化概念、跨法連結與處理狀態不是獨立法源；下面逐條保留來源plainText，未以本次日期重寫。

## U06-A1｜第 1 條

1   為防治性騷擾及保護被害人之權益，特制定本法。
2   性騷擾事件之處理及防治，依本法之規定。但依性騷擾事件發生之場域及當事人之身分關係，性別平等教育法及性別平等工作法別有規定其處理及防治事項者，適用各該法律之規定。

來源條目欄位（正規化資料）：
- id：article-1
- articleNumber：1
- displayNumber：第 1 條
- title：None
- structureId：chapter-1
- metadata：{"source": "全國法規資料庫 性騷擾防治法（PDF：法規-性騷擾防治法.pdf）", "lastModified": "2023-08-16"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   為防治性騷擾及保護被害人之權益，特制定本法。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   性騷擾事件之處理及防治，依本法之規定。但依性騷擾事件發生之場域及當事人之身分關係，性別平等教育法及性別平等工作法別有規定其處理及防治事項者，適用各該法律之規定。"
  }
]
```

## U06-A2｜第 2 條

1   本法所稱性騷擾，指性侵害犯罪以外，對他人實施違反其意願而與性或性別有關之行為，且有下列情形之一：
一、以明示或暗示之方式，或以歧視、侮辱之言行，或以他法，而有損害他人人格尊嚴，或造成使人心生畏怖、感受敵意或冒犯之情境，或不當影響其工作、教育、訓練、服務、計畫、活動或正常生活之進行。
二、以該他人順服或拒絕該行為，作為自己或他人獲得、喪失或減損其學習、工作、訓練、服務、計畫、活動有關權益之條件。
2   本法所稱權勢性騷擾，指對於因教育、訓練、醫療、公務、業務、求職或其他相類關係受自己監督、照護、指導之人，利用權勢或機會為性騷擾。

來源條目欄位（正規化資料）：
- id：article-2
- articleNumber：2
- displayNumber：第 2 條
- title：None
- structureId：chapter-1
- metadata：{"source": "全國法規資料庫 性騷擾防治法（PDF：法規-性騷擾防治法.pdf）", "lastModified": "2023-08-16"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   本法所稱性騷擾，指性侵害犯罪以外，對他人實施違反其意願而與性或性別有關之行為，且有下列情形之一："
  },
  {
    "type": "item",
    "number": "一",
    "text": "一、以明示或暗示之方式，或以歧視、侮辱之言行，或以他法，而有損害他人人格尊嚴，或造成使人心生畏怖、感受敵意或冒犯之情境，或不當影響其工作、教育、訓練、服務、計畫、活動或正常生活之進行。"
  },
  {
    "type": "item",
    "number": "二",
    "text": "二、以該他人順服或拒絕該行為，作為自己或他人獲得、喪失或減損其學習、工作、訓練、服務、計畫、活動有關權益之條件。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   本法所稱權勢性騷擾，指對於因教育、訓練、醫療、公務、業務、求職或其他相類關係受自己監督、照護、指導之人，利用權勢或機會為性騷擾。"
  }
]
```

## U06-A3｜第 3 條

1   本法所稱部隊，指國防部所屬單位。
2   本法所稱學校，指公私立各級學校、軍事學校、預備學校、警察各級學校及少年矯正學校。
3   本法所稱機構，指法人、合夥、設有代表人或管理人之非法人團體及其他組織。

來源條目欄位（正規化資料）：
- id：article-3
- articleNumber：3
- displayNumber：第 3 條
- title：None
- structureId：chapter-1
- metadata：{"source": "全國法規資料庫 性騷擾防治法（PDF：法規-性騷擾防治法.pdf）", "lastModified": "2023-08-16"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   本法所稱部隊，指國防部所屬單位。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   本法所稱學校，指公私立各級學校、軍事學校、預備學校、警察各級學校及少年矯正學校。"
  },
  {
    "type": "paragraph",
    "number": "3",
    "text": "3   本法所稱機構，指法人、合夥、設有代表人或管理人之非法人團體及其他組織。"
  }
]
```

## U06-A4｜第 4 條

本法所稱主管機關：在中央為衛生福利部；在直轄市為直轄市政府；在縣（市）為縣（市）政府。

來源條目欄位（正規化資料）：
- id：article-4
- articleNumber：4
- displayNumber：第 4 條
- title：None
- structureId：chapter-1
- metadata：{"source": "全國法規資料庫 性騷擾防治法（PDF：法規-性騷擾防治法.pdf）", "lastModified": "2023-08-16"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": null,
    "text": "本法所稱主管機關：在中央為衛生福利部；在直轄市為直轄市政府；在縣（市）為縣（市）政府。"
  }
]
```

## U06-A5｜第 5 條

1   中央主管機關辦理下列事項。但涉及各中央目的事業主管機關職掌者，各該中央目的事業主管機關應配合辦理：
一、研擬與審議性騷擾防治政策及法規事項。
二、協調、督導及考核各級政府性騷擾防治之執行事項。
三、督導直轄市、縣（市）主管機關建立性騷擾事件處理程序及協助提供被害人保護扶助事項。
四、培訓性騷擾事件調查處理專業人才。
五、推展性騷擾防治教育及宣導事項。
六、辦理性騷擾防治績效優良之政府機關（構）、部隊、學校、機構、僱用人、團體或個人之獎勵事項。
七、彙整與統計性騷擾事件之各項資料及建立性騷擾事件電子資料庫。
八、辦理性騷擾防治趨勢及有關問題研究之事項。
九、其他性騷擾防治事項。
2   中央主管機關辦理前項事項，應遴聘（派）學者專家、民間團體及相關機關代表提供諮詢，其中學者專家、民間團體代表，不得少於總數二分之一；且女性代表不得少於總數二分之一。

來源條目欄位（正規化資料）：
- id：article-5
- articleNumber：5
- displayNumber：第 5 條
- title：None
- structureId：chapter-1
- metadata：{"source": "全國法規資料庫 性騷擾防治法（PDF：法規-性騷擾防治法.pdf）", "lastModified": "2023-08-16"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   中央主管機關辦理下列事項。但涉及各中央目的事業主管機關職掌者，各該中央目的事業主管機關應配合辦理："
  },
  {
    "type": "item",
    "number": "一",
    "text": "一、研擬與審議性騷擾防治政策及法規事項。"
  },
  {
    "type": "item",
    "number": "二",
    "text": "二、協調、督導及考核各級政府性騷擾防治之執行事項。"
  },
  {
    "type": "item",
    "number": "三",
    "text": "三、督導直轄市、縣（市）主管機關建立性騷擾事件處理程序及協助提供被害人保護扶助事項。"
  },
  {
    "type": "item",
    "number": "四",
    "text": "四、培訓性騷擾事件調查處理專業人才。"
  },
  {
    "type": "item",
    "number": "五",
    "text": "五、推展性騷擾防治教育及宣導事項。"
  },
  {
    "type": "item",
    "number": "六",
    "text": "六、辦理性騷擾防治績效優良之政府機關（構）、部隊、學校、機構、僱用人、團體或個人之獎勵事項。"
  },
  {
    "type": "item",
    "number": "七",
    "text": "七、彙整與統計性騷擾事件之各項資料及建立性騷擾事件電子資料庫。"
  },
  {
    "type": "item",
    "number": "八",
    "text": "八、辦理性騷擾防治趨勢及有關問題研究之事項。"
  },
  {
    "type": "item",
    "number": "九",
    "text": "九、其他性騷擾防治事項。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   中央主管機關辦理前項事項，應遴聘（派）學者專家、民間團體及相關機關代表提供諮詢，其中學者專家、民間團體代表，不得少於總數二分之一；且女性代表不得少於總數二分之一。"
  }
]
```

## U06-A6｜第 6 條

1   直轄市、縣（市）主管機關應設性騷擾防治審議會（以下簡稱審議會），辦理下列事項。但涉及各直轄市、縣（市）目的事業主管機關職掌者，各該直轄市、縣（市）目的事業主管機關應配合辦理：
一、擬定性騷擾防治政策及法規事項。
二、協調、督導及執行性騷擾防治事項。
三、調查、調解、審議性騷擾案件及移送有關機關事項。
四、提供被害人諮詢協談、心理輔導、法律協助、社會福利資源及其他必要之服務。
五、推展性騷擾防治教育訓練及宣導事項。
六、彙整及統計性騷擾事件各項資料。
七、其他性騷擾防治事項。
2   前項審議會置召集人一人，由直轄市長、縣（市）長或副首長兼任，並應遴聘（派）有關機關高級職員、社會公正人士、民間團體代表、學者專家為委員；其中社會公正人士、民間團體代表、學者專家不得少於總數二分之一；且女性代表不得少於總數二分之一。

來源條目欄位（正規化資料）：
- id：article-6
- articleNumber：6
- displayNumber：第 6 條
- title：None
- structureId：chapter-1
- metadata：{"source": "全國法規資料庫 性騷擾防治法（PDF：法規-性騷擾防治法.pdf）", "lastModified": "2023-08-16"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   直轄市、縣（市）主管機關應設性騷擾防治審議會（以下簡稱審議會），辦理下列事項。但涉及各直轄市、縣（市）目的事業主管機關職掌者，各該直轄市、縣（市）目的事業主管機關應配合辦理："
  },
  {
    "type": "item",
    "number": "一",
    "text": "一、擬定性騷擾防治政策及法規事項。"
  },
  {
    "type": "item",
    "number": "二",
    "text": "二、協調、督導及執行性騷擾防治事項。"
  },
  {
    "type": "item",
    "number": "三",
    "text": "三、調查、調解、審議性騷擾案件及移送有關機關事項。"
  },
  {
    "type": "item",
    "number": "四",
    "text": "四、提供被害人諮詢協談、心理輔導、法律協助、社會福利資源及其他必要之服務。"
  },
  {
    "type": "item",
    "number": "五",
    "text": "五、推展性騷擾防治教育訓練及宣導事項。"
  },
  {
    "type": "item",
    "number": "六",
    "text": "六、彙整及統計性騷擾事件各項資料。"
  },
  {
    "type": "item",
    "number": "七",
    "text": "七、其他性騷擾防治事項。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   前項審議會置召集人一人，由直轄市長、縣（市）長或副首長兼任，並應遴聘（派）有關機關高級職員、社會公正人士、民間團體代表、學者專家為委員；其中社會公正人士、民間團體代表、學者專家不得少於總數二分之一；且女性代表不得少於總數二分之一。"
  }
]
```

## U06-A7｜第 7 條

1   政府機關（構）、部隊、學校、機構或僱用人，於所屬公共場所及公眾得出入之場所，應採取下列預防措施，防治性騷擾行為之發生：
一、組織之成員、受僱人或受服務人員人數達十人以上者，應設立申訴管道協調處理。
二、組織之成員、受僱人或受服務人員人數達三十人以上者，並應訂定性騷擾防治措施，且公開揭示之。
2   政府機關（構）、部隊、學校、機構或僱用人於前項場所有性騷擾事件發生當時知悉者，應採取下列有效之糾正及補救措施，並注意被害人安全及隱私之維護：
一、協助被害人申訴及保全相關證據。
二、必要時協助通知警察機關到場處理。
三、檢討所屬場所安全。
3   政府機關（構）、部隊、學校、機構或僱用人於性騷擾事件發生後知悉者，應採取前項第三款之糾正及補救措施。
4   為預防及處理性騷擾事件，中央主管機關應訂定性騷擾防治之準則；其內容應包括性騷擾樣態、防治原則、申訴管道、教育訓練方案及其他相關措施。

來源條目欄位（正規化資料）：
- id：article-7
- articleNumber：7
- displayNumber：第 7 條
- title：None
- structureId：chapter-2
- metadata：{"source": "全國法規資料庫 性騷擾防治法（PDF：法規-性騷擾防治法.pdf）", "lastModified": "2023-08-16"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   政府機關（構）、部隊、學校、機構或僱用人，於所屬公共場所及公眾得出入之場所，應採取下列預防措施，防治性騷擾行為之發生："
  },
  {
    "type": "item",
    "number": "一",
    "text": "一、組織之成員、受僱人或受服務人員人數達十人以上者，應設立申訴管道協調處理。"
  },
  {
    "type": "item",
    "number": "二",
    "text": "二、組織之成員、受僱人或受服務人員人數達三十人以上者，並應訂定性騷擾防治措施，且公開揭示之。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   政府機關（構）、部隊、學校、機構或僱用人於前項場所有性騷擾事件發生當時知悉者，應採取下列有效之糾正及補救措施，並注意被害人安全及隱私之維護："
  },
  {
    "type": "item",
    "number": "一",
    "text": "一、協助被害人申訴及保全相關證據。"
  },
  {
    "type": "item",
    "number": "二",
    "text": "二、必要時協助通知警察機關到場處理。"
  },
  {
    "type": "item",
    "number": "三",
    "text": "三、檢討所屬場所安全。"
  },
  {
    "type": "paragraph",
    "number": "3",
    "text": "3   政府機關（構）、部隊、學校、機構或僱用人於性騷擾事件發生後知悉者，應採取前項第三款之糾正及補救措施。"
  },
  {
    "type": "paragraph",
    "number": "4",
    "text": "4   為預防及處理性騷擾事件，中央主管機關應訂定性騷擾防治之準則；其內容應包括性騷擾樣態、防治原則、申訴管道、教育訓練方案及其他相關措施。"
  }
]
```

## U06-A8｜第 8 條

前條所定政府機關（構）、部隊、學校、機構或僱用人應定期舉辦或鼓勵所屬人員參與防治性騷擾之相關教育訓練。

來源條目欄位（正規化資料）：
- id：article-8
- articleNumber：8
- displayNumber：第 8 條
- title：None
- structureId：chapter-2
- metadata：{"source": "全國法規資料庫 性騷擾防治法（PDF：法規-性騷擾防治法.pdf）", "lastModified": "2023-08-16"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": null,
    "text": "前條所定政府機關（構）、部隊、學校、機構或僱用人應定期舉辦或鼓勵所屬人員參與防治性騷擾之相關教育訓練。"
  }
]
```

## U06-A9｜第 9 條

1   政府機關（構）、部隊、學校、機構、僱用人對於在性騷擾事件申訴、調查、偵查或審理程序中，為申訴、告訴、告發、提起訴訟、作證、提供協助或其他參與行為之人，不得為不當之差別待遇。
2   違反前項規定者，負損害賠償責任。

來源條目欄位（正規化資料）：
- id：article-9
- articleNumber：9
- displayNumber：第 9 條
- title：None
- structureId：chapter-2
- metadata：{"source": "全國法規資料庫 性騷擾防治法（PDF：法規-性騷擾防治法.pdf）", "lastModified": "2023-08-16"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   政府機關（構）、部隊、學校、機構、僱用人對於在性騷擾事件申訴、調查、偵查或審理程序中，為申訴、告訴、告發、提起訴訟、作證、提供協助或其他參與行為之人，不得為不當之差別待遇。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   違反前項規定者，負損害賠償責任。"
  }
]
```

## U06-A10｜第 10 條

1   宣傳品、出版品、廣播、電視、網際網路或其他媒體，不得報導或記載被害人之姓名或其他足資識別被害人身分之資訊。但有下列情形之一者，不在此限：
一、被害人為成年人，經本人同意。但心智障礙者、受監護宣告或輔助宣告者，應以其可理解方式提供資訊；受監護宣告者並應取得其監護人同意。
二、檢察官或法院依法認為有必要。
2   前項第一款但書規定之監護人為同意時，應尊重受監護宣告者之意願。
3   第一項第一款但書所定監護人為該性騷擾事件行為人、犯罪嫌疑人或被告時，不得報導或記載被害人之姓名或其他足資識別被害人身分之資訊。
4   任何人除第一項但書規定情形外，不得以媒體或其他方法公開或揭露被害人之姓名及其他足資識別被害人身分之資訊。
5   因職務或業務知悉或持有第一項足資識別被害人身分之資訊者，除法律另有規定外，應予保密。
6   行政機關及司法機關所公示之文書，不得揭露被害人之姓名、出生年月日、住居所及其他足資識別被害人身分之資訊。

來源條目欄位（正規化資料）：
- id：article-10
- articleNumber：10
- displayNumber：第 10 條
- title：None
- structureId：chapter-3
- metadata：{"source": "全國法規資料庫 性騷擾防治法（PDF：法規-性騷擾防治法.pdf）", "lastModified": "2023-08-16"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   宣傳品、出版品、廣播、電視、網際網路或其他媒體，不得報導或記載被害人之姓名或其他足資識別被害人身分之資訊。但有下列情形之一者，不在此限："
  },
  {
    "type": "item",
    "number": "一",
    "text": "一、被害人為成年人，經本人同意。但心智障礙者、受監護宣告或輔助宣告者，應以其可理解方式提供資訊；受監護宣告者並應取得其監護人同意。"
  },
  {
    "type": "item",
    "number": "二",
    "text": "二、檢察官或法院依法認為有必要。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   前項第一款但書規定之監護人為同意時，應尊重受監護宣告者之意願。"
  },
  {
    "type": "paragraph",
    "number": "3",
    "text": "3   第一項第一款但書所定監護人為該性騷擾事件行為人、犯罪嫌疑人或被告時，不得報導或記載被害人之姓名或其他足資識別被害人身分之資訊。"
  },
  {
    "type": "paragraph",
    "number": "4",
    "text": "4   任何人除第一項但書規定情形外，不得以媒體或其他方法公開或揭露被害人之姓名及其他足資識別被害人身分之資訊。"
  },
  {
    "type": "paragraph",
    "number": "5",
    "text": "5   因職務或業務知悉或持有第一項足資識別被害人身分之資訊者，除法律另有規定外，應予保密。"
  },
  {
    "type": "paragraph",
    "number": "6",
    "text": "6   行政機關及司法機關所公示之文書，不得揭露被害人之姓名、出生年月日、住居所及其他足資識別被害人身分之資訊。"
  }
]
```

## U06-A11｜第 11 條

政府機關（構）、部隊、學校、警察機關及直轄市、縣（市）主管機關於性騷擾事件調查過程中，應視被害人之身心狀況，主動提供或轉介諮詢協談、心理輔導、法律協助、社會福利資源及其他必要之服務。

來源條目欄位（正規化資料）：
- id：article-11
- articleNumber：11
- displayNumber：第 11 條
- title：None
- structureId：chapter-3
- metadata：{"source": "全國法規資料庫 性騷擾防治法（PDF：法規-性騷擾防治法.pdf）", "lastModified": "2023-08-16"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": null,
    "text": "政府機關（構）、部隊、學校、警察機關及直轄市、縣（市）主管機關於性騷擾事件調查過程中，應視被害人之身心狀況，主動提供或轉介諮詢協談、心理輔導、法律協助、社會福利資源及其他必要之服務。"
  }
]
```

## U06-A12｜第 12 條

1   對他人為性騷擾者，負損害賠償責任。
2   前項情形，雖非財產上之損害，亦得請求賠償相當之金額，其名譽被侵害者，並得請求回復名譽之適當處分。
3   依前二項規定負損害賠償責任，且屬權勢性騷擾者，法院並得因被害人之請求，依侵害情節，酌定損害額一倍至三倍之懲罰性賠償金。

來源條目欄位（正規化資料）：
- id：article-12
- articleNumber：12
- displayNumber：第 12 條
- title：None
- structureId：chapter-3
- metadata：{"source": "全國法規資料庫 性騷擾防治法（PDF：法規-性騷擾防治法.pdf）", "lastModified": "2023-08-16"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   對他人為性騷擾者，負損害賠償責任。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   前項情形，雖非財產上之損害，亦得請求賠償相當之金額，其名譽被侵害者，並得請求回復名譽之適當處分。"
  },
  {
    "type": "paragraph",
    "number": "3",
    "text": "3   依前二項規定負損害賠償責任，且屬權勢性騷擾者，法院並得因被害人之請求，依侵害情節，酌定損害額一倍至三倍之懲罰性賠償金。"
  }
]
```

## U06-A13｜第 13 條

1   受僱人、機構負責人利用執行職務之便，對他人為性騷擾，依前條第二項規定對被害人為回復名譽之適當處分時，僱用人、機構應提供適當之協助。
2   學生、接受教育或訓練之人員於學校、教育或訓練機構接受教育或訓練時，對他人為性騷擾，依前條第二項規定對被害人為回復名譽之適當處分時，學校、教育或訓練機構應提供適當之協助。
3   前二項規定於政府機關（構）、部隊不適用之。

來源條目欄位（正規化資料）：
- id：article-13
- articleNumber：13
- displayNumber：第 13 條
- title：None
- structureId：chapter-3
- metadata：{"source": "全國法規資料庫 性騷擾防治法（PDF：法規-性騷擾防治法.pdf）", "lastModified": "2023-08-16"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   受僱人、機構負責人利用執行職務之便，對他人為性騷擾，依前條第二項規定對被害人為回復名譽之適當處分時，僱用人、機構應提供適當之協助。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   學生、接受教育或訓練之人員於學校、教育或訓練機構接受教育或訓練時，對他人為性騷擾，依前條第二項規定對被害人為回復名譽之適當處分時，學校、教育或訓練機構應提供適當之協助。"
  },
  {
    "type": "paragraph",
    "number": "3",
    "text": "3   前二項規定於政府機關（構）、部隊不適用之。"
  }
]
```

## U06-A14｜第 14 條

1   性騷擾事件被害人除可依相關法律請求協助外，得依下列規定提出申訴：
一、屬權勢性騷擾以外之性騷擾事件者，於知悉事件發生後二年內提出申訴。但自性騷擾事件發生之日起逾五年者，不得提出。
二、屬權勢性騷擾事件者，於知悉事件發生後三年內提出申訴。但自性騷擾事件發生之日起逾七年者，不得提出。
2   性騷擾事件發生時被害人未成年者，得於成年後三年內提出申訴。但依前項各款規定有較長之申訴期限者，從其規定。
3   前二項申訴得以書面或言詞，依下列規定提出：
一、申訴時行為人有所屬政府機關（構）、部隊、學校：向該政府機關（構）、部隊、學校提出。
二、申訴時行為人為政府機關（構）首長、各級軍事機關（構）及部隊上校編階以上之主官、學校校長、機構之最高負責人或僱用人：向該政府機關（構）、部隊、學校、機構或僱用人所在地之直轄市、縣（市）主管機關提出。
三、申訴時行為人不明或為前二款以外之人：向性騷擾事件發生地之警察機關提出。
4   性騷擾事件經撤回申訴或依第二十一條第五項規定視為撤回申訴者，不得就同一事件再行申訴。
5   申訴有下列情形之一者，直轄市、縣（市）主管機關應不予受理：
一、當事人逾期提出申訴。
二、申訴不合法定程式，經通知限期補正，屆期未補正。
三、同一性騷擾事件，撤回申訴或視為撤回申訴後再行申訴。

來源條目欄位（正規化資料）：
- id：article-14
- articleNumber：14
- displayNumber：第 14 條
- title：None
- structureId：chapter-4
- metadata：{"source": "全國法規資料庫 性騷擾防治法（PDF：法規-性騷擾防治法.pdf）", "lastModified": "2023-08-16"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   性騷擾事件被害人除可依相關法律請求協助外，得依下列規定提出申訴："
  },
  {
    "type": "item",
    "number": "一",
    "text": "一、屬權勢性騷擾以外之性騷擾事件者，於知悉事件發生後二年內提出申訴。但自性騷擾事件發生之日起逾五年者，不得提出。"
  },
  {
    "type": "item",
    "number": "二",
    "text": "二、屬權勢性騷擾事件者，於知悉事件發生後三年內提出申訴。但自性騷擾事件發生之日起逾七年者，不得提出。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   性騷擾事件發生時被害人未成年者，得於成年後三年內提出申訴。但依前項各款規定有較長之申訴期限者，從其規定。"
  },
  {
    "type": "paragraph",
    "number": "3",
    "text": "3   前二項申訴得以書面或言詞，依下列規定提出："
  },
  {
    "type": "item",
    "number": "一",
    "text": "一、申訴時行為人有所屬政府機關（構）、部隊、學校：向該政府機關（構）、部隊、學校提出。"
  },
  {
    "type": "item",
    "number": "二",
    "text": "二、申訴時行為人為政府機關（構）首長、各級軍事機關（構）及部隊上校編階以上之主官、學校校長、機構之最高負責人或僱用人：向該政府機關（構）、部隊、學校、機構或僱用人所在地之直轄市、縣（市）主管機關提出。"
  },
  {
    "type": "item",
    "number": "三",
    "text": "三、申訴時行為人不明或為前二款以外之人：向性騷擾事件發生地之警察機關提出。"
  },
  {
    "type": "paragraph",
    "number": "4",
    "text": "4   性騷擾事件經撤回申訴或依第二十一條第五項規定視為撤回申訴者，不得就同一事件再行申訴。"
  },
  {
    "type": "paragraph",
    "number": "5",
    "text": "5   申訴有下列情形之一者，直轄市、縣（市）主管機關應不予受理："
  },
  {
    "type": "item",
    "number": "一",
    "text": "一、當事人逾期提出申訴。"
  },
  {
    "type": "item",
    "number": "二",
    "text": "二、申訴不合法定程式，經通知限期補正，屆期未補正。"
  },
  {
    "type": "item",
    "number": "三",
    "text": "三、同一性騷擾事件，撤回申訴或視為撤回申訴後再行申訴。"
  }
]
```

## U06-A15｜第 15 條

1   政府機關（構）、部隊、學校、警察機關及直轄市、縣（市）主管機關應於受理申訴或移送到達之日起七日內開始調查，並應於二個月內調查完成；必要時，得延長一個月，並應通知當事人。
2   直轄市、縣（市）主管機關受理前條第三項第二款性騷擾申訴案件後，審議會召集人應於七日內指派委員三人至五人組成調查小組進行調查，並依前項規定辦理；調查小組之女性代表不得少於總數二分之一，並推選一人為小組召集人。
3   性騷擾事件之調查應秉持客觀、公正、專業之原則，給予雙方當事人充分陳述意見及答辯之機會，並應適時通知案件辦理情形；有詢問當事人之必要時，應避免重複詢問。
4   政府機關（構）、部隊、學校及警察機關為第一項調查及審議會為第二項調查，應作成調查報告及處理建議，移送直轄市、縣（市）主管機關辦理。

來源條目欄位（正規化資料）：
- id：article-15
- articleNumber：15
- displayNumber：第 15 條
- title：None
- structureId：chapter-4
- metadata：{"source": "全國法規資料庫 性騷擾防治法（PDF：法規-性騷擾防治法.pdf）", "lastModified": "2023-08-16"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   政府機關（構）、部隊、學校、警察機關及直轄市、縣（市）主管機關應於受理申訴或移送到達之日起七日內開始調查，並應於二個月內調查完成；必要時，得延長一個月，並應通知當事人。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   直轄市、縣（市）主管機關受理前條第三項第二款性騷擾申訴案件後，審議會召集人應於七日內指派委員三人至五人組成調查小組進行調查，並依前項規定辦理；調查小組之女性代表不得少於總數二分之一，並推選一人為小組召集人。"
  },
  {
    "type": "paragraph",
    "number": "3",
    "text": "3   性騷擾事件之調查應秉持客觀、公正、專業之原則，給予雙方當事人充分陳述意見及答辯之機會，並應適時通知案件辦理情形；有詢問當事人之必要時，應避免重複詢問。"
  },
  {
    "type": "paragraph",
    "number": "4",
    "text": "4   政府機關（構）、部隊、學校及警察機關為第一項調查及審議會為第二項調查，應作成調查報告及處理建議，移送直轄市、縣（市）主管機關辦理。"
  }
]
```

## U06-A16｜第 16 條

1   直轄市、縣（市）主管機關於接獲前條第四項之調查報告及處理建議後，應提報審議會審議；審議會審議認有必要者，得依前條第二項規定組成調查小組重行調查後再行審議。
2   性騷擾事件已進入偵查或審判程序者，審議會認有必要時，得議決於該程序終結前，停止該事件之處理。
3   性騷擾申訴案件經審議會審議後，直轄市、縣（市）主管機關應將該申訴案件調查結果之決定，以書面載明事實及理由通知申訴人、行為人、原移送單位及第十四條第三項第二款所定行為人之所屬單位。
4   申訴人及行為人對於前項調查結果之決定不服者，得依法提起訴願。

來源條目欄位（正規化資料）：
- id：article-16
- articleNumber：16
- displayNumber：第 16 條
- title：None
- structureId：chapter-4
- metadata：{"source": "全國法規資料庫 性騷擾防治法（PDF：法規-性騷擾防治法.pdf）", "lastModified": "2023-08-16"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   直轄市、縣（市）主管機關於接獲前條第四項之調查報告及處理建議後，應提報審議會審議；審議會審議認有必要者，得依前條第二項規定組成調查小組重行調查後再行審議。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   性騷擾事件已進入偵查或審判程序者，審議會認有必要時，得議決於該程序終結前，停止該事件之處理。"
  },
  {
    "type": "paragraph",
    "number": "3",
    "text": "3   性騷擾申訴案件經審議會審議後，直轄市、縣（市）主管機關應將該申訴案件調查結果之決定，以書面載明事實及理由通知申訴人、行為人、原移送單位及第十四條第三項第二款所定行為人之所屬單位。"
  },
  {
    "type": "paragraph",
    "number": "4",
    "text": "4   申訴人及行為人對於前項調查結果之決定不服者，得依法提起訴願。"
  }
]
```

## U06-A17｜第 17 條

政府機關（構）、部隊、學校、警察機關及直轄市、縣（市）主管機關進行調查時，行為人及受邀協助調查之人或單位應予配合，並提供相關資料，不得規避、妨礙或拒絕。

來源條目欄位（正規化資料）：
- id：article-17
- articleNumber：17
- displayNumber：第 17 條
- title：None
- structureId：chapter-4
- metadata：{"source": "全國法規資料庫 性騷擾防治法（PDF：法規-性騷擾防治法.pdf）", "lastModified": "2023-08-16"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": null,
    "text": "政府機關（構）、部隊、學校、警察機關及直轄市、縣（市）主管機關進行調查時，行為人及受邀協助調查之人或單位應予配合，並提供相關資料，不得規避、妨礙或拒絕。"
  }
]
```

## U06-A18｜第 18 條

1   權勢性騷擾以外之性騷擾事件，任一方當事人得以書面或言詞向直轄市、縣（市）主管機關申請調解。政府機關（構）、部隊、學校及警察機關於性騷擾事件調查程序中，獲知任一方當事人有調解意願時，應協助其向直轄市、縣（市）主管機關申請調解。
2   當事人以言詞申請調解者，直轄市、縣（市）主管機關應製作筆錄；以書面申請者，應按他造人數提出繕本。
3   調解期間，除依被害人之請求停止調查外，調查程序繼續進行。

來源條目欄位（正規化資料）：
- id：article-18
- articleNumber：18
- displayNumber：第 18 條
- title：None
- structureId：chapter-5
- metadata：{"source": "全國法規資料庫 性騷擾防治法（PDF：法規-性騷擾防治法.pdf）", "lastModified": "2023-08-16"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   權勢性騷擾以外之性騷擾事件，任一方當事人得以書面或言詞向直轄市、縣（市）主管機關申請調解。政府機關（構）、部隊、學校及警察機關於性騷擾事件調查程序中，獲知任一方當事人有調解意願時，應協助其向直轄市、縣（市）主管機關申請調解。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   當事人以言詞申請調解者，直轄市、縣（市）主管機關應製作筆錄；以書面申請者，應按他造人數提出繕本。"
  },
  {
    "type": "paragraph",
    "number": "3",
    "text": "3   調解期間，除依被害人之請求停止調查外，調查程序繼續進行。"
  }
]
```

## U06-A19｜第 19 條

1   直轄市、縣（市）主管機關應於受理調解申請後十日內，遴聘具有法學素養、性別平等意識之學者專家一人至三人擔任性騷擾事件調解委員調解之。
2   前項調解委員經遴聘後二十日內，直轄市、縣（市）主管機關應決定調解期日，通知當事人或其代理人到場，並將申請書狀或言詞申請筆錄繕本一併送達他造。但經當事人之一方申請延期者，得延長十日。

來源條目欄位（正規化資料）：
- id：article-19
- articleNumber：19
- displayNumber：第 19 條
- title：None
- structureId：chapter-5
- metadata：{"source": "全國法規資料庫 性騷擾防治法（PDF：法規-性騷擾防治法.pdf）", "lastModified": "2023-08-16"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   直轄市、縣（市）主管機關應於受理調解申請後十日內，遴聘具有法學素養、性別平等意識之學者專家一人至三人擔任性騷擾事件調解委員調解之。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   前項調解委員經遴聘後二十日內，直轄市、縣（市）主管機關應決定調解期日，通知當事人或其代理人到場，並將申請書狀或言詞申請筆錄繕本一併送達他造。但經當事人之一方申請延期者，得延長十日。"
  }
]
```

## U06-A20｜第 20 條

1   調解委員應親自進行調解，不得委任他人代理。
2   調解得視案件情形為必要之調查及商請有關機關協助。
3   調解除勘驗費，應由當事人核實支付外，不得收取任何費用或報酬。

來源條目欄位（正規化資料）：
- id：article-20
- articleNumber：20
- displayNumber：第 20 條
- title：None
- structureId：chapter-5
- metadata：{"source": "全國法規資料庫 性騷擾防治法（PDF：法規-性騷擾防治法.pdf）", "lastModified": "2023-08-16"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   調解委員應親自進行調解，不得委任他人代理。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   調解得視案件情形為必要之調查及商請有關機關協助。"
  },
  {
    "type": "paragraph",
    "number": "3",
    "text": "3   調解除勘驗費，應由當事人核實支付外，不得收取任何費用或報酬。"
  }
]
```

## U06-A21｜第 21 條

1   調解成立者，應作成調解書，並由當事人及出席調解委員簽名、蓋章或按指印。
2   前項調解書應記載事項如下：
一、當事人或其法定代理人之姓名、出生年月日、住居所及身分證明文件字號。
二、出席調解委員之姓名。
三、調解事由。
四、調解成立之內容。
五、調解成立之年、月、日。
六、決定機關及其首長。
3   直轄市、縣（市）主管機關應於調解成立之日起十日內將調解書及相關資料送請管轄法院核定。調解書經法院核定後，除抽存一份外，併調解事件資料發還直轄市、縣（市）主管機關送達當事人。
4   法院因調解內容牴觸法令、違背公共秩序或善良風俗或不能強制執行而未予核定者，應將其理由通知直轄市、縣（市）主管機關。
5   性騷擾申訴案件於作成調查結果之決定前經調解成立，調解書上載有當事人同意撤回申訴、告訴、自訴或起訴意旨，於法院核定後，其已提起之申訴、刑事告訴或自訴均視為撤回；其已提起之民事訴訟視為訴訟終結，原告並得於送達法院核定調解書之日起三個月內，向法院聲請退還已繳裁判費三分之二。
6   調解成立，經法院核定後，當事人就該事件不得提起申訴、刑事告訴、自訴及民事訴訟。

來源條目欄位（正規化資料）：
- id：article-21
- articleNumber：21
- displayNumber：第 21 條
- title：None
- structureId：chapter-5
- metadata：{"source": "全國法規資料庫 性騷擾防治法（PDF：法規-性騷擾防治法.pdf）", "lastModified": "2023-08-16"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   調解成立者，應作成調解書，並由當事人及出席調解委員簽名、蓋章或按指印。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   前項調解書應記載事項如下："
  },
  {
    "type": "item",
    "number": "一",
    "text": "一、當事人或其法定代理人之姓名、出生年月日、住居所及身分證明文件字號。"
  },
  {
    "type": "item",
    "number": "二",
    "text": "二、出席調解委員之姓名。"
  },
  {
    "type": "item",
    "number": "三",
    "text": "三、調解事由。"
  },
  {
    "type": "item",
    "number": "四",
    "text": "四、調解成立之內容。"
  },
  {
    "type": "item",
    "number": "五",
    "text": "五、調解成立之年、月、日。"
  },
  {
    "type": "item",
    "number": "六",
    "text": "六、決定機關及其首長。"
  },
  {
    "type": "paragraph",
    "number": "3",
    "text": "3   直轄市、縣（市）主管機關應於調解成立之日起十日內將調解書及相關資料送請管轄法院核定。調解書經法院核定後，除抽存一份外，併調解事件資料發還直轄市、縣（市）主管機關送達當事人。"
  },
  {
    "type": "paragraph",
    "number": "4",
    "text": "4   法院因調解內容牴觸法令、違背公共秩序或善良風俗或不能強制執行而未予核定者，應將其理由通知直轄市、縣（市）主管機關。"
  },
  {
    "type": "paragraph",
    "number": "5",
    "text": "5   性騷擾申訴案件於作成調查結果之決定前經調解成立，調解書上載有當事人同意撤回申訴、告訴、自訴或起訴意旨，於法院核定後，其已提起之申訴、刑事告訴或自訴均視為撤回；其已提起之民事訴訟視為訴訟終結，原告並得於送達法院核定調解書之日起三個月內，向法院聲請退還已繳裁判費三分之二。"
  },
  {
    "type": "paragraph",
    "number": "6",
    "text": "6   調解成立，經法院核定後，當事人就該事件不得提起申訴、刑事告訴、自訴及民事訴訟。"
  }
]
```

## U06-A22｜第 22 條

1   當事人無正當理由，於調解期日不到場者，視為調解不成立。但調解委員認為有成立調解之望者，得另訂調解期日。
2   調解不成立者，直轄市、縣（市）主管機關應即發給調解不成立證明書。被害人於調解不成立證明書送達後十日內，得向直轄市、縣（市）主管機關申請將調解事件移送該管司法機關，效力分別如下：
一、已提起申訴者，依申訴程序進行；未提起申訴者，視為申請調解時，提起申訴。
二、該調解事件移送民事法院，其第一審裁判費暫免徵收。
三、該調解事件涉及第二十五條第一項規定，於移送該管檢察官偵查時，視為於申請調解時已經告訴。

來源條目欄位（正規化資料）：
- id：article-22
- articleNumber：22
- displayNumber：第 22 條
- title：None
- structureId：chapter-5
- metadata：{"source": "全國法規資料庫 性騷擾防治法（PDF：法規-性騷擾防治法.pdf）", "lastModified": "2023-08-16"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   當事人無正當理由，於調解期日不到場者，視為調解不成立。但調解委員認為有成立調解之望者，得另訂調解期日。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   調解不成立者，直轄市、縣（市）主管機關應即發給調解不成立證明書。被害人於調解不成立證明書送達後十日內，得向直轄市、縣（市）主管機關申請將調解事件移送該管司法機關，效力分別如下："
  },
  {
    "type": "item",
    "number": "一",
    "text": "一、已提起申訴者，依申訴程序進行；未提起申訴者，視為申請調解時，提起申訴。"
  },
  {
    "type": "item",
    "number": "二",
    "text": "二、該調解事件移送民事法院，其第一審裁判費暫免徵收。"
  },
  {
    "type": "item",
    "number": "三",
    "text": "三、該調解事件涉及第二十五條第一項規定，於移送該管檢察官偵查時，視為於申請調解時已經告訴。"
  }
]
```

## U06-A23｜第 23 條

1   調解經法院核定，其屬民事調解者，與民事確定判決有同一之效力；屬涉及第二十五條第一項規定之刑事調解，以給付金錢或其他代替物或有價證券之一定數量為標的者，其調解書得為執行名義。
2   經法院核定後之民事調解，有無效或得撤銷之原因者，當事人得向原核定法院提起宣告調解無效或撤銷調解之訴。
3   前項規定，當事人應於法院核定之調解書送達後三十日內為之。
4   民事訴訟法第五百零二條及強制執行法第十八條第二項規定，於第二項情形準用之。

來源條目欄位（正規化資料）：
- id：article-23
- articleNumber：23
- displayNumber：第 23 條
- title：None
- structureId：chapter-5
- metadata：{"source": "全國法規資料庫 性騷擾防治法（PDF：法規-性騷擾防治法.pdf）", "lastModified": "2023-08-16"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   調解經法院核定，其屬民事調解者，與民事確定判決有同一之效力；屬涉及第二十五條第一項規定之刑事調解，以給付金錢或其他代替物或有價證券之一定數量為標的者，其調解書得為執行名義。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   經法院核定後之民事調解，有無效或得撤銷之原因者，當事人得向原核定法院提起宣告調解無效或撤銷調解之訴。"
  },
  {
    "type": "paragraph",
    "number": "3",
    "text": "3   前項規定，當事人應於法院核定之調解書送達後三十日內為之。"
  },
  {
    "type": "paragraph",
    "number": "4",
    "text": "4   民事訴訟法第五百零二條及強制執行法第十八條第二項規定，於第二項情形準用之。"
  }
]
```

## U06-A24｜第 24 條

1   調解程序，不公開之。
2   調解委員及經辦調解事務之人，對於調解事件，除已公開之事項外，應保守秘密。

來源條目欄位（正規化資料）：
- id：article-24
- articleNumber：24
- displayNumber：第 24 條
- title：None
- structureId：chapter-5
- metadata：{"source": "全國法規資料庫 性騷擾防治法（PDF：法規-性騷擾防治法.pdf）", "lastModified": "2023-08-16"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   調解程序，不公開之。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   調解委員及經辦調解事務之人，對於調解事件，除已公開之事項外，應保守秘密。"
  }
]
```

## U06-A25｜第 25 條

1   意圖性騷擾，乘人不及抗拒而為親吻、擁抱或觸摸其臀部、胸部或其他身體隱私處之行為者，處二年以下有期徒刑、拘役或併科新臺幣十萬元以下罰金；利用第二條第二項之權勢或機會而犯之者，加重其刑至二分之一。
2   前項之罪，須告訴乃論。

來源條目欄位（正規化資料）：
- id：article-25
- articleNumber：25
- displayNumber：第 25 條
- title：None
- structureId：chapter-6
- metadata：{"source": "全國法規資料庫 性騷擾防治法（PDF：法規-性騷擾防治法.pdf）", "lastModified": "2023-08-16"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   意圖性騷擾，乘人不及抗拒而為親吻、擁抱或觸摸其臀部、胸部或其他身體隱私處之行為者，處二年以下有期徒刑、拘役或併科新臺幣十萬元以下罰金；利用第二條第二項之權勢或機會而犯之者，加重其刑至二分之一。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   前項之罪，須告訴乃論。"
  }
]
```

## U06-A26｜第 26 條

1   廣播、電視事業違反第十條第一項或第三項規定者，由目的事業主管機關處新臺幣六萬元以上六十萬元以下罰鍰，並令其限期改正；屆期未改正者，得按次處罰。
2   前項以外之宣傳品、出版品、網際網路或其他媒體業者違反第十條第一項或第三項規定者，由目的事業主管機關處負責人新臺幣六萬元以上六十萬元以下罰鍰，並得沒入第十條第一項規定之物品、令其限期移除內容、下架或其他必要之處置；屆期不履行者，得按次處罰。
3   前二項規定，於被害人死亡，經目的事業主管機關權衡為維護治安、安定人心、澄清視聽、防止危險擴大或其他社會公益，認有報導或揭露必要者，不罰。
4   違反第十條第五項規定者，由直轄市、縣（市）主管機關處新臺幣六萬元以上六十萬元以下罰鍰。
5   第一項及第二項以外之任何人違反第十條第四項規定，而無正當理由者，由直轄市、縣（市）主管機關處新臺幣二萬元以上十萬元以下罰鍰。
6   宣傳品、出版品、網際網路或其他媒體無負責人或負責人對行為人之行為不具監督關係者，第二項之處罰對象為行為人。

來源條目欄位（正規化資料）：
- id：article-26
- articleNumber：26
- displayNumber：第 26 條
- title：None
- structureId：chapter-6
- metadata：{"source": "全國法規資料庫 性騷擾防治法（PDF：法規-性騷擾防治法.pdf）", "lastModified": "2023-08-16"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   廣播、電視事業違反第十條第一項或第三項規定者，由目的事業主管機關處新臺幣六萬元以上六十萬元以下罰鍰，並令其限期改正；屆期未改正者，得按次處罰。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   前項以外之宣傳品、出版品、網際網路或其他媒體業者違反第十條第一項或第三項規定者，由目的事業主管機關處負責人新臺幣六萬元以上六十萬元以下罰鍰，並得沒入第十條第一項規定之物品、令其限期移除內容、下架或其他必要之處置；屆期不履行者，得按次處罰。"
  },
  {
    "type": "paragraph",
    "number": "3",
    "text": "3   前二項規定，於被害人死亡，經目的事業主管機關權衡為維護治安、安定人心、澄清視聽、防止危險擴大或其他社會公益，認有報導或揭露必要者，不罰。"
  },
  {
    "type": "paragraph",
    "number": "4",
    "text": "4   違反第十條第五項規定者，由直轄市、縣（市）主管機關處新臺幣六萬元以上六十萬元以下罰鍰。"
  },
  {
    "type": "paragraph",
    "number": "5",
    "text": "5   第一項及第二項以外之任何人違反第十條第四項規定，而無正當理由者，由直轄市、縣（市）主管機關處新臺幣二萬元以上十萬元以下罰鍰。"
  },
  {
    "type": "paragraph",
    "number": "6",
    "text": "6   宣傳品、出版品、網際網路或其他媒體無負責人或負責人對行為人之行為不具監督關係者，第二項之處罰對象為行為人。"
  }
]
```

## U06-A27｜第 27 條

1   對他人為權勢性騷擾，經申訴調查成立者，由直轄市、縣（市）主管機關處新臺幣六萬元以上六十萬元以下罰鍰。
2   對他人為權勢性騷擾以外之性騷擾，經申訴調查成立者，由直轄市、縣（市）主管機關處新臺幣一萬元以上十萬元以下罰鍰。
3   前二項規定之裁處權，自被害人提出申訴時起，因三年期間之經過而消滅。

來源條目欄位（正規化資料）：
- id：article-27
- articleNumber：27
- displayNumber：第 27 條
- title：None
- structureId：chapter-6
- metadata：{"source": "全國法規資料庫 性騷擾防治法（PDF：法規-性騷擾防治法.pdf）", "lastModified": "2023-08-16"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   對他人為權勢性騷擾，經申訴調查成立者，由直轄市、縣（市）主管機關處新臺幣六萬元以上六十萬元以下罰鍰。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   對他人為權勢性騷擾以外之性騷擾，經申訴調查成立者，由直轄市、縣（市）主管機關處新臺幣一萬元以上十萬元以下罰鍰。"
  },
  {
    "type": "paragraph",
    "number": "3",
    "text": "3   前二項規定之裁處權，自被害人提出申訴時起，因三年期間之經過而消滅。"
  }
]
```

## U06-A28｜第 28 條

1   違反第七條第一項規定者，由直轄市、縣（市）主管機關處新臺幣二萬元以上二十萬元以下罰鍰，並令其限期改正；屆期未改正者，得按次處罰。
2   違反第七條第二項規定，致被害人權益受損者，由直轄市、縣（市）主管機關處新臺幣二萬元以上二十萬元以下罰鍰。

來源條目欄位（正規化資料）：
- id：article-28
- articleNumber：28
- displayNumber：第 28 條
- title：None
- structureId：chapter-6
- metadata：{"source": "全國法規資料庫 性騷擾防治法（PDF：法規-性騷擾防治法.pdf）", "lastModified": "2023-08-16"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   違反第七條第一項規定者，由直轄市、縣（市）主管機關處新臺幣二萬元以上二十萬元以下罰鍰，並令其限期改正；屆期未改正者，得按次處罰。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   違反第七條第二項規定，致被害人權益受損者，由直轄市、縣（市）主管機關處新臺幣二萬元以上二十萬元以下罰鍰。"
  }
]
```

## U06-A29｜第 29 條

政府機關（構）、部隊、學校、機構或僱用人違反第九條第一項規定為不當之差別待遇者，由直轄市、縣（市）主管機關處新臺幣一萬元以上十萬元以下罰鍰，並令其限期改正；屆期未改正者，得按次處罰。

來源條目欄位（正規化資料）：
- id：article-29
- articleNumber：29
- displayNumber：第 29 條
- title：None
- structureId：chapter-6
- metadata：{"source": "全國法規資料庫 性騷擾防治法（PDF：法規-性騷擾防治法.pdf）", "lastModified": "2023-08-16"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": null,
    "text": "政府機關（構）、部隊、學校、機構或僱用人違反第九條第一項規定為不當之差別待遇者，由直轄市、縣（市）主管機關處新臺幣一萬元以上十萬元以下罰鍰，並令其限期改正；屆期未改正者，得按次處罰。"
  }
]
```

## U06-A30｜第 30 條

行為人違反第十七條規定，無正當理由規避、妨礙、拒絕調查或拒絕提供資料者，由直轄市、縣（市）主管機關處新臺幣一萬元以上五萬元以下罰鍰，並得按次處罰。

來源條目欄位（正規化資料）：
- id：article-30
- articleNumber：30
- displayNumber：第 30 條
- title：None
- structureId：chapter-6
- metadata：{"source": "全國法規資料庫 性騷擾防治法（PDF：法規-性騷擾防治法.pdf）", "lastModified": "2023-08-16"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": null,
    "text": "行為人違反第十七條規定，無正當理由規避、妨礙、拒絕調查或拒絕提供資料者，由直轄市、縣（市）主管機關處新臺幣一萬元以上五萬元以下罰鍰，並得按次處罰。"
  }
]
```

## U06-A31｜第 31 條

1   第七條至第九條、第十二條至第十三條、第二十八條及第二十九條之規定，於性侵害犯罪準用之。
2   前項行政罰鍰之科處，由性侵害犯罪防治主管機關為之。

來源條目欄位（正規化資料）：
- id：article-31
- articleNumber：31
- displayNumber：第 31 條
- title：None
- structureId：chapter-7
- metadata：{"source": "全國法規資料庫 性騷擾防治法（PDF：法規-性騷擾防治法.pdf）", "lastModified": "2023-08-16"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   第七條至第九條、第十二條至第十三條、第二十八條及第二十九條之規定，於性侵害犯罪準用之。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   前項行政罰鍰之科處，由性侵害犯罪防治主管機關為之。"
  }
]
```

## U06-A32｜第 32 條

本法中華民國一百十二年七月三十一日修正之本條文施行前，已受理之性騷擾申訴、再申訴事件尚未終結者，及修正施行前已發生之性騷擾事件而於修正施行後受理申訴者，均依修正施行後之規定終結之。但已進行之程序，其效力不受影響。

來源條目欄位（正規化資料）：
- id：article-32
- articleNumber：32
- displayNumber：第 32 條
- title：None
- structureId：chapter-7
- metadata：{"source": "全國法規資料庫 性騷擾防治法（PDF：法規-性騷擾防治法.pdf）", "lastModified": "2023-08-16"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": null,
    "text": "本法中華民國一百十二年七月三十一日修正之本條文施行前，已受理之性騷擾申訴、再申訴事件尚未終結者，及修正施行前已發生之性騷擾事件而於修正施行後受理申訴者，均依修正施行後之規定終結之。但已進行之程序，其效力不受影響。"
  }
]
```

## U06-A33｜第 33 條

本法施行細則，由中央主管機關定之。

來源條目欄位（正規化資料）：
- id：article-33
- articleNumber：33
- displayNumber：第 33 條
- title：None
- structureId：chapter-7
- metadata：{"source": "全國法規資料庫 性騷擾防治法（PDF：法規-性騷擾防治法.pdf）", "lastModified": "2023-08-16"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": null,
    "text": "本法施行細則，由中央主管機關定之。"
  }
]
```

## U06-A34｜第 34 條

本法除第七條第二項、第三項、第十四條至第二十四條、第二十七條、第二十八條第二項及第三十條自中華民國一百十三年三月八日施行外，自公布日施行。

來源條目欄位（正規化資料）：
- id：article-34
- articleNumber：34
- displayNumber：第 34 條
- title：None
- structureId：chapter-7
- metadata：{"source": "全國法規資料庫 性騷擾防治法（PDF：法規-性騷擾防治法.pdf）", "lastModified": "2023-08-16"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": null,
    "text": "本法除第七條第二項、第三項、第十四條至第二十四條、第二十七條、第二十八條第二項及第三十條自中華民國一百十三年三月八日施行外，自公布日施行。"
  }
]
```

## 來源其他資料

- schemaVersion：1.3.0
- processing：{"normalizedBy": "ai", "processedAt": "2026-07-22T00:00:00Z", "sourceType": "document", "warnings": ["來源 PDF未印出官方法規代碼，code 依規範填「UNKNOWN」。"]}