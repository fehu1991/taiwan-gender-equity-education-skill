# LAW-U07｜性騷擾防治法施行細則

資料集：CGE-NB-1.3.0.1；編製日：2026-09-09。此日期不是法律查核日。

## 來源與版本

- source_id：U07
- filename：性騷擾防治法施行細則.json
- path：sources/uploaded/性騷擾防治法施行細則.json
- sha256：182200118624420ea5f35c97511f3c8156d20d13b28707b70a982a6ab54a4ee0
- regulation_id：tw-sexual-harassment-prevention-act-enforcement-rules
- name：性騷擾防治法施行細則
- version：{"id": "tw-sexual-harassment-prevention-act-enforcement-rules-20240306", "label": "修正日期：民國 113 年 03 月 06 日", "promulgationDate": "2024-03-06", "effectiveDate": "2024-03-08", "effectiveDateNote": "本版本施行條文明定自公布（發布）日施行，依中央法規標準法第13條，自公布（發布）之日起算至第三日起發生效力，故施行日為公布（發布）日之後二日。", "status": "effective"}
- article_count：26
- source_kind：user_uploaded_ai_normalized_json
- review_status：attachment_reference_not_full_current_audit
- review_notes：[]
- official_source_ids：[]
- normalization_warnings：["來源 PDF未載明主管機關，authority 依規範填「未提供」。", "來源 PDF未印出官方法規代碼，code 依規範填「UNKNOWN」。"]
- processed_at：2026-07-22T00:00:00Z
- authoritative_current_full_text：False

- id：tw-sexual-harassment-prevention-act-enforcement-rules
- code：UNKNOWN
- name：性騷擾防治法施行細則
- shortName：性騷擾防治法施行細則
- jurisdiction：TW
- authority：未提供
- aliases：[]
- version：{"id": "tw-sexual-harassment-prevention-act-enforcement-rules-20240306", "label": "修正日期：民國 113 年 03 月 06 日", "promulgationDate": "2024-03-06", "effectiveDate": "2024-03-08", "effectiveDateNote": "本版本施行條文明定自公布（發布）日施行，依中央法規標準法第13條，自公布（發布）之日起算至第三日起發生效力，故施行日為公布（發布）日之後二日。", "status": "effective"}
- structure：[]
- legalConcepts：[{"id": "sexual-harassment-prevention-framework", "name": "性騷擾防治法律框架", "description": "彙整我國性騷擾之定義、防治義務、申訴調查程序與相關罰則所涉之法規；並涵蓋依場域與當事人身分關係而分流適用之性別平等工作法與性別平等教育法。", "aliases": ["性騷擾防治"], "tags": ["性騷擾", "防治", "申訴"], "role": "supporting", "sortOrder": 1}, {"id": "gender-equity-campus-framework", "name": "校園性別事件處理法律框架", "description": "彙整校園性侵害、性騷擾及性霸凌事件之防治、調查與處理程序所涉之法規，包含性別平等教育法及其授權訂定之準則與學校校內規定。", "aliases": ["校園性別事件"], "tags": ["校園", "性別事件", "性平教育"], "role": "related", "sortOrder": 2}, {"id": "sexual-assault-prevention-framework", "name": "性侵害犯罪防治法律框架", "description": "彙整性侵害犯罪之防治、被害人保護與加害人處遇所涉之法規。", "aliases": ["性侵害防治"], "tags": ["性侵害", "被害人保護"], "role": "related", "sortOrder": 3}]
- crossRegulationLinks：[{"conceptId": "sexual-harassment-prevention-framework", "sourceArticleId": "article-1", "label": "引用性騷擾防治法", "relationType": "authorization", "conditionText": "本細則依性騷擾防治法（以下簡稱本法）第三十三條規定訂定之。", "targetRegulationId": "tw-sexual-harassment-prevention-act", "targetRegulationNames": ["性騷擾防治法"], "targetArticleNumber": "33", "triggerTerms": ["本細則依"], "linkMode": "automatic", "id": "link-tw-sexual-harassment-prevention-act-enforcement-rules-cite-1", "sortOrder": 0}, {"conceptId": "gender-equity-campus-framework", "sourceArticleId": "article-3", "label": "引用性別平等教育法", "relationType": "application", "conditionText": "政府機關（構）、部隊、學校、警察機關或直轄市、縣（市）主管機關，接獲本法第一條第二項但書所定性別平等教育法及性別平等工作法之性騷擾事件，應於接獲之日起二十日內，移送該事件之主管機關，並副知當事人。", "targetRegulationId": "tw-gender-equity-education-act", "targetRegulationNames": ["性別平等教育法"], "targetArticleNumber": null, "triggerTerms": ["但書所定"], "linkMode": "automatic", "id": "link-tw-sexual-harassment-prevention-act-enforcement-rules-cite-2", "sortOrder": 1}, {"conceptId": "sexual-harassment-prevention-framework", "sourceArticleId": "article-3", "label": "引用性別平等工作法", "relationType": "application", "conditionText": "政府機關（構）、部隊、學校、警察機關或直轄市、縣（市）主管機關，接獲本法第一條第二項但書所定性別平等教育法及性別平等工作法之性騷擾事件，應於接獲之日起二十日內，移送該事件之主管機關，並副知當事人。", "targetRegulationId": "tw-gender-equality-employment-act", "targetRegulationNames": ["性別平等工作法"], "targetArticleNumber": null, "triggerTerms": ["教育法及"], "linkMode": "automatic", "id": "link-tw-sexual-harassment-prevention-act-enforcement-rules-cite-3", "sortOrder": 2}, {"conceptId": "sexual-assault-prevention-framework", "sourceArticleId": "article-4", "label": "引用性侵害犯罪防治法", "relationType": "authorization", "conditionText": "本法第二條所稱性侵害犯罪，指性侵害犯罪防治法第二條第一款所定之犯罪。", "targetRegulationId": "tw-sexual-assault-crime-prevention-act", "targetRegulationNames": ["性侵害犯罪防治法"], "targetArticleNumber": "2", "triggerTerms": ["犯罪，指"], "linkMode": "automatic", "id": "link-tw-sexual-harassment-prevention-act-enforcement-rules-cite-4", "sortOrder": 3}, {"conceptId": "sexual-harassment-prevention-framework", "sourceArticleId": "article-16", "label": "引用行政程序法", "relationType": "application", "conditionText": "政府機關（構）、部隊、學校或直轄市、縣（市）主管機關調查性騷擾事件，必要時，得依行政程序法第十九條規定請求警察機關協助。", "targetRegulationId": "tw-administrative-procedure-act", "targetRegulationNames": ["行政程序法"], "targetArticleNumber": "19", "triggerTerms": ["時，得依"], "linkMode": "automatic", "id": "link-tw-sexual-harassment-prevention-act-enforcement-rules-cite-5", "sortOrder": 4}]
- definedTerms：[]

正規化概念、跨法連結與處理狀態不是獨立法源；下面逐條保留來源plainText，未以本次日期重寫。

## U07-A1｜第 1 條

本細則依性騷擾防治法（以下簡稱本法）第三十三條規定訂定之。

來源條目欄位（正規化資料）：
- id：article-1
- articleNumber：1
- displayNumber：第 1 條
- title：None
- structureId：None
- metadata：{"source": "全國法規資料庫 性騷擾防治法施行細則（PDF：法規-性騷擾防治法施行細則.pdf）", "lastModified": "2024-03-06"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": null,
    "text": "本細則依性騷擾防治法（以下簡稱本法）第三十三條規定訂定之。"
  }
]
```

## U07-A2｜第 2 條

性騷擾之認定，應就個案審酌事件發生之背景、環境、當事人之關係、言詞、行為、認知或其他具體事實為之。

來源條目欄位（正規化資料）：
- id：article-2
- articleNumber：2
- displayNumber：第 2 條
- title：None
- structureId：None
- metadata：{"source": "全國法規資料庫 性騷擾防治法施行細則（PDF：法規-性騷擾防治法施行細則.pdf）", "lastModified": "2024-03-06"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": null,
    "text": "性騷擾之認定，應就個案審酌事件發生之背景、環境、當事人之關係、言詞、行為、認知或其他具體事實為之。"
  }
]
```

## U07-A3｜第 3 條

政府機關（構）、部隊、學校、警察機關或直轄市、縣（市）主管機關，接獲本法第一條第二項但書所定性別平等教育法及性別平等工作法之性騷擾事件，應於接獲之日起二十日內，移送該事件之主管機關，並副知當事人。

來源條目欄位（正規化資料）：
- id：article-3
- articleNumber：3
- displayNumber：第 3 條
- title：None
- structureId：None
- metadata：{"source": "全國法規資料庫 性騷擾防治法施行細則（PDF：法規-性騷擾防治法施行細則.pdf）", "lastModified": "2024-03-06"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": null,
    "text": "政府機關（構）、部隊、學校、警察機關或直轄市、縣（市）主管機關，接獲本法第一條第二項但書所定性別平等教育法及性別平等工作法之性騷擾事件，應於接獲之日起二十日內，移送該事件之主管機關，並副知當事人。"
  }
]
```

## U07-A4｜第 4 條

本法第二條所稱性侵害犯罪，指性侵害犯罪防治法第二條第一款所定之犯罪。

來源條目欄位（正規化資料）：
- id：article-4
- articleNumber：4
- displayNumber：第 4 條
- title：None
- structureId：None
- metadata：{"source": "全國法規資料庫 性騷擾防治法施行細則（PDF：法規-性騷擾防治法施行細則.pdf）", "lastModified": "2024-03-06"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": null,
    "text": "本法第二條所稱性侵害犯罪，指性侵害犯罪防治法第二條第一款所定之犯罪。"
  }
]
```

## U07-A5｜第 5 條

1   本法第六條所定性騷擾防治審議會，應每季至少召開一次。
2   召集人不能出席時，由副召集人或出席委員互推一人代理之。

來源條目欄位（正規化資料）：
- id：article-5
- articleNumber：5
- displayNumber：第 5 條
- title：None
- structureId：None
- metadata：{"source": "全國法規資料庫 性騷擾防治法施行細則（PDF：法規-性騷擾防治法施行細則.pdf）", "lastModified": "2024-03-06"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   本法第六條所定性騷擾防治審議會，應每季至少召開一次。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   召集人不能出席時，由副召集人或出席委員互推一人代理之。"
  }
]
```

## U07-A6｜第 6 條

性騷擾事件之調查人員、審議或調解委員，應具備性別平等意識。

來源條目欄位（正規化資料）：
- id：article-6
- articleNumber：6
- displayNumber：第 6 條
- title：None
- structureId：None
- metadata：{"source": "全國法規資料庫 性騷擾防治法施行細則（PDF：法規-性騷擾防治法施行細則.pdf）", "lastModified": "2024-03-06"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": null,
    "text": "性騷擾事件之調查人員、審議或調解委員，應具備性別平等意識。"
  }
]
```

## U07-A7｜第 7 條

性騷擾事件之調查、審議及調解，應以不公開方式為之，並保護當事人之隱私及其他權益。

來源條目欄位（正規化資料）：
- id：article-7
- articleNumber：7
- displayNumber：第 7 條
- title：None
- structureId：None
- metadata：{"source": "全國法規資料庫 性騷擾防治法施行細則（PDF：法規-性騷擾防治法施行細則.pdf）", "lastModified": "2024-03-06"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": null,
    "text": "性騷擾事件之調查、審議及調解，應以不公開方式為之，並保護當事人之隱私及其他權益。"
  }
]
```

## U07-A8｜第 8 條

1   本法第七條第一項所定組織成員、受僱人或受服務人員之計算，包括分支機構及附屬單位，並依被害人申訴當月第一個工作日之總人數計算。
2   前項受服務人員，指到達該政府機關（構）、部隊、學校、機構或僱用人之處所受服務，且非組織成員或受僱人者。

來源條目欄位（正規化資料）：
- id：article-8
- articleNumber：8
- displayNumber：第 8 條
- title：None
- structureId：None
- metadata：{"source": "全國法規資料庫 性騷擾防治法施行細則（PDF：法規-性騷擾防治法施行細則.pdf）", "lastModified": "2024-03-06"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   本法第七條第一項所定組織成員、受僱人或受服務人員之計算，包括分支機構及附屬單位，並依被害人申訴當月第一個工作日之總人數計算。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   前項受服務人員，指到達該政府機關（構）、部隊、學校、機構或僱用人之處所受服務，且非組織成員或受僱人者。"
  }
]
```

## U07-A9｜第 9 條

本法第九條所稱不當之差別待遇，指無正當理由之解僱、降調、減薪或損害其依法所應享有之權益。

來源條目欄位（正規化資料）：
- id：article-9
- articleNumber：9
- displayNumber：第 9 條
- title：None
- structureId：None
- metadata：{"source": "全國法規資料庫 性騷擾防治法施行細則（PDF：法規-性騷擾防治法施行細則.pdf）", "lastModified": "2024-03-06"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": null,
    "text": "本法第九條所稱不當之差別待遇，指無正當理由之解僱、降調、減薪或損害其依法所應享有之權益。"
  }
]
```

## U07-A10｜第 10 條

本法第十條第一項所定其他足資識別被害人身分之資訊，包括被害人照片、影像、圖畫、聲音、住址、親屬姓名或其關係、就讀學校、班級、工作場所與名稱或其他得以直接或間接方式識別該被害人個人之資料。

來源條目欄位（正規化資料）：
- id：article-10
- articleNumber：10
- displayNumber：第 10 條
- title：None
- structureId：None
- metadata：{"source": "全國法規資料庫 性騷擾防治法施行細則（PDF：法規-性騷擾防治法施行細則.pdf）", "lastModified": "2024-03-06"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": null,
    "text": "本法第十條第一項所定其他足資識別被害人身分之資訊，包括被害人照片、影像、圖畫、聲音、住址、親屬姓名或其關係、就讀學校、班級、工作場所與名稱或其他得以直接或間接方式識別該被害人個人之資料。"
  }
]
```

## U07-A11｜第 11 條

本法第十一條所定被害人諮詢協談、心理輔導、法律協助、社會福利資源及其他必要之服務，由被害人居所地之直轄市、縣（市）主管機關提供，並得因事件個案需要，協調相關單位協助。

來源條目欄位（正規化資料）：
- id：article-11
- articleNumber：11
- displayNumber：第 11 條
- title：None
- structureId：None
- metadata：{"source": "全國法規資料庫 性騷擾防治法施行細則（PDF：法規-性騷擾防治法施行細則.pdf）", "lastModified": "2024-03-06"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": null,
    "text": "本法第十一條所定被害人諮詢協談、心理輔導、法律協助、社會福利資源及其他必要之服務，由被害人居所地之直轄市、縣（市）主管機關提供，並得因事件個案需要，協調相關單位協助。"
  }
]
```

## U07-A12｜第 12 條

1   本法第十四條所定性騷擾之申訴，得以書面或言詞提出；其以言詞為之者，受理之人員或單位應作成紀錄，經向申訴人朗讀或使閱覽，確認其內容無誤後，由其簽名或蓋章。
2   以書面提出之申訴或以言詞作成之申訴紀錄（以下併稱申訴書），應載明下列事項：
一、申訴人之姓名、性別、出生年月日、身分證明文件編號、服務或就學之單位與職稱、住所或居所及聯絡電話。
二、有法定代理人者，其姓名、性別、出生年月日、身分證明文件編號、職業、住所或居所及聯絡電話。
三、有委任代理人者，其姓名、性別、出生年月日、身分證明文件編號、職業、住所或居所及聯絡電話。
四、申訴之事實內容及相關證據。
五、性騷擾事件發生及知悉之時間。
六、申訴之年月日。
3   前項第三款規定，申訴人應檢附委任書。

來源條目欄位（正規化資料）：
- id：article-12
- articleNumber：12
- displayNumber：第 12 條
- title：None
- structureId：None
- metadata：{"source": "全國法規資料庫 性騷擾防治法施行細則（PDF：法規-性騷擾防治法施行細則.pdf）", "lastModified": "2024-03-06"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   本法第十四條所定性騷擾之申訴，得以書面或言詞提出；其以言詞為之者，受理之人員或單位應作成紀錄，經向申訴人朗讀或使閱覽，確認其內容無誤後，由其簽名或蓋章。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   以書面提出之申訴或以言詞作成之申訴紀錄（以下併稱申訴書），應載明下列事項："
  },
  {
    "type": "item",
    "number": "一",
    "text": "一、申訴人之姓名、性別、出生年月日、身分證明文件編號、服務或就學之單位與職稱、住所或居所及聯絡電話。"
  },
  {
    "type": "item",
    "number": "二",
    "text": "二、有法定代理人者，其姓名、性別、出生年月日、身分證明文件編號、職業、住所或居所及聯絡電話。"
  },
  {
    "type": "item",
    "number": "三",
    "text": "三、有委任代理人者，其姓名、性別、出生年月日、身分證明文件編號、職業、住所或居所及聯絡電話。"
  },
  {
    "type": "item",
    "number": "四",
    "text": "四、申訴之事實內容及相關證據。"
  },
  {
    "type": "item",
    "number": "五",
    "text": "五、性騷擾事件發生及知悉之時間。"
  },
  {
    "type": "item",
    "number": "六",
    "text": "六、申訴之年月日。"
  },
  {
    "type": "paragraph",
    "number": "3",
    "text": "3   前項第三款規定，申訴人應檢附委任書。"
  }
]
```

## U07-A13｜第 13 條

1   政府機關（構）、部隊、學校、警察機關或直轄市、縣（市）主管機關（以下併稱受理單位）接獲性騷擾申訴而不具調查權限者，應於接獲申訴之日起十四日內查明並移送具有調查權之受理單位（以下稱調查單位），未能查明調查單位者，應移送性騷擾事件發生地之警察機關就性騷擾申訴為調查。
2   前項移送，應以書面通知當事人，並副知直轄市、縣（市）主管機關。

來源條目欄位（正規化資料）：
- id：article-13
- articleNumber：13
- displayNumber：第 13 條
- title：None
- structureId：None
- metadata：{"source": "全國法規資料庫 性騷擾防治法施行細則（PDF：法規-性騷擾防治法施行細則.pdf）", "lastModified": "2024-03-06"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   政府機關（構）、部隊、學校、警察機關或直轄市、縣（市）主管機關（以下併稱受理單位）接獲性騷擾申訴而不具調查權限者，應於接獲申訴之日起十四日內查明並移送具有調查權之受理單位（以下稱調查單位），未能查明調查單位者，應移送性騷擾事件發生地之警察機關就性騷擾申訴為調查。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   前項移送，應以書面通知當事人，並副知直轄市、縣（市）主管機關。"
  }
]
```

## U07-A14｜第 14 條

1   申訴書不合第十二條規定，而其情形可補正者，受理單位應通知申訴人於十四日內補正。
2   受理單位認性騷擾事件有本法第十四條第五項所定不予受理情形之一者，應即移送直轄市、縣（市）主管機關決定不予受理或應續行調查。
3   直轄市、縣（市）主管機關認應續行調查者，應即移送調查單位為本法第十五條第一項之調查。

來源條目欄位（正規化資料）：
- id：article-14
- articleNumber：14
- displayNumber：第 14 條
- title：None
- structureId：None
- metadata：{"source": "全國法規資料庫 性騷擾防治法施行細則（PDF：法規-性騷擾防治法施行細則.pdf）", "lastModified": "2024-03-06"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   申訴書不合第十二條規定，而其情形可補正者，受理單位應通知申訴人於十四日內補正。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   受理單位認性騷擾事件有本法第十四條第五項所定不予受理情形之一者，應即移送直轄市、縣（市）主管機關決定不予受理或應續行調查。"
  },
  {
    "type": "paragraph",
    "number": "3",
    "text": "3   直轄市、縣（市）主管機關認應續行調查者，應即移送調查單位為本法第十五條第一項之調查。"
  }
]
```

## U07-A15｜第 15 條

1   性騷擾事件之調查人員於調查過程中，有下列各款情形之一者，應自行迴避：
一、本人或其配偶、前配偶、四親等內之血親或三親等內之姻親或曾有此關係者為該事件之當事人。
二、本人或其配偶、前配偶，就該事件與當事人有共同權利人或共同義務人之關係。
三、現為或曾為該事件當事人之代理人、輔佐人。
四、於該事件，曾為證人、鑑定人。
2   性騷擾事件之調查人員有下列各款情形之一，當事人得申請迴避︰
一、有前項所定之情形而不自行迴避。
二、有具體事實，足認其執行調查有偏頗之虞。
3   前項申請，應舉其原因及事實，向該事件之調查單位為之，並為適當之釋明；被申請迴避之調查人員，得提出意見書。
4   被申請迴避之調查人員，於調查單位為准駁前，應停止調查工作。但有急迫情形，仍應為必要處置。
5   調查人員有第一項所定情形不自行迴避，且未經當事人申請迴避者，調查單位應命其迴避。
6   直轄市、縣（市）主管機關之審議委員或調解委員，有第一項各款情形時，應行迴避。

來源條目欄位（正規化資料）：
- id：article-15
- articleNumber：15
- displayNumber：第 15 條
- title：None
- structureId：None
- metadata：{"source": "全國法規資料庫 性騷擾防治法施行細則（PDF：法規-性騷擾防治法施行細則.pdf）", "lastModified": "2024-03-06"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   性騷擾事件之調查人員於調查過程中，有下列各款情形之一者，應自行迴避："
  },
  {
    "type": "item",
    "number": "一",
    "text": "一、本人或其配偶、前配偶、四親等內之血親或三親等內之姻親或曾有此關係者為該事件之當事人。"
  },
  {
    "type": "item",
    "number": "二",
    "text": "二、本人或其配偶、前配偶，就該事件與當事人有共同權利人或共同義務人之關係。"
  },
  {
    "type": "item",
    "number": "三",
    "text": "三、現為或曾為該事件當事人之代理人、輔佐人。"
  },
  {
    "type": "item",
    "number": "四",
    "text": "四、於該事件，曾為證人、鑑定人。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   性騷擾事件之調查人員有下列各款情形之一，當事人得申請迴避︰"
  },
  {
    "type": "item",
    "number": "一",
    "text": "一、有前項所定之情形而不自行迴避。"
  },
  {
    "type": "item",
    "number": "二",
    "text": "二、有具體事實，足認其執行調查有偏頗之虞。"
  },
  {
    "type": "paragraph",
    "number": "3",
    "text": "3   前項申請，應舉其原因及事實，向該事件之調查單位為之，並為適當之釋明；被申請迴避之調查人員，得提出意見書。"
  },
  {
    "type": "paragraph",
    "number": "4",
    "text": "4   被申請迴避之調查人員，於調查單位為准駁前，應停止調查工作。但有急迫情形，仍應為必要處置。"
  },
  {
    "type": "paragraph",
    "number": "5",
    "text": "5   調查人員有第一項所定情形不自行迴避，且未經當事人申請迴避者，調查單位應命其迴避。"
  },
  {
    "type": "paragraph",
    "number": "6",
    "text": "6   直轄市、縣（市）主管機關之審議委員或調解委員，有第一項各款情形時，應行迴避。"
  }
]
```

## U07-A16｜第 16 條

政府機關（構）、部隊、學校或直轄市、縣（市）主管機關調查性騷擾事件，必要時，得依行政程序法第十九條規定請求警察機關協助。

來源條目欄位（正規化資料）：
- id：article-16
- articleNumber：16
- displayNumber：第 16 條
- title：None
- structureId：None
- metadata：{"source": "全國法規資料庫 性騷擾防治法施行細則（PDF：法規-性騷擾防治法施行細則.pdf）", "lastModified": "2024-03-06"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": null,
    "text": "政府機關（構）、部隊、學校或直轄市、縣（市）主管機關調查性騷擾事件，必要時，得依行政程序法第十九條規定請求警察機關協助。"
  }
]
```

## U07-A17｜第 17 條

1   性騷擾事件之當事人或證人有權力不對等之情形時，應避免使其對質。
2   調查人員因調查之必要，得於不違反保密義務範圍內另作成書面資料，交由當事人閱覽或告以要旨。

來源條目欄位（正規化資料）：
- id：article-17
- articleNumber：17
- displayNumber：第 17 條
- title：None
- structureId：None
- metadata：{"source": "全國法規資料庫 性騷擾防治法施行細則（PDF：法規-性騷擾防治法施行細則.pdf）", "lastModified": "2024-03-06"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   性騷擾事件之當事人或證人有權力不對等之情形時，應避免使其對質。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   調查人員因調查之必要，得於不違反保密義務範圍內另作成書面資料，交由當事人閱覽或告以要旨。"
  }
]
```

## U07-A18｜第 18 條

調查單位依本法所為調查報告及處理建議，應載明下列事項：
一、性騷擾事件之案由，包括當事人之敘述。
二、調查訪談過程紀錄，包括日期及對象。
三、申訴人、證人與相關人士、被申訴人之陳述及答辯。
四、相關物證之查驗。
五、性騷擾事件調查結果及處理建議。

來源條目欄位（正規化資料）：
- id：article-18
- articleNumber：18
- displayNumber：第 18 條
- title：None
- structureId：None
- metadata：{"source": "全國法規資料庫 性騷擾防治法施行細則（PDF：法規-性騷擾防治法施行細則.pdf）", "lastModified": "2024-03-06"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": null,
    "text": "調查單位依本法所為調查報告及處理建議，應載明下列事項："
  },
  {
    "type": "item",
    "number": "一",
    "text": "一、性騷擾事件之案由，包括當事人之敘述。"
  },
  {
    "type": "item",
    "number": "二",
    "text": "二、調查訪談過程紀錄，包括日期及對象。"
  },
  {
    "type": "item",
    "number": "三",
    "text": "三、申訴人、證人與相關人士、被申訴人之陳述及答辯。"
  },
  {
    "type": "item",
    "number": "四",
    "text": "四、相關物證之查驗。"
  },
  {
    "type": "item",
    "number": "五",
    "text": "五、性騷擾事件調查結果及處理建議。"
  }
]
```

## U07-A19｜第 19 條

1   直轄市、縣（市）主管機關接獲性騷擾事件調查報告及處理建議，與相關書表資料後，認有補正之必要者，應通知該事件調查單位補正。
2   前項調查單位，應於收受通知後十四日內補正。

來源條目欄位（正規化資料）：
- id：article-19
- articleNumber：19
- displayNumber：第 19 條
- title：None
- structureId：None
- metadata：{"source": "全國法規資料庫 性騷擾防治法施行細則（PDF：法規-性騷擾防治法施行細則.pdf）", "lastModified": "2024-03-06"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   直轄市、縣（市）主管機關接獲性騷擾事件調查報告及處理建議，與相關書表資料後，認有補正之必要者，應通知該事件調查單位補正。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   前項調查單位，應於收受通知後十四日內補正。"
  }
]
```

## U07-A20｜第 20 條

1   本法第十六條第一項所定有必要重行調查者，指下列情形之一：
一、調查程序有重大瑕疵。
二、有足以影響原調查認定之新事實、新證據。
三、其他性騷擾防治審議會認有必要重行調查之原因。
2   前項重行調查應於二個月內調查完成；必要時，得延長一個月，並通知當事人。

來源條目欄位（正規化資料）：
- id：article-20
- articleNumber：20
- displayNumber：第 20 條
- title：None
- structureId：None
- metadata：{"source": "全國法規資料庫 性騷擾防治法施行細則（PDF：法規-性騷擾防治法施行細則.pdf）", "lastModified": "2024-03-06"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   本法第十六條第一項所定有必要重行調查者，指下列情形之一："
  },
  {
    "type": "item",
    "number": "一",
    "text": "一、調查程序有重大瑕疵。"
  },
  {
    "type": "item",
    "number": "二",
    "text": "二、有足以影響原調查認定之新事實、新證據。"
  },
  {
    "type": "item",
    "number": "三",
    "text": "三、其他性騷擾防治審議會認有必要重行調查之原因。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   前項重行調查應於二個月內調查完成；必要時，得延長一個月，並通知當事人。"
  }
]
```

## U07-A21｜第 21 條

行為人無正當理由規避、妨礙或拒絕提供資料者，政府機關（構）、部隊、學校、警察機關，應通知直轄市、縣（市）主管機關依本法第三十條辦理。

來源條目欄位（正規化資料）：
- id：article-21
- articleNumber：21
- displayNumber：第 21 條
- title：None
- structureId：None
- metadata：{"source": "全國法規資料庫 性騷擾防治法施行細則（PDF：法規-性騷擾防治法施行細則.pdf）", "lastModified": "2024-03-06"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": null,
    "text": "行為人無正當理由規避、妨礙或拒絕提供資料者，政府機關（構）、部隊、學校、警察機關，應通知直轄市、縣（市）主管機關依本法第三十條辦理。"
  }
]
```

## U07-A22｜第 22 條

調解委員不得以強暴、脅迫、恐嚇或詐術進行調解、阻止起訴、告訴或自訴，或有其他涉嫌犯罪之行為。

來源條目欄位（正規化資料）：
- id：article-22
- articleNumber：22
- displayNumber：第 22 條
- title：None
- structureId：None
- metadata：{"source": "全國法規資料庫 性騷擾防治法施行細則（PDF：法規-性騷擾防治法施行細則.pdf）", "lastModified": "2024-03-06"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": null,
    "text": "調解委員不得以強暴、脅迫、恐嚇或詐術進行調解、阻止起訴、告訴或自訴，或有其他涉嫌犯罪之行為。"
  }
]
```

## U07-A23｜第 23 條

依本法第十八條申請調解者，於調解期間，直轄市、縣（市）主管機關依被害人請求停止調查時，應通知調查單位停止調查。

來源條目欄位（正規化資料）：
- id：article-23
- articleNumber：23
- displayNumber：第 23 條
- title：None
- structureId：None
- metadata：{"source": "全國法規資料庫 性騷擾防治法施行細則（PDF：法規-性騷擾防治法施行細則.pdf）", "lastModified": "2024-03-06"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": null,
    "text": "依本法第十八條申請調解者，於調解期間，直轄市、縣（市）主管機關依被害人請求停止調查時，應通知調查單位停止調查。"
  }
]
```

## U07-A24｜第 24 條

本法第二十六條所稱目的事業主管機關，指下列機關：
一、廣播、電視事業：國家通訊傳播委員會。
二、宣傳品、出版品、網際網路或其他媒體：被害人居所地之直轄市、縣（市）主管機關。

來源條目欄位（正規化資料）：
- id：article-24
- articleNumber：24
- displayNumber：第 24 條
- title：None
- structureId：None
- metadata：{"source": "全國法規資料庫 性騷擾防治法施行細則（PDF：法規-性騷擾防治法施行細則.pdf）", "lastModified": "2024-03-06"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": null,
    "text": "本法第二十六條所稱目的事業主管機關，指下列機關："
  },
  {
    "type": "item",
    "number": "一",
    "text": "一、廣播、電視事業：國家通訊傳播委員會。"
  },
  {
    "type": "item",
    "number": "二",
    "text": "二、宣傳品、出版品、網際網路或其他媒體：被害人居所地之直轄市、縣（市）主管機關。"
  }
]
```

## U07-A25｜第 25 條

本法第六章所稱直轄市、縣（市）主管機關，指下列機關：
一、本法第二十六條第四項及第五項：被害人居所地之直轄市、縣（市）主管機關。
二、本法第二十七條、第二十九條及第三十條：性騷擾事件調查單位所在地之直轄市、縣（市）主管機關。
三、本法第二十八條：該政府機關（構）、部隊、學校、機構或僱用人所在地之直轄市、縣（市）主管機關。

來源條目欄位（正規化資料）：
- id：article-25
- articleNumber：25
- displayNumber：第 25 條
- title：None
- structureId：None
- metadata：{"source": "全國法規資料庫 性騷擾防治法施行細則（PDF：法規-性騷擾防治法施行細則.pdf）", "lastModified": "2024-03-06"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": null,
    "text": "本法第六章所稱直轄市、縣（市）主管機關，指下列機關："
  },
  {
    "type": "item",
    "number": "一",
    "text": "一、本法第二十六條第四項及第五項：被害人居所地之直轄市、縣（市）主管機關。"
  },
  {
    "type": "item",
    "number": "二",
    "text": "二、本法第二十七條、第二十九條及第三十條：性騷擾事件調查單位所在地之直轄市、縣（市）主管機關。"
  },
  {
    "type": "item",
    "number": "三",
    "text": "三、本法第二十八條：該政府機關（構）、部隊、學校、機構或僱用人所在地之直轄市、縣（市）主管機關。"
  }
]
```

## U07-A26｜第 26 條

本細則自發布日施行。

來源條目欄位（正規化資料）：
- id：article-26
- articleNumber：26
- displayNumber：第 26 條
- title：None
- structureId：None
- metadata：{"source": "全國法規資料庫 性騷擾防治法施行細則（PDF：法規-性騷擾防治法施行細則.pdf）", "lastModified": "2024-03-06"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": null,
    "text": "本細則自發布日施行。"
  }
]
```

## 來源其他資料

- schemaVersion：1.3.0
- processing：{"normalizedBy": "ai", "processedAt": "2026-07-22T00:00:00Z", "sourceType": "document", "warnings": ["來源 PDF未載明主管機關，authority 依規範填「未提供」。", "來源 PDF未印出官方法規代碼，code 依規範填「UNKNOWN」。"]}