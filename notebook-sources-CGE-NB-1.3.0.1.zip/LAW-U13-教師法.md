# LAW-U13｜教師法

資料集：CGE-NB-1.3.0.1；編製日：2026-09-09。此日期不是法律查核日。

## 來源與版本

- source_id：U13
- filename：教師法.json
- path：sources/uploaded/教師法.json
- sha256：fdce67156356721be86ac82ab756b423b411e49e72b5613a9c2994db35d41816
- regulation_id：tw-teachers-act
- name：教師法
- version：{"id": "tw-teachers-act-20190605", "label": "修正日期：民國 108 年 06 月 05 日", "promulgationDate": "2019-06-05", "effectiveDate": null, "effectiveDateNote": "依第53條，本法施行日期由行政院定之；來源文本未載行政院所定之具體施行日期，故不填施行日。", "status": "effective"}
- article_count：53
- source_kind：user_uploaded_ai_normalized_json
- review_status：superseded_version
- review_notes：["官方教師法已於2026-05-13修正第25、53條。附件是2019-06-05版，不能標示為現行全文。", "2019年全文修正之施行日，依官方沿革為2020-06-30；原檔effectiveDate=null予以保留。"]
- official_source_ids：["W04", "W05"]
- normalization_warnings：["本版本施行日期無法自來源確認，effectiveDate 填 null，理由見 effectiveDateNote。", "來源 PDF未印出官方法規代碼，code 依規範填「UNKNOWN」。", "以下法規經條文明文引用，但未包含於本次匯入批次，targetRegulationId 暫留 null，待該等法規匯入後可依名稱自動或人工連結：師資培育法。"]
- processed_at：2026-07-22T00:00:00Z
- authoritative_current_full_text：False

- id：tw-teachers-act
- code：UNKNOWN
- name：教師法
- shortName：教師法
- jurisdiction：TW
- authority：教育部
- aliases：[]
- version：{"id": "tw-teachers-act-20190605", "label": "修正日期：民國 108 年 06 月 05 日", "promulgationDate": "2019-06-05", "effectiveDate": null, "effectiveDateNote": "依第53條，本法施行日期由行政院定之；來源文本未載行政院所定之具體施行日期，故不填施行日。", "status": "effective"}
- structure：[{"id": "chapter-1", "type": "chapter", "label": "第 一 章 總則", "parentId": null, "sortOrder": 0}, {"id": "chapter-2", "type": "chapter", "label": "第 二 章 資格檢定及審定", "parentId": null, "sortOrder": 1}, {"id": "chapter-3", "type": "chapter", "label": "第 三 章 聘任", "parentId": null, "sortOrder": 2}, {"id": "chapter-4", "type": "chapter", "label": "第 四 章 解聘、不續聘、停聘及資遣", "parentId": null, "sortOrder": 3}, {"id": "chapter-5", "type": "chapter", "label": "第 五 章 權利義務", "parentId": null, "sortOrder": 4}, {"id": "chapter-6", "type": "chapter", "label": "第 六 章 教師組織", "parentId": null, "sortOrder": 5}, {"id": "chapter-7", "type": "chapter", "label": "第 七 章 申訴及救濟", "parentId": null, "sortOrder": 6}, {"id": "chapter-8", "type": "chapter", "label": "第 八 章 附則", "parentId": null, "sortOrder": 7}]
- legalConcepts：[{"id": "teacher-employment-framework", "name": "教師任用與聘任法律框架", "description": "彙整各級學校教師之資格、任用、聘任、解聘與不適任處理所涉之法規。", "aliases": ["教師任用"], "tags": ["教師", "任用", "聘任"], "role": "primary", "sortOrder": 0}, {"id": "child-youth-protection-framework", "name": "兒童及少年保護法律框架", "description": "彙整兒童及少年之福利、權益保障與性剝削防制所涉之法規。", "aliases": ["兒少保護"], "tags": ["兒童", "少年", "保護"], "role": "related", "sortOrder": 1}, {"id": "gender-equity-campus-framework", "name": "校園性別事件處理法律框架", "description": "彙整校園性侵害、性騷擾及性霸凌事件之防治、調查與處理程序所涉之法規，包含性別平等教育法及其授權訂定之準則與學校校內規定。", "aliases": ["校園性別事件"], "tags": ["校園", "性別事件", "性平教育"], "role": "related", "sortOrder": 2}, {"id": "sexual-assault-prevention-framework", "name": "性侵害犯罪防治法律框架", "description": "彙整性侵害犯罪之防治、被害人保護與加害人處遇所涉之法規。", "aliases": ["性侵害防治"], "tags": ["性侵害", "被害人保護"], "role": "related", "sortOrder": 3}, {"id": "sexual-harassment-prevention-framework", "name": "性騷擾防治法律框架", "description": "彙整我國性騷擾之定義、防治義務、申訴調查程序與相關罰則所涉之法規；並涵蓋依場域與當事人身分關係而分流適用之性別平等工作法與性別平等教育法。", "aliases": ["性騷擾防治"], "tags": ["性騷擾", "防治", "申訴"], "role": "related", "sortOrder": 4}]
- crossRegulationLinks：[{"id": "link-tw-teachers-act-1", "conceptId": "teacher-employment-framework", "sourceArticleId": null, "label": "授權訂定施行細則", "relationType": "authorization", "conditionText": "本法施行細則，由中央主管機關定之。", "targetRegulationId": "tw-teachers-act-enforcement-rules", "targetRegulationNames": ["教師法施行細則"], "targetArticleNumber": null, "triggerTerms": ["施行細則"], "linkMode": "automatic", "sortOrder": 0}, {"conceptId": "teacher-employment-framework", "sourceArticleId": "article-3", "label": "引用教育人員任用條例", "relationType": "application", "conditionText": "2   軍警校院及矯正學校依本法及教育人員任用條例規定聘任之專任教師，除法律另有規定者外，適用本法之規定。", "targetRegulationId": "tw-educational-personnel-employment-act", "targetRegulationNames": ["教育人員任用條例"], "targetArticleNumber": null, "triggerTerms": ["依本法及"], "linkMode": "automatic", "id": "link-tw-teachers-act-cite-2", "sortOrder": 1}, {"conceptId": "teacher-employment-framework", "sourceArticleId": "article-9", "label": "引用師資培育法", "relationType": "application", "conditionText": "一、依師資培育法規定分發之公費生。", "targetRegulationId": null, "targetRegulationNames": ["師資培育法"], "targetArticleNumber": null, "triggerTerms": ["依"], "linkMode": "automatic_or_manual", "id": "link-tw-teachers-act-cite-3", "sortOrder": 2}, {"conceptId": "teacher-employment-framework", "sourceArticleId": "article-10", "label": "引用大學法", "relationType": "application", "conditionText": "3   專科以上學校教師之聘任及期限，分別依大學法及專科學校法之規定辦理。", "targetRegulationId": "tw-university-act", "targetRegulationNames": ["大學法"], "targetArticleNumber": null, "triggerTerms": ["，分別依"], "linkMode": "automatic", "id": "link-tw-teachers-act-cite-4", "sortOrder": 3}, {"conceptId": "sexual-assault-prevention-framework", "sourceArticleId": "article-14", "label": "引用性侵害犯罪防治法", "relationType": "authorization", "conditionText": "三、犯性侵害犯罪防治法第二條第一項所定之罪，經有罪判決確定。", "targetRegulationId": "tw-sexual-assault-crime-prevention-act", "targetRegulationNames": ["性侵害犯罪防治法"], "targetArticleNumber": "2", "triggerTerms": ["\n三、犯"], "linkMode": "automatic", "id": "link-tw-teachers-act-cite-5", "sortOrder": 4}, {"conceptId": "child-youth-protection-framework", "sourceArticleId": "article-14", "label": "引用兒童及少年性剝削防制條例", "relationType": "penalty", "conditionText": "六、受兒童及少年性剝削防制條例規定處罰，或受性騷擾防治法第二十條或第二十五條規定處罰，經學校性別平等教育委員會確認，有解聘及終身不得聘任為教師之必要。", "targetRegulationId": "tw-child-youth-sexual-exploitation-prevention-act", "targetRegulationNames": ["兒童及少年性剝削防制條例"], "targetArticleNumber": null, "triggerTerms": ["\n六、受"], "linkMode": "automatic", "id": "link-tw-teachers-act-cite-6", "sortOrder": 5}, {"conceptId": "sexual-harassment-prevention-framework", "sourceArticleId": "article-14", "label": "引用性騷擾防治法", "relationType": "penalty", "conditionText": "六、受兒童及少年性剝削防制條例規定處罰，或受性騷擾防治法第二十條或第二十五條規定處罰，經學校性別平等教育委員會確認，有解聘及終身不得聘任為教師之必要。", "targetRegulationId": "tw-sexual-harassment-prevention-act", "targetRegulationNames": ["性騷擾防治法"], "targetArticleNumber": "20", "triggerTerms": ["罰，或受"], "linkMode": "automatic", "id": "link-tw-teachers-act-cite-7", "sortOrder": 6}, {"conceptId": "child-youth-protection-framework", "sourceArticleId": "article-14", "label": "引用兒童及少年福利與權益保障法", "relationType": "penalty", "conditionText": "七、經各級社政主管機關依兒童及少年福利與權益保障法第九十七條規定處罰，並經學校教師評審委員會確認，有解聘及終身不得聘任為教師之必要。", "targetRegulationId": "tw-child-youth-welfare-rights-protection-act", "targetRegulationNames": ["兒童及少年福利與權益保障法"], "targetArticleNumber": "97", "triggerTerms": ["管機關依"], "linkMode": "automatic", "id": "link-tw-teachers-act-cite-8", "sortOrder": 7}, {"conceptId": "gender-equity-campus-framework", "sourceArticleId": "article-14", "label": "引用性別平等教育法", "relationType": "application", "conditionText": "八、知悉服務學校發生疑似校園性侵害事件，未依性別平等教育法規定通報，致再度發生校園性侵害事件；或偽造、變造、湮滅或隱匿他人所犯校園性侵害事件之證據，經學校或有關機關查證屬實。", "targetRegulationId": "tw-gender-equity-education-act", "targetRegulationNames": ["性別平等教育法"], "targetArticleNumber": null, "triggerTerms": ["件，未依"], "linkMode": "automatic", "id": "link-tw-teachers-act-cite-9", "sortOrder": 8}, {"conceptId": "teacher-employment-framework", "sourceArticleId": "article-14", "label": "引用大學法", "relationType": "application", "conditionText": "2   教師有前項第一款至第三款規定情形之一者，免經教師評審委員會審議，並免報主管機關核准，予以解聘，不受大學法第二十條第一項及專科學校法第二十七條第一項規定之限制。", "targetRegulationId": "tw-university-act", "targetRegulationNames": ["大學法"], "targetArticleNumber": "20", "triggerTerms": ["聘，不受"], "linkMode": "automatic", "id": "link-tw-teachers-act-cite-10", "sortOrder": 9}, {"conceptId": "child-youth-protection-framework", "sourceArticleId": "article-15", "label": "引用兒童及少年性剝削防制條例", "relationType": "penalty", "conditionText": "二、受兒童及少年性剝削防制條例規定處罰，或受性騷擾防治法第二十條或第二十五條規定處罰，經學校性別平等教育委員會確認，有解聘之必要。", "targetRegulationId": "tw-child-youth-sexual-exploitation-prevention-act", "targetRegulationNames": ["兒童及少年性剝削防制條例"], "targetArticleNumber": null, "triggerTerms": ["\n二、受"], "linkMode": "automatic", "id": "link-tw-teachers-act-cite-11", "sortOrder": 10}, {"conceptId": "sexual-harassment-prevention-framework", "sourceArticleId": "article-15", "label": "引用性騷擾防治法", "relationType": "penalty", "conditionText": "二、受兒童及少年性剝削防制條例規定處罰，或受性騷擾防治法第二十條或第二十五條規定處罰，經學校性別平等教育委員會確認，有解聘之必要。", "targetRegulationId": "tw-sexual-harassment-prevention-act", "targetRegulationNames": ["性騷擾防治法"], "targetArticleNumber": "20", "triggerTerms": ["罰，或受"], "linkMode": "automatic", "id": "link-tw-teachers-act-cite-12", "sortOrder": 11}, {"conceptId": "child-youth-protection-framework", "sourceArticleId": "article-15", "label": "引用兒童及少年福利與權益保障法", "relationType": "penalty", "conditionText": "四、經各級社政主管機關依兒童及少年福利與權益保障法第九十七條規定處罰，並經學校教師評審委員會確認，有解聘之必要。", "targetRegulationId": "tw-child-youth-welfare-rights-protection-act", "targetRegulationNames": ["兒童及少年福利與權益保障法"], "targetArticleNumber": "97", "triggerTerms": ["管機關依"], "linkMode": "automatic", "id": "link-tw-teachers-act-cite-13", "sortOrder": 12}, {"conceptId": "teacher-employment-framework", "sourceArticleId": "article-19", "label": "引用大學法", "relationType": "application", "conditionText": "3   前二項已聘任之教師屬依第二十條第一項規定通報有案者，免經教師評審委員會審議，並免報主管機關核准，予以解聘，不受大學法第二十條第一項及專科學校法第二十七條第一項規定之限制；非屬依第二十條第一項規定通報有案者，應依第十四條或第十五條規定予以解聘。", "targetRegulationId": "tw-university-act", "targetRegulationNames": ["大學法"], "targetArticleNumber": "20", "triggerTerms": ["聘，不受"], "linkMode": "automatic", "id": "link-tw-teachers-act-cite-14", "sortOrder": 13}, {"conceptId": "child-youth-protection-framework", "sourceArticleId": "article-20", "label": "引用兒童及少年性剝削防制條例", "relationType": "application", "conditionText": "3   各級主管機關協助學校辦理前項查詢，得使用中央社政主管機關建立之依兒童及少年性剝削防制條例、性騷擾防治法第二十條或兒童及少年福利與權益保障法第九十七條規定受行政處罰者之資料庫。", "targetRegulationId": "tw-child-youth-sexual-exploitation-prevention-act", "targetRegulationNames": ["兒童及少年性剝削防制條例"], "targetArticleNumber": null, "triggerTerms": ["建立之依"], "linkMode": "automatic", "id": "link-tw-teachers-act-cite-15", "sortOrder": 14}, {"conceptId": "sexual-harassment-prevention-framework", "sourceArticleId": "article-20", "label": "引用性騷擾防治法", "relationType": "application", "conditionText": "3   各級主管機關協助學校辦理前項查詢，得使用中央社政主管機關建立之依兒童及少年性剝削防制條例、性騷擾防治法第二十條或兒童及少年福利與權益保障法第九十七條規定受行政處罰者之資料庫。", "targetRegulationId": "tw-sexual-harassment-prevention-act", "targetRegulationNames": ["性騷擾防治法"], "targetArticleNumber": "20", "triggerTerms": ["制條例、"], "linkMode": "automatic", "id": "link-tw-teachers-act-cite-16", "sortOrder": 15}, {"conceptId": "child-youth-protection-framework", "sourceArticleId": "article-20", "label": "引用兒童及少年福利與權益保障法", "relationType": "penalty", "conditionText": "3   各級主管機關協助學校辦理前項查詢，得使用中央社政主管機關建立之依兒童及少年性剝削防制條例、性騷擾防治法第二十條或兒童及少年福利與權益保障法第九十七條規定受行政處罰者之資料庫。", "targetRegulationId": "tw-child-youth-welfare-rights-protection-act", "targetRegulationNames": ["兒童及少年福利與權益保障法"], "targetArticleNumber": "97", "triggerTerms": ["二十條或"], "linkMode": "automatic", "id": "link-tw-teachers-act-cite-17", "sortOrder": 16}, {"conceptId": "teacher-employment-framework", "sourceArticleId": "article-44", "label": "引用訴願法", "relationType": "application", "conditionText": "3   教師依本法提起申訴、再申訴後，不得復依訴願法提起訴願；於申訴、再申訴程序終結前提起訴願者，受理訴願機關應於十日內，將該事件移送應受理之教師申訴評議委員會，並通知教師；同時提起訴願者，亦同。", "targetRegulationId": "tw-petitions-and-appeals-act", "targetRegulationNames": ["訴願法"], "targetArticleNumber": null, "triggerTerms": ["不得復依"], "linkMode": "automatic", "id": "link-tw-teachers-act-cite-18", "sortOrder": 17}, {"conceptId": "teacher-employment-framework", "sourceArticleId": "article-47", "label": "引用教育人員任用條例", "relationType": "application", "conditionText": "3   各級學校專業、技術科目教師及擔任健康與護理課程之護理教師，其資格均依教育人員任用條例之規定辦理。", "targetRegulationId": "tw-educational-personnel-employment-act", "targetRegulationNames": ["教育人員任用條例"], "targetArticleNumber": null, "triggerTerms": ["資格均依"], "linkMode": "automatic", "id": "link-tw-teachers-act-cite-19", "sortOrder": 18}]
- definedTerms：[{"id": "competent-authority", "name": "主管機關", "aliases": [], "definition": "在中央為教育部；在直轄市為直轄市政府；在縣（市）為縣（市）政府。", "definitionArticleId": "article-2", "definitionText": "1   本法所稱主管機關：在中央為教育部；在直轄市為直轄市政府；在縣（市）為縣（市）政府。", "scope": "regulation", "targetRegulationNames": [], "sortOrder": 0}]

正規化概念、跨法連結與處理狀態不是獨立法源；下面逐條保留來源plainText，未以本次日期重寫。

## U13-A1｜第 1 條

為明定教師權利義務，保障教師工作及生活，提升教師專業地位，並維護學生學習權，特制定本法。

來源條目欄位（正規化資料）：
- id：article-1
- articleNumber：1
- displayNumber：第 1 條
- title：None
- structureId：chapter-1
- metadata：{"source": "全國法規資料庫 教師法（PDF：教師法.pdf）", "lastModified": "2019-06-05"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": null,
    "text": "為明定教師權利義務，保障教師工作及生活，提升教師專業地位，並維護學生學習權，特制定本法。"
  }
]
```

## U13-A2｜第 2 條

1   本法所稱主管機關：在中央為教育部；在直轄市為直轄市政府；在縣（市）為縣（市）政府。
2   軍警校院及矯正學校依本法規定處理專任教師之事項時，除資格檢定及審定外，以其所屬主管機關為本法所稱主管機關。

來源條目欄位（正規化資料）：
- id：article-2
- articleNumber：2
- displayNumber：第 2 條
- title：None
- structureId：chapter-1
- metadata：{"source": "全國法規資料庫 教師法（PDF：教師法.pdf）", "lastModified": "2019-06-05"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   本法所稱主管機關：在中央為教育部；在直轄市為直轄市政府；在縣（市）為縣（市）政府。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   軍警校院及矯正學校依本法規定處理專任教師之事項時，除資格檢定及審定外，以其所屬主管機關為本法所稱主管機關。"
  }
]
```

## U13-A3｜第 3 條

1   本法於公立及已立案之私立學校編制內，按月支給待遇，並依法取得教師資格之專任教師適用之。
2   軍警校院及矯正學校依本法及教育人員任用條例規定聘任之專任教師，除法律另有規定者外，適用本法之規定。

來源條目欄位（正規化資料）：
- id：article-3
- articleNumber：3
- displayNumber：第 3 條
- title：None
- structureId：chapter-1
- metadata：{"source": "全國法規資料庫 教師法（PDF：教師法.pdf）", "lastModified": "2019-06-05"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   本法於公立及已立案之私立學校編制內，按月支給待遇，並依法取得教師資格之專任教師適用之。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   軍警校院及矯正學校依本法及教育人員任用條例規定聘任之專任教師，除法律另有規定者外，適用本法之規定。"
  }
]
```

## U13-A4｜第 4 條

教師資格檢定及審定、聘任、解聘、不續聘、停聘及資遣、權利義務、教師組織、申訴及救濟等事項，應依本法之規定。

來源條目欄位（正規化資料）：
- id：article-4
- articleNumber：4
- displayNumber：第 4 條
- title：None
- structureId：chapter-1
- metadata：{"source": "全國法規資料庫 教師法（PDF：教師法.pdf）", "lastModified": "2019-06-05"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": null,
    "text": "教師資格檢定及審定、聘任、解聘、不續聘、停聘及資遣、權利義務、教師組織、申訴及救濟等事項，應依本法之規定。"
  }
]
```

## U13-A5｜第 5 條

教師資格之取得分檢定及審定二種：高級中等以下學校之教師採檢定制；專科以上學校之教師採審定制。

來源條目欄位（正規化資料）：
- id：article-5
- articleNumber：5
- displayNumber：第 5 條
- title：None
- structureId：chapter-2
- metadata：{"source": "全國法規資料庫 教師法（PDF：教師法.pdf）", "lastModified": "2019-06-05"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": null,
    "text": "教師資格之取得分檢定及審定二種：高級中等以下學校之教師採檢定制；專科以上學校之教師採審定制。"
  }
]
```

## U13-A6｜第 6 條

高級中等以下學校教師資格之檢定，另以法律定之；經檢定合格之教師，由中央主管機關發給教師證書。

來源條目欄位（正規化資料）：
- id：article-6
- articleNumber：6
- displayNumber：第 6 條
- title：None
- structureId：chapter-2
- metadata：{"source": "全國法規資料庫 教師法（PDF：教師法.pdf）", "lastModified": "2019-06-05"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": null,
    "text": "高級中等以下學校教師資格之檢定，另以法律定之；經檢定合格之教師，由中央主管機關發給教師證書。"
  }
]
```

## U13-A7｜第 7 條

專科以上學校教師資格之審定分學校審查及中央主管機關審查二階段；教師經學校審查合格者，由學校報請中央主管機關審查，再審查合格者，由中央主管機關發給教師證書。但經中央主管機關認可之學校審查合格者，得逕由中央主管機關發給教師證書。

來源條目欄位（正規化資料）：
- id：article-7
- articleNumber：7
- displayNumber：第 7 條
- title：None
- structureId：chapter-2
- metadata：{"source": "全國法規資料庫 教師法（PDF：教師法.pdf）", "lastModified": "2019-06-05"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": null,
    "text": "專科以上學校教師資格之審定分學校審查及中央主管機關審查二階段；教師經學校審查合格者，由學校報請中央主管機關審查，再審查合格者，由中央主管機關發給教師證書。但經中央主管機關認可之學校審查合格者，得逕由中央主管機關發給教師證書。"
  }
]
```

## U13-A8｜第 8 條

專科以上學校教師資格審定辦法，由中央主管機關定之。

來源條目欄位（正規化資料）：
- id：article-8
- articleNumber：8
- displayNumber：第 8 條
- title：None
- structureId：chapter-2
- metadata：{"source": "全國法規資料庫 教師法（PDF：教師法.pdf）", "lastModified": "2019-06-05"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": null,
    "text": "專科以上學校教師資格審定辦法，由中央主管機關定之。"
  }
]
```

## U13-A9｜第 9 條

1   高級中等以下學校教師之聘任，分初聘、續聘及長期聘任，除有下列情形之一者外，應經教師評審委員會審查通過後，由校長聘任之：
一、依師資培育法規定分發之公費生。
二、依國民教育法或高級中等教育法回任教師之校長。
2   前項教師評審委員會之組成，應包括教師代表、學校行政人員代表及家長會代表一人；其中未兼行政或董事之教師代表，不得少於總額二分之一，但教師之員額少於委員總額二分之一者，不在此限。
3   高級中等以下學校教師評審委員會於處理第十四條第一項第七款及第十款、第十五條第一項第一款至第四款時，學校應另行增聘校外學者專家擔任委員，至未兼行政或董事之教師代表人數少於委員總額二分之一為止。
4   前三項教師評審委員會之任務、組成方式、任期、議事、迴避及其他相關事項之辦法，由中央主管機關定之。

來源條目欄位（正規化資料）：
- id：article-9
- articleNumber：9
- displayNumber：第 9 條
- title：None
- structureId：chapter-3
- metadata：{"source": "全國法規資料庫 教師法（PDF：教師法.pdf）", "lastModified": "2019-06-05"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   高級中等以下學校教師之聘任，分初聘、續聘及長期聘任，除有下列情形之一者外，應經教師評審委員會審查通過後，由校長聘任之："
  },
  {
    "type": "item",
    "number": "一",
    "text": "一、依師資培育法規定分發之公費生。"
  },
  {
    "type": "item",
    "number": "二",
    "text": "二、依國民教育法或高級中等教育法回任教師之校長。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   前項教師評審委員會之組成，應包括教師代表、學校行政人員代表及家長會代表一人；其中未兼行政或董事之教師代表，不得少於總額二分之一，但教師之員額少於委員總額二分之一者，不在此限。"
  },
  {
    "type": "paragraph",
    "number": "3",
    "text": "3   高級中等以下學校教師評審委員會於處理第十四條第一項第七款及第十款、第十五條第一項第一款至第四款時，學校應另行增聘校外學者專家擔任委員，至未兼行政或董事之教師代表人數少於委員總額二分之一為止。"
  },
  {
    "type": "paragraph",
    "number": "4",
    "text": "4   前三項教師評審委員會之任務、組成方式、任期、議事、迴避及其他相關事項之辦法，由中央主管機關定之。"
  }
]
```

## U13-A10｜第 10 條

1   高級中等以下學校教師之聘任，以具有教師證書者為限。
2   高級中等以下學校教師聘任期限，初聘為一年；續聘第一次為一年，以後續聘每次為二年；續聘三次以上服務成績優良者，經教師評審委員會全體委員三分之二以上審查通過後，得以長期聘任，其聘期由各校教師評審委員會訂定之，至多七年。
3   專科以上學校教師之聘任及期限，分別依大學法及專科學校法之規定辦理。

來源條目欄位（正規化資料）：
- id：article-10
- articleNumber：10
- displayNumber：第 10 條
- title：None
- structureId：chapter-3
- metadata：{"source": "全國法規資料庫 教師法（PDF：教師法.pdf）", "lastModified": "2019-06-05"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   高級中等以下學校教師之聘任，以具有教師證書者為限。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   高級中等以下學校教師聘任期限，初聘為一年；續聘第一次為一年，以後續聘每次為二年；續聘三次以上服務成績優良者，經教師評審委員會全體委員三分之二以上審查通過後，得以長期聘任，其聘期由各校教師評審委員會訂定之，至多七年。"
  },
  {
    "type": "paragraph",
    "number": "3",
    "text": "3   專科以上學校教師之聘任及期限，分別依大學法及專科學校法之規定辦理。"
  }
]
```

## U13-A11｜第 11 條

1   高級中等以下學校科、組、課程調整或學校減班、停辦或解散時，學校對仍願繼續任教且在校內有其他適當工作可以調任之合格教師，應優先輔導調整職務；在校內無其他適當工作可以調整職務者，學校或主管機關應優先輔導介聘。
2   高級中等以下學校或主管機關依前項規定優先輔導介聘之教師，經學校教師評審委員會審查發現有第三十條各款情形之一者，其聘任應不予通過。

來源條目欄位（正規化資料）：
- id：article-11
- articleNumber：11
- displayNumber：第 11 條
- title：None
- structureId：chapter-3
- metadata：{"source": "全國法規資料庫 教師法（PDF：教師法.pdf）", "lastModified": "2019-06-05"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   高級中等以下學校科、組、課程調整或學校減班、停辦或解散時，學校對仍願繼續任教且在校內有其他適當工作可以調任之合格教師，應優先輔導調整職務；在校內無其他適當工作可以調整職務者，學校或主管機關應優先輔導介聘。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   高級中等以下學校或主管機關依前項規定優先輔導介聘之教師，經學校教師評審委員會審查發現有第三十條各款情形之一者，其聘任應不予通過。"
  }
]
```

## U13-A12｜第 12 條

1   專科以上學校系、所、科、組、課程調整或學校減班、停辦、解散時，學校對仍願繼續任教且有其他適當工作可以調任之合格教師，應優先輔導遷調，各該主管機關應輔導學校執行。
2   專科以上學校依前項規定優先輔導遷調之教師，經教師評審委員會審查發現有下列各款情形之一者，其聘任得不予通過：
一、第十四條第一項、第十五條第一項或第十六條第一項各款情形之一，尚在解聘或不續聘處理程序中。
二、有第十八條、第二十一條、第二十二條第一項或第二項之情形，尚在停聘處理程序中或停聘期間。
三、第二十七條第一項第二款或第三款情形之一，尚在資遣處理程序中。

來源條目欄位（正規化資料）：
- id：article-12
- articleNumber：12
- displayNumber：第 12 條
- title：None
- structureId：chapter-3
- metadata：{"source": "全國法規資料庫 教師法（PDF：教師法.pdf）", "lastModified": "2019-06-05"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   專科以上學校系、所、科、組、課程調整或學校減班、停辦、解散時，學校對仍願繼續任教且有其他適當工作可以調任之合格教師，應優先輔導遷調，各該主管機關應輔導學校執行。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   專科以上學校依前項規定優先輔導遷調之教師，經教師評審委員會審查發現有下列各款情形之一者，其聘任得不予通過："
  },
  {
    "type": "item",
    "number": "一",
    "text": "一、第十四條第一項、第十五條第一項或第十六條第一項各款情形之一，尚在解聘或不續聘處理程序中。"
  },
  {
    "type": "item",
    "number": "二",
    "text": "二、有第十八條、第二十一條、第二十二條第一項或第二項之情形，尚在停聘處理程序中或停聘期間。"
  },
  {
    "type": "item",
    "number": "三",
    "text": "三、第二十七條第一項第二款或第三款情形之一，尚在資遣處理程序中。"
  }
]
```

## U13-A13｜第 13 條

教師除有第十四條至第十六條、第十八條、第十九條、第二十一條及第二十二條情形之一者外，不得解聘、不續聘或停聘。

來源條目欄位（正規化資料）：
- id：article-13
- articleNumber：13
- displayNumber：第 13 條
- title：None
- structureId：chapter-3
- metadata：{"source": "全國法規資料庫 教師法（PDF：教師法.pdf）", "lastModified": "2019-06-05"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": null,
    "text": "教師除有第十四條至第十六條、第十八條、第十九條、第二十一條及第二十二條情形之一者外，不得解聘、不續聘或停聘。"
  }
]
```

## U13-A14｜第 14 條

1   教師有下列各款情形之一者，應予解聘，且終身不得聘任為教師：
一、動員戡亂時期終止後，犯內亂、外患罪，經有罪判決確定。
二、服公務，因貪污行為經有罪判決確定。
三、犯性侵害犯罪防治法第二條第一項所定之罪，經有罪判決確定。
四、經學校性別平等教育委員會或依法組成之相關委員會調查確認有性侵害行為屬實。
五、經學校性別平等教育委員會或依法組成之相關委員會調查確認有性騷擾或性霸凌行為，有解聘及終身不得聘任為教師之必要。
六、受兒童及少年性剝削防制條例規定處罰，或受性騷擾防治法第二十條或第二十五條規定處罰，經學校性別平等教育委員會確認，有解聘及終身不得聘任為教師之必要。
七、經各級社政主管機關依兒童及少年福利與權益保障法第九十七條規定處罰，並經學校教師評審委員會確認，有解聘及終身不得聘任為教師之必要。
八、知悉服務學校發生疑似校園性侵害事件，未依性別平等教育法規定通報，致再度發生校園性侵害事件；或偽造、變造、湮滅或隱匿他人所犯校園性侵害事件之證據，經學校或有關機關查證屬實。
九、偽造、變造或湮滅他人所犯校園毒品危害事件之證據，經學校或有關機關查證屬實。
十、體罰或霸凌學生，造成其身心嚴重侵害。
十一、行為違反相關法規，經學校或有關機關查證屬實，有解聘及終身不得聘任為教師之必要。
2   教師有前項第一款至第三款規定情形之一者，免經教師評審委員會審議，並免報主管機關核准，予以解聘，不受大學法第二十條第一項及專科學校法第二十七條第一項規定之限制。
3   教師有第一項第四款至第六款規定情形之一者，免經教師評審委員會審議，由學校逕報主管機關核准後，予以解聘，不受大學法第二十條第一項及專科學校法第二十七條第一項規定之限制。
4   教師有第一項第七款或第十款規定情形之一者，應經教師評審委員會委員三分之二以上出席及出席委員二分之一以上之審議通過，並報主管機關核准後，予以解聘；有第八款、第九款或第十一款規定情形之一者，應經教師評審委員會委員三分之二以上出席及出席委員三分之二以上之審議通過，並報主管機關核准後，予以解聘。

來源條目欄位（正規化資料）：
- id：article-14
- articleNumber：14
- displayNumber：第 14 條
- title：None
- structureId：chapter-4
- metadata：{"source": "全國法規資料庫 教師法（PDF：教師法.pdf）", "lastModified": "2019-06-05"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   教師有下列各款情形之一者，應予解聘，且終身不得聘任為教師："
  },
  {
    "type": "item",
    "number": "一",
    "text": "一、動員戡亂時期終止後，犯內亂、外患罪，經有罪判決確定。"
  },
  {
    "type": "item",
    "number": "二",
    "text": "二、服公務，因貪污行為經有罪判決確定。"
  },
  {
    "type": "item",
    "number": "三",
    "text": "三、犯性侵害犯罪防治法第二條第一項所定之罪，經有罪判決確定。"
  },
  {
    "type": "item",
    "number": "四",
    "text": "四、經學校性別平等教育委員會或依法組成之相關委員會調查確認有性侵害行為屬實。"
  },
  {
    "type": "item",
    "number": "五",
    "text": "五、經學校性別平等教育委員會或依法組成之相關委員會調查確認有性騷擾或性霸凌行為，有解聘及終身不得聘任為教師之必要。"
  },
  {
    "type": "item",
    "number": "六",
    "text": "六、受兒童及少年性剝削防制條例規定處罰，或受性騷擾防治法第二十條或第二十五條規定處罰，經學校性別平等教育委員會確認，有解聘及終身不得聘任為教師之必要。"
  },
  {
    "type": "item",
    "number": "七",
    "text": "七、經各級社政主管機關依兒童及少年福利與權益保障法第九十七條規定處罰，並經學校教師評審委員會確認，有解聘及終身不得聘任為教師之必要。"
  },
  {
    "type": "item",
    "number": "八",
    "text": "八、知悉服務學校發生疑似校園性侵害事件，未依性別平等教育法規定通報，致再度發生校園性侵害事件；或偽造、變造、湮滅或隱匿他人所犯校園性侵害事件之證據，經學校或有關機關查證屬實。"
  },
  {
    "type": "item",
    "number": "九",
    "text": "九、偽造、變造或湮滅他人所犯校園毒品危害事件之證據，經學校或有關機關查證屬實。"
  },
  {
    "type": "item",
    "number": "十",
    "text": "十、體罰或霸凌學生，造成其身心嚴重侵害。"
  },
  {
    "type": "item",
    "number": "十一",
    "text": "十一、行為違反相關法規，經學校或有關機關查證屬實，有解聘及終身不得聘任為教師之必要。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   教師有前項第一款至第三款規定情形之一者，免經教師評審委員會審議，並免報主管機關核准，予以解聘，不受大學法第二十條第一項及專科學校法第二十七條第一項規定之限制。"
  },
  {
    "type": "paragraph",
    "number": "3",
    "text": "3   教師有第一項第四款至第六款規定情形之一者，免經教師評審委員會審議，由學校逕報主管機關核准後，予以解聘，不受大學法第二十條第一項及專科學校法第二十七條第一項規定之限制。"
  },
  {
    "type": "paragraph",
    "number": "4",
    "text": "4   教師有第一項第七款或第十款規定情形之一者，應經教師評審委員會委員三分之二以上出席及出席委員二分之一以上之審議通過，並報主管機關核准後，予以解聘；有第八款、第九款或第十一款規定情形之一者，應經教師評審委員會委員三分之二以上出席及出席委員三分之二以上之審議通過，並報主管機關核准後，予以解聘。"
  }
]
```

## U13-A15｜第 15 條

1   教師有下列各款情形之一者，應予解聘，且應議決一年至四年不得聘任為教師：
一、經學校性別平等教育委員會或依法組成之相關委員會調查確認有性騷擾或性霸凌行為，有解聘之必要。
二、受兒童及少年性剝削防制條例規定處罰，或受性騷擾防治法第二十條或第二十五條規定處罰，經學校性別平等教育委員會確認，有解聘之必要。
三、體罰或霸凌學生，造成其身心侵害，有解聘之必要。
四、經各級社政主管機關依兒童及少年福利與權益保障法第九十七條規定處罰，並經學校教師評審委員會確認，有解聘之必要。
五、行為違反相關法規，經學校或有關機關查證屬實，有解聘之必要。
2   教師有前項第一款或第二款規定情形之一者，應經教師評審委員會委員二分之一以上出席及出席委員二分之一以上之審議通過，並報主管機關核准後，予以解聘。
3   教師有第一項第三款或第四款規定情形之一者，應經教師評審委員會委員三分之二以上出席及出席委員二分之一以上之審議通過，並報主管機關核准後，予以解聘；有第五款規定情形者，應經教師評審委員會委員三分之二以上出席及出席委員三分之二以上之審議通過，並報主管機關核准後，予以解聘。

來源條目欄位（正規化資料）：
- id：article-15
- articleNumber：15
- displayNumber：第 15 條
- title：None
- structureId：chapter-4
- metadata：{"source": "全國法規資料庫 教師法（PDF：教師法.pdf）", "lastModified": "2019-06-05"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   教師有下列各款情形之一者，應予解聘，且應議決一年至四年不得聘任為教師："
  },
  {
    "type": "item",
    "number": "一",
    "text": "一、經學校性別平等教育委員會或依法組成之相關委員會調查確認有性騷擾或性霸凌行為，有解聘之必要。"
  },
  {
    "type": "item",
    "number": "二",
    "text": "二、受兒童及少年性剝削防制條例規定處罰，或受性騷擾防治法第二十條或第二十五條規定處罰，經學校性別平等教育委員會確認，有解聘之必要。"
  },
  {
    "type": "item",
    "number": "三",
    "text": "三、體罰或霸凌學生，造成其身心侵害，有解聘之必要。"
  },
  {
    "type": "item",
    "number": "四",
    "text": "四、經各級社政主管機關依兒童及少年福利與權益保障法第九十七條規定處罰，並經學校教師評審委員會確認，有解聘之必要。"
  },
  {
    "type": "item",
    "number": "五",
    "text": "五、行為違反相關法規，經學校或有關機關查證屬實，有解聘之必要。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   教師有前項第一款或第二款規定情形之一者，應經教師評審委員會委員二分之一以上出席及出席委員二分之一以上之審議通過，並報主管機關核准後，予以解聘。"
  },
  {
    "type": "paragraph",
    "number": "3",
    "text": "3   教師有第一項第三款或第四款規定情形之一者，應經教師評審委員會委員三分之二以上出席及出席委員二分之一以上之審議通過，並報主管機關核准後，予以解聘；有第五款規定情形者，應經教師評審委員會委員三分之二以上出席及出席委員三分之二以上之審議通過，並報主管機關核准後，予以解聘。"
  }
]
```

## U13-A16｜第 16 條

1   教師聘任後，有下列各款情形之一者，應經教師評審委員會審議通過，並報主管機關核准後，予以解聘或不續聘；其情節以資遣為宜者，應依第二十七條規定辦理：
一、教學不力或不能勝任工作有具體事實。
二、違反聘約情節重大。
2   教師有前項各款規定情形之一者，應經教師評審委員會委員三分之二以上出席及出席委員三分之二以上之審議通過。但高級中等以下學校教師有前項第一款情形，學校向主管機關申請教師專業審查會調查屬實，應經教師評審委員會委員二分之一以上出席及出席委員二分之一以上之審議通過。

來源條目欄位（正規化資料）：
- id：article-16
- articleNumber：16
- displayNumber：第 16 條
- title：None
- structureId：chapter-4
- metadata：{"source": "全國法規資料庫 教師法（PDF：教師法.pdf）", "lastModified": "2019-06-05"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   教師聘任後，有下列各款情形之一者，應經教師評審委員會審議通過，並報主管機關核准後，予以解聘或不續聘；其情節以資遣為宜者，應依第二十七條規定辦理："
  },
  {
    "type": "item",
    "number": "一",
    "text": "一、教學不力或不能勝任工作有具體事實。"
  },
  {
    "type": "item",
    "number": "二",
    "text": "二、違反聘約情節重大。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   教師有前項各款規定情形之一者，應經教師評審委員會委員三分之二以上出席及出席委員三分之二以上之審議通過。但高級中等以下學校教師有前項第一款情形，學校向主管機關申請教師專業審查會調查屬實，應經教師評審委員會委員二分之一以上出席及出席委員二分之一以上之審議通過。"
  }
]
```

## U13-A17｜第 17 條

1   主管機關為協助高級中等以下學校處理前條第一項第一款及第二十六條第二項情形之案件，應成立教師專業審查會，受理學校申請案件或依第二十六條第二項提交教師專業審查會審議之案件。
2   教師專業審查會置委員十一人至十九人，任期二年，由主管機關首長就行政機關代表、教育學者、法律專家、兒童及少年福利學者專家、全國或地方校長團體代表、全國或地方家長團體代表及全國或地方教師組織推派之代表遴聘（派）兼之；任一性別委員人數不得少於委員總數三分之一。
3   第一項教師專業審查會之組成及運作辦法，由中央主管機關定之。
4   教師專業審查會之結案報告摘要，應供公眾查閱。

來源條目欄位（正規化資料）：
- id：article-17
- articleNumber：17
- displayNumber：第 17 條
- title：None
- structureId：chapter-4
- metadata：{"source": "全國法規資料庫 教師法（PDF：教師法.pdf）", "lastModified": "2019-06-05"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   主管機關為協助高級中等以下學校處理前條第一項第一款及第二十六條第二項情形之案件，應成立教師專業審查會，受理學校申請案件或依第二十六條第二項提交教師專業審查會審議之案件。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   教師專業審查會置委員十一人至十九人，任期二年，由主管機關首長就行政機關代表、教育學者、法律專家、兒童及少年福利學者專家、全國或地方校長團體代表、全國或地方家長團體代表及全國或地方教師組織推派之代表遴聘（派）兼之；任一性別委員人數不得少於委員總數三分之一。"
  },
  {
    "type": "paragraph",
    "number": "3",
    "text": "3   第一項教師專業審查會之組成及運作辦法，由中央主管機關定之。"
  },
  {
    "type": "paragraph",
    "number": "4",
    "text": "4   教師專業審查會之結案報告摘要，應供公眾查閱。"
  }
]
```

## U13-A18｜第 18 條

1   教師行為違反相關法規，經學校或有關機關查證屬實，未達解聘之程度，而有停聘之必要者，得審酌案件情節，經教師評審委員會委員三分之二以上出席及出席委員三分之二以上之審議通過，議決停聘六個月至三年，並報主管機關核准後，予以終局停聘。
2   前項停聘期間，不得申請退休、資遣或在學校任教。

來源條目欄位（正規化資料）：
- id：article-18
- articleNumber：18
- displayNumber：第 18 條
- title：None
- structureId：chapter-4
- metadata：{"source": "全國法規資料庫 教師法（PDF：教師法.pdf）", "lastModified": "2019-06-05"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   教師行為違反相關法規，經學校或有關機關查證屬實，未達解聘之程度，而有停聘之必要者，得審酌案件情節，經教師評審委員會委員三分之二以上出席及出席委員三分之二以上之審議通過，議決停聘六個月至三年，並報主管機關核准後，予以終局停聘。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   前項停聘期間，不得申請退休、資遣或在學校任教。"
  }
]
```

## U13-A19｜第 19 條

1   有下列各款情形之一者，不得聘任為教師；已聘任者，應予以解聘：
一、有第十四條第一項各款情形之一。
二、有第十五條第一項各款情形之一，於該議決一年至四年期間。
2   有前條第一項情形者，於該停聘六個月至三年期間，其他學校不得聘任其為教師；已聘任者，應予以解聘。
3   前二項已聘任之教師屬依第二十條第一項規定通報有案者，免經教師評審委員會審議，並免報主管機關核准，予以解聘，不受大學法第二十條第一項及專科學校法第二十七條第一項規定之限制；非屬依第二十條第一項規定通報有案者，應依第十四條或第十五條規定予以解聘。
4   本法中華民國一百零二年六月二十七日修正之條文施行前，因行為不檢有損師道，經有關機關查證屬實而解聘或不續聘之教師，除屬性侵害行為；性騷擾、性霸凌行為、行為違反相關法令且情節重大；體罰或霸凌學生造成其身心嚴重侵害者外，於解聘或不續聘生效日起算逾四年者，得聘任為教師。

來源條目欄位（正規化資料）：
- id：article-19
- articleNumber：19
- displayNumber：第 19 條
- title：None
- structureId：chapter-4
- metadata：{"source": "全國法規資料庫 教師法（PDF：教師法.pdf）", "lastModified": "2019-06-05"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   有下列各款情形之一者，不得聘任為教師；已聘任者，應予以解聘："
  },
  {
    "type": "item",
    "number": "一",
    "text": "一、有第十四條第一項各款情形之一。"
  },
  {
    "type": "item",
    "number": "二",
    "text": "二、有第十五條第一項各款情形之一，於該議決一年至四年期間。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   有前條第一項情形者，於該停聘六個月至三年期間，其他學校不得聘任其為教師；已聘任者，應予以解聘。"
  },
  {
    "type": "paragraph",
    "number": "3",
    "text": "3   前二項已聘任之教師屬依第二十條第一項規定通報有案者，免經教師評審委員會審議，並免報主管機關核准，予以解聘，不受大學法第二十條第一項及專科學校法第二十七條第一項規定之限制；非屬依第二十條第一項規定通報有案者，應依第十四條或第十五條規定予以解聘。"
  },
  {
    "type": "paragraph",
    "number": "4",
    "text": "4   本法中華民國一百零二年六月二十七日修正之條文施行前，因行為不檢有損師道，經有關機關查證屬實而解聘或不續聘之教師，除屬性侵害行為；性騷擾、性霸凌行為、行為違反相關法令且情節重大；體罰或霸凌學生造成其身心嚴重侵害者外，於解聘或不續聘生效日起算逾四年者，得聘任為教師。"
  }
]
```

## U13-A20｜第 20 條

1   教師有第十四條第一項、第十五條第一項、第十八條第一項及前條第一項、第二項規定之情形者，各級主管機關及各級學校應依規定辦理通報、資訊之蒐集及查詢。
2   學校聘任教師前，應查詢其有無前條第一項及第二項規定之情形；已聘任者，應定期查詢。
3   各級主管機關協助學校辦理前項查詢，得使用中央社政主管機關建立之依兒童及少年性剝削防制條例、性騷擾防治法第二十條或兒童及少年福利與權益保障法第九十七條規定受行政處罰者之資料庫。
4   前三項之通報、資訊之蒐集、查詢、處理、利用及其他相關事項之辦法，由中央主管機關定之。

來源條目欄位（正規化資料）：
- id：article-20
- articleNumber：20
- displayNumber：第 20 條
- title：None
- structureId：chapter-4
- metadata：{"source": "全國法規資料庫 教師法（PDF：教師法.pdf）", "lastModified": "2019-06-05"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   教師有第十四條第一項、第十五條第一項、第十八條第一項及前條第一項、第二項規定之情形者，各級主管機關及各級學校應依規定辦理通報、資訊之蒐集及查詢。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   學校聘任教師前，應查詢其有無前條第一項及第二項規定之情形；已聘任者，應定期查詢。"
  },
  {
    "type": "paragraph",
    "number": "3",
    "text": "3   各級主管機關協助學校辦理前項查詢，得使用中央社政主管機關建立之依兒童及少年性剝削防制條例、性騷擾防治法第二十條或兒童及少年福利與權益保障法第九十七條規定受行政處罰者之資料庫。"
  },
  {
    "type": "paragraph",
    "number": "4",
    "text": "4   前三項之通報、資訊之蒐集、查詢、處理、利用及其他相關事項之辦法，由中央主管機關定之。"
  }
]
```

## U13-A21｜第 21 條

教師有下列各款情形之一者，當然暫時予以停聘：
一、依刑事訴訟程序被通緝或羈押。
二、依刑事確定判決，受褫奪公權之宣告。
三、依刑事確定判決，受徒刑之宣告，在監所執行中。

來源條目欄位（正規化資料）：
- id：article-21
- articleNumber：21
- displayNumber：第 21 條
- title：None
- structureId：chapter-4
- metadata：{"source": "全國法規資料庫 教師法（PDF：教師法.pdf）", "lastModified": "2019-06-05"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": null,
    "text": "教師有下列各款情形之一者，當然暫時予以停聘："
  },
  {
    "type": "item",
    "number": "一",
    "text": "一、依刑事訴訟程序被通緝或羈押。"
  },
  {
    "type": "item",
    "number": "二",
    "text": "二、依刑事確定判決，受褫奪公權之宣告。"
  },
  {
    "type": "item",
    "number": "三",
    "text": "三、依刑事確定判決，受徒刑之宣告，在監所執行中。"
  }
]
```

## U13-A22｜第 22 條

1   教師涉有下列各款情形之一者，服務學校應於知悉之日起一個月內經教師評審委員會審議通過後，免報主管機關核准，暫時予以停聘六個月以下，並靜候調查；必要時，得經教師評審委員會審議通過後，延長停聘期間二次，每次不得逾三個月。經調查屬實者，於報主管機關後，至主管機關核准及學校解聘前，應予停聘，免經教師評審委員會審議：
一、第十四條第一項第四款至第六款情形。
二、第十五條第一項第一款或第二款情形。
2   教師涉有下列各款情形之一，服務學校認為有先行停聘進行調查之必要者，應經教師評審委員會審議通過，免報主管機關核准，暫時予以停聘三個月以下；必要時得經教師評審委員會審議通過後，延長停聘期間一次，且不得逾三個月。經調查屬實者，於報主管機關後，至主管機關核准及學校解聘前，得經教師評審委員會審議通過後，予以停聘：
一、第十四條第一項第七款至第十一款情形。
二、第十五條第一項第三款至第五款情形。
3   前二項情形應經教師評審委員會委員二分之一以上出席及出席委員二分之一以上之審議通過。

來源條目欄位（正規化資料）：
- id：article-22
- articleNumber：22
- displayNumber：第 22 條
- title：None
- structureId：chapter-4
- metadata：{"source": "全國法規資料庫 教師法（PDF：教師法.pdf）", "lastModified": "2019-06-05"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   教師涉有下列各款情形之一者，服務學校應於知悉之日起一個月內經教師評審委員會審議通過後，免報主管機關核准，暫時予以停聘六個月以下，並靜候調查；必要時，得經教師評審委員會審議通過後，延長停聘期間二次，每次不得逾三個月。經調查屬實者，於報主管機關後，至主管機關核准及學校解聘前，應予停聘，免經教師評審委員會審議："
  },
  {
    "type": "item",
    "number": "一",
    "text": "一、第十四條第一項第四款至第六款情形。"
  },
  {
    "type": "item",
    "number": "二",
    "text": "二、第十五條第一項第一款或第二款情形。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   教師涉有下列各款情形之一，服務學校認為有先行停聘進行調查之必要者，應經教師評審委員會審議通過，免報主管機關核准，暫時予以停聘三個月以下；必要時得經教師評審委員會審議通過後，延長停聘期間一次，且不得逾三個月。經調查屬實者，於報主管機關後，至主管機關核准及學校解聘前，得經教師評審委員會審議通過後，予以停聘："
  },
  {
    "type": "item",
    "number": "一",
    "text": "一、第十四條第一項第七款至第十一款情形。"
  },
  {
    "type": "item",
    "number": "二",
    "text": "二、第十五條第一項第三款至第五款情形。"
  },
  {
    "type": "paragraph",
    "number": "3",
    "text": "3   前二項情形應經教師評審委員會委員二分之一以上出席及出席委員二分之一以上之審議通過。"
  }
]
```

## U13-A23｜第 23 條

1   教師停聘期間，服務學校應予保留底缺；終局停聘期間遇有聘約期限屆滿情形者，學校應予續聘。
2   依第十八條、前條第一項或第二項規定停聘之教師，於停聘期間屆滿後，學校應予復聘，教師應於停聘期間屆滿次日向學校報到復聘。
3   依前條第一項或第二項規定停聘之教師，於停聘期間屆滿前，停聘事由已消滅者，得申請復聘。
4   依前項規定申請復聘之教師，應經教師評審委員會委員二分之一以上出席及出席委員二分之一以上之審議通過後復聘。
5   依第二十一條規定停聘之教師，於停聘事由消滅後，除經學校依前條第二項規定予以停聘外，學校應予復聘，教師應於事由消滅後次日向學校報到復聘。
6   經依法停聘之教師，未依第二項規定於停聘期間屆滿次日或未依前項規定於事由消滅後次日向學校報到復聘，或未依第三項規定於停聘事由消滅後三個月內申請復聘者，服務學校應負責查催，教師於回復聘任報到前，仍視為停聘；如仍未於接到查催通知之日起三十日內報到復聘者，除有不可歸責於該教師之事由外，視為辭職。

來源條目欄位（正規化資料）：
- id：article-23
- articleNumber：23
- displayNumber：第 23 條
- title：None
- structureId：chapter-4
- metadata：{"source": "全國法規資料庫 教師法（PDF：教師法.pdf）", "lastModified": "2019-06-05"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   教師停聘期間，服務學校應予保留底缺；終局停聘期間遇有聘約期限屆滿情形者，學校應予續聘。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   依第十八條、前條第一項或第二項規定停聘之教師，於停聘期間屆滿後，學校應予復聘，教師應於停聘期間屆滿次日向學校報到復聘。"
  },
  {
    "type": "paragraph",
    "number": "3",
    "text": "3   依前條第一項或第二項規定停聘之教師，於停聘期間屆滿前，停聘事由已消滅者，得申請復聘。"
  },
  {
    "type": "paragraph",
    "number": "4",
    "text": "4   依前項規定申請復聘之教師，應經教師評審委員會委員二分之一以上出席及出席委員二分之一以上之審議通過後復聘。"
  },
  {
    "type": "paragraph",
    "number": "5",
    "text": "5   依第二十一條規定停聘之教師，於停聘事由消滅後，除經學校依前條第二項規定予以停聘外，學校應予復聘，教師應於事由消滅後次日向學校報到復聘。"
  },
  {
    "type": "paragraph",
    "number": "6",
    "text": "6   經依法停聘之教師，未依第二項規定於停聘期間屆滿次日或未依前項規定於事由消滅後次日向學校報到復聘，或未依第三項規定於停聘事由消滅後三個月內申請復聘者，服務學校應負責查催，教師於回復聘任報到前，仍視為停聘；如仍未於接到查催通知之日起三十日內報到復聘者，除有不可歸責於該教師之事由外，視為辭職。"
  }
]
```

## U13-A24｜第 24 條

1   受解聘、不續聘或停聘之教師，依法提起救濟後，原解聘、不續聘或停聘決定經撤銷或因其他事由失去效力，除得依法另為處理者外，其服務學校應通知其復聘，免經教師評審委員會審議。
2   依前項規定復聘之教師，於接獲復聘通知後，應於三十日內報到，其未於期限內報到者，除經核准延長或有不可歸責於該教師之事由外，視為辭職。
3   依第一項或前條第二項、第三項或第五項規定復聘之教師，服務學校應回復其教師職務。

來源條目欄位（正規化資料）：
- id：article-24
- articleNumber：24
- displayNumber：第 24 條
- title：None
- structureId：chapter-4
- metadata：{"source": "全國法規資料庫 教師法（PDF：教師法.pdf）", "lastModified": "2019-06-05"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   受解聘、不續聘或停聘之教師，依法提起救濟後，原解聘、不續聘或停聘決定經撤銷或因其他事由失去效力，除得依法另為處理者外，其服務學校應通知其復聘，免經教師評審委員會審議。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   依前項規定復聘之教師，於接獲復聘通知後，應於三十日內報到，其未於期限內報到者，除經核准延長或有不可歸責於該教師之事由外，視為辭職。"
  },
  {
    "type": "paragraph",
    "number": "3",
    "text": "3   依第一項或前條第二項、第三項或第五項規定復聘之教師，服務學校應回復其教師職務。"
  }
]
```

## U13-A25｜第 25 條

1   依第十八條第一項或第二十一條第二款、第三款停聘之教師，停聘期間不發給待遇。
2   依第二十一條第一款、第二十二條第一項、第二十三條第六項停聘之教師，於停聘期間不發給待遇；停聘事由消滅後，未受解聘或終局停聘處分，並回復聘任者，補發其停聘期間全數本薪（年功薪）。
3   依第二十二條第二項停聘之教師，於停聘期間發給半數本薪（年功薪）；調查後未受解聘或終局停聘處分，並回復聘任者，補發其停聘期間另半數本薪（年功薪）。

來源條目欄位（正規化資料）：
- id：article-25
- articleNumber：25
- displayNumber：第 25 條
- title：None
- structureId：chapter-4
- metadata：{"source": "全國法規資料庫 教師法（PDF：教師法.pdf）", "lastModified": "2019-06-05"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   依第十八條第一項或第二十一條第二款、第三款停聘之教師，停聘期間不發給待遇。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   依第二十一條第一款、第二十二條第一項、第二十三條第六項停聘之教師，於停聘期間不發給待遇；停聘事由消滅後，未受解聘或終局停聘處分，並回復聘任者，補發其停聘期間全數本薪（年功薪）。"
  },
  {
    "type": "paragraph",
    "number": "3",
    "text": "3   依第二十二條第二項停聘之教師，於停聘期間發給半數本薪（年功薪）；調查後未受解聘或終局停聘處分，並回復聘任者，補發其停聘期間另半數本薪（年功薪）。"
  }
]
```

## U13-A26｜第 26 條

1   學校教師評審委員會、性別平等教育委員會或依法組成之相關委員會依第十四條至第十六條規定作成教師解聘或不續聘之決議，或依第十八條規定作成教師終局停聘之決議後，除本法另有規定外，學校應自決議作成之日起十日內報主管機關核准，並同時以書面附理由通知當事人。
2   高級中等以下學校教師涉有第十四條至第十六條或第十八條規定之情形，學校教師評審委員會未依規定召開、審議或決議，主管機關認有違法之虞時，應敘明理由交回學校審議或復議；屆期未依法審議或復議者，主管機關得敘明理由逕行提交教師專業審查會審議，並得追究學校相關人員責任。
3   前項教師專業審查會之決議，應依該案件性質，以學校教師評審委員會原應經之委員出席比率及表決比率審議通過；其決議視同學校教師評審委員會之決議。
4   專科以上學校教師涉有第十四條至第十六條或第十八條規定之情形，學校教師評審委員會未依規定召開、審議或決議，主管機關認有違法之虞時，應敘明理由交回學校審議或復議；屆期未依法審議或復議者，主管機關得追究學校相關人員責任。
5   教師解聘、不續聘或終局停聘案尚在處理程序中，其聘約期限屆滿者，學校應予暫時繼續聘任。

來源條目欄位（正規化資料）：
- id：article-26
- articleNumber：26
- displayNumber：第 26 條
- title：None
- structureId：chapter-4
- metadata：{"source": "全國法規資料庫 教師法（PDF：教師法.pdf）", "lastModified": "2019-06-05"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   學校教師評審委員會、性別平等教育委員會或依法組成之相關委員會依第十四條至第十六條規定作成教師解聘或不續聘之決議，或依第十八條規定作成教師終局停聘之決議後，除本法另有規定外，學校應自決議作成之日起十日內報主管機關核准，並同時以書面附理由通知當事人。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   高級中等以下學校教師涉有第十四條至第十六條或第十八條規定之情形，學校教師評審委員會未依規定召開、審議或決議，主管機關認有違法之虞時，應敘明理由交回學校審議或復議；屆期未依法審議或復議者，主管機關得敘明理由逕行提交教師專業審查會審議，並得追究學校相關人員責任。"
  },
  {
    "type": "paragraph",
    "number": "3",
    "text": "3   前項教師專業審查會之決議，應依該案件性質，以學校教師評審委員會原應經之委員出席比率及表決比率審議通過；其決議視同學校教師評審委員會之決議。"
  },
  {
    "type": "paragraph",
    "number": "4",
    "text": "4   專科以上學校教師涉有第十四條至第十六條或第十八條規定之情形，學校教師評審委員會未依規定召開、審議或決議，主管機關認有違法之虞時，應敘明理由交回學校審議或復議；屆期未依法審議或復議者，主管機關得追究學校相關人員責任。"
  },
  {
    "type": "paragraph",
    "number": "5",
    "text": "5   教師解聘、不續聘或終局停聘案尚在處理程序中，其聘約期限屆滿者，學校應予暫時繼續聘任。"
  }
]
```

## U13-A27｜第 27 條

1   教師有下列各款情事之一者，應經教師評審委員會審議通過，並報主管機關核准後，得予以資遣：
一、因系、所、科、組、課程調整或學校減班、停辦、解散時，現職已無工作又無其他適當工作可以調任。
二、現職工作不適任且無其他工作可調任；或經中央衛生主管機關評鑑合格之醫院證明身體衰弱不能勝任工作。
三、受監護宣告或輔助宣告，尚未撤銷。
2   符合退休資格之教師有前項各款情形之一，經核准資遣者，得於資遣確定之日起一個月內依規定申請辦理退休，並以原核准資遣生效日為退休生效日。

來源條目欄位（正規化資料）：
- id：article-27
- articleNumber：27
- displayNumber：第 27 條
- title：None
- structureId：chapter-4
- metadata：{"source": "全國法規資料庫 教師法（PDF：教師法.pdf）", "lastModified": "2019-06-05"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   教師有下列各款情事之一者，應經教師評審委員會審議通過，並報主管機關核准後，得予以資遣："
  },
  {
    "type": "item",
    "number": "一",
    "text": "一、因系、所、科、組、課程調整或學校減班、停辦、解散時，現職已無工作又無其他適當工作可以調任。"
  },
  {
    "type": "item",
    "number": "二",
    "text": "二、現職工作不適任且無其他工作可調任；或經中央衛生主管機關評鑑合格之醫院證明身體衰弱不能勝任工作。"
  },
  {
    "type": "item",
    "number": "三",
    "text": "三、受監護宣告或輔助宣告，尚未撤銷。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   符合退休資格之教師有前項各款情形之一，經核准資遣者，得於資遣確定之日起一個月內依規定申請辦理退休，並以原核准資遣生效日為退休生效日。"
  }
]
```

## U13-A28｜第 28 條

1   學校於知悉教師涉有第十四條第一項或第十五條第一項所定情形之日起，不得同意其退休或資遣。
2   教師離職後，學校始知悉該教師於聘任期間涉有第十四條第一項或第十五條第一項所定之情形者，學校仍應予以解聘，並依第二十條規定辦理通報。

來源條目欄位（正規化資料）：
- id：article-28
- articleNumber：28
- displayNumber：第 28 條
- title：None
- structureId：chapter-4
- metadata：{"source": "全國法規資料庫 教師法（PDF：教師法.pdf）", "lastModified": "2019-06-05"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   學校於知悉教師涉有第十四條第一項或第十五條第一項所定情形之日起，不得同意其退休或資遣。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   教師離職後，學校始知悉該教師於聘任期間涉有第十四條第一項或第十五條第一項所定之情形者，學校仍應予以解聘，並依第二十條規定辦理通報。"
  }
]
```

## U13-A29｜第 29 條

高級中等以下學校依本法所為教師之解聘、不續聘、停聘或資遣程序及相關事項之辦法，由中央主管機關定之。

來源條目欄位（正規化資料）：
- id：article-29
- articleNumber：29
- displayNumber：第 29 條
- title：None
- structureId：chapter-4
- metadata：{"source": "全國法規資料庫 教師法（PDF：教師法.pdf）", "lastModified": "2019-06-05"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": null,
    "text": "高級中等以下學校依本法所為教師之解聘、不續聘、停聘或資遣程序及相關事項之辦法，由中央主管機關定之。"
  }
]
```

## U13-A30｜第 30 條

高級中等以下學校現職教師，有下列各款情形之一者，不得申請介聘：
一、有第十四條第一項、第十五條第一項或第十六條第一項各款情形之一，尚在調查、解聘或不續聘處理程序中。
二、有第十八條第一項、第二十一條、第二十二條第一項或第二項情形，尚在調查、停聘處理程序中或停聘期間。
三、有第二十七條第一項第二款或第三款情形，尚在調查、資遣處理程序中。

來源條目欄位（正規化資料）：
- id：article-30
- articleNumber：30
- displayNumber：第 30 條
- title：None
- structureId：chapter-4
- metadata：{"source": "全國法規資料庫 教師法（PDF：教師法.pdf）", "lastModified": "2019-06-05"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": null,
    "text": "高級中等以下學校現職教師，有下列各款情形之一者，不得申請介聘："
  },
  {
    "type": "item",
    "number": "一",
    "text": "一、有第十四條第一項、第十五條第一項或第十六條第一項各款情形之一，尚在調查、解聘或不續聘處理程序中。"
  },
  {
    "type": "item",
    "number": "二",
    "text": "二、有第十八條第一項、第二十一條、第二十二條第一項或第二項情形，尚在調查、停聘處理程序中或停聘期間。"
  },
  {
    "type": "item",
    "number": "三",
    "text": "三、有第二十七條第一項第二款或第三款情形，尚在調查、資遣處理程序中。"
  }
]
```

## U13-A31｜第 31 條

1   教師接受聘任後，依有關法令及學校章則之規定，享有下列權利：
一、對學校教學及行政事項提供興革意見。
二、享有待遇、福利、退休、撫卹、資遣、保險等權益及保障。
三、參加在職進修、研究及學術交流活動。
四、參加教師組織，並參與其他依法令規定所舉辦之活動。
五、對主管機關或學校有關其個人之措施，認為違法或不當致損害其權益者，得依法提出申訴。
六、教師之教學及對學生之輔導依法令及學校章則享有專業自主。
七、除法令另有規定者外，教師得拒絕參與主管機關或學校所指派與教學無關之工作或活動。
八、教師依法執行職務涉訟時，其服務學校應輔助其延聘律師為其辯護及提供法律上之協助。
九、其他依本法或其他法律應享有之權利。
2   前項第八款情形，教師因公涉訟輔助辦法，由中央主管機關定之；另其涉訟係因教師之故意或重大過失所致者，應不予輔助；如服務學校已支付涉訟輔助費用者，應以書面限期命其繳還。

來源條目欄位（正規化資料）：
- id：article-31
- articleNumber：31
- displayNumber：第 31 條
- title：None
- structureId：chapter-5
- metadata：{"source": "全國法規資料庫 教師法（PDF：教師法.pdf）", "lastModified": "2019-06-05"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   教師接受聘任後，依有關法令及學校章則之規定，享有下列權利："
  },
  {
    "type": "item",
    "number": "一",
    "text": "一、對學校教學及行政事項提供興革意見。"
  },
  {
    "type": "item",
    "number": "二",
    "text": "二、享有待遇、福利、退休、撫卹、資遣、保險等權益及保障。"
  },
  {
    "type": "item",
    "number": "三",
    "text": "三、參加在職進修、研究及學術交流活動。"
  },
  {
    "type": "item",
    "number": "四",
    "text": "四、參加教師組織，並參與其他依法令規定所舉辦之活動。"
  },
  {
    "type": "item",
    "number": "五",
    "text": "五、對主管機關或學校有關其個人之措施，認為違法或不當致損害其權益者，得依法提出申訴。"
  },
  {
    "type": "item",
    "number": "六",
    "text": "六、教師之教學及對學生之輔導依法令及學校章則享有專業自主。"
  },
  {
    "type": "item",
    "number": "七",
    "text": "七、除法令另有規定者外，教師得拒絕參與主管機關或學校所指派與教學無關之工作或活動。"
  },
  {
    "type": "item",
    "number": "八",
    "text": "八、教師依法執行職務涉訟時，其服務學校應輔助其延聘律師為其辯護及提供法律上之協助。"
  },
  {
    "type": "item",
    "number": "九",
    "text": "九、其他依本法或其他法律應享有之權利。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   前項第八款情形，教師因公涉訟輔助辦法，由中央主管機關定之；另其涉訟係因教師之故意或重大過失所致者，應不予輔助；如服務學校已支付涉訟輔助費用者，應以書面限期命其繳還。"
  }
]
```

## U13-A32｜第 32 條

1   教師除應遵守法令履行聘約外，並負有下列義務：
一、遵守聘約規定，維護校譽。
二、積極維護學生受教之權益。
三、依有關法令及學校安排之課程，實施適性教學活動。
四、輔導或管教學生，導引其適性發展，並培養其健全人格。
五、從事與教學有關之研究、進修。
六、嚴守職分，本於良知，發揚師道及專業精神。
七、依有關法令參與學校學術、行政工作及社會教育活動。
八、非依法律規定不得洩漏學生個人或其家庭資料。
九、擔任導師。
十、其他依本法或其他法律規定應盡之義務。
2   前項第四款及第九款之辦法，由各校校務會議定之。

來源條目欄位（正規化資料）：
- id：article-32
- articleNumber：32
- displayNumber：第 32 條
- title：None
- structureId：chapter-5
- metadata：{"source": "全國法規資料庫 教師法（PDF：教師法.pdf）", "lastModified": "2019-06-05"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   教師除應遵守法令履行聘約外，並負有下列義務："
  },
  {
    "type": "item",
    "number": "一",
    "text": "一、遵守聘約規定，維護校譽。"
  },
  {
    "type": "item",
    "number": "二",
    "text": "二、積極維護學生受教之權益。"
  },
  {
    "type": "item",
    "number": "三",
    "text": "三、依有關法令及學校安排之課程，實施適性教學活動。"
  },
  {
    "type": "item",
    "number": "四",
    "text": "四、輔導或管教學生，導引其適性發展，並培養其健全人格。"
  },
  {
    "type": "item",
    "number": "五",
    "text": "五、從事與教學有關之研究、進修。"
  },
  {
    "type": "item",
    "number": "六",
    "text": "六、嚴守職分，本於良知，發揚師道及專業精神。"
  },
  {
    "type": "item",
    "number": "七",
    "text": "七、依有關法令參與學校學術、行政工作及社會教育活動。"
  },
  {
    "type": "item",
    "number": "八",
    "text": "八、非依法律規定不得洩漏學生個人或其家庭資料。"
  },
  {
    "type": "item",
    "number": "九",
    "text": "九、擔任導師。"
  },
  {
    "type": "item",
    "number": "十",
    "text": "十、其他依本法或其他法律規定應盡之義務。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   前項第四款及第九款之辦法，由各校校務會議定之。"
  }
]
```

## U13-A33｜第 33 條

1   各級學校教師在職期間應主動積極進修、研究與其教學有關之知能。
2   教師在職進修得享有帶職帶薪或留職停薪之保障；其進修、研究之經費得由學校或所屬主管機關編列預算支應。
3   為提升教育品質，鼓勵各級學校教師進修、研究，中央主管機關應規劃多元之教師進修、研究等專業發展制度，其方式、獎勵相關事項之辦法，由中央主管機關定之。
4   高級中等以下學校各主管機關應建立教師諮商輔導支持體系，協助教師諮商輔導；其辦法由各該主管機關定之。

來源條目欄位（正規化資料）：
- id：article-33
- articleNumber：33
- displayNumber：第 33 條
- title：None
- structureId：chapter-5
- metadata：{"source": "全國法規資料庫 教師法（PDF：教師法.pdf）", "lastModified": "2019-06-05"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   各級學校教師在職期間應主動積極進修、研究與其教學有關之知能。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   教師在職進修得享有帶職帶薪或留職停薪之保障；其進修、研究之經費得由學校或所屬主管機關編列預算支應。"
  },
  {
    "type": "paragraph",
    "number": "3",
    "text": "3   為提升教育品質，鼓勵各級學校教師進修、研究，中央主管機關應規劃多元之教師進修、研究等專業發展制度，其方式、獎勵相關事項之辦法，由中央主管機關定之。"
  },
  {
    "type": "paragraph",
    "number": "4",
    "text": "4   高級中等以下學校各主管機關應建立教師諮商輔導支持體系，協助教師諮商輔導；其辦法由各該主管機關定之。"
  }
]
```

## U13-A34｜第 34 條

教師違反第三十二條第一項各款之規定者，各聘任學校應交教師評審委員會評議後，由學校依有關法令規定處理。

來源條目欄位（正規化資料）：
- id：article-34
- articleNumber：34
- displayNumber：第 34 條
- title：None
- structureId：chapter-5
- metadata：{"source": "全國法規資料庫 教師法（PDF：教師法.pdf）", "lastModified": "2019-06-05"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": null,
    "text": "教師違反第三十二條第一項各款之規定者，各聘任學校應交教師評審委員會評議後，由學校依有關法令規定處理。"
  }
]
```

## U13-A35｜第 35 條

1   教師因婚、喪、疾病、分娩或其他正當事由，得依規定請假；其基於法定義務出席作證性侵害、性騷擾及霸凌事件，應給予公假。
2   前項教師請假之假別、日數、請假程序、核定權責與違反之處理及其他相關事項之規則，由中央主管機關定之。

來源條目欄位（正規化資料）：
- id：article-35
- articleNumber：35
- displayNumber：第 35 條
- title：None
- structureId：chapter-5
- metadata：{"source": "全國法規資料庫 教師法（PDF：教師法.pdf）", "lastModified": "2019-06-05"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   教師因婚、喪、疾病、分娩或其他正當事由，得依規定請假；其基於法定義務出席作證性侵害、性騷擾及霸凌事件，應給予公假。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   前項教師請假之假別、日數、請假程序、核定權責與違反之處理及其他相關事項之規則，由中央主管機關定之。"
  }
]
```

## U13-A36｜第 36 條

教師之待遇，另以法律定之。

來源條目欄位（正規化資料）：
- id：article-36
- articleNumber：36
- displayNumber：第 36 條
- title：None
- structureId：chapter-5
- metadata：{"source": "全國法規資料庫 教師法（PDF：教師法.pdf）", "lastModified": "2019-06-05"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": null,
    "text": "教師之待遇，另以法律定之。"
  }
]
```

## U13-A37｜第 37 條

公私立學校教師互轉時，其未核給退休、撫卹、離職及資遣給與之任職年資應合併計算。

來源條目欄位（正規化資料）：
- id：article-37
- articleNumber：37
- displayNumber：第 37 條
- title：None
- structureId：chapter-5
- metadata：{"source": "全國法規資料庫 教師法（PDF：教師法.pdf）", "lastModified": "2019-06-05"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": null,
    "text": "公私立學校教師互轉時，其未核給退休、撫卹、離職及資遣給與之任職年資應合併計算。"
  }
]
```

## U13-A38｜第 38 條

教師之退休、撫卹、離職、資遣及保險，另以法律定之。

來源條目欄位（正規化資料）：
- id：article-38
- articleNumber：38
- displayNumber：第 38 條
- title：None
- structureId：chapter-5
- metadata：{"source": "全國法規資料庫 教師法（PDF：教師法.pdf）", "lastModified": "2019-06-05"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": null,
    "text": "教師之退休、撫卹、離職、資遣及保險，另以法律定之。"
  }
]
```

## U13-A39｜第 39 條

1   教師組織分為三級：在學校為學校教師會；在直轄市及縣（市）為地方教師會；在中央為全國教師會。
2   學校班級數少於二十班時，得跨區 （鄉、鎮）合併成立學校教師會。
3   各級教師組織之設立，應依人民團體法規定向該管主管機關申請辦理。
4   地方教師會應有行政區內半數以上學校教師會加入，始得設立。全國教師會應有半數以上之地方教師會加入，始得成立。

來源條目欄位（正規化資料）：
- id：article-39
- articleNumber：39
- displayNumber：第 39 條
- title：None
- structureId：chapter-6
- metadata：{"source": "全國法規資料庫 教師法（PDF：教師法.pdf）", "lastModified": "2019-06-05"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   教師組織分為三級：在學校為學校教師會；在直轄市及縣（市）為地方教師會；在中央為全國教師會。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   學校班級數少於二十班時，得跨區 （鄉、鎮）合併成立學校教師會。"
  },
  {
    "type": "paragraph",
    "number": "3",
    "text": "3   各級教師組織之設立，應依人民團體法規定向該管主管機關申請辦理。"
  },
  {
    "type": "paragraph",
    "number": "4",
    "text": "4   地方教師會應有行政區內半數以上學校教師會加入，始得設立。全國教師會應有半數以上之地方教師會加入，始得成立。"
  }
]
```

## U13-A40｜第 40 條

各級教師組織之基本任務如下：
一、維護教師專業尊嚴與專業自主權。
二、與各級機關協議教師聘約及聘約準則。
三、研究並協助解決各項教育問題。
四、監督離職給付儲金機構之管理、營運、給付等事宜。
五、派出代表參與教師聘任、申訴及其他與教師有關之法定組織。
六、制定教師自律公約。

來源條目欄位（正規化資料）：
- id：article-40
- articleNumber：40
- displayNumber：第 40 條
- title：None
- structureId：chapter-6
- metadata：{"source": "全國法規資料庫 教師法（PDF：教師法.pdf）", "lastModified": "2019-06-05"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": null,
    "text": "各級教師組織之基本任務如下："
  },
  {
    "type": "item",
    "number": "一",
    "text": "一、維護教師專業尊嚴與專業自主權。"
  },
  {
    "type": "item",
    "number": "二",
    "text": "二、與各級機關協議教師聘約及聘約準則。"
  },
  {
    "type": "item",
    "number": "三",
    "text": "三、研究並協助解決各項教育問題。"
  },
  {
    "type": "item",
    "number": "四",
    "text": "四、監督離職給付儲金機構之管理、營運、給付等事宜。"
  },
  {
    "type": "item",
    "number": "五",
    "text": "五、派出代表參與教師聘任、申訴及其他與教師有關之法定組織。"
  },
  {
    "type": "item",
    "number": "六",
    "text": "六、制定教師自律公約。"
  }
]
```

## U13-A41｜第 41 條

1   學校不得限制教師參加教師組織或擔任教師組織職務。
2   學校不得因教師參加教師組織、擔任教師組織職務或參與活動，拒絕聘用、解聘或為其他不利之待遇。

來源條目欄位（正規化資料）：
- id：article-41
- articleNumber：41
- displayNumber：第 41 條
- title：None
- structureId：chapter-6
- metadata：{"source": "全國法規資料庫 教師法（PDF：教師法.pdf）", "lastModified": "2019-06-05"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   學校不得限制教師參加教師組織或擔任教師組織職務。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   學校不得因教師參加教師組織、擔任教師組織職務或參與活動，拒絕聘用、解聘或為其他不利之待遇。"
  }
]
```

## U13-A42｜第 42 條

1   教師對學校或主管機關有關其個人之措施，認為違法或不當，致損害其權益者，得向各級教師申訴評議委員會提起申訴、再申訴。
2   教師因學校或主管機關對其依法申請之案件，於法定期間內應作為而不作為，認為損害其權益者，亦得提起申訴；法令未規定應作為之期間者，其期間自學校或主管機關受理申請之日起為二個月。
3   申訴之提起，應於收受或知悉措施之次日起三十日內以書面為之；再申訴應於申訴評議書達到之次日起三十日內以書面為之。
4   前項期間，以申訴評議委員會收受申訴書或再申訴書之日期為準。

來源條目欄位（正規化資料）：
- id：article-42
- articleNumber：42
- displayNumber：第 42 條
- title：None
- structureId：chapter-7
- metadata：{"source": "全國法規資料庫 教師法（PDF：教師法.pdf）", "lastModified": "2019-06-05"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   教師對學校或主管機關有關其個人之措施，認為違法或不當，致損害其權益者，得向各級教師申訴評議委員會提起申訴、再申訴。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   教師因學校或主管機關對其依法申請之案件，於法定期間內應作為而不作為，認為損害其權益者，亦得提起申訴；法令未規定應作為之期間者，其期間自學校或主管機關受理申請之日起為二個月。"
  },
  {
    "type": "paragraph",
    "number": "3",
    "text": "3   申訴之提起，應於收受或知悉措施之次日起三十日內以書面為之；再申訴應於申訴評議書達到之次日起三十日內以書面為之。"
  },
  {
    "type": "paragraph",
    "number": "4",
    "text": "4   前項期間，以申訴評議委員會收受申訴書或再申訴書之日期為準。"
  }
]
```

## U13-A43｜第 43 條

1   教師申訴評議委員會委員，由教師、社會公正人士、學者專家、該地區教師組織代表，及組成教師申訴評議委員會之主管機關或學校代表擔任之；其中未兼行政職務之教師人數不得少於委員總數三分之二。
2   前項教師組織代表在直轄市、縣（市）由直轄市、縣（市）教師會推薦；在專科以上學校由該校教師會推薦，其無教師會者，由該學校教育階段相當或直轄市、縣（市）教師會推薦；在中央教師申訴評議委員會由全國教師會推薦。
3   教師申訴評議委員會之組織、迴避、評議程序與方式及其他相關事項之準則，由中央主管機關定之；軍警校院及矯正學校適用之規定，得由各該主管機關另定之。
4   各級教師申訴評議委員會組織與第一項及第二項規定不符者，應於本法中華民國一百零八年五月十日修正之條文施行之日起一年內完成修正。

來源條目欄位（正規化資料）：
- id：article-43
- articleNumber：43
- displayNumber：第 43 條
- title：None
- structureId：chapter-7
- metadata：{"source": "全國法規資料庫 教師法（PDF：教師法.pdf）", "lastModified": "2019-06-05"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   教師申訴評議委員會委員，由教師、社會公正人士、學者專家、該地區教師組織代表，及組成教師申訴評議委員會之主管機關或學校代表擔任之；其中未兼行政職務之教師人數不得少於委員總數三分之二。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   前項教師組織代表在直轄市、縣（市）由直轄市、縣（市）教師會推薦；在專科以上學校由該校教師會推薦，其無教師會者，由該學校教育階段相當或直轄市、縣（市）教師會推薦；在中央教師申訴評議委員會由全國教師會推薦。"
  },
  {
    "type": "paragraph",
    "number": "3",
    "text": "3   教師申訴評議委員會之組織、迴避、評議程序與方式及其他相關事項之準則，由中央主管機關定之；軍警校院及矯正學校適用之規定，得由各該主管機關另定之。"
  },
  {
    "type": "paragraph",
    "number": "4",
    "text": "4   各級教師申訴評議委員會組織與第一項及第二項規定不符者，應於本法中華民國一百零八年五月十日修正之條文施行之日起一年內完成修正。"
  }
]
```

## U13-A44｜第 44 條

1   教師申訴之程序分為申訴及再申訴二級如下：
一、專科以上學校分學校及中央二級。
二、高級中等以下學校分直轄市、縣（市）及中央二級。但中央主管機關所屬學校為中央一級，其提起之申訴，以再申訴論。
2   教師不服申訴決定者，得提起再申訴；學校及主管機關不服申訴決定者，亦同。
3   教師依本法提起申訴、再申訴後，不得復依訴願法提起訴願；於申訴、再申訴程序終結前提起訴願者，受理訴願機關應於十日內，將該事件移送應受理之教師申訴評議委員會，並通知教師；同時提起訴願者，亦同。
4   教師依訴願法提起訴願後，復依本法提起申訴者，受理之教師申訴評議委員會應停止評議，並於教師撤回訴願或訴願決定確定後繼續評議；原措施屬行政處分者，應為申訴不受理之決定。
5   本法中華民國一百零八年五月十日修正之條文施行前，尚未終結之事件，其以後之程序，依修正施行後之本法規定終結之。
6   原措施性質屬行政處分者，其再申訴決定視同訴願決定；不服再申訴決定者，得依法提起行政訴訟。

來源條目欄位（正規化資料）：
- id：article-44
- articleNumber：44
- displayNumber：第 44 條
- title：None
- structureId：chapter-7
- metadata：{"source": "全國法規資料庫 教師法（PDF：教師法.pdf）", "lastModified": "2019-06-05"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   教師申訴之程序分為申訴及再申訴二級如下："
  },
  {
    "type": "item",
    "number": "一",
    "text": "一、專科以上學校分學校及中央二級。"
  },
  {
    "type": "item",
    "number": "二",
    "text": "二、高級中等以下學校分直轄市、縣（市）及中央二級。但中央主管機關所屬學校為中央一級，其提起之申訴，以再申訴論。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   教師不服申訴決定者，得提起再申訴；學校及主管機關不服申訴決定者，亦同。"
  },
  {
    "type": "paragraph",
    "number": "3",
    "text": "3   教師依本法提起申訴、再申訴後，不得復依訴願法提起訴願；於申訴、再申訴程序終結前提起訴願者，受理訴願機關應於十日內，將該事件移送應受理之教師申訴評議委員會，並通知教師；同時提起訴願者，亦同。"
  },
  {
    "type": "paragraph",
    "number": "4",
    "text": "4   教師依訴願法提起訴願後，復依本法提起申訴者，受理之教師申訴評議委員會應停止評議，並於教師撤回訴願或訴願決定確定後繼續評議；原措施屬行政處分者，應為申訴不受理之決定。"
  },
  {
    "type": "paragraph",
    "number": "5",
    "text": "5   本法中華民國一百零八年五月十日修正之條文施行前，尚未終結之事件，其以後之程序，依修正施行後之本法規定終結之。"
  },
  {
    "type": "paragraph",
    "number": "6",
    "text": "6   原措施性質屬行政處分者，其再申訴決定視同訴願決定；不服再申訴決定者，得依法提起行政訴訟。"
  }
]
```

## U13-A45｜第 45 條

1   評議決定確定後，就其事件，有拘束各關係機關、學校之效力；原措施之學校或主管機關應依評議決定執行，主管機關並應依法監督其確實執行。
2   學校未依前項規定辦理，主管機關得依相關法規追究責任，並作為扣減或停止部分或全部學校獎勵、補助或其他措施之依據。

來源條目欄位（正規化資料）：
- id：article-45
- articleNumber：45
- displayNumber：第 45 條
- title：None
- structureId：chapter-7
- metadata：{"source": "全國法規資料庫 教師法（PDF：教師法.pdf）", "lastModified": "2019-06-05"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   評議決定確定後，就其事件，有拘束各關係機關、學校之效力；原措施之學校或主管機關應依評議決定執行，主管機關並應依法監督其確實執行。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   學校未依前項規定辦理，主管機關得依相關法規追究責任，並作為扣減或停止部分或全部學校獎勵、補助或其他措施之依據。"
  }
]
```

## U13-A46｜第 46 條

1   直轄市、縣（市）及中央教師申訴評議委員會之評議書應主動公開。但其他法律另有規定者，依其規定。
2   前項公開，應不包括自然人姓名以外之自然人國民身分證統一編號、護照號碼及其他足資識別該個人之資料。

來源條目欄位（正規化資料）：
- id：article-46
- articleNumber：46
- displayNumber：第 46 條
- title：None
- structureId：chapter-7
- metadata：{"source": "全國法規資料庫 教師法（PDF：教師法.pdf）", "lastModified": "2019-06-05"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   直轄市、縣（市）及中央教師申訴評議委員會之評議書應主動公開。但其他法律另有規定者，依其規定。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   前項公開，應不包括自然人姓名以外之自然人國民身分證統一編號、護照號碼及其他足資識別該個人之資料。"
  }
]
```

## U13-A47｜第 47 條

1   各級學校兼任教師之資格檢定與審定，依本法之規定辦理。
2   兼任、代課及代理教師之權利、義務、資格、聘任、終止聘約、停止聘約之執行與其通報、資訊之蒐集、查詢及其他相關事項之辦法，由中央主管機關定之。
3   各級學校專業、技術科目教師及擔任健康與護理課程之護理教師，其資格均依教育人員任用條例之規定辦理。

來源條目欄位（正規化資料）：
- id：article-47
- articleNumber：47
- displayNumber：第 47 條
- title：None
- structureId：chapter-8
- metadata：{"source": "全國法規資料庫 教師法（PDF：教師法.pdf）", "lastModified": "2019-06-05"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   各級學校兼任教師之資格檢定與審定，依本法之規定辦理。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   兼任、代課及代理教師之權利、義務、資格、聘任、終止聘約、停止聘約之執行與其通報、資訊之蒐集、查詢及其他相關事項之辦法，由中央主管機關定之。"
  },
  {
    "type": "paragraph",
    "number": "3",
    "text": "3   各級學校專業、技術科目教師及擔任健康與護理課程之護理教師，其資格均依教育人員任用條例之規定辦理。"
  }
]
```

## U13-A48｜第 48 條

1   前條第三項之護理教師，其解職、申訴、進修、待遇、福利、退休、資遣、撫卹事項，準用教師相關法令規定。
2   經主管機關介派之護理教師具有健康與護理科合格教師資格者，主管機關得辦理介聘為健康與護理科教師；其介聘辦法，由中央主管機關定之。

來源條目欄位（正規化資料）：
- id：article-48
- articleNumber：48
- displayNumber：第 48 條
- title：None
- structureId：chapter-8
- metadata：{"source": "全國法規資料庫 教師法（PDF：教師法.pdf）", "lastModified": "2019-06-05"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   前條第三項之護理教師，其解職、申訴、進修、待遇、福利、退休、資遣、撫卹事項，準用教師相關法令規定。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   經主管機關介派之護理教師具有健康與護理科合格教師資格者，主管機關得辦理介聘為健康與護理科教師；其介聘辦法，由中央主管機關定之。"
  }
]
```

## U13-A49｜第 49 條

本法各相關條文之規定，於下列幼兒園教師準用之：
一、公立幼兒園教師，其聘任、解聘、不續聘、停聘、資遣、教師組織、申訴、救濟及其他管理相關事項。
二、中華民國一百年十二月三十一日以前已準用本法之私立幼兒園教師，其聘任、進修、研究、離職、資遣、教師組織及申訴相關事項。

來源條目欄位（正規化資料）：
- id：article-49
- articleNumber：49
- displayNumber：第 49 條
- title：None
- structureId：chapter-8
- metadata：{"source": "全國法規資料庫 教師法（PDF：教師法.pdf）", "lastModified": "2019-06-05"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": null,
    "text": "本法各相關條文之規定，於下列幼兒園教師準用之："
  },
  {
    "type": "item",
    "number": "一",
    "text": "一、公立幼兒園教師，其聘任、解聘、不續聘、停聘、資遣、教師組織、申訴、救濟及其他管理相關事項。"
  },
  {
    "type": "item",
    "number": "二",
    "text": "二、中華民國一百年十二月三十一日以前已準用本法之私立幼兒園教師，其聘任、進修、研究、離職、資遣、教師組織及申訴相關事項。"
  }
]
```

## U13-A50｜第 50 條

各級學校校長，得準用教師申訴之規定提起申訴。

來源條目欄位（正規化資料）：
- id：article-50
- articleNumber：50
- displayNumber：第 50 條
- title：None
- structureId：chapter-8
- metadata：{"source": "全國法規資料庫 教師法（PDF：教師法.pdf）", "lastModified": "2019-06-05"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": null,
    "text": "各級學校校長，得準用教師申訴之規定提起申訴。"
  }
]
```

## U13-A51｜第 51 條

本法授權中央主管機關訂定之各項法規命令，中央主管機關應邀請全國教師組織代表參與訂定。

來源條目欄位（正規化資料）：
- id：article-51
- articleNumber：51
- displayNumber：第 51 條
- title：None
- structureId：chapter-8
- metadata：{"source": "全國法規資料庫 教師法（PDF：教師法.pdf）", "lastModified": "2019-06-05"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": null,
    "text": "本法授權中央主管機關訂定之各項法規命令，中央主管機關應邀請全國教師組織代表參與訂定。"
  }
]
```

## U13-A52｜第 52 條

本法施行細則，由中央主管機關定之。

來源條目欄位（正規化資料）：
- id：article-52
- articleNumber：52
- displayNumber：第 52 條
- title：None
- structureId：chapter-8
- metadata：{"source": "全國法規資料庫 教師法（PDF：教師法.pdf）", "lastModified": "2019-06-05"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": null,
    "text": "本法施行細則，由中央主管機關定之。"
  }
]
```

## U13-A53｜第 53 條

本法施行日期，由行政院定之。

來源條目欄位（正規化資料）：
- id：article-53
- articleNumber：53
- displayNumber：第 53 條
- title：None
- structureId：chapter-8
- metadata：{"source": "全國法規資料庫 教師法（PDF：教師法.pdf）", "lastModified": "2019-06-05"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": null,
    "text": "本法施行日期，由行政院定之。"
  }
]
```

## 來源其他資料

- schemaVersion：1.3.0
- processing：{"normalizedBy": "ai", "processedAt": "2026-07-22T00:00:00Z", "sourceType": "document", "warnings": ["本版本施行日期無法自來源確認，effectiveDate 填 null，理由見 effectiveDateNote。", "來源 PDF未印出官方法規代碼，code 依規範填「UNKNOWN」。", "以下法規經條文明文引用，但未包含於本次匯入批次，targetRegulationId 暫留 null，待該等法規匯入後可依名稱自動或人工連結：師資培育法。"]}