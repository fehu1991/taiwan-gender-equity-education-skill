# LAW-U10｜專科以上學校兼任教師聘任辦法

資料集：CGE-NB-1.3.0.1；編製日：2026-09-09。此日期不是法律查核日。

## 來源與版本

- source_id：U10
- filename：專科以上學校兼任教師聘任辦法.json
- path：sources/uploaded/專科以上學校兼任教師聘任辦法.json
- sha256：00ff29392488fb3729c2480c31efaf0327514ec0917b6f0548f08c9c8f6ebac6
- regulation_id：tw-part-time-teacher-appointment-regulations
- name：專科以上學校兼任教師聘任辦法
- version：{"id": "tw-part-time-teacher-appointment-regulations-20251029", "label": "修正日期：民國 114 年 10 月 29 日", "promulgationDate": "2025-10-29", "effectiveDate": "2025-10-31", "effectiveDateNote": "本版本施行條文明定自公布（發布）日施行，依中央法規標準法第13條，自公布（發布）之日起算至第三日起發生效力，故施行日為公布（發布）日之後二日。 另依第23條第2項，中華民國一百十四年七月三十日修正發布之條文，自一百十四年八月一日施行。", "status": "effective"}
- article_count：23
- source_kind：user_uploaded_ai_normalized_json
- review_status：version_checked_not_full_diff
- review_notes：["部分條文保留歷史法條引用；不得依crossRegulationLinks直接替換現行條號。"]
- official_source_ids：["W06"]
- normalization_warnings：["來源 PDF未載明主管機關，authority 依規範填「未提供」。", "來源 PDF未印出官方法規代碼，code 依規範填「UNKNOWN」。"]
- processed_at：2026-07-22T00:00:00Z
- authoritative_current_full_text：False

- id：tw-part-time-teacher-appointment-regulations
- code：UNKNOWN
- name：專科以上學校兼任教師聘任辦法
- shortName：兼任教師聘任辦法
- jurisdiction：TW
- authority：未提供
- aliases：[]
- version：{"id": "tw-part-time-teacher-appointment-regulations-20251029", "label": "修正日期：民國 114 年 10 月 29 日", "promulgationDate": "2025-10-29", "effectiveDate": "2025-10-31", "effectiveDateNote": "本版本施行條文明定自公布（發布）日施行，依中央法規標準法第13條，自公布（發布）之日起算至第三日起發生效力，故施行日為公布（發布）日之後二日。 另依第23條第2項，中華民國一百十四年七月三十日修正發布之條文，自一百十四年八月一日施行。", "status": "effective"}
- structure：[]
- legalConcepts：[{"id": "teacher-employment-framework", "name": "教師任用與聘任法律框架", "description": "彙整各級學校教師之資格、任用、聘任、解聘與不適任處理所涉之法規。", "aliases": ["教師任用"], "tags": ["教師", "任用", "聘任"], "role": "administrative", "sortOrder": 4}, {"id": "child-youth-protection-framework", "name": "兒童及少年保護法律框架", "description": "彙整兒童及少年之福利、權益保障與性剝削防制所涉之法規。", "aliases": ["兒少保護"], "tags": ["兒童", "少年", "保護"], "role": "related", "sortOrder": 5}, {"id": "gender-equity-campus-framework", "name": "校園性別事件處理法律框架", "description": "彙整校園性侵害、性騷擾及性霸凌事件之防治、調查與處理程序所涉之法規，包含性別平等教育法及其授權訂定之準則與學校校內規定。", "aliases": ["校園性別事件"], "tags": ["校園", "性別事件", "性平教育"], "role": "related", "sortOrder": 6}, {"id": "insurance-act-framework", "name": "保險法律框架", "description": "彙整保險契約、保險業組織及監理所涉之法規，包含保險法本文及其施行細則。", "aliases": ["保險法制"], "tags": ["保險", "保險業"], "role": "related", "sortOrder": 7}, {"id": "national-health-insurance-framework", "name": "全民健康保險法律框架", "description": "彙整全民健康保險之保險對象、保險費、保險給付與行政管理所涉之法規，包含本法及其施行細則。", "aliases": ["健保法制"], "tags": ["健保", "社會保險"], "role": "related", "sortOrder": 8}, {"id": "sexual-assault-prevention-framework", "name": "性侵害犯罪防治法律框架", "description": "彙整性侵害犯罪之防治、被害人保護與加害人處遇所涉之法規。", "aliases": ["性侵害防治"], "tags": ["性侵害", "被害人保護"], "role": "related", "sortOrder": 9}, {"id": "sexual-harassment-prevention-framework", "name": "性騷擾防治法律框架", "description": "彙整我國性騷擾之定義、防治義務、申訴調查程序與相關罰則所涉之法規；並涵蓋依場域與當事人身分關係而分流適用之性別平等工作法與性別平等教育法。", "aliases": ["性騷擾防治"], "tags": ["性騷擾", "防治", "申訴"], "role": "related", "sortOrder": 10}]
- crossRegulationLinks：[{"conceptId": "teacher-employment-framework", "sourceArticleId": "article-1", "label": "引用教師法", "relationType": "authorization", "conditionText": "本辦法依教師法（以下簡稱本法）第四十七條第二項規定訂定之。", "targetRegulationId": "tw-teachers-act", "targetRegulationNames": ["教師法"], "targetArticleNumber": "47", "triggerTerms": ["本辦法依"], "linkMode": "automatic", "id": "link-tw-part-time-teacher-appointment-regulations-cite-1", "sortOrder": 0}, {"conceptId": "teacher-employment-framework", "sourceArticleId": "article-2", "label": "引用大學法", "relationType": "application", "conditionText": "1   本辦法所稱兼任教師，指以部分時間在專科以上學校擔任教學工作，並依大學法及專科學校法之教師分級，及教育人員任用條例所定資格聘任者。", "targetRegulationId": "tw-university-act", "targetRegulationNames": ["大學法"], "targetArticleNumber": null, "triggerTerms": ["作，並依"], "linkMode": "automatic", "id": "link-tw-part-time-teacher-appointment-regulations-cite-2", "sortOrder": 1}, {"conceptId": "teacher-employment-framework", "sourceArticleId": "article-2", "label": "引用教育人員任用條例", "relationType": "application", "conditionText": "1   本辦法所稱兼任教師，指以部分時間在專科以上學校擔任教學工作，並依大學法及專科學校法之教師分級，及教育人員任用條例所定資格聘任者。", "targetRegulationId": "tw-educational-personnel-employment-act", "targetRegulationNames": ["教育人員任用條例"], "targetArticleNumber": null, "triggerTerms": ["分級，及"], "linkMode": "automatic", "id": "link-tw-part-time-teacher-appointment-regulations-cite-3", "sortOrder": 2}, {"conceptId": "sexual-assault-prevention-framework", "sourceArticleId": "article-5", "label": "引用性侵害犯罪防治法", "relationType": "authorization", "conditionText": "三、犯性侵害犯罪防治法第二條第一項所定之罪，經有罪判決確定。", "targetRegulationId": "tw-sexual-assault-crime-prevention-act", "targetRegulationNames": ["性侵害犯罪防治法"], "targetArticleNumber": "2", "triggerTerms": ["\n三、犯"], "linkMode": "automatic", "id": "link-tw-part-time-teacher-appointment-regulations-cite-4", "sortOrder": 3}, {"conceptId": "child-youth-protection-framework", "sourceArticleId": "article-5", "label": "引用兒童及少年性剝削防制條例", "relationType": "penalty", "conditionText": "六、受兒童及少年性剝削防制條例規定處罰，或受性騷擾防治法第二十條或第二十五條規定處罰，經學校性別平等教育委員會或依法令組成之相關委員會確認，有終止聘約及終身不得聘任為兼任教師之必要。", "targetRegulationId": "tw-child-youth-sexual-exploitation-prevention-act", "targetRegulationNames": ["兒童及少年性剝削防制條例"], "targetArticleNumber": null, "triggerTerms": ["\n六、受"], "linkMode": "automatic", "id": "link-tw-part-time-teacher-appointment-regulations-cite-5", "sortOrder": 4}, {"conceptId": "sexual-harassment-prevention-framework", "sourceArticleId": "article-5", "label": "引用性騷擾防治法", "relationType": "penalty", "conditionText": "六、受兒童及少年性剝削防制條例規定處罰，或受性騷擾防治法第二十條或第二十五條規定處罰，經學校性別平等教育委員會或依法令組成之相關委員會確認，有終止聘約及終身不得聘任為兼任教師之必要。", "targetRegulationId": "tw-sexual-harassment-prevention-act", "targetRegulationNames": ["性騷擾防治法"], "targetArticleNumber": "20", "triggerTerms": ["罰，或受"], "linkMode": "automatic", "id": "link-tw-part-time-teacher-appointment-regulations-cite-6", "sortOrder": 5}, {"conceptId": "child-youth-protection-framework", "sourceArticleId": "article-5", "label": "引用兒童及少年福利與權益保障法", "relationType": "penalty", "conditionText": "七、經各級社政主管機關依兒童及少年福利與權益保障法第九十七條規定處罰，並經教師評審委員會確認，有終止聘約及終身不得聘任為兼任教師之必要。", "targetRegulationId": "tw-child-youth-welfare-rights-protection-act", "targetRegulationNames": ["兒童及少年福利與權益保障法"], "targetArticleNumber": "97", "triggerTerms": ["管機關依"], "linkMode": "automatic", "id": "link-tw-part-time-teacher-appointment-regulations-cite-7", "sortOrder": 6}, {"conceptId": "gender-equity-campus-framework", "sourceArticleId": "article-5", "label": "引用性別平等教育法", "relationType": "application", "conditionText": "八、知悉服務學校發生疑似校園性侵害事件，未依性別平等教育法規定通報，致再度發生校園性侵害事件；或偽造、變造、湮滅或隱匿他人所犯校園性侵害事件之證據，經學校查證屬實。", "targetRegulationId": "tw-gender-equity-education-act", "targetRegulationNames": ["性別平等教育法"], "targetArticleNumber": null, "triggerTerms": ["件，未依"], "linkMode": "automatic", "id": "link-tw-part-time-teacher-appointment-regulations-cite-8", "sortOrder": 7}, {"conceptId": "child-youth-protection-framework", "sourceArticleId": "article-6", "label": "引用兒童及少年性剝削防制條例", "relationType": "penalty", "conditionText": "二、受兒童及少年性剝削防制條例規定處罰，或受性騷擾防治法第二十條或第二十五條規定處罰，經學校性別平等教育委員會或依法令組成之相關委員會確認，有終止聘約之必要。", "targetRegulationId": "tw-child-youth-sexual-exploitation-prevention-act", "targetRegulationNames": ["兒童及少年性剝削防制條例"], "targetArticleNumber": null, "triggerTerms": ["\n二、受"], "linkMode": "automatic", "id": "link-tw-part-time-teacher-appointment-regulations-cite-9", "sortOrder": 8}, {"conceptId": "sexual-harassment-prevention-framework", "sourceArticleId": "article-6", "label": "引用性騷擾防治法", "relationType": "penalty", "conditionText": "二、受兒童及少年性剝削防制條例規定處罰，或受性騷擾防治法第二十條或第二十五條規定處罰，經學校性別平等教育委員會或依法令組成之相關委員會確認，有終止聘約之必要。", "targetRegulationId": "tw-sexual-harassment-prevention-act", "targetRegulationNames": ["性騷擾防治法"], "targetArticleNumber": "20", "triggerTerms": ["罰，或受"], "linkMode": "automatic", "id": "link-tw-part-time-teacher-appointment-regulations-cite-10", "sortOrder": 9}, {"conceptId": "child-youth-protection-framework", "sourceArticleId": "article-6", "label": "引用兒童及少年福利與權益保障法", "relationType": "penalty", "conditionText": "四、經各級社政主管機關依兒童及少年福利與權益保障法第九十七條規定處罰，並經教師評審委員會確認，有終止聘約之必要。", "targetRegulationId": "tw-child-youth-welfare-rights-protection-act", "targetRegulationNames": ["兒童及少年福利與權益保障法"], "targetArticleNumber": "97", "triggerTerms": ["管機關依"], "linkMode": "automatic", "id": "link-tw-part-time-teacher-appointment-regulations-cite-11", "sortOrder": 10}, {"conceptId": "gender-equity-campus-framework", "sourceArticleId": "article-8", "label": "引用性別平等教育法", "relationType": "application", "conditionText": "六、有性別平等教育法第二十七條之一第一項第一款、第三項前段情形。", "targetRegulationId": "tw-gender-equity-education-act", "targetRegulationNames": ["性別平等教育法"], "targetArticleNumber": "27", "triggerTerms": ["\n六、有"], "linkMode": "automatic", "id": "link-tw-part-time-teacher-appointment-regulations-cite-12", "sortOrder": 11}, {"conceptId": "teacher-employment-framework", "sourceArticleId": "article-14", "label": "引用教師法", "relationType": "application", "conditionText": "三、對教師資格審定之申請、審查結果及學校依本辦法有關其個人終止聘約、停止聘約執行、待遇、請假與退休金之措施，認為違法或不當致損害其權益者，得準用教師法之申訴程序，請求救濟。", "targetRegulationId": "tw-teachers-act", "targetRegulationNames": ["教師法"], "targetArticleNumber": null, "triggerTerms": ["，得準用"], "linkMode": "automatic", "id": "link-tw-part-time-teacher-appointment-regulations-cite-13", "sortOrder": 12}, {"conceptId": "insurance-act-framework", "sourceArticleId": "article-19", "label": "引用保險法", "relationType": "application", "conditionText": "兼任教師符合勞工保險條例、勞工職業災害保險及保護法、就業保險法或全民健康保險法所定資格者，學校於聘約有效期間為其投保勞工保險、勞工職業災害保險、就業保險及全民健康保險。", "targetRegulationId": "tw-insurance-act", "targetRegulationNames": ["保險法"], "targetArticleNumber": null, "triggerTerms": ["法、就業"], "linkMode": "automatic", "id": "link-tw-part-time-teacher-appointment-regulations-cite-14", "sortOrder": 13}, {"conceptId": "national-health-insurance-framework", "sourceArticleId": "article-19", "label": "引用全民健康保險法", "relationType": "application", "conditionText": "兼任教師符合勞工保險條例、勞工職業災害保險及保護法、就業保險法或全民健康保險法所定資格者，學校於聘約有效期間為其投保勞工保險、勞工職業災害保險、就業保險及全民健康保險。", "targetRegulationId": "tw-national-health-insurance-act", "targetRegulationNames": ["全民健康保險法"], "targetArticleNumber": null, "triggerTerms": ["保險法或"], "linkMode": "automatic", "id": "link-tw-part-time-teacher-appointment-regulations-cite-15", "sortOrder": 14}, {"conceptId": "teacher-employment-framework", "sourceArticleId": "article-22", "label": "引用大學法", "relationType": "application", "conditionText": "依大學法或專科學校法聘任之兼任專業技術人員或兼任專業及技術教師，準用本辦法之規定。", "targetRegulationId": "tw-university-act", "targetRegulationNames": ["大學法"], "targetArticleNumber": null, "triggerTerms": ["依"], "linkMode": "automatic", "id": "link-tw-part-time-teacher-appointment-regulations-cite-16", "sortOrder": 15}]
- definedTerms：[{"id": "tw-part-time-teacher-appointment-regulations-term-1", "name": "兼任教師", "aliases": [], "definition": "以部分時間在專科以上學校擔任教學工作，並依大學法及專科學校法之教師分級，及教育人員任用條例所定資格聘任者。", "definitionArticleId": "article-2", "definitionText": "1   本辦法所稱兼任教師，指以部分時間在專科以上學校擔任教學工作，並依大學法及專科學校法之教師分級，及教育人員任用條例所定資格聘任者。", "scope": "regulation", "targetRegulationNames": [], "sortOrder": 0}, {"id": "tw-part-time-teacher-appointment-regulations-term-2", "name": "未具本職", "aliases": [], "definition": "兼任教師未具下列身分之一：\n一、軍人保險身分者。\n二、公教人員保險身分者。\n三、農民健康保險身分者。\n四、勞工保險身分之下列全部時間工作者：\n（一）以機關學校為投保單位：機關學校專任有給人員。\n（二）非以機關學校為投保單位：1.公、民營事業、機構之全部時間受雇者。2.雇主或自營業主。3.專門職業及技術人員自行執業者。\n五、已依相關退休（職、伍）法規，支（兼）領退休（職、伍）給與者。", "definitionArticleId": "article-20", "definitionText": "2   前項所稱未具本職，指兼任教師未具下列身分之一：\n一、軍人保險身分者。\n二、公教人員保險身分者。\n三、農民健康保險身分者。\n四、勞工保險身分之下列全部時間工作者：\n（一）以機關學校為投保單位：機關學校專任有給人員。\n（二）非以機關學校為投保單位：1.公、民營事業、機構之全部時間受雇者。2.雇主或自營業主。3.專門職業及技術人員自行執業者。\n五、已依相關退休（職、伍）法規，支（兼）領退休（職、伍）給與者。", "scope": "regulation", "targetRegulationNames": [], "sortOrder": 1}]

正規化概念、跨法連結與處理狀態不是獨立法源；下面逐條保留來源plainText，未以本次日期重寫。

## U10-A1｜第 1 條

本辦法依教師法（以下簡稱本法）第四十七條第二項規定訂定之。

來源條目欄位（正規化資料）：
- id：article-1
- articleNumber：1
- displayNumber：第 1 條
- title：None
- structureId：None
- metadata：{"source": "全國法規資料庫 專科以上學校兼任教師聘任辦法（PDF：專科以上學校兼任教師聘任辦法.pdf）", "lastModified": "2025-10-29"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": null,
    "text": "本辦法依教師法（以下簡稱本法）第四十七條第二項規定訂定之。"
  }
]
```

## U10-A2｜第 2 條

1   本辦法所稱兼任教師，指以部分時間在專科以上學校擔任教學工作，並依大學法及專科學校法之教師分級，及教育人員任用條例所定資格聘任者。
2   軍警校院依本法規定聘任之兼任教師，除法令另有規定者外，適用本辦法之規定。

來源條目欄位（正規化資料）：
- id：article-2
- articleNumber：2
- displayNumber：第 2 條
- title：None
- structureId：None
- metadata：{"source": "全國法規資料庫 專科以上學校兼任教師聘任辦法（PDF：專科以上學校兼任教師聘任辦法.pdf）", "lastModified": "2025-10-29"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   本辦法所稱兼任教師，指以部分時間在專科以上學校擔任教學工作，並依大學法及專科學校法之教師分級，及教育人員任用條例所定資格聘任者。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   軍警校院依本法規定聘任之兼任教師，除法令另有規定者外，適用本辦法之規定。"
  }
]
```

## U10-A3｜第 3 條

專科以上學校因專業特殊性、產業實務經驗或實際教學等需求，得聘任兼任教師。

來源條目欄位（正規化資料）：
- id：article-3
- articleNumber：3
- displayNumber：第 3 條
- title：None
- structureId：None
- metadata：{"source": "全國法規資料庫 專科以上學校兼任教師聘任辦法（PDF：專科以上學校兼任教師聘任辦法.pdf）", "lastModified": "2025-10-29"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": null,
    "text": "專科以上學校因專業特殊性、產業實務經驗或實際教學等需求，得聘任兼任教師。"
  }
]
```

## U10-A4｜第 4 條

1   專科以上學校聘任兼任教師，其聘期起訖日期應以學期制或學年制為之，並應以聘約約定授課及相關權利義務事項。但聘約所定聘期更有利於兼任教師者，從其約定。
2   兼任教師聘任後，學校因學生選課人數未達開課標準，致無聘任該兼任教師之需求者，聘期屆滿前得終止聘約。
3   兼任教師之聘任及終止聘約程序，除本辦法規定者外，由各校定之。

來源條目欄位（正規化資料）：
- id：article-4
- articleNumber：4
- displayNumber：第 4 條
- title：None
- structureId：None
- metadata：{"source": "全國法規資料庫 專科以上學校兼任教師聘任辦法（PDF：專科以上學校兼任教師聘任辦法.pdf）", "lastModified": "2025-10-29"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   專科以上學校聘任兼任教師，其聘期起訖日期應以學期制或學年制為之，並應以聘約約定授課及相關權利義務事項。但聘約所定聘期更有利於兼任教師者，從其約定。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   兼任教師聘任後，學校因學生選課人數未達開課標準，致無聘任該兼任教師之需求者，聘期屆滿前得終止聘約。"
  },
  {
    "type": "paragraph",
    "number": "3",
    "text": "3   兼任教師之聘任及終止聘約程序，除本辦法規定者外，由各校定之。"
  }
]
```

## U10-A5｜第 5 條

1   兼任教師有下列各款情形之一者，學校應予終止聘約，且終身不得聘任為兼任教師：
一、動員戡亂時期終止後，犯內亂、外患罪，經有罪判決確定。
二、服公務，因貪污行為經有罪判決確定。
三、犯性侵害犯罪防治法第二條第一項所定之罪，經有罪判決確定。
四、經學校性別平等教育委員會或依法令組成之相關委員會調查確認有性侵害行為屬實。
五、經學校性別平等教育委員會或依法令組成之相關委員會調查確認有性騷擾或性霸凌行為，有終止聘約及終身不得聘任為兼任教師之必要。
六、受兒童及少年性剝削防制條例規定處罰，或受性騷擾防治法第二十條或第二十五條規定處罰，經學校性別平等教育委員會或依法令組成之相關委員會確認，有終止聘約及終身不得聘任為兼任教師之必要。
七、經各級社政主管機關依兒童及少年福利與權益保障法第九十七條規定處罰，並經教師評審委員會確認，有終止聘約及終身不得聘任為兼任教師之必要。
八、知悉服務學校發生疑似校園性侵害事件，未依性別平等教育法規定通報，致再度發生校園性侵害事件；或偽造、變造、湮滅或隱匿他人所犯校園性侵害事件之證據，經學校查證屬實。
九、偽造、變造或湮滅他人所犯校園毒品危害事件之證據，經學校查證屬實。
十、體罰或霸凌學生，造成其身心嚴重侵害。
十一、行為違反相關法規，經學校查證屬實，有終止聘約及終身不得聘任為兼任教師之必要。
2   兼任教師有前項第一款至第六款規定情形之一者，免經教師評審委員會審議，予以終止聘約。
3   兼任教師有第一項第七款或第十款規定情形之一者，應經教師評審委員會委員三分之二以上出席及出席委員二分之一以上之審議通過，予以終止聘約；有第一項第八款、第九款或第十一款規定情形之一者，應經教師評審委員會委員三分之二以上出席及出席委員三分之二以上之審議通過，予以終止聘約。

來源條目欄位（正規化資料）：
- id：article-5
- articleNumber：5
- displayNumber：第 5 條
- title：None
- structureId：None
- metadata：{"source": "全國法規資料庫 專科以上學校兼任教師聘任辦法（PDF：專科以上學校兼任教師聘任辦法.pdf）", "lastModified": "2025-10-29"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   兼任教師有下列各款情形之一者，學校應予終止聘約，且終身不得聘任為兼任教師："
  },
  {
    "type": "item",
    "number": "一",
    "text": "一、動員戡亂時期終止後，犯內亂、外患罪，經有罪判決確定。"
  },
  {
    "type": "item",
    "number": "二",
    "text": "二、服公務，因貪污行為經有罪判決確定。"
  },
  {
    "type": "item",
    "number": "三",
    "text": "三、犯性侵害犯罪防治法第二條第一項所定之罪，經有罪判決確定。"
  },
  {
    "type": "item",
    "number": "四",
    "text": "四、經學校性別平等教育委員會或依法令組成之相關委員會調查確認有性侵害行為屬實。"
  },
  {
    "type": "item",
    "number": "五",
    "text": "五、經學校性別平等教育委員會或依法令組成之相關委員會調查確認有性騷擾或性霸凌行為，有終止聘約及終身不得聘任為兼任教師之必要。"
  },
  {
    "type": "item",
    "number": "六",
    "text": "六、受兒童及少年性剝削防制條例規定處罰，或受性騷擾防治法第二十條或第二十五條規定處罰，經學校性別平等教育委員會或依法令組成之相關委員會確認，有終止聘約及終身不得聘任為兼任教師之必要。"
  },
  {
    "type": "item",
    "number": "七",
    "text": "七、經各級社政主管機關依兒童及少年福利與權益保障法第九十七條規定處罰，並經教師評審委員會確認，有終止聘約及終身不得聘任為兼任教師之必要。"
  },
  {
    "type": "item",
    "number": "八",
    "text": "八、知悉服務學校發生疑似校園性侵害事件，未依性別平等教育法規定通報，致再度發生校園性侵害事件；或偽造、變造、湮滅或隱匿他人所犯校園性侵害事件之證據，經學校查證屬實。"
  },
  {
    "type": "item",
    "number": "九",
    "text": "九、偽造、變造或湮滅他人所犯校園毒品危害事件之證據，經學校查證屬實。"
  },
  {
    "type": "item",
    "number": "十",
    "text": "十、體罰或霸凌學生，造成其身心嚴重侵害。"
  },
  {
    "type": "item",
    "number": "十一",
    "text": "十一、行為違反相關法規，經學校查證屬實，有終止聘約及終身不得聘任為兼任教師之必要。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   兼任教師有前項第一款至第六款規定情形之一者，免經教師評審委員會審議，予以終止聘約。"
  },
  {
    "type": "paragraph",
    "number": "3",
    "text": "3   兼任教師有第一項第七款或第十款規定情形之一者，應經教師評審委員會委員三分之二以上出席及出席委員二分之一以上之審議通過，予以終止聘約；有第一項第八款、第九款或第十一款規定情形之一者，應經教師評審委員會委員三分之二以上出席及出席委員三分之二以上之審議通過，予以終止聘約。"
  }
]
```

## U10-A6｜第 6 條

1   兼任教師有下列各款情形之一者，學校應予終止聘約，且應議決一年至四年不得聘任為兼任教師：
一、經學校性別平等教育委員會或依法令組成之相關委員會調查確認有性騷擾或性霸凌行為，有終止聘約之必要。
二、受兒童及少年性剝削防制條例規定處罰，或受性騷擾防治法第二十條或第二十五條規定處罰，經學校性別平等教育委員會或依法令組成之相關委員會確認，有終止聘約之必要。
三、體罰或霸凌學生，造成其身心侵害，有終止聘約之必要。
四、經各級社政主管機關依兒童及少年福利與權益保障法第九十七條規定處罰，並經教師評審委員會確認，有終止聘約之必要。
五、行為違反相關法規，經學校查證屬實，有終止聘約之必要。
2   兼任教師有前項第一款或第二款規定情形之一者，免經教師評審委員會審議，予以終止聘約。
3   兼任教師有第一項第三款或第四款規定情形之一者，應經教師評審委員會委員三分之二以上出席及出席委員二分之一以上之審議通過，予以終止聘約；有第一項第五款規定情形者，應經教師評審委員會委員三分之二以上出席及出席委員三分之二以上之審議通過，予以終止聘約。

來源條目欄位（正規化資料）：
- id：article-6
- articleNumber：6
- displayNumber：第 6 條
- title：None
- structureId：None
- metadata：{"source": "全國法規資料庫 專科以上學校兼任教師聘任辦法（PDF：專科以上學校兼任教師聘任辦法.pdf）", "lastModified": "2025-10-29"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   兼任教師有下列各款情形之一者，學校應予終止聘約，且應議決一年至四年不得聘任為兼任教師："
  },
  {
    "type": "item",
    "number": "一",
    "text": "一、經學校性別平等教育委員會或依法令組成之相關委員會調查確認有性騷擾或性霸凌行為，有終止聘約之必要。"
  },
  {
    "type": "item",
    "number": "二",
    "text": "二、受兒童及少年性剝削防制條例規定處罰，或受性騷擾防治法第二十條或第二十五條規定處罰，經學校性別平等教育委員會或依法令組成之相關委員會確認，有終止聘約之必要。"
  },
  {
    "type": "item",
    "number": "三",
    "text": "三、體罰或霸凌學生，造成其身心侵害，有終止聘約之必要。"
  },
  {
    "type": "item",
    "number": "四",
    "text": "四、經各級社政主管機關依兒童及少年福利與權益保障法第九十七條規定處罰，並經教師評審委員會確認，有終止聘約之必要。"
  },
  {
    "type": "item",
    "number": "五",
    "text": "五、行為違反相關法規，經學校查證屬實，有終止聘約之必要。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   兼任教師有前項第一款或第二款規定情形之一者，免經教師評審委員會審議，予以終止聘約。"
  },
  {
    "type": "paragraph",
    "number": "3",
    "text": "3   兼任教師有第一項第三款或第四款規定情形之一者，應經教師評審委員會委員三分之二以上出席及出席委員二分之一以上之審議通過，予以終止聘約；有第一項第五款規定情形者，應經教師評審委員會委員三分之二以上出席及出席委員三分之二以上之審議通過，予以終止聘約。"
  }
]
```

## U10-A7｜第 7 條

1   兼任教師聘任後，有下列各款情形之一者，應經教師評審委員會審議通過，予以終止聘約：
一、教學不力或不能勝任工作有具體事實。
二、違反聘約情節重大。
2   兼任教師有前項各款規定情形之一者，應經教師評審委員會委員三分之二以上出席及出席委員三分之二以上之審議通過。

來源條目欄位（正規化資料）：
- id：article-7
- articleNumber：7
- displayNumber：第 7 條
- title：None
- structureId：None
- metadata：{"source": "全國法規資料庫 專科以上學校兼任教師聘任辦法（PDF：專科以上學校兼任教師聘任辦法.pdf）", "lastModified": "2025-10-29"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   兼任教師聘任後，有下列各款情形之一者，應經教師評審委員會審議通過，予以終止聘約："
  },
  {
    "type": "item",
    "number": "一",
    "text": "一、教學不力或不能勝任工作有具體事實。"
  },
  {
    "type": "item",
    "number": "二",
    "text": "二、違反聘約情節重大。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   兼任教師有前項各款規定情形之一者，應經教師評審委員會委員三分之二以上出席及出席委員三分之二以上之審議通過。"
  }
]
```

## U10-A8｜第 8 條

1   有下列各款情形之一者，不得聘任為兼任教師；已聘任者，學校應予以終止聘約：
一、有第五條第一項各款情形。
二、有第六條第一項各款情形，於該議決一年至四年期間。
三、有本法第十四條第一項各款、第十九條第一項第一款情形。
四、有本法第十五條第一項各款、第十九條第一項第二款情形，於該議決一年至四年期間。
五、有本法第十八條第一項情形，於該終局停聘六個月至三年期間。
六、有性別平等教育法第二十七條之一第一項第一款、第三項前段情形。
七、有性別平等教育法第二十七條之一第一項第二款、第三項後段情形，於該議決一年至四年期間。
2   有前項各款情形，且屬依第九條、本法第二十條第一項或性別平等教育法第二十七條之一第四項規定通報有案者，未聘任者，不得聘任；已聘任者，免經教師評審委員會、學校性別平等教育委員會或依法令組成之相關委員會審議，由學校逕予終止聘約；非屬依第九條、本法第二十條第一項或性別平等教育法第二十七條之一第四項規定通報有案者，學校應依第五條或第六條規定辦理，未聘任者，不得聘任；已聘任者，予以終止聘約。

來源條目欄位（正規化資料）：
- id：article-8
- articleNumber：8
- displayNumber：第 8 條
- title：None
- structureId：None
- metadata：{"source": "全國法規資料庫 專科以上學校兼任教師聘任辦法（PDF：專科以上學校兼任教師聘任辦法.pdf）", "lastModified": "2025-10-29"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   有下列各款情形之一者，不得聘任為兼任教師；已聘任者，學校應予以終止聘約："
  },
  {
    "type": "item",
    "number": "一",
    "text": "一、有第五條第一項各款情形。"
  },
  {
    "type": "item",
    "number": "二",
    "text": "二、有第六條第一項各款情形，於該議決一年至四年期間。"
  },
  {
    "type": "item",
    "number": "三",
    "text": "三、有本法第十四條第一項各款、第十九條第一項第一款情形。"
  },
  {
    "type": "item",
    "number": "四",
    "text": "四、有本法第十五條第一項各款、第十九條第一項第二款情形，於該議決一年至四年期間。"
  },
  {
    "type": "item",
    "number": "五",
    "text": "五、有本法第十八條第一項情形，於該終局停聘六個月至三年期間。"
  },
  {
    "type": "item",
    "number": "六",
    "text": "六、有性別平等教育法第二十七條之一第一項第一款、第三項前段情形。"
  },
  {
    "type": "item",
    "number": "七",
    "text": "七、有性別平等教育法第二十七條之一第一項第二款、第三項後段情形，於該議決一年至四年期間。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   有前項各款情形，且屬依第九條、本法第二十條第一項或性別平等教育法第二十七條之一第四項規定通報有案者，未聘任者，不得聘任；已聘任者，免經教師評審委員會、學校性別平等教育委員會或依法令組成之相關委員會審議，由學校逕予終止聘約；非屬依第九條、本法第二十條第一項或性別平等教育法第二十七條之一第四項規定通報有案者，學校應依第五條或第六條規定辦理，未聘任者，不得聘任；已聘任者，予以終止聘約。"
  }
]
```

## U10-A9｜第 9 條

兼任教師有第五條第一項、第六條第一項及前條規定之情形者，學校應辦理通報、資訊之蒐集、查詢、處理及利用；學校聘任兼任教師前，應查詢其有無前條規定之情形，已聘任者，應定期查詢；其通報、資訊之蒐集、查詢、處理、利用及其他相關事項，準用不適任教育人員之通報資訊蒐集及查詢處理利用辦法之規定。

來源條目欄位（正規化資料）：
- id：article-9
- articleNumber：9
- displayNumber：第 9 條
- title：None
- structureId：None
- metadata：{"source": "全國法規資料庫 專科以上學校兼任教師聘任辦法（PDF：專科以上學校兼任教師聘任辦法.pdf）", "lastModified": "2025-10-29"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": null,
    "text": "兼任教師有第五條第一項、第六條第一項及前條規定之情形者，學校應辦理通報、資訊之蒐集、查詢、處理及利用；學校聘任兼任教師前，應查詢其有無前條規定之情形，已聘任者，應定期查詢；其通報、資訊之蒐集、查詢、處理、利用及其他相關事項，準用不適任教育人員之通報資訊蒐集及查詢處理利用辦法之規定。"
  }
]
```

## U10-A10｜第 10 條

兼任教師有下列各款情形之一者，當然暫時予以停止聘約執行：
一、依刑事訴訟程序被通緝或羈押。
二、依刑事確定判決，受褫奪公權之宣告。
三、依刑事確定判決，受徒刑之宣告，在監所執行中。

來源條目欄位（正規化資料）：
- id：article-10
- articleNumber：10
- displayNumber：第 10 條
- title：None
- structureId：None
- metadata：{"source": "全國法規資料庫 專科以上學校兼任教師聘任辦法（PDF：專科以上學校兼任教師聘任辦法.pdf）", "lastModified": "2025-10-29"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": null,
    "text": "兼任教師有下列各款情形之一者，當然暫時予以停止聘約執行："
  },
  {
    "type": "item",
    "number": "一",
    "text": "一、依刑事訴訟程序被通緝或羈押。"
  },
  {
    "type": "item",
    "number": "二",
    "text": "二、依刑事確定判決，受褫奪公權之宣告。"
  },
  {
    "type": "item",
    "number": "三",
    "text": "三、依刑事確定判決，受徒刑之宣告，在監所執行中。"
  }
]
```

## U10-A11｜第 11 條

1   兼任教師於聘約有效期間內，涉有下列各款情形之一者，服務學校應於知悉之日起一個月內經教師評審委員會審議通過後，暫時予以停止聘約執行六個月以下，並靜候調查；必要時，得經教師評審委員會審議通過後，延長停止聘約執行之期間二次，每次不得逾三個月；其停止聘約執行之期間不得超過聘約有效期間。經調查屬實者，依第五條或第六條規定辦理：
一、第五條第一項第四款至第六款情形。
二、第六條第一項第一款或第二款情形。
2   兼任教師於聘約有效期間內，涉有下列各款情形之一，服務學校認為有先行停止聘約執行進行調查之必要者，應經教師評審委員會審議通過，暫時予以停止聘約執行三個月以下；必要時，得經教師評審委員會審議通過後，延長停止聘約執行之期間一次，且不得逾三個月；其停止聘約執行之期間不得超過聘約有效期間。經調查屬實者，依第五條或第六條規定辦理：
一、第五條第一項第七款至第十一款情形。
二、第六條第一項第三款至第五款情形。
3   前二項情形應經教師評審委員會委員二分之一以上出席及出席委員二分之一以上之審議通過。

來源條目欄位（正規化資料）：
- id：article-11
- articleNumber：11
- displayNumber：第 11 條
- title：None
- structureId：None
- metadata：{"source": "全國法規資料庫 專科以上學校兼任教師聘任辦法（PDF：專科以上學校兼任教師聘任辦法.pdf）", "lastModified": "2025-10-29"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   兼任教師於聘約有效期間內，涉有下列各款情形之一者，服務學校應於知悉之日起一個月內經教師評審委員會審議通過後，暫時予以停止聘約執行六個月以下，並靜候調查；必要時，得經教師評審委員會審議通過後，延長停止聘約執行之期間二次，每次不得逾三個月；其停止聘約執行之期間不得超過聘約有效期間。經調查屬實者，依第五條或第六條規定辦理："
  },
  {
    "type": "item",
    "number": "一",
    "text": "一、第五條第一項第四款至第六款情形。"
  },
  {
    "type": "item",
    "number": "二",
    "text": "二、第六條第一項第一款或第二款情形。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   兼任教師於聘約有效期間內，涉有下列各款情形之一，服務學校認為有先行停止聘約執行進行調查之必要者，應經教師評審委員會審議通過，暫時予以停止聘約執行三個月以下；必要時，得經教師評審委員會審議通過後，延長停止聘約執行之期間一次，且不得逾三個月；其停止聘約執行之期間不得超過聘約有效期間。經調查屬實者，依第五條或第六條規定辦理："
  },
  {
    "type": "item",
    "number": "一",
    "text": "一、第五條第一項第七款至第十一款情形。"
  },
  {
    "type": "item",
    "number": "二",
    "text": "二、第六條第一項第三款至第五款情形。"
  },
  {
    "type": "paragraph",
    "number": "3",
    "text": "3   前二項情形應經教師評審委員會委員二分之一以上出席及出席委員二分之一以上之審議通過。"
  }
]
```

## U10-A12｜第 12 條

1   依第十條第二款、第三款規定停止聘約執行之兼任教師，於停止聘約執行之期間，不發給鐘點費。
2   依第十條第一款、前條第一項規定停止聘約執行之兼任教師，於停止聘約執行之期間，不發給鐘點費；停止聘約執行之事由消滅後，未予終止聘約者，補發其停止聘約執行之期間全數鐘點費。
3   依前條第二項規定停止聘約執行之兼任教師，於停止聘約執行之期間，發給半數鐘點費；調查後未予終止聘約者，補發其停止聘約執行之期間另半數鐘點費。

來源條目欄位（正規化資料）：
- id：article-12
- articleNumber：12
- displayNumber：第 12 條
- title：None
- structureId：None
- metadata：{"source": "全國法規資料庫 專科以上學校兼任教師聘任辦法（PDF：專科以上學校兼任教師聘任辦法.pdf）", "lastModified": "2025-10-29"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   依第十條第二款、第三款規定停止聘約執行之兼任教師，於停止聘約執行之期間，不發給鐘點費。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   依第十條第一款、前條第一項規定停止聘約執行之兼任教師，於停止聘約執行之期間，不發給鐘點費；停止聘約執行之事由消滅後，未予終止聘約者，補發其停止聘約執行之期間全數鐘點費。"
  },
  {
    "type": "paragraph",
    "number": "3",
    "text": "3   依前條第二項規定停止聘約執行之兼任教師，於停止聘約執行之期間，發給半數鐘點費；調查後未予終止聘約者，補發其停止聘約執行之期間另半數鐘點費。"
  }
]
```

## U10-A13｜第 13 條

學校依第四條第二項、第五條第一項、第六條第一項、第七條第一項或第八條第一項規定終止聘約，及依第十條或第十一條第一項、第二項規定停止聘約執行者，應以書面通知當事人，並附記理由及不服者提起救濟之方法、期間、受理機關。

來源條目欄位（正規化資料）：
- id：article-13
- articleNumber：13
- displayNumber：第 13 條
- title：None
- structureId：None
- metadata：{"source": "全國法規資料庫 專科以上學校兼任教師聘任辦法（PDF：專科以上學校兼任教師聘任辦法.pdf）", "lastModified": "2025-10-29"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": null,
    "text": "學校依第四條第二項、第五條第一項、第六條第一項、第七條第一項或第八條第一項規定終止聘約，及依第十條或第十一條第一項、第二項規定停止聘約執行者，應以書面通知當事人，並附記理由及不服者提起救濟之方法、期間、受理機關。"
  }
]
```

## U10-A14｜第 14 條

兼任教師於受聘期間，享有下列權利：
一、對學校教學及行政事項提供意見。
二、享有待遇、請假、保險及退休金等依法令規定之權益。
三、對教師資格審定之申請、審查結果及學校依本辦法有關其個人終止聘約、停止聘約執行、待遇、請假與退休金之措施，認為違法或不當致損害其權益者，得準用教師法之申訴程序，請求救濟。
四、教師之教學依法令享有教學自主。
五、除法令另有規定者外，得拒絕參與教育行政機關或學校所指派與教學無關之工作或活動。
六、其他法令規定應享之權利。

來源條目欄位（正規化資料）：
- id：article-14
- articleNumber：14
- displayNumber：第 14 條
- title：None
- structureId：None
- metadata：{"source": "全國法規資料庫 專科以上學校兼任教師聘任辦法（PDF：專科以上學校兼任教師聘任辦法.pdf）", "lastModified": "2025-10-29"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": null,
    "text": "兼任教師於受聘期間，享有下列權利："
  },
  {
    "type": "item",
    "number": "一",
    "text": "一、對學校教學及行政事項提供意見。"
  },
  {
    "type": "item",
    "number": "二",
    "text": "二、享有待遇、請假、保險及退休金等依法令規定之權益。"
  },
  {
    "type": "item",
    "number": "三",
    "text": "三、對教師資格審定之申請、審查結果及學校依本辦法有關其個人終止聘約、停止聘約執行、待遇、請假與退休金之措施，認為違法或不當致損害其權益者，得準用教師法之申訴程序，請求救濟。"
  },
  {
    "type": "item",
    "number": "四",
    "text": "四、教師之教學依法令享有教學自主。"
  },
  {
    "type": "item",
    "number": "五",
    "text": "五、除法令另有規定者外，得拒絕參與教育行政機關或學校所指派與教學無關之工作或活動。"
  },
  {
    "type": "item",
    "number": "六",
    "text": "六、其他法令規定應享之權利。"
  }
]
```

## U10-A15｜第 15 條

兼任教師於受聘期間，負有下列義務：
一、遵守聘約規定，維護校譽。
二、積極維護學生受教之權益。
三、依有關法令及學校安排之課程，實施教學活動。
四、嚴守職分，本於良知，發揚師道及專業精神。
五、非依法律規定不得洩漏學生個人或其家庭資料。
六、其他法令規定應盡之義務。

來源條目欄位（正規化資料）：
- id：article-15
- articleNumber：15
- displayNumber：第 15 條
- title：None
- structureId：None
- metadata：{"source": "全國法規資料庫 專科以上學校兼任教師聘任辦法（PDF：專科以上學校兼任教師聘任辦法.pdf）", "lastModified": "2025-10-29"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": null,
    "text": "兼任教師於受聘期間，負有下列義務："
  },
  {
    "type": "item",
    "number": "一",
    "text": "一、遵守聘約規定，維護校譽。"
  },
  {
    "type": "item",
    "number": "二",
    "text": "二、積極維護學生受教之權益。"
  },
  {
    "type": "item",
    "number": "三",
    "text": "三、依有關法令及學校安排之課程，實施教學活動。"
  },
  {
    "type": "item",
    "number": "四",
    "text": "四、嚴守職分，本於良知，發揚師道及專業精神。"
  },
  {
    "type": "item",
    "number": "五",
    "text": "五、非依法律規定不得洩漏學生個人或其家庭資料。"
  },
  {
    "type": "item",
    "number": "六",
    "text": "六、其他法令規定應盡之義務。"
  }
]
```

## U10-A16｜第 16 條

1   兼任教師待遇以鐘點費支給，授課期間並應按月發給。
2   兼任教師如因天然災害停止上班上課或國定假日致無實際授課，學校仍應發給鐘點費。
3   第一項鐘點費為統攝性報酬，包括兼任教師從事課程設計規劃、教材準備、授課、批閱學生作業及試卷、回答學生課程疑義等一貫體系之教學活動之報酬。
4   公立專科以上學校兼任教師鐘點費支給基準，由教育部擬訂，報行政院核定。但依國立大學校院校務基金相關規定得支給較高數額者，不在此限。
5   私立專科以上學校兼任教師鐘點費，由學校視財務狀況定之；其鐘點費支給基準，不得低於公立專科以上學校兼任教師鐘點費支給數額。

來源條目欄位（正規化資料）：
- id：article-16
- articleNumber：16
- displayNumber：第 16 條
- title：None
- structureId：None
- metadata：{"source": "全國法規資料庫 專科以上學校兼任教師聘任辦法（PDF：專科以上學校兼任教師聘任辦法.pdf）", "lastModified": "2025-10-29"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   兼任教師待遇以鐘點費支給，授課期間並應按月發給。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   兼任教師如因天然災害停止上班上課或國定假日致無實際授課，學校仍應發給鐘點費。"
  },
  {
    "type": "paragraph",
    "number": "3",
    "text": "3   第一項鐘點費為統攝性報酬，包括兼任教師從事課程設計規劃、教材準備、授課、批閱學生作業及試卷、回答學生課程疑義等一貫體系之教學活動之報酬。"
  },
  {
    "type": "paragraph",
    "number": "4",
    "text": "4   公立專科以上學校兼任教師鐘點費支給基準，由教育部擬訂，報行政院核定。但依國立大學校院校務基金相關規定得支給較高數額者，不在此限。"
  },
  {
    "type": "paragraph",
    "number": "5",
    "text": "5   私立專科以上學校兼任教師鐘點費，由學校視財務狀況定之；其鐘點費支給基準，不得低於公立專科以上學校兼任教師鐘點費支給數額。"
  }
]
```

## U10-A17｜第 17 條

1   兼任教師之請假，比照教師請假規則第三條請假日數核算，並依下列規定辦理：
一、生理假：每月得請生理假一日，每次以一曆日計給為原則，不得分次申請；全學年請假日數未逾三曆日，不併入病假計算，其餘日數併入病假計算。
二、安胎休養：懷孕期間經醫師診斷需安胎休養者，按所需期間依曆給假；請假期間之應授課時數併入病假計算。
三、娩假、流產假：日數比照專任教師核給，依曆給假，並應一次請畢。
四、捐贈骨髓或器官者，視實際需要給假。
五、具原住民族身分之教師，依原住民族委員會公告各該原住民族歲時祭儀放假日計給。
六、婚假、產前假、陪產檢及陪產假、事假、家庭照顧假、身心調適假、病假、喪假，依排定課表之平均每週授課時數，除以四十小時，乘以應給予請假日數並乘以八小時，不足一小時部分以一小時計；申請得以時計。
2   兼任教師於授課期間依前項規定請假者，學校應發給鐘點費，並支應補課、代課鐘點費。但病假超過前項規定時數者，以事假抵銷，事假、家庭照顧假及身心調適假合計超過前項規定時數者，不發給鐘點費。
3   兼任教師依第一項規定申請家庭照顧假、身心調適假、生理假、產前假、娩假、流產假、陪產檢及陪產假，以及因安胎事由申請其他假別之假時，服務學校不得拒絕，且不得為其他不利之處分。
4   第一項規定之假別外，其餘假別及請假相關規定，由各校自行定之。

來源條目欄位（正規化資料）：
- id：article-17
- articleNumber：17
- displayNumber：第 17 條
- title：None
- structureId：None
- metadata：{"source": "全國法規資料庫 專科以上學校兼任教師聘任辦法（PDF：專科以上學校兼任教師聘任辦法.pdf）", "lastModified": "2025-10-29"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   兼任教師之請假，比照教師請假規則第三條請假日數核算，並依下列規定辦理："
  },
  {
    "type": "item",
    "number": "一",
    "text": "一、生理假：每月得請生理假一日，每次以一曆日計給為原則，不得分次申請；全學年請假日數未逾三曆日，不併入病假計算，其餘日數併入病假計算。"
  },
  {
    "type": "item",
    "number": "二",
    "text": "二、安胎休養：懷孕期間經醫師診斷需安胎休養者，按所需期間依曆給假；請假期間之應授課時數併入病假計算。"
  },
  {
    "type": "item",
    "number": "三",
    "text": "三、娩假、流產假：日數比照專任教師核給，依曆給假，並應一次請畢。"
  },
  {
    "type": "item",
    "number": "四",
    "text": "四、捐贈骨髓或器官者，視實際需要給假。"
  },
  {
    "type": "item",
    "number": "五",
    "text": "五、具原住民族身分之教師，依原住民族委員會公告各該原住民族歲時祭儀放假日計給。"
  },
  {
    "type": "item",
    "number": "六",
    "text": "六、婚假、產前假、陪產檢及陪產假、事假、家庭照顧假、身心調適假、病假、喪假，依排定課表之平均每週授課時數，除以四十小時，乘以應給予請假日數並乘以八小時，不足一小時部分以一小時計；申請得以時計。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   兼任教師於授課期間依前項規定請假者，學校應發給鐘點費，並支應補課、代課鐘點費。但病假超過前項規定時數者，以事假抵銷，事假、家庭照顧假及身心調適假合計超過前項規定時數者，不發給鐘點費。"
  },
  {
    "type": "paragraph",
    "number": "3",
    "text": "3   兼任教師依第一項規定申請家庭照顧假、身心調適假、生理假、產前假、娩假、流產假、陪產檢及陪產假，以及因安胎事由申請其他假別之假時，服務學校不得拒絕，且不得為其他不利之處分。"
  },
  {
    "type": "paragraph",
    "number": "4",
    "text": "4   第一項規定之假別外，其餘假別及請假相關規定，由各校自行定之。"
  }
]
```

## U10-A18｜第 18 條

兼任教師請假所遺課務之調課、補課、代課規定，由學校自行訂定，並應注意學生及兼任教師權益之維護。

來源條目欄位（正規化資料）：
- id：article-18
- articleNumber：18
- displayNumber：第 18 條
- title：None
- structureId：None
- metadata：{"source": "全國法規資料庫 專科以上學校兼任教師聘任辦法（PDF：專科以上學校兼任教師聘任辦法.pdf）", "lastModified": "2025-10-29"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": null,
    "text": "兼任教師請假所遺課務之調課、補課、代課規定，由學校自行訂定，並應注意學生及兼任教師權益之維護。"
  }
]
```

## U10-A19｜第 19 條

兼任教師符合勞工保險條例、勞工職業災害保險及保護法、就業保險法或全民健康保險法所定資格者，學校於聘約有效期間為其投保勞工保險、勞工職業災害保險、就業保險及全民健康保險。

來源條目欄位（正規化資料）：
- id：article-19
- articleNumber：19
- displayNumber：第 19 條
- title：None
- structureId：None
- metadata：{"source": "全國法規資料庫 專科以上學校兼任教師聘任辦法（PDF：專科以上學校兼任教師聘任辦法.pdf）", "lastModified": "2025-10-29"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": null,
    "text": "兼任教師符合勞工保險條例、勞工職業災害保險及保護法、就業保險法或全民健康保險法所定資格者，學校於聘約有效期間為其投保勞工保險、勞工職業災害保險、就業保險及全民健康保險。"
  }
]
```

## U10-A20｜第 20 條

1   兼任教師符合勞工退休金條例所定資格者，學校於聘約有效期間，應依勞工退休金條例規定，按月為未具本職兼任教師提繳退休金。
2   前項所稱未具本職，指兼任教師未具下列身分之一：
一、軍人保險身分者。
二、公教人員保險身分者。
三、農民健康保險身分者。
四、勞工保險身分之下列全部時間工作者：
（一）以機關學校為投保單位：機關學校專任有給人員。
（二）非以機關學校為投保單位：1.公、民營事業、機構之全部時間受雇者。2.雇主或自營業主。3.專門職業及技術人員自行執業者。
五、已依相關退休（職、伍）法規，支（兼）領退休（職、伍）給與者。

來源條目欄位（正規化資料）：
- id：article-20
- articleNumber：20
- displayNumber：第 20 條
- title：None
- structureId：None
- metadata：{"source": "全國法規資料庫 專科以上學校兼任教師聘任辦法（PDF：專科以上學校兼任教師聘任辦法.pdf）", "lastModified": "2025-10-29"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   兼任教師符合勞工退休金條例所定資格者，學校於聘約有效期間，應依勞工退休金條例規定，按月為未具本職兼任教師提繳退休金。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   前項所稱未具本職，指兼任教師未具下列身分之一："
  },
  {
    "type": "item",
    "number": "一",
    "text": "一、軍人保險身分者。"
  },
  {
    "type": "item",
    "number": "二",
    "text": "二、公教人員保險身分者。"
  },
  {
    "type": "item",
    "number": "三",
    "text": "三、農民健康保險身分者。"
  },
  {
    "type": "item",
    "number": "四",
    "text": "四、勞工保險身分之下列全部時間工作者："
  },
  {
    "type": "subitem",
    "number": "一",
    "text": "（一）以機關學校為投保單位：機關學校專任有給人員。"
  },
  {
    "type": "subitem",
    "number": "二",
    "text": "（二）非以機關學校為投保單位：1.公、民營事業、機構之全部時間受雇者。2.雇主或自營業主。3.專門職業及技術人員自行執業者。"
  },
  {
    "type": "item",
    "number": "五",
    "text": "五、已依相關退休（職、伍）法規，支（兼）領退休（職、伍）給與者。"
  }
]
```

## U10-A21｜第 21 條

兼任教師之聘期、終止聘約、停止聘約執行、待遇、請假、退休金及其他重要事項，應納入聘約。

來源條目欄位（正規化資料）：
- id：article-21
- articleNumber：21
- displayNumber：第 21 條
- title：None
- structureId：None
- metadata：{"source": "全國法規資料庫 專科以上學校兼任教師聘任辦法（PDF：專科以上學校兼任教師聘任辦法.pdf）", "lastModified": "2025-10-29"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": null,
    "text": "兼任教師之聘期、終止聘約、停止聘約執行、待遇、請假、退休金及其他重要事項，應納入聘約。"
  }
]
```

## U10-A22｜第 22 條

依大學法或專科學校法聘任之兼任專業技術人員或兼任專業及技術教師，準用本辦法之規定。

來源條目欄位（正規化資料）：
- id：article-22
- articleNumber：22
- displayNumber：第 22 條
- title：None
- structureId：None
- metadata：{"source": "全國法規資料庫 專科以上學校兼任教師聘任辦法（PDF：專科以上學校兼任教師聘任辦法.pdf）", "lastModified": "2025-10-29"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": null,
    "text": "依大學法或專科學校法聘任之兼任專業技術人員或兼任專業及技術教師，準用本辦法之規定。"
  }
]
```

## U10-A23｜第 23 條

1   本辦法自發布日施行。
2   本辦法中華民國一百十四年七月三十日修正發布之條文，自一百十四年八月一日施行。

來源條目欄位（正規化資料）：
- id：article-23
- articleNumber：23
- displayNumber：第 23 條
- title：None
- structureId：None
- metadata：{"source": "全國法規資料庫 專科以上學校兼任教師聘任辦法（PDF：專科以上學校兼任教師聘任辦法.pdf）", "lastModified": "2025-10-29"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   本辦法自發布日施行。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   本辦法中華民國一百十四年七月三十日修正發布之條文，自一百十四年八月一日施行。"
  }
]
```

## 來源其他資料

- schemaVersion：1.3.0
- processing：{"normalizedBy": "ai", "processedAt": "2026-07-22T00:00:00Z", "sourceType": "document", "warnings": ["來源 PDF未載明主管機關，authority 依規範填「未提供」。", "來源 PDF未印出官方法規代碼，code 依規範填「UNKNOWN」。"]}