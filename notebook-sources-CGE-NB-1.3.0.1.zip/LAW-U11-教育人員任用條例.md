# LAW-U11｜教育人員任用條例

資料集：CGE-NB-1.3.0.1；編製日：2026-09-09。此日期不是法律查核日。

## 來源與版本

- source_id：U11
- filename：教育人員任用條例.json
- path：sources/uploaded/教育人員任用條例.json
- sha256：85790c06580c5b7440f23b6b15b951682f45ed3946278e104b95eb0ffc420b06
- regulation_id：tw-educational-personnel-employment-act
- name：教育人員任用條例
- version：{"id": "tw-educational-personnel-employment-act-20140122", "label": "修正日期：民國 103 年 01 月 22 日", "promulgationDate": "2014-01-22", "effectiveDate": "2014-01-24", "effectiveDateNote": "本版本施行條文明定自公布（發布）日施行，依中央法規標準法第13條，自公布（發布）之日起算至第三日起發生效力，故施行日為公布（發布）日之後二日。 另依第43條第2項，中華民國九十八年十月二十三日修正之條文，自九十八年十一月二十三日施行。", "status": "effective"}
- article_count：50
- source_kind：user_uploaded_ai_normalized_json
- review_status：version_checked_not_full_diff
- review_notes：[]
- official_source_ids：["W18"]
- normalization_warnings：["來源 PDF未載明主管機關，authority 依規範填「未提供」。", "來源 PDF未印出官方法規代碼，code 依規範填「UNKNOWN」。"]
- processed_at：2026-07-22T00:00:00Z
- authoritative_current_full_text：False

- id：tw-educational-personnel-employment-act
- code：UNKNOWN
- name：教育人員任用條例
- shortName：教育人員任用條例
- jurisdiction：TW
- authority：未提供
- aliases：[]
- version：{"id": "tw-educational-personnel-employment-act-20140122", "label": "修正日期：民國 103 年 01 月 22 日", "promulgationDate": "2014-01-22", "effectiveDate": "2014-01-24", "effectiveDateNote": "本版本施行條文明定自公布（發布）日施行，依中央法規標準法第13條，自公布（發布）之日起算至第三日起發生效力，故施行日為公布（發布）日之後二日。 另依第43條第2項，中華民國九十八年十月二十三日修正之條文，自九十八年十一月二十三日施行。", "status": "effective"}
- structure：[{"id": "chapter-1", "type": "chapter", "label": "第 一 章 總則", "parentId": null, "sortOrder": 0}, {"id": "chapter-2", "type": "chapter", "label": "第 二 章 任用資格", "parentId": null, "sortOrder": 1}, {"id": "chapter-3", "type": "chapter", "label": "第 三 章 任用程序", "parentId": null, "sortOrder": 2}, {"id": "chapter-4", "type": "chapter", "label": "第 四 章 任用限制", "parentId": null, "sortOrder": 3}, {"id": "chapter-5", "type": "chapter", "label": "第 五 章 任期", "parentId": null, "sortOrder": 4}, {"id": "chapter-6", "type": "chapter", "label": "第 六 章 附則", "parentId": null, "sortOrder": 5}]
- legalConcepts：[{"id": "teacher-employment-framework", "name": "教師任用與聘任法律框架", "description": "彙整各級學校教師之資格、任用、聘任、解聘與不適任處理所涉之法規。", "aliases": ["教師任用"], "tags": ["教師", "任用", "聘任"], "role": "supporting", "sortOrder": 2}, {"id": "gender-equity-campus-framework", "name": "校園性別事件處理法律框架", "description": "彙整校園性侵害、性騷擾及性霸凌事件之防治、調查與處理程序所涉之法規，包含性別平等教育法及其授權訂定之準則與學校校內規定。", "aliases": ["校園性別事件"], "tags": ["校園", "性別事件", "性平教育"], "role": "related", "sortOrder": 3}, {"id": "sexual-assault-prevention-framework", "name": "性侵害犯罪防治法律框架", "description": "彙整性侵害犯罪之防治、被害人保護與加害人處遇所涉之法規。", "aliases": ["性侵害防治"], "tags": ["性侵害", "被害人保護"], "role": "related", "sortOrder": 4}]
- crossRegulationLinks：[{"conceptId": "teacher-employment-framework", "sourceArticleId": "article-4", "label": "引用大學法", "relationType": "application", "conditionText": "2   前項第三款國民小學一級單位主管之學校行政工作年資，於師資培育之大學所設附屬國民小學校長，得為大學法規所定一級單位主管之學校行政工作年資。", "targetRegulationId": "tw-university-act", "targetRegulationNames": ["大學法"], "targetArticleNumber": null, "triggerTerms": ["長，得為"], "linkMode": "automatic", "id": "link-tw-educational-personnel-employment-act-cite-1", "sortOrder": 0}, {"conceptId": "teacher-employment-framework", "sourceArticleId": "article-5", "label": "引用大學法", "relationType": "application", "conditionText": "2   師資培育之大學附設國民中學校長資格，除依前項各款規定辦理外，得曾任教育學院、系專任講師及中等學校教師各三年以上，並應持有中等學校教師證書；前項第三款國民中學一級單位主管之學校行政工作年資，並得為大學法規所定一級單位主管之學校行政工作年資。", "targetRegulationId": "tw-university-act", "targetRegulationNames": ["大學法"], "targetArticleNumber": null, "triggerTerms": ["，並得為"], "linkMode": "automatic", "id": "link-tw-educational-personnel-employment-act-cite-2", "sortOrder": 1}, {"conceptId": "teacher-employment-framework", "sourceArticleId": "article-6", "label": "引用大學法", "relationType": "application", "conditionText": "2   師資培育之大學附設高級中等學校校長資格，除依前項各款規定辦理外，得曾任教育學院、系專任副教授或曾任與擬任職業學校性質相關學科專任副教授，及中等學校教師各二年以上，並具各級學校法規所定一級單位主管之學校行政工作一年以上，且應持有中等學校教師證書；前項第三款高級中等學校一級單位主管之學校行政工作年資，並得為大學法規所定一級單位主管之學校行政工作年資。", "targetRegulationId": "tw-university-act", "targetRegulationNames": ["大學法"], "targetArticleNumber": null, "triggerTerms": ["，並得為"], "linkMode": "automatic", "id": "link-tw-educational-personnel-employment-act-cite-3", "sortOrder": 2}, {"conceptId": "teacher-employment-framework", "sourceArticleId": "article-30-1", "label": "引用大學法", "relationType": "application", "conditionText": "本條例修正施行前已取得講師、助教證書之現職人員，如繼續任教而未中斷，得逕依原升等辦法送審，不受大學法第二十九條之限制。社會教育機構專業人員及學術研究機構研究人員原依本條例聘任者，得比照辦理。", "targetRegulationId": "tw-university-act", "targetRegulationNames": ["大學法"], "targetArticleNumber": "29", "triggerTerms": ["審，不受"], "linkMode": "automatic", "id": "link-tw-educational-personnel-employment-act-cite-4", "sortOrder": 3}, {"conceptId": "sexual-assault-prevention-framework", "sourceArticleId": "article-31", "label": "引用性侵害犯罪防治法", "relationType": "authorization", "conditionText": "三、曾犯性侵害犯罪防治法第二條第一項所定之罪，經有罪判決確定。", "targetRegulationId": "tw-sexual-assault-crime-prevention-act", "targetRegulationNames": ["性侵害犯罪防治法"], "targetArticleNumber": "2", "triggerTerms": ["三、曾犯"], "linkMode": "automatic", "id": "link-tw-educational-personnel-employment-act-cite-5", "sortOrder": 4}, {"conceptId": "gender-equity-campus-framework", "sourceArticleId": "article-31", "label": "引用性別平等教育法", "relationType": "application", "conditionText": "十、知悉服務學校發生疑似校園性侵害事件，未依性別平等教育法規定通報，致再度發生校園性侵害事件；或偽造、變造、湮滅或隱匿他人所犯校園性侵害事件之證據，經有關機關查證屬實。", "targetRegulationId": "tw-gender-equity-education-act", "targetRegulationNames": ["性別平等教育法"], "targetArticleNumber": null, "triggerTerms": ["件，未依"], "linkMode": "automatic", "id": "link-tw-educational-personnel-employment-act-cite-6", "sortOrder": 5}, {"conceptId": "teacher-employment-framework", "sourceArticleId": "article-31", "label": "引用教師法", "relationType": "application", "conditionText": "2   教育人員有前項第十三款規定之情事，除情節重大者及教師應依教師法第十四條規定辦理外，其餘經議決解聘或免職者，應併審酌案件情節，議決一年至四年不得聘任為教育人員，並報主管教育行政機關核定。", "targetRegulationId": "tw-teachers-act", "targetRegulationNames": ["教師法"], "targetArticleNumber": "14", "triggerTerms": ["教師應依"], "linkMode": "automatic", "id": "link-tw-educational-personnel-employment-act-cite-7", "sortOrder": 6}]
- definedTerms：[]

正規化概念、跨法連結與處理狀態不是獨立法源；下面逐條保留來源plainText，未以本次日期重寫。

## U11-A1｜第 1 條

教育人員之任用，依本條例行之。本條例未規定者，適用其他有關法律之規定。

來源條目欄位（正規化資料）：
- id：article-1
- articleNumber：1
- displayNumber：第 1 條
- title：None
- structureId：chapter-1
- metadata：{"source": "全國法規資料庫 教育人員任用條例（PDF：教育人員任用條例.pdf）", "lastModified": "2014-01-22"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": null,
    "text": "教育人員之任用，依本條例行之。本條例未規定者，適用其他有關法律之規定。"
  }
]
```

## U11-A2｜第 2 條

本條例所稱教育人員為各公立各級學校校長、教師、職員、運動教練，社會教育機構專業人員及各級主管教育行政機關所屬學術研究機構（以下簡稱學術研究機構）研究人員。

來源條目欄位（正規化資料）：
- id：article-2
- articleNumber：2
- displayNumber：第 2 條
- title：None
- structureId：chapter-1
- metadata：{"source": "全國法規資料庫 教育人員任用條例（PDF：教育人員任用條例.pdf）", "lastModified": "2014-01-22"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": null,
    "text": "本條例所稱教育人員為各公立各級學校校長、教師、職員、運動教練，社會教育機構專業人員及各級主管教育行政機關所屬學術研究機構（以下簡稱學術研究機構）研究人員。"
  }
]
```

## U11-A3｜第 3 條

教育人員之任用，應注意其品德及對國家之忠誠；其學識、經驗、才能、體能，應與擬任職務之種類、性質相當。各級學校校長及社會教育機構、學術研究機構主管人員之任用，並應注重其領導能力。

來源條目欄位（正規化資料）：
- id：article-3
- articleNumber：3
- displayNumber：第 3 條
- title：None
- structureId：chapter-2
- metadata：{"source": "全國法規資料庫 教育人員任用條例（PDF：教育人員任用條例.pdf）", "lastModified": "2014-01-22"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": null,
    "text": "教育人員之任用，應注意其品德及對國家之忠誠；其學識、經驗、才能、體能，應與擬任職務之種類、性質相當。各級學校校長及社會教育機構、學術研究機構主管人員之任用，並應注重其領導能力。"
  }
]
```

## U11-A4｜第 4 條

1   國民小學校長應持有國民小學教師證書，並具下列資格之一：
一、曾任國民小學教師五年以上，及各級學校法規所定一級單位主管之學校行政工作三年以上。
二、曾任國民小學或國民中學教師三年以上或合計四年以上，及薦任第八職等以上或與其相當之教育行政相關工作二年以上。
三、曾任各級學校教師合計七年以上，其中擔任國民小學教師至少三年，及國民小學一級單位主管之學校行政工作二年以上。
2   前項第三款國民小學一級單位主管之學校行政工作年資，於師資培育之大學所設附屬國民小學校長，得為大學法規所定一級單位主管之學校行政工作年資。

來源條目欄位（正規化資料）：
- id：article-4
- articleNumber：4
- displayNumber：第 4 條
- title：None
- structureId：chapter-2
- metadata：{"source": "全國法規資料庫 教育人員任用條例（PDF：教育人員任用條例.pdf）", "lastModified": "2014-01-22"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   國民小學校長應持有國民小學教師證書，並具下列資格之一："
  },
  {
    "type": "item",
    "number": "一",
    "text": "一、曾任國民小學教師五年以上，及各級學校法規所定一級單位主管之學校行政工作三年以上。"
  },
  {
    "type": "item",
    "number": "二",
    "text": "二、曾任國民小學或國民中學教師三年以上或合計四年以上，及薦任第八職等以上或與其相當之教育行政相關工作二年以上。"
  },
  {
    "type": "item",
    "number": "三",
    "text": "三、曾任各級學校教師合計七年以上，其中擔任國民小學教師至少三年，及國民小學一級單位主管之學校行政工作二年以上。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   前項第三款國民小學一級單位主管之學校行政工作年資，於師資培育之大學所設附屬國民小學校長，得為大學法規所定一級單位主管之學校行政工作年資。"
  }
]
```

## U11-A5｜第 5 條

1   國民中學校長應持有中等學校教師證書，並具下列資格之一：
一、曾任國民中學教師五年以上，及各級學校法規所定一級單位主管之學校行政工作三年以上。
二、曾任國民小學或中等學校教師三年以上或合計四年以上，及薦任第八職等以上或與其相當之教育行政相關工作二年以上。
三、曾任各級學校教師合計七年以上，其中擔任國民中學教師至少三年，及國民中學一級單位主管之學校行政工作二年以上。
2   師資培育之大學附設國民中學校長資格，除依前項各款規定辦理外，得曾任教育學院、系專任講師及中等學校教師各三年以上，並應持有中等學校教師證書；前項第三款國民中學一級單位主管之學校行政工作年資，並得為大學法規所定一級單位主管之學校行政工作年資。
3   持有國民中學主任甄選儲訓合格證書之高級中等學校附設國民中學部教師，其兼任高級中等學校主任者，得以該主任年資，採計為第一項第三款國民中學一級單位主管之學校行政工作年資。

來源條目欄位（正規化資料）：
- id：article-5
- articleNumber：5
- displayNumber：第 5 條
- title：None
- structureId：chapter-2
- metadata：{"source": "全國法規資料庫 教育人員任用條例（PDF：教育人員任用條例.pdf）", "lastModified": "2014-01-22"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   國民中學校長應持有中等學校教師證書，並具下列資格之一："
  },
  {
    "type": "item",
    "number": "一",
    "text": "一、曾任國民中學教師五年以上，及各級學校法規所定一級單位主管之學校行政工作三年以上。"
  },
  {
    "type": "item",
    "number": "二",
    "text": "二、曾任國民小學或中等學校教師三年以上或合計四年以上，及薦任第八職等以上或與其相當之教育行政相關工作二年以上。"
  },
  {
    "type": "item",
    "number": "三",
    "text": "三、曾任各級學校教師合計七年以上，其中擔任國民中學教師至少三年，及國民中學一級單位主管之學校行政工作二年以上。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   師資培育之大學附設國民中學校長資格，除依前項各款規定辦理外，得曾任教育學院、系專任講師及中等學校教師各三年以上，並應持有中等學校教師證書；前項第三款國民中學一級單位主管之學校行政工作年資，並得為大學法規所定一級單位主管之學校行政工作年資。"
  },
  {
    "type": "paragraph",
    "number": "3",
    "text": "3   持有國民中學主任甄選儲訓合格證書之高級中等學校附設國民中學部教師，其兼任高級中等學校主任者，得以該主任年資，採計為第一項第三款國民中學一級單位主管之學校行政工作年資。"
  }
]
```

## U11-A6｜第 6 條

1   高級中等學校校長應持有中等學校教師證書，並具下列資格之一：
一、曾任高級中等學校教師五年以上，及各級學校法規所定一級單位主管之學校行政工作三年以上。
二、曾任中等學校教師三年以上，及薦任第九職等以上或與其相當之教育行政相關工作二年以上。
三、曾任各級學校教師合計七年以上，其中擔任高級中等學校教師至少三年，及高級中等學校一級單位主管之學校行政工作二年以上。
2   師資培育之大學附設高級中等學校校長資格，除依前項各款規定辦理外，得曾任教育學院、系專任副教授或曾任與擬任職業學校性質相關學科專任副教授，及中等學校教師各二年以上，並具各級學校法規所定一級單位主管之學校行政工作一年以上，且應持有中等學校教師證書；前項第三款高級中等學校一級單位主管之學校行政工作年資，並得為大學法規所定一級單位主管之學校行政工作年資。
3   民族藝術高級中等學校校長資格，除依第一項各款規定辦理外，得曾任高級中等學校或專科以上學校之戲劇、藝術或其相關科、系（所、學程）教師二年以上，及各級學校法規所定主管職務、薦任第九職等以上或與其相當之教育、文化行政工作二年以上。

來源條目欄位（正規化資料）：
- id：article-6
- articleNumber：6
- displayNumber：第 6 條
- title：None
- structureId：chapter-2
- metadata：{"source": "全國法規資料庫 教育人員任用條例（PDF：教育人員任用條例.pdf）", "lastModified": "2014-01-22"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   高級中等學校校長應持有中等學校教師證書，並具下列資格之一："
  },
  {
    "type": "item",
    "number": "一",
    "text": "一、曾任高級中等學校教師五年以上，及各級學校法規所定一級單位主管之學校行政工作三年以上。"
  },
  {
    "type": "item",
    "number": "二",
    "text": "二、曾任中等學校教師三年以上，及薦任第九職等以上或與其相當之教育行政相關工作二年以上。"
  },
  {
    "type": "item",
    "number": "三",
    "text": "三、曾任各級學校教師合計七年以上，其中擔任高級中等學校教師至少三年，及高級中等學校一級單位主管之學校行政工作二年以上。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   師資培育之大學附設高級中等學校校長資格，除依前項各款規定辦理外，得曾任教育學院、系專任副教授或曾任與擬任職業學校性質相關學科專任副教授，及中等學校教師各二年以上，並具各級學校法規所定一級單位主管之學校行政工作一年以上，且應持有中等學校教師證書；前項第三款高級中等學校一級單位主管之學校行政工作年資，並得為大學法規所定一級單位主管之學校行政工作年資。"
  },
  {
    "type": "paragraph",
    "number": "3",
    "text": "3   民族藝術高級中等學校校長資格，除依第一項各款規定辦理外，得曾任高級中等學校或專科以上學校之戲劇、藝術或其相關科、系（所、學程）教師二年以上，及各級學校法規所定主管職務、薦任第九職等以上或與其相當之教育、文化行政工作二年以上。"
  }
]
```

## U11-A6-1｜第 6-1 條

特殊教育學校校長應持有學校所設最高教育階段教師證書及具備特殊教育之專業知能，並具下列資格之一：
一、曾任特殊教育學校（班）教師五年以上，及各級學校法規所定一級單位主管之學校行政工作三年以上。
二、曾任特殊教育學校（班）教師三年以上，及薦任第九職等以上或與其相當之教育行政相關工作二年以上。
三、曾任各級學校教師合計七年以上，其中擔任特殊教育學校（班）教師至少三年，及高級中等以下學校一級單位主管之學校行政工作二年以上。

來源條目欄位（正規化資料）：
- id：article-6-1
- articleNumber：6-1
- displayNumber：第 6-1 條
- title：None
- structureId：chapter-2
- metadata：{"source": "全國法規資料庫 教育人員任用條例（PDF：教育人員任用條例.pdf）", "lastModified": "2014-01-22"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": null,
    "text": "特殊教育學校校長應持有學校所設最高教育階段教師證書及具備特殊教育之專業知能，並具下列資格之一："
  },
  {
    "type": "item",
    "number": "一",
    "text": "一、曾任特殊教育學校（班）教師五年以上，及各級學校法規所定一級單位主管之學校行政工作三年以上。"
  },
  {
    "type": "item",
    "number": "二",
    "text": "二、曾任特殊教育學校（班）教師三年以上，及薦任第九職等以上或與其相當之教育行政相關工作二年以上。"
  },
  {
    "type": "item",
    "number": "三",
    "text": "三、曾任各級學校教師合計七年以上，其中擔任特殊教育學校（班）教師至少三年，及高級中等以下學校一級單位主管之學校行政工作二年以上。"
  }
]
```

## U11-A7｜第 7 條

（刪除）

來源條目欄位（正規化資料）：
- id：article-7
- articleNumber：7
- displayNumber：第 7 條
- title：None
- structureId：chapter-2
- metadata：{"source": "全國法規資料庫 教育人員任用條例（PDF：教育人員任用條例.pdf）", "lastModified": "2014-01-22"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": null,
    "text": "（刪除）"
  }
]
```

## U11-A8｜第 8 條

專科學校校長應具下列第一款各目資格之一及第二款資格：
一、具下列資格之一：
（一）中央研究院院士。
（二）教授。
（三）曾任相當教授之教學、學術研究工作。
（四）曾任副教授三年以上。
（五）曾任相當副教授三年以上之教學、學術研究工作。
二、曾任學校、政府機關（構）或其他公民營事業機構之主管職務合計三年以上。

來源條目欄位（正規化資料）：
- id：article-8
- articleNumber：8
- displayNumber：第 8 條
- title：None
- structureId：chapter-2
- metadata：{"source": "全國法規資料庫 教育人員任用條例（PDF：教育人員任用條例.pdf）", "lastModified": "2014-01-22"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": null,
    "text": "專科學校校長應具下列第一款各目資格之一及第二款資格："
  },
  {
    "type": "item",
    "number": "一",
    "text": "一、具下列資格之一："
  },
  {
    "type": "subitem",
    "number": "一",
    "text": "（一）中央研究院院士。"
  },
  {
    "type": "subitem",
    "number": "二",
    "text": "（二）教授。"
  },
  {
    "type": "subitem",
    "number": "三",
    "text": "（三）曾任相當教授之教學、學術研究工作。"
  },
  {
    "type": "subitem",
    "number": "四",
    "text": "（四）曾任副教授三年以上。"
  },
  {
    "type": "subitem",
    "number": "五",
    "text": "（五）曾任相當副教授三年以上之教學、學術研究工作。"
  },
  {
    "type": "item",
    "number": "二",
    "text": "二、曾任學校、政府機關（構）或其他公民營事業機構之主管職務合計三年以上。"
  }
]
```

## U11-A9｜第 9 條

（刪除）

來源條目欄位（正規化資料）：
- id：article-9
- articleNumber：9
- displayNumber：第 9 條
- title：None
- structureId：chapter-2
- metadata：{"source": "全國法規資料庫 教育人員任用條例（PDF：教育人員任用條例.pdf）", "lastModified": "2014-01-22"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": null,
    "text": "（刪除）"
  }
]
```

## U11-A10｜第 10 條

1   大學校長應具下列第一款各目資格之一及第二款資格：
一、具下列資格之一：
（一）中央研究院院士。
（二）教授。
（三）曾任相當教授之教學、學術研究工作。
二、曾任學校、政府機關（構）或其他公民營事業機構之主管職務合計三年以上。
2   獨立學院校長資格，除依前項各款規定辦理外，得以具有博士學位，並曾任與擬任學院性質相關之專門職業，或簡任第十二職等以上或與其相當之教育行政職務合計六年以上者充任之。
3   大學及獨立學院校長之資格除應符合前二項規定外，各校得因校務發展及特殊專業需求，另定前二項以外之資格條件，並於組織規程中明定。

來源條目欄位（正規化資料）：
- id：article-10
- articleNumber：10
- displayNumber：第 10 條
- title：None
- structureId：chapter-2
- metadata：{"source": "全國法規資料庫 教育人員任用條例（PDF：教育人員任用條例.pdf）", "lastModified": "2014-01-22"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   大學校長應具下列第一款各目資格之一及第二款資格："
  },
  {
    "type": "item",
    "number": "一",
    "text": "一、具下列資格之一："
  },
  {
    "type": "subitem",
    "number": "一",
    "text": "（一）中央研究院院士。"
  },
  {
    "type": "subitem",
    "number": "二",
    "text": "（二）教授。"
  },
  {
    "type": "subitem",
    "number": "三",
    "text": "（三）曾任相當教授之教學、學術研究工作。"
  },
  {
    "type": "item",
    "number": "二",
    "text": "二、曾任學校、政府機關（構）或其他公民營事業機構之主管職務合計三年以上。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   獨立學院校長資格，除依前項各款規定辦理外，得以具有博士學位，並曾任與擬任學院性質相關之專門職業，或簡任第十二職等以上或與其相當之教育行政職務合計六年以上者充任之。"
  },
  {
    "type": "paragraph",
    "number": "3",
    "text": "3   大學及獨立學院校長之資格除應符合前二項規定外，各校得因校務發展及特殊專業需求，另定前二項以外之資格條件，並於組織規程中明定。"
  }
]
```

## U11-A10-1｜第 10-1 條

1   本條例中華民國一百年十一月十五日修正之條文施行前曾任或現任各級學校校長，或經公開甄選儲訓合格之國民中學、國民小學校長候用人員，或符合修正前高級中等以上學校校長聘任資格者，具有同級學校校長之聘任資格；主管教育行政機關已依修正前第四條、第五條規定資格辦理校長候用人員儲訓作業者，其儲訓合格之人員，亦同。
2   專科學校改制為技術學院設有專科部者，其校長得由原專科學校校長繼續擔任至任期屆滿為止。
3   本條例中華民國一百年十一月十五日修正之條文施行前，主管教育行政機關、學校或董事會已依修正前第四條至前條規定資格辦理校長遴選作業中者，其校長聘任資格得依修正前規定辦理。

來源條目欄位（正規化資料）：
- id：article-10-1
- articleNumber：10-1
- displayNumber：第 10-1 條
- title：None
- structureId：chapter-2
- metadata：{"source": "全國法規資料庫 教育人員任用條例（PDF：教育人員任用條例.pdf）", "lastModified": "2014-01-22"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   本條例中華民國一百年十一月十五日修正之條文施行前曾任或現任各級學校校長，或經公開甄選儲訓合格之國民中學、國民小學校長候用人員，或符合修正前高級中等以上學校校長聘任資格者，具有同級學校校長之聘任資格；主管教育行政機關已依修正前第四條、第五條規定資格辦理校長候用人員儲訓作業者，其儲訓合格之人員，亦同。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   專科學校改制為技術學院設有專科部者，其校長得由原專科學校校長繼續擔任至任期屆滿為止。"
  },
  {
    "type": "paragraph",
    "number": "3",
    "text": "3   本條例中華民國一百年十一月十五日修正之條文施行前，主管教育行政機關、學校或董事會已依修正前第四條至前條規定資格辦理校長遴選作業中者，其校長聘任資格得依修正前規定辦理。"
  }
]
```

## U11-A11｜第 11 條

師範大學、師範學院、師範專科學校校、院長，除應具備本條例相關各條規定之資格外，並以修習教育者為原則。

來源條目欄位（正規化資料）：
- id：article-11
- articleNumber：11
- displayNumber：第 11 條
- title：None
- structureId：chapter-2
- metadata：{"source": "全國法規資料庫 教育人員任用條例（PDF：教育人員任用條例.pdf）", "lastModified": "2014-01-22"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": null,
    "text": "師範大學、師範學院、師範專科學校校、院長，除應具備本條例相關各條規定之資格外，並以修習教育者為原則。"
  }
]
```

## U11-A12｜第 12 條

國民小學教師應具有左列資格之一：
一、師範專科學校畢業者。
二、師範大學、師範學院各學系、或教育學院、系畢業者。
三、本條例施行前，依規定取得國民小學教師合格證書尚在有效期間者。

來源條目欄位（正規化資料）：
- id：article-12
- articleNumber：12
- displayNumber：第 12 條
- title：None
- structureId：chapter-2
- metadata：{"source": "全國法規資料庫 教育人員任用條例（PDF：教育人員任用條例.pdf）", "lastModified": "2014-01-22"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": null,
    "text": "國民小學教師應具有左列資格之一："
  },
  {
    "type": "item",
    "number": "一",
    "text": "一、師範專科學校畢業者。"
  },
  {
    "type": "item",
    "number": "二",
    "text": "二、師範大學、師範學院各學系、或教育學院、系畢業者。"
  },
  {
    "type": "item",
    "number": "三",
    "text": "三、本條例施行前，依規定取得國民小學教師合格證書尚在有效期間者。"
  }
]
```

## U11-A13｜第 13 條

中等學校教師應具有左列資格之一：
一、師範大學、師範學院各系、所畢業者。
二、教育學院各系、所或大學教育學系、所畢業者。
三、大學或獨立學院各系、所畢業，經修習規定之教育學科及學分者。
四、本條例施行前，依規定取得中等學校教師合格證書尚在有效期間者。

來源條目欄位（正規化資料）：
- id：article-13
- articleNumber：13
- displayNumber：第 13 條
- title：None
- structureId：chapter-2
- metadata：{"source": "全國法規資料庫 教育人員任用條例（PDF：教育人員任用條例.pdf）", "lastModified": "2014-01-22"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": null,
    "text": "中等學校教師應具有左列資格之一："
  },
  {
    "type": "item",
    "number": "一",
    "text": "一、師範大學、師範學院各系、所畢業者。"
  },
  {
    "type": "item",
    "number": "二",
    "text": "二、教育學院各系、所或大學教育學系、所畢業者。"
  },
  {
    "type": "item",
    "number": "三",
    "text": "三、大學或獨立學院各系、所畢業，經修習規定之教育學科及學分者。"
  },
  {
    "type": "item",
    "number": "四",
    "text": "四、本條例施行前，依規定取得中等學校教師合格證書尚在有效期間者。"
  }
]
```

## U11-A14｜第 14 條

1   大學、獨立學院及專科學校教師分為教授、副教授、助理教授、講師。
2   大學、獨立學院及專科學校教師應具有專門著作在國內外知名學術或專業刊物發表，或已為接受且出具證明將定期發表，或經出版公開發行，並經教育部審查其著作合格者，始得升等；必要時，教育部得授權學校辦理審查。
3   大學、獨立學院及專科學校體育、藝術、應用科技等以技能為主之教師聘任或升等，得以作品、成就證明或技術報告代替專門著作送審。
4   大學、獨立學院及專科學校教師之聘任、升等均應辦理資格審查；其審查辦法由教育部定之。

來源條目欄位（正規化資料）：
- id：article-14
- articleNumber：14
- displayNumber：第 14 條
- title：None
- structureId：chapter-2
- metadata：{"source": "全國法規資料庫 教育人員任用條例（PDF：教育人員任用條例.pdf）", "lastModified": "2014-01-22"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   大學、獨立學院及專科學校教師分為教授、副教授、助理教授、講師。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   大學、獨立學院及專科學校教師應具有專門著作在國內外知名學術或專業刊物發表，或已為接受且出具證明將定期發表，或經出版公開發行，並經教育部審查其著作合格者，始得升等；必要時，教育部得授權學校辦理審查。"
  },
  {
    "type": "paragraph",
    "number": "3",
    "text": "3   大學、獨立學院及專科學校體育、藝術、應用科技等以技能為主之教師聘任或升等，得以作品、成就證明或技術報告代替專門著作送審。"
  },
  {
    "type": "paragraph",
    "number": "4",
    "text": "4   大學、獨立學院及專科學校教師之聘任、升等均應辦理資格審查；其審查辦法由教育部定之。"
  }
]
```

## U11-A15｜第 15 條

1   大學、獨立學院及專科學校得聘任助教協助教學及研究工作。
2   助教應具有左列資格之一：
一、大學或獨立學院畢業，成績優良者。
二、三年制專科學校畢業，曾從事與所習學科有關之研究工作、專門職業或職務二年以上；或二年制、五年制專科學校畢業，曾從事與所習學科有關之研究工作、專門職業或職務三年以上，成績優良者。

來源條目欄位（正規化資料）：
- id：article-15
- articleNumber：15
- displayNumber：第 15 條
- title：None
- structureId：chapter-2
- metadata：{"source": "全國法規資料庫 教育人員任用條例（PDF：教育人員任用條例.pdf）", "lastModified": "2014-01-22"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   大學、獨立學院及專科學校得聘任助教協助教學及研究工作。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   助教應具有左列資格之一："
  },
  {
    "type": "item",
    "number": "一",
    "text": "一、大學或獨立學院畢業，成績優良者。"
  },
  {
    "type": "item",
    "number": "二",
    "text": "二、三年制專科學校畢業，曾從事與所習學科有關之研究工作、專門職業或職務二年以上；或二年制、五年制專科學校畢業，曾從事與所習學科有關之研究工作、專門職業或職務三年以上，成績優良者。"
  }
]
```

## U11-A16｜第 16 條

講師應具有左列資格之一：
一、在研究院、所研究，得有碩士學位或其同等學歷證書，成績優良者。
二、大學或獨立學院畢業，曾任助教擔任協助教學或研究工作四年以上，成績優良，並有專門著作者。
三、大學或獨立學院畢業，曾從事與所習學科有關之研究工作、專門職業或職務六年以上，成績優良，並有專門著作者。

來源條目欄位（正規化資料）：
- id：article-16
- articleNumber：16
- displayNumber：第 16 條
- title：None
- structureId：chapter-2
- metadata：{"source": "全國法規資料庫 教育人員任用條例（PDF：教育人員任用條例.pdf）", "lastModified": "2014-01-22"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": null,
    "text": "講師應具有左列資格之一："
  },
  {
    "type": "item",
    "number": "一",
    "text": "一、在研究院、所研究，得有碩士學位或其同等學歷證書，成績優良者。"
  },
  {
    "type": "item",
    "number": "二",
    "text": "二、大學或獨立學院畢業，曾任助教擔任協助教學或研究工作四年以上，成績優良，並有專門著作者。"
  },
  {
    "type": "item",
    "number": "三",
    "text": "三、大學或獨立學院畢業，曾從事與所習學科有關之研究工作、專門職業或職務六年以上，成績優良，並有專門著作者。"
  }
]
```

## U11-A16-1｜第 16-1 條

助理教授應具有左列資格之一：
一、具有博士學位或其同等學歷證書，成績優良，並有專門著作者。
二、具有碩士學位或其同等學歷證書，曾從事與所習學科有關之研究工作、專門職業或職務四年以上，成績優良，並有專門著作者。
三、大學或獨立學院醫學系、中醫學系、牙醫學系畢業，擔任臨床工作九年以上，其中至少曾任醫學中心主治醫師四年，成績優良，並有專門著作者。
四、曾任講師三年以上，成績優良，並有專門著作者。

來源條目欄位（正規化資料）：
- id：article-16-1
- articleNumber：16-1
- displayNumber：第 16-1 條
- title：None
- structureId：chapter-2
- metadata：{"source": "全國法規資料庫 教育人員任用條例（PDF：教育人員任用條例.pdf）", "lastModified": "2014-01-22"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": null,
    "text": "助理教授應具有左列資格之一："
  },
  {
    "type": "item",
    "number": "一",
    "text": "一、具有博士學位或其同等學歷證書，成績優良，並有專門著作者。"
  },
  {
    "type": "item",
    "number": "二",
    "text": "二、具有碩士學位或其同等學歷證書，曾從事與所習學科有關之研究工作、專門職業或職務四年以上，成績優良，並有專門著作者。"
  },
  {
    "type": "item",
    "number": "三",
    "text": "三、大學或獨立學院醫學系、中醫學系、牙醫學系畢業，擔任臨床工作九年以上，其中至少曾任醫學中心主治醫師四年，成績優良，並有專門著作者。"
  },
  {
    "type": "item",
    "number": "四",
    "text": "四、曾任講師三年以上，成績優良，並有專門著作者。"
  }
]
```

## U11-A17｜第 17 條

副教授應具有左列資格之一：
一、具有博士學位或其同等學歷證書，曾從事與所習學科有關之研究工作、專門職業或職務四年以上，並有專門著作者。
二、曾任助理教授三年以上，成績優良，並有專門著作者。

來源條目欄位（正規化資料）：
- id：article-17
- articleNumber：17
- displayNumber：第 17 條
- title：None
- structureId：chapter-2
- metadata：{"source": "全國法規資料庫 教育人員任用條例（PDF：教育人員任用條例.pdf）", "lastModified": "2014-01-22"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": null,
    "text": "副教授應具有左列資格之一："
  },
  {
    "type": "item",
    "number": "一",
    "text": "一、具有博士學位或其同等學歷證書，曾從事與所習學科有關之研究工作、專門職業或職務四年以上，並有專門著作者。"
  },
  {
    "type": "item",
    "number": "二",
    "text": "二、曾任助理教授三年以上，成績優良，並有專門著作者。"
  }
]
```

## U11-A18｜第 18 條

教授應具有左列資格之一：
一、具有博士學位或其同等學歷證書，曾從事與所習學科有關之研究工作、專門職業或職務八年以上，有創作或發明，在學術上有重要貢獻或重要專門著作者。
二、曾任副教授三年以上，成績優良，並有重要專門著作者。

來源條目欄位（正規化資料）：
- id：article-18
- articleNumber：18
- displayNumber：第 18 條
- title：None
- structureId：chapter-2
- metadata：{"source": "全國法規資料庫 教育人員任用條例（PDF：教育人員任用條例.pdf）", "lastModified": "2014-01-22"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": null,
    "text": "教授應具有左列資格之一："
  },
  {
    "type": "item",
    "number": "一",
    "text": "一、具有博士學位或其同等學歷證書，曾從事與所習學科有關之研究工作、專門職業或職務八年以上，有創作或發明，在學術上有重要貢獻或重要專門著作者。"
  },
  {
    "type": "item",
    "number": "二",
    "text": "二、曾任副教授三年以上，成績優良，並有重要專門著作者。"
  }
]
```

## U11-A19｜第 19 條

在學術上有傑出之貢獻，並經教育部學術審議會委員二分之一以上出席及出席委員四分之三以上之決議通過者，得任大學、獨立學院或專科學校教師，不受前四條規定之限制。

來源條目欄位（正規化資料）：
- id：article-19
- articleNumber：19
- displayNumber：第 19 條
- title：None
- structureId：chapter-2
- metadata：{"source": "全國法規資料庫 教育人員任用條例（PDF：教育人員任用條例.pdf）", "lastModified": "2014-01-22"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": null,
    "text": "在學術上有傑出之貢獻，並經教育部學術審議會委員二分之一以上出席及出席委員四分之三以上之決議通過者，得任大學、獨立學院或專科學校教師，不受前四條規定之限制。"
  }
]
```

## U11-A20｜第 20 條

1   偏遠或特殊地區之學校校長、教師之資格及專業科目、技術科目、特殊科目教師及稀少性科技人員之資格，由教育部定之。
2   在民國八十三年二月七日前已考進師範學院幼教系及八十四年十一月十六日前已考進師範學院進修部幼教系肄業之師範生，參加偏遠地區國民小學教師甄試，其教育學科及學分之採計，由原就讀之師資培育機構依實質認定原則處理之。
3   參加八十九學年度各縣市偏遠地區國小教師甄試錄取未獲介聘，符合前項規定者，應比照辦理。

來源條目欄位（正規化資料）：
- id：article-20
- articleNumber：20
- displayNumber：第 20 條
- title：None
- structureId：chapter-2
- metadata：{"source": "全國法規資料庫 教育人員任用條例（PDF：教育人員任用條例.pdf）", "lastModified": "2014-01-22"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   偏遠或特殊地區之學校校長、教師之資格及專業科目、技術科目、特殊科目教師及稀少性科技人員之資格，由教育部定之。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   在民國八十三年二月七日前已考進師範學院幼教系及八十四年十一月十六日前已考進師範學院進修部幼教系肄業之師範生，參加偏遠地區國民小學教師甄試，其教育學科及學分之採計，由原就讀之師資培育機構依實質認定原則處理之。"
  },
  {
    "type": "paragraph",
    "number": "3",
    "text": "3   參加八十九學年度各縣市偏遠地區國小教師甄試錄取未獲介聘，符合前項規定者，應比照辦理。"
  }
]
```

## U11-A21｜第 21 條

1   學校職員之任用，依其職務類別，分別適用公務人員任用法或技術人員任用條例之規定，並辦理銓敘審查。
2   本條例施行前已遴用之學校編制內現任職員，其任用資格適用原有關法令規定，並得在各學校間調任。
3   各學校編制內現任職員，在本條例修正施行前，已具有公務人員或技術人員法定任用資格者，依現職改任換敘；其改任換敘辦法由考試院會同行政院定之。
4   學校人事人員及主計人員之任用，分別依照各該有關法律規定辦理。
5   公立學校職員升等考試規則由考試院定之。

來源條目欄位（正規化資料）：
- id：article-21
- articleNumber：21
- displayNumber：第 21 條
- title：None
- structureId：chapter-2
- metadata：{"source": "全國法規資料庫 教育人員任用條例（PDF：教育人員任用條例.pdf）", "lastModified": "2014-01-22"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   學校職員之任用，依其職務類別，分別適用公務人員任用法或技術人員任用條例之規定，並辦理銓敘審查。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   本條例施行前已遴用之學校編制內現任職員，其任用資格適用原有關法令規定，並得在各學校間調任。"
  },
  {
    "type": "paragraph",
    "number": "3",
    "text": "3   各學校編制內現任職員，在本條例修正施行前，已具有公務人員或技術人員法定任用資格者，依現職改任換敘；其改任換敘辦法由考試院會同行政院定之。"
  },
  {
    "type": "paragraph",
    "number": "4",
    "text": "4   學校人事人員及主計人員之任用，分別依照各該有關法律規定辦理。"
  },
  {
    "type": "paragraph",
    "number": "5",
    "text": "5   公立學校職員升等考試規則由考試院定之。"
  }
]
```

## U11-A22｜第 22 條

1   社會教育機構專業人員及學術研究機構研究人員之聘任資格，依其職務等級，準用各級學校教師之規定。
2   前項機構一般行政人員之任用資格，依公務人員有關法規之規定。

來源條目欄位（正規化資料）：
- id：article-22
- articleNumber：22
- displayNumber：第 22 條
- title：None
- structureId：chapter-2
- metadata：{"source": "全國法規資料庫 教育人員任用條例（PDF：教育人員任用條例.pdf）", "lastModified": "2014-01-22"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   社會教育機構專業人員及學術研究機構研究人員之聘任資格，依其職務等級，準用各級學校教師之規定。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   前項機構一般行政人員之任用資格，依公務人員有關法規之規定。"
  }
]
```

## U11-A22-1｜第 22-1 條

各級學校專任運動教練之資格，由中央體育主管機關定之；聘任程序及聘期，由中央主管機關定之。

來源條目欄位（正規化資料）：
- id：article-22-1
- articleNumber：22-1
- displayNumber：第 22-1 條
- title：None
- structureId：chapter-2
- metadata：{"source": "全國法規資料庫 教育人員任用條例（PDF：教育人員任用條例.pdf）", "lastModified": "2014-01-22"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": null,
    "text": "各級學校專任運動教練之資格，由中央體育主管機關定之；聘任程序及聘期，由中央主管機關定之。"
  }
]
```

## U11-A23｜第 23 條

（刪除）

來源條目欄位（正規化資料）：
- id：article-23
- articleNumber：23
- displayNumber：第 23 條
- title：None
- structureId：chapter-3
- metadata：{"source": "全國法規資料庫 教育人員任用條例（PDF：教育人員任用條例.pdf）", "lastModified": "2014-01-22"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": null,
    "text": "（刪除）"
  }
]
```

## U11-A24｜第 24 條

（刪除）

來源條目欄位（正規化資料）：
- id：article-24
- articleNumber：24
- displayNumber：第 24 條
- title：None
- structureId：chapter-3
- metadata：{"source": "全國法規資料庫 教育人員任用條例（PDF：教育人員任用條例.pdf）", "lastModified": "2014-01-22"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": null,
    "text": "（刪除）"
  }
]
```

## U11-A25｜第 25 條

（刪除）

來源條目欄位（正規化資料）：
- id：article-25
- articleNumber：25
- displayNumber：第 25 條
- title：None
- structureId：chapter-3
- metadata：{"source": "全國法規資料庫 教育人員任用條例（PDF：教育人員任用條例.pdf）", "lastModified": "2014-01-22"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": null,
    "text": "（刪除）"
  }
]
```

## U11-A26｜第 26 條

1   各級學校教師之聘任，應本公平、公正、公開之原則辦理，其程序如左：
一、高級中等以下學校教師除依法令分發者外，由校長就經公開甄選之合格人員中，提請教師評審委員會審查通過後聘任。
二、專科學校教師經科務會議，由科主任提經教師評審委員會評審通過後，報請校長聘任。
三、大學、獨立學院各學系、研究所教師，學校應於傳播媒體或學術刊物刊載徵聘資訊後，由系主任或所長就應徵人員提經系（所）、院、校教師評審委員會評審通過後，報請校長聘任。
2   前項教師評審委員會之設置辦法，除專科以上學校由學校組織規程規定外，其辦法由教育部定之。

來源條目欄位（正規化資料）：
- id：article-26
- articleNumber：26
- displayNumber：第 26 條
- title：None
- structureId：chapter-3
- metadata：{"source": "全國法規資料庫 教育人員任用條例（PDF：教育人員任用條例.pdf）", "lastModified": "2014-01-22"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   各級學校教師之聘任，應本公平、公正、公開之原則辦理，其程序如左："
  },
  {
    "type": "item",
    "number": "一",
    "text": "一、高級中等以下學校教師除依法令分發者外，由校長就經公開甄選之合格人員中，提請教師評審委員會審查通過後聘任。"
  },
  {
    "type": "item",
    "number": "二",
    "text": "二、專科學校教師經科務會議，由科主任提經教師評審委員會評審通過後，報請校長聘任。"
  },
  {
    "type": "item",
    "number": "三",
    "text": "三、大學、獨立學院各學系、研究所教師，學校應於傳播媒體或學術刊物刊載徵聘資訊後，由系主任或所長就應徵人員提經系（所）、院、校教師評審委員會評審通過後，報請校長聘任。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   前項教師評審委員會之設置辦法，除專科以上學校由學校組織規程規定外，其辦法由教育部定之。"
  }
]
```

## U11-A27｜第 27 條

1   國民中、小學校長之遴選，除依法兼任者外，應就合格人員以公開方式甄選之。
2   中等學校教師，除分發者外，亦同。

來源條目欄位（正規化資料）：
- id：article-27
- articleNumber：27
- displayNumber：第 27 條
- title：None
- structureId：chapter-3
- metadata：{"source": "全國法規資料庫 教育人員任用條例（PDF：教育人員任用條例.pdf）", "lastModified": "2014-01-22"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   國民中、小學校長之遴選，除依法兼任者外，應就合格人員以公開方式甄選之。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   中等學校教師，除分發者外，亦同。"
  }
]
```

## U11-A28｜第 28 條

學校職員之任用程序，除主計人員、人事人員分別依各該有關法律規定辦理外，由校長就合格人員中任用，並報主管教育行政機關核備。

來源條目欄位（正規化資料）：
- id：article-28
- articleNumber：28
- displayNumber：第 28 條
- title：None
- structureId：chapter-3
- metadata：{"source": "全國法規資料庫 教育人員任用條例（PDF：教育人員任用條例.pdf）", "lastModified": "2014-01-22"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": null,
    "text": "學校職員之任用程序，除主計人員、人事人員分別依各該有關法律規定辦理外，由校長就合格人員中任用，並報主管教育行政機關核備。"
  }
]
```

## U11-A29｜第 29 條

社會教育機構專業人員、學術研究機構研究人員，由各該首長遴選合格人員，報請主管教育行政機關核准後聘任。

來源條目欄位（正規化資料）：
- id：article-29
- articleNumber：29
- displayNumber：第 29 條
- title：None
- structureId：chapter-3
- metadata：{"source": "全國法規資料庫 教育人員任用條例（PDF：教育人員任用條例.pdf）", "lastModified": "2014-01-22"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": null,
    "text": "社會教育機構專業人員、學術研究機構研究人員，由各該首長遴選合格人員，報請主管教育行政機關核准後聘任。"
  }
]
```

## U11-A30｜第 30 條

學校教師經任用後，應依左列程序，報請審查其資格：
一、國民中、小學教師應送由服務學校報請該管縣（市）政府轉報省教育廳審查。
二、高級中等學校教師應送由服務學校轉報省教育廳審查。
三、直轄市所屬公私立中、小學教師應送由服務學校轉報市教育局審查。
四、師範校院，設有教育院、系之大學附屬中、小學及國立中等學校教師，應送由服務學校層轉所在地區之省（市）教育廳（局）審查。
五、專科以上學校教師應送由服務學校轉報教育部審查。教師資格審查、登記辦法由教育部定之。

來源條目欄位（正規化資料）：
- id：article-30
- articleNumber：30
- displayNumber：第 30 條
- title：None
- structureId：chapter-3
- metadata：{"source": "全國法規資料庫 教育人員任用條例（PDF：教育人員任用條例.pdf）", "lastModified": "2014-01-22"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": null,
    "text": "學校教師經任用後，應依左列程序，報請審查其資格："
  },
  {
    "type": "item",
    "number": "一",
    "text": "一、國民中、小學教師應送由服務學校報請該管縣（市）政府轉報省教育廳審查。"
  },
  {
    "type": "item",
    "number": "二",
    "text": "二、高級中等學校教師應送由服務學校轉報省教育廳審查。"
  },
  {
    "type": "item",
    "number": "三",
    "text": "三、直轄市所屬公私立中、小學教師應送由服務學校轉報市教育局審查。"
  },
  {
    "type": "item",
    "number": "四",
    "text": "四、師範校院，設有教育院、系之大學附屬中、小學及國立中等學校教師，應送由服務學校層轉所在地區之省（市）教育廳（局）審查。"
  },
  {
    "type": "item",
    "number": "五",
    "text": "五、專科以上學校教師應送由服務學校轉報教育部審查。教師資格審查、登記辦法由教育部定之。"
  }
]
```

## U11-A30-1｜第 30-1 條

本條例修正施行前已取得講師、助教證書之現職人員，如繼續任教而未中斷，得逕依原升等辦法送審，不受大學法第二十九條之限制。社會教育機構專業人員及學術研究機構研究人員原依本條例聘任者，得比照辦理。

來源條目欄位（正規化資料）：
- id：article-30-1
- articleNumber：30-1
- displayNumber：第 30-1 條
- title：None
- structureId：chapter-3
- metadata：{"source": "全國法規資料庫 教育人員任用條例（PDF：教育人員任用條例.pdf）", "lastModified": "2014-01-22"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": null,
    "text": "本條例修正施行前已取得講師、助教證書之現職人員，如繼續任教而未中斷，得逕依原升等辦法送審，不受大學法第二十九條之限制。社會教育機構專業人員及學術研究機構研究人員原依本條例聘任者，得比照辦理。"
  }
]
```

## U11-A31｜第 31 條

1   具有下列情事之一者，不得為教育人員；其已任用者，應報請主管教育行政機關核准後，予以解聘或免職：
一、曾犯內亂、外患罪，經有罪判決確定或通緝有案尚未結案。
二、曾服公務，因貪污瀆職經有罪判決確定或通緝有案尚未結案。
三、曾犯性侵害犯罪防治法第二條第一項所定之罪，經有罪判決確定。
四、依法停止任用，或受休職處分尚未期滿，或因案停止職務，其原因尚未消滅。
五、褫奪公權尚未復權。
六、受監護或輔助宣告尚未撤銷。
七、經合格醫師證明有精神病尚未痊癒。
八、經學校性別平等教育委員會或依法組成之相關委員會調查確認有性侵害行為屬實。
九、經學校性別平等教育委員會或依法組成之相關委員會調查確認有性騷擾或性霸凌行為，且情節重大。
十、知悉服務學校發生疑似校園性侵害事件，未依性別平等教育法規定通報，致再度發生校園性侵害事件；或偽造、變造、湮滅或隱匿他人所犯校園性侵害事件之證據，經有關機關查證屬實。
十一、偽造、變造或湮滅他人所犯校園毒品危害事件之證據，經有關機關查證屬實。
十二、體罰或霸凌學生，造成其身心嚴重侵害。
十三、行為違反相關法令，經有關機關查證屬實。
2   教育人員有前項第十三款規定之情事，除情節重大者及教師應依教師法第十四條規定辦理外，其餘經議決解聘或免職者，應併審酌案件情節，議決一年至四年不得聘任為教育人員，並報主管教育行政機關核定。
3   第一項教育人員為校長時，應由主管教育行政機關予以解聘，其涉及第八款或第九款之行為，應由主管機關之性別平等教育委員會或依法組成之相關委員會調查之。
4   被告為教育人員之性侵害刑事案件，其主管教育行政機關或所屬學校得於偵查或審判中，聲請司法機關提供案件相關資訊，並通知其偵查、裁判結果。但其妨害偵查不公開、足以妨害另案之偵查、違反法定保密義務，或有害被告訴訟防禦權之行使者，不在此限。
5   為避免聘任之教育人員有第一項第一款至第十二款及第二項規定之情事，各主管機關及各級學校應依規定辦理通報、資訊之蒐集及查詢；其通報、資訊之蒐集、查詢及其他應遵行事項之辦法，由教育部定之。
6   本條例中華民國一百零三年一月三日修正之條文施行前，因行為不檢有損師道，經有關機關查證屬實而解聘或免職之教育人員，除屬性侵害行為；性騷擾、性霸凌行為、行為違反相關法令，且情節重大；體罰或霸凌學生造成其身心嚴重侵害者外，於解聘或免職生效日起算逾四年者，得聘任為教育人員。

來源條目欄位（正規化資料）：
- id：article-31
- articleNumber：31
- displayNumber：第 31 條
- title：None
- structureId：chapter-4
- metadata：{"source": "全國法規資料庫 教育人員任用條例（PDF：教育人員任用條例.pdf）", "lastModified": "2014-01-22"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   具有下列情事之一者，不得為教育人員；其已任用者，應報請主管教育行政機關核准後，予以解聘或免職："
  },
  {
    "type": "item",
    "number": "一",
    "text": "一、曾犯內亂、外患罪，經有罪判決確定或通緝有案尚未結案。"
  },
  {
    "type": "item",
    "number": "二",
    "text": "二、曾服公務，因貪污瀆職經有罪判決確定或通緝有案尚未結案。"
  },
  {
    "type": "item",
    "number": "三",
    "text": "三、曾犯性侵害犯罪防治法第二條第一項所定之罪，經有罪判決確定。"
  },
  {
    "type": "item",
    "number": "四",
    "text": "四、依法停止任用，或受休職處分尚未期滿，或因案停止職務，其原因尚未消滅。"
  },
  {
    "type": "item",
    "number": "五",
    "text": "五、褫奪公權尚未復權。"
  },
  {
    "type": "item",
    "number": "六",
    "text": "六、受監護或輔助宣告尚未撤銷。"
  },
  {
    "type": "item",
    "number": "七",
    "text": "七、經合格醫師證明有精神病尚未痊癒。"
  },
  {
    "type": "item",
    "number": "八",
    "text": "八、經學校性別平等教育委員會或依法組成之相關委員會調查確認有性侵害行為屬實。"
  },
  {
    "type": "item",
    "number": "九",
    "text": "九、經學校性別平等教育委員會或依法組成之相關委員會調查確認有性騷擾或性霸凌行為，且情節重大。"
  },
  {
    "type": "item",
    "number": "十",
    "text": "十、知悉服務學校發生疑似校園性侵害事件，未依性別平等教育法規定通報，致再度發生校園性侵害事件；或偽造、變造、湮滅或隱匿他人所犯校園性侵害事件之證據，經有關機關查證屬實。"
  },
  {
    "type": "item",
    "number": "十一",
    "text": "十一、偽造、變造或湮滅他人所犯校園毒品危害事件之證據，經有關機關查證屬實。"
  },
  {
    "type": "item",
    "number": "十二",
    "text": "十二、體罰或霸凌學生，造成其身心嚴重侵害。"
  },
  {
    "type": "item",
    "number": "十三",
    "text": "十三、行為違反相關法令，經有關機關查證屬實。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   教育人員有前項第十三款規定之情事，除情節重大者及教師應依教師法第十四條規定辦理外，其餘經議決解聘或免職者，應併審酌案件情節，議決一年至四年不得聘任為教育人員，並報主管教育行政機關核定。"
  },
  {
    "type": "paragraph",
    "number": "3",
    "text": "3   第一項教育人員為校長時，應由主管教育行政機關予以解聘，其涉及第八款或第九款之行為，應由主管機關之性別平等教育委員會或依法組成之相關委員會調查之。"
  },
  {
    "type": "paragraph",
    "number": "4",
    "text": "4   被告為教育人員之性侵害刑事案件，其主管教育行政機關或所屬學校得於偵查或審判中，聲請司法機關提供案件相關資訊，並通知其偵查、裁判結果。但其妨害偵查不公開、足以妨害另案之偵查、違反法定保密義務，或有害被告訴訟防禦權之行使者，不在此限。"
  },
  {
    "type": "paragraph",
    "number": "5",
    "text": "5   為避免聘任之教育人員有第一項第一款至第十二款及第二項規定之情事，各主管機關及各級學校應依規定辦理通報、資訊之蒐集及查詢；其通報、資訊之蒐集、查詢及其他應遵行事項之辦法，由教育部定之。"
  },
  {
    "type": "paragraph",
    "number": "6",
    "text": "6   本條例中華民國一百零三年一月三日修正之條文施行前，因行為不檢有損師道，經有關機關查證屬實而解聘或免職之教育人員，除屬性侵害行為；性騷擾、性霸凌行為、行為違反相關法令，且情節重大；體罰或霸凌學生造成其身心嚴重侵害者外，於解聘或免職生效日起算逾四年者，得聘任為教育人員。"
  }
]
```

## U11-A32｜第 32 條

各級學校校長不得任用其配偶或三親等以內血親、姻親為本校職員或命與其具有各該親屬關係之教師兼任行政職務。但接任校長前已在職者，屬於經管財務之職務，應調整其職務或工作；屬於有任期之職務，得續任至任期屆滿。

來源條目欄位（正規化資料）：
- id：article-32
- articleNumber：32
- displayNumber：第 32 條
- title：None
- structureId：chapter-4
- metadata：{"source": "全國法規資料庫 教育人員任用條例（PDF：教育人員任用條例.pdf）", "lastModified": "2014-01-22"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": null,
    "text": "各級學校校長不得任用其配偶或三親等以內血親、姻親為本校職員或命與其具有各該親屬關係之教師兼任行政職務。但接任校長前已在職者，屬於經管財務之職務，應調整其職務或工作；屬於有任期之職務，得續任至任期屆滿。"
  }
]
```

## U11-A33｜第 33 條

有痼疾不能任事，或曾服公務交代未清者，不得任用為教育人員。已屆應即退休年齡者，不得任用為專任教育人員。

來源條目欄位（正規化資料）：
- id：article-33
- articleNumber：33
- displayNumber：第 33 條
- title：None
- structureId：chapter-4
- metadata：{"source": "全國法規資料庫 教育人員任用條例（PDF：教育人員任用條例.pdf）", "lastModified": "2014-01-22"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": null,
    "text": "有痼疾不能任事，或曾服公務交代未清者，不得任用為教育人員。已屆應即退休年齡者，不得任用為專任教育人員。"
  }
]
```

## U11-A34｜第 34 條

專任教育人員，除法令另有規定外，不得在外兼課或兼職。

來源條目欄位（正規化資料）：
- id：article-34
- articleNumber：34
- displayNumber：第 34 條
- title：None
- structureId：chapter-4
- metadata：{"source": "全國法規資料庫 教育人員任用條例（PDF：教育人員任用條例.pdf）", "lastModified": "2014-01-22"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": null,
    "text": "專任教育人員，除法令另有規定外，不得在外兼課或兼職。"
  }
]
```

## U11-A34-1｜第 34-1 條

1   專任教育人員，除法律另有規定外，因育嬰、侍親、進修、借調或其他情事，經服務之學校、機構或主管教育行政機關核准後，得辦理留職停薪。
2   前項教育人員留職停薪之事由、核准程序、期限、次數、復職及其他應遵行事項之辦法，由教育部定之。

來源條目欄位（正規化資料）：
- id：article-34-1
- articleNumber：34-1
- displayNumber：第 34-1 條
- title：None
- structureId：chapter-4
- metadata：{"source": "全國法規資料庫 教育人員任用條例（PDF：教育人員任用條例.pdf）", "lastModified": "2014-01-22"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   專任教育人員，除法律另有規定外，因育嬰、侍親、進修、借調或其他情事，經服務之學校、機構或主管教育行政機關核准後，得辦理留職停薪。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   前項教育人員留職停薪之事由、核准程序、期限、次數、復職及其他應遵行事項之辦法，由教育部定之。"
  }
]
```

## U11-A35｜第 35 條

第三十二條之規定，於社會教育機構、學術研究機構首長準用之。

來源條目欄位（正規化資料）：
- id：article-35
- articleNumber：35
- displayNumber：第 35 條
- title：None
- structureId：chapter-4
- metadata：{"source": "全國法規資料庫 教育人員任用條例（PDF：教育人員任用條例.pdf）", "lastModified": "2014-01-22"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": null,
    "text": "第三十二條之規定，於社會教育機構、學術研究機構首長準用之。"
  }
]
```

## U11-A36｜第 36 條

1   各級學校校長均採任期制，其任期應依相關法規規定。
2   前項校長卸任後，持有教師證書者，得免經教師評審委員會審議，依下列規定回任教師：
一、專科以上學校校長：逕行回任原校教師。
二、高級中等以下學校校長：依各級各類學校法律之規定辦理。

來源條目欄位（正規化資料）：
- id：article-36
- articleNumber：36
- displayNumber：第 36 條
- title：None
- structureId：chapter-5
- metadata：{"source": "全國法規資料庫 教育人員任用條例（PDF：教育人員任用條例.pdf）", "lastModified": "2014-01-22"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   各級學校校長均採任期制，其任期應依相關法規規定。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   前項校長卸任後，持有教師證書者，得免經教師評審委員會審議，依下列規定回任教師："
  },
  {
    "type": "item",
    "number": "一",
    "text": "一、專科以上學校校長：逕行回任原校教師。"
  },
  {
    "type": "item",
    "number": "二",
    "text": "二、高級中等以下學校校長：依各級各類學校法律之規定辦理。"
  }
]
```

## U11-A37｜第 37 條

1   專科以上學校教師之聘期，初聘為一年，續聘第一次為一年，以後續聘，每次均為二年。
2   中等學校教師之聘期，初聘為一年，以後續聘，每次均為二年。

來源條目欄位（正規化資料）：
- id：article-37
- articleNumber：37
- displayNumber：第 37 條
- title：None
- structureId：chapter-5
- metadata：{"source": "全國法規資料庫 教育人員任用條例（PDF：教育人員任用條例.pdf）", "lastModified": "2014-01-22"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   專科以上學校教師之聘期，初聘為一年，續聘第一次為一年，以後續聘，每次均為二年。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   中等學校教師之聘期，初聘為一年，以後續聘，每次均為二年。"
  }
]
```

## U11-A38｜第 38 條

1   學校在聘約有效期間內，除教師違反聘約或因重大事故報經主管教育行政機關核准者外，不得解聘。
2   教師在聘約有效期間內，非有正當事由，不得辭聘。

來源條目欄位（正規化資料）：
- id：article-38
- articleNumber：38
- displayNumber：第 38 條
- title：None
- structureId：chapter-5
- metadata：{"source": "全國法規資料庫 教育人員任用條例（PDF：教育人員任用條例.pdf）", "lastModified": "2014-01-22"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   學校在聘約有效期間內，除教師違反聘約或因重大事故報經主管教育行政機關核准者外，不得解聘。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   教師在聘約有效期間內，非有正當事由，不得辭聘。"
  }
]
```

## U11-A39｜第 39 條

（刪除）

來源條目欄位（正規化資料）：
- id：article-39
- articleNumber：39
- displayNumber：第 39 條
- title：None
- structureId：chapter-5
- metadata：{"source": "全國法規資料庫 教育人員任用條例（PDF：教育人員任用條例.pdf）", "lastModified": "2014-01-22"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": null,
    "text": "（刪除）"
  }
]
```

## U11-A40｜第 40 條

1   學校校長、教師及運動教練之職務等級表，由教育部定之；學校職員之官等、職等及職務列等，適用公務人員任用法之規定。
2   本條例施行前遴用之職員適用之原有薪級表，得配合相當職務列等予以修正。

來源條目欄位（正規化資料）：
- id：article-40
- articleNumber：40
- displayNumber：第 40 條
- title：None
- structureId：chapter-6
- metadata：{"source": "全國法規資料庫 教育人員任用條例（PDF：教育人員任用條例.pdf）", "lastModified": "2014-01-22"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   學校校長、教師及運動教練之職務等級表，由教育部定之；學校職員之官等、職等及職務列等，適用公務人員任用法之規定。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   本條例施行前遴用之職員適用之原有薪級表，得配合相當職務列等予以修正。"
  }
]
```

## U11-A41｜第 41 條

私立學校校長、教師之任用資格及其審查程序，準用本條例之規定。但宗教研修學院校長，得以大學畢業，具有宗教研修教學經驗十年以上及宗教事業機構主管職務經驗六年以上者充任之。

來源條目欄位（正規化資料）：
- id：article-41
- articleNumber：41
- displayNumber：第 41 條
- title：None
- structureId：chapter-6
- metadata：{"source": "全國法規資料庫 教育人員任用條例（PDF：教育人員任用條例.pdf）", "lastModified": "2014-01-22"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": null,
    "text": "私立學校校長、教師之任用資格及其審查程序，準用本條例之規定。但宗教研修學院校長，得以大學畢業，具有宗教研修教學經驗十年以上及宗教事業機構主管職務經驗六年以上者充任之。"
  }
]
```

## U11-A41-1｜第 41-1 條

高級中等以上學校擔任軍訓護理課程之護理教師，其資格、遴選、介派（聘）、遷調辦法，由中央主管機關定之。

來源條目欄位（正規化資料）：
- id：article-41-1
- articleNumber：41-1
- displayNumber：第 41-1 條
- title：None
- structureId：chapter-6
- metadata：{"source": "全國法規資料庫 教育人員任用條例（PDF：教育人員任用條例.pdf）", "lastModified": "2014-01-22"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": null,
    "text": "高級中等以上學校擔任軍訓護理課程之護理教師，其資格、遴選、介派（聘）、遷調辦法，由中央主管機關定之。"
  }
]
```

## U11-A42｜第 42 條

本條例施行細則，由教育部定之。

來源條目欄位（正規化資料）：
- id：article-42
- articleNumber：42
- displayNumber：第 42 條
- title：None
- structureId：chapter-6
- metadata：{"source": "全國法規資料庫 教育人員任用條例（PDF：教育人員任用條例.pdf）", "lastModified": "2014-01-22"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": null,
    "text": "本條例施行細則，由教育部定之。"
  }
]
```

## U11-A43｜第 43 條

1   本條例自公布日施行。
2   本條例中華民國九十八年十月二十三日修正之條文，自九十八年十一月二十三日施行。

來源條目欄位（正規化資料）：
- id：article-43
- articleNumber：43
- displayNumber：第 43 條
- title：None
- structureId：chapter-6
- metadata：{"source": "全國法規資料庫 教育人員任用條例（PDF：教育人員任用條例.pdf）", "lastModified": "2014-01-22"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   本條例自公布日施行。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   本條例中華民國九十八年十月二十三日修正之條文，自九十八年十一月二十三日施行。"
  }
]
```

## 來源其他資料

- schemaVersion：1.3.0
- processing：{"normalizedBy": "ai", "processedAt": "2026-07-22T00:00:00Z", "sourceType": "document", "warnings": ["來源 PDF未載明主管機關，authority 依規範填「未提供」。", "來源 PDF未印出官方法規代碼，code 依規範填「UNKNOWN」。"]}