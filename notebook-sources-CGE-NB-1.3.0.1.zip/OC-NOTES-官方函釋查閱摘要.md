# OC-NOTES｜官方函釋查閱摘要

資料集：CGE-NB-1.3.0.1；編製日：2026-09-09。此日期不是法律查核日。

這7筆是查閱摘要，不能當作7份公文原件。

### OC2024-01｜来源卡（編製資料，非原函）

- record_id：OC2024-01
- source_id：OC2024-01
- source_path：sources/circulars/official-notes/OC2024-01.md
- source_year：2024
- publication_date：2024-05-21
- publication_date_raw：2024-05-21
- document_number：臺教學(三)字第1130037236號
- number_key：臺教學(三)字第1130037236號
- serial：1130037236
- subject_raw：〔索引摘要〕行為人現所屬學校派代表參與調查之定義
- source_line_start：1
- source_line_end：25
- text_sha256：847f895d47114c6e35eabc1e05ae189410ec095f0546a74d6e46d9bb596183e6
- content_kind：external_official_reading_note
- representation：external_reading_summary
- same_document_record_ids：["C2024-003"]
- issuer：教育部
- issuer_note：外部查閱已核對發文機關。
- current_effect_review：not_exhaustively_verified
- current_effect_note：收錄、查無停止適用紀錄及檢索排名，均不等於現行有效；須併讀已整理關係及適用時法。
- known_relation_ids：["CR-034"]
- quality_issue_ids：["QDUP-002"]
- official_urls：["https://www.cyvs.cy.edu.tw/ischool/public/resource_view/open.php?file=613b306645d5389cfb847254abd6c886.pdf"]
- effective_date：None
- effective_date_note：發文日期不自動充作施行或停止適用日期；另見逐項關係紀錄。
- topics：["會務與迴避", "身分與管轄", "年度業務與受教權", "調查與證據"]

前後函與同號關係：
- relation_id：CR-034
- from_number：臺教學(三)字第1140134739號
- from_record_id：C2026-001
- to_number：臺教學(三)字第1130037236號
- relation_type：supplements
- scope：調查小組組成恆定及議處權責異動、畢業升學例外
- effective_on：None
- effective_date_basis：不自發文日推定施行日期；按所述變更範圍及適用時點審查
- notes：
- review_basis：user_uploaded_transcription
- scope_review：對照來源文字所支持的關係，不代表歷年函示效力全面查核
- announced_on：2026-01-22
- to_record_ids：["OC2024-01", "C2024-003"]
- target_presence：indexed_primary_entry
- evidence：{"record_id": "C2026-001", "source_path": "sources/circulars/uploaded/2026(1).md", "line_start": 14, "line_end": 14, "exact_text": "二、查本部113年5月21日臺教學(三)字第1130037236號函（諒達）釋示「校園性別事件防治準則（以下簡稱防治準則）第12條第1項規定校園性別事件案之行為人現所屬學校派代表參與調查定義」在案；次查本部113 年10 月29 日臺教學( 三) 字第1132804741A號令（以下簡稱本部113年10月29日令）核釋防治準則第32條第3項規定，如有防治準則第12條第2項規定情形，由事件管轄學校完成調查屬實者，應將調查報告及處理建議移送行為人現所屬學校（即議處權責學校）作成終局處理結果時，應由議處權責學校（或機關）以書面通知申請人、被害人、檢舉人及行為人，向議處權責學校（或機關）提起申復及救濟。", "content_kind": "user_uploaded_transcription"}
- official_urls：[]

品質與同號提示：
- issue_id：QDUP-002
- kind：multiple_representations_of_same_document
- record_ids：["OC2024-01", "C2024-003"]
- same_normalized_text：False
- finding：同一主文號有多個來源位置；保留全部，不能算成不同函件。
- handling：精確文號檢索回傳全部條目；正式引用選定來源位置。

### 查閱摘要原文

# 臺教學(三)字第1130037236號｜官方查閱摘要

- 發文日期：2024-05-21
- 發文字號：臺教學(三)字第1130037236號
- 主旨：〔索引摘要〕行為人現所屬學校派代表參與調查之定義
- 發文機關：教育部
- 查閱日期：2026-09-06
- 資料性質：本次外部研究摘要，非使用者附件，非官方函令全文或逐字轉錄。
- 查閱範圍：原函2頁（教育部函之國立嘉義高商公開副本）；正文已閱，並檢視第2頁影像。
- 全年完整性：2024年選錄，未取得使用者2024年度檔，不代表全年函示全集。
- 原件收錄：否；網路工具可閱，執行環境下載失敗，未在本套件保存PDF或HTML原件。

## 原始來源

- https://www.cyvs.cy.edu.tw/ischool/public/resource_view/open.php?file=613b306645d5389cfb847254abd6c886.pdf

## 查閱摘要

依原函說明四，防治準則第12條第1項所稱行為人現所屬學校派代表參與調查，於成立調查小組的情況，是指該校代表應成為小組成員。說明五另處理未成立小組時的出席安排；不能把這段理解成教職員工案件也可不組小組。說明六分別處理被害人現所屬學校代表，以及性平法第33條第4項後段但書的例外。
承辦應核對派代表、成為小組成員、出席性平會三種身分，不只邀請列席即認為完成法定組成。並讀2024年6月3日函的全外聘資格說明。
本函沒有一般性免除迴避或免除專業資格、性別比例的意思。

## 使用限制

作為找到原文及辨識程序變更的入口。正式引用須開啟原始來源，引用原函說明段落及附件頁碼；不得把本摘要當逐字函文，也不得據摘要主旨創設義務。現行作業另查後續函令及有效法規。

### OC2024-02｜来源卡（編製資料，非原函）

- record_id：OC2024-02
- source_id：OC2024-02
- source_path：sources/circulars/official-notes/OC2024-02.md
- source_year：2024
- publication_date：2024-06-03
- publication_date_raw：2024-06-03
- document_number：臺教學(三)字第1132802434號
- number_key：臺教學(三)字第1132802434號
- serial：1132802434
- subject_raw：〔索引摘要〕調查小組成員應全部外聘之定義
- source_line_start：1
- source_line_end：25
- text_sha256：4fc3ee1aff7de5a6ef15b717c82b53bae37bac8de04c244c3f8f0ec1f25462ad
- content_kind：external_official_reading_note
- representation：external_reading_summary
- same_document_record_ids：["C2024-004"]
- issuer：教育部
- issuer_note：外部查閱已核對發文機關。
- current_effect_review：not_exhaustively_verified
- current_effect_note：收錄、查無停止適用紀錄及檢索排名，均不等於現行有效；須併讀已整理關係及適用時法。
- known_relation_ids：[]
- quality_issue_ids：["QDUP-003"]
- official_urls：["https://secret.ndhu.edu.tw/var/file/11/1011/img/2933/399172907.pdf"]
- effective_date：None
- effective_date_note：發文日期不自動充作施行或停止適用日期；另見逐項關係紀錄。
- topics：["會務與迴避", "調查與證據", "年度業務與受教權", "身分與管轄"]

前後函與同號關係：
本資料集未整理到關係；不證明現行有效。

品質與同號提示：
- issue_id：QDUP-003
- kind：multiple_representations_of_same_document
- record_ids：["OC2024-02", "C2024-004"]
- same_normalized_text：False
- finding：同一主文號有多個來源位置；保留全部，不能算成不同函件。
- handling：精確文號檢索回傳全部條目；正式引用選定來源位置。

### 查閱摘要原文

# 臺教學(三)字第1132802434號｜官方查閱摘要

- 發文日期：2024-06-03
- 發文字號：臺教學(三)字第1132802434號
- 主旨：〔索引摘要〕調查小組成員應全部外聘之定義
- 發文機關：教育部
- 查閱日期：2026-09-06
- 資料性質：本次外部研究摘要，非使用者附件，非官方函令全文或逐字轉錄。
- 查閱範圍：原函2頁（教育部函之國立東華大學公開副本）；正文與兩頁影像均已閱。
- 全年完整性：2024年選錄，未取得使用者2024年度檔，不代表全年函示全集。
- 原件收錄：否；網路工具可閱，執行環境下載失敗，未在本套件保存PDF或HTML原件。

## 原始來源

- https://secret.ndhu.edu.tw/var/file/11/1011/img/2933/399172907.pdf

## 查閱摘要

原函說明三至五解釋全部外聘，以事件管轄學校或機關以外人員組成為基礎。該校性平會本來的外聘委員，並不只因擔任性平會委員就失去外聘資格。被害人現所屬學校不等於事件管轄學校時，其代表可符合外聘資格。
行為人現所屬學校派代表擔任調查小組成員時，函文明定該代表亦應外聘，不得為行為人現所屬學校成員；該校性平會之外聘委員可擔任。不能只查是不是事件管轄學校的員工，就忽略與行為人現校的關係。
函文要求2024年3月8日相關規定施行後組成的小組符合全外聘規定。具體案件仍須併核對性平法第33條及其他迴避、資格要件。

## 使用限制

作為找到原文及辨識程序變更的入口。正式引用須開啟原始來源，引用原函說明段落及附件頁碼；不得把本摘要當逐字函文，也不得據摘要主旨創設義務。現行作業另查後續函令及有效法規。

### OC2024-03｜来源卡（編製資料，非原函）

- record_id：OC2024-03
- source_id：OC2024-03
- source_path：sources/circulars/official-notes/OC2024-03.md
- source_year：2024
- publication_date：2024-07-30
- publication_date_raw：2024-07-30
- document_number：臺教學(三)字第1132803568號
- number_key：臺教學(三)字第1132803568號
- serial：1132803568
- subject_raw：〔索引摘要〕調查處理經費支應及行政實務處理
- source_line_start：1
- source_line_end：27
- text_sha256：036069961fef1a1e31cb24ae9a31365e9db01e2206e0916796a96dd7a34656d4
- content_kind：external_official_reading_note
- representation：external_reading_summary
- same_document_record_ids：["C2024-006"]
- issuer：教育部
- issuer_note：外部查閱已核對發文機關。
- current_effect_review：not_exhaustively_verified
- current_effect_note：收錄、查無停止適用紀錄及檢索排名，均不等於現行有效；須併讀已整理關係及適用時法。
- known_relation_ids：["CR-013", "CR-022"]
- quality_issue_ids：["QDUP-004"]
- official_urls：["https://www.cyvs.cy.edu.tw/ischool/public/resource_view/open.php?file=0060c93e3ecebee5c21aea66c7be751c.pdf", "https://www.cyvs.cy.edu.tw/ischool/public/resource_view/open.php?file=f85f48e4d5fa4d5a4839cec4462350b0.pdf"]
- effective_date：None
- effective_date_note：發文日期不自動充作施行或停止適用日期；另見逐項關係紀錄。
- topics：["經費與行政支援", "年度業務與受教權", "教育處置與輔導", "會務與迴避", "法規沿革與適用", "調查與證據"]

前後函與同號關係：
- relation_id：CR-013
- from_number：臺教學(三)字第1132803568號
- to_number：臺教學(三)字第1080088013號
- relation_type：modifies_part
- scope：校園性別事件調查處理經費支應規定；1130723版附件
- effective_on：None
- effective_date_basis：未自發文日推定法定施行日；適用時點另核
- notes：本套件僅收官方查閱摘要及原件網址，使用時核對附件各財源適用差異。
- review_basis：external_official_text_read; local_note_only
- scope_review：來源文字可支持的關係；不是所有後續法規及函令的完整效力審查
- from_record_id：OC2024-03
- announced_on：2024-07-30
- to_record_ids：["C2019-005"]
- target_presence：indexed_primary_entry
- evidence：{"record_id": "OC2024-03", "source_path": "sources/circulars/official-notes/OC2024-03.md", "line_start": 20, "line_end": 20, "exact_text": "函文檢送2024年7月23日版經費及行政實務說明；附件第一點調整2019年6月21日臺教學(三)字第1080088013號函的支應規定。外聘專家調查會議出席費當時上限為每次2,500元；稿費記載每千字1,100至1,600元，並註明日後主計總處修正時依其規定。", "content_kind": "external_official_reading_note"}
- official_urls：["https://www.cyvs.cy.edu.tw/ischool/public/resource_view/open.php?file=0060c93e3ecebee5c21aea66c7be751c.pdf", "https://www.cyvs.cy.edu.tw/ischool/public/resource_view/open.php?file=f85f48e4d5fa4d5a4839cec4462350b0.pdf"]

- relation_id：CR-022
- from_number：臺教學(三)字第1132803568號
- from_record_id：C2024-006
- to_number：臺教學(三)字第1080088013號
- relation_type：modifies_part
- scope：調查費用與行政實務支應規定，不排除本文大專校院自籌收入另定支用之條件
- effective_on：None
- effective_date_basis：不自發文日推定施行日期；按所述變更範圍及適用時點審查
- notes：
- review_basis：user_uploaded_transcription
- scope_review：對照來源文字所支持的關係，不代表歷年函示效力全面查核
- announced_on：2024-07-30
- to_record_ids：["C2019-005"]
- target_presence：indexed_primary_entry
- evidence：{"record_id": "C2024-006", "source_path": "sources/circulars/uploaded/2024(1).md", "line_start": 121, "line_end": 121, "exact_text": "調整本部108 年6 月21 日以臺教學(三)字第1080088013 號函所列支應規定如下：（一） 調查小組調查費之支給：1. 外聘之專家學者：以調查會議支給出席費，每次會議以新臺幣2,500 元為上限。會議依調查對象不同以場次計，每場次2-3 小時為原則。", "content_kind": "user_uploaded_transcription"}
- official_urls：[]

品質與同號提示：
- issue_id：QDUP-004
- kind：multiple_representations_of_same_document
- record_ids：["OC2024-03", "C2024-006"]
- same_normalized_text：False
- finding：同一主文號有多個來源位置；保留全部，不能算成不同函件。
- handling：精確文號檢索回傳全部條目；正式引用選定來源位置。

### 查閱摘要原文

# 臺教學(三)字第1132803568號｜官方查閱摘要

- 發文日期：2024-07-30
- 發文字號：臺教學(三)字第1132803568號
- 主旨：〔索引摘要〕調查處理經費支應及行政實務處理
- 發文機關：教育部
- 查閱日期：2026-09-06
- 資料性質：本次外部研究摘要，非使用者附件，非官方函令全文或逐字轉錄。
- 查閱範圍：函1頁及1130723版附件3頁；附件3頁影像均已閱。
- 全年完整性：2024年選錄，未取得使用者2024年度檔，不代表全年函示全集。
- 原件收錄：否；網路工具可閱，執行環境下載失敗，未在本套件保存PDF或HTML原件。

## 原始來源

- https://www.cyvs.cy.edu.tw/ischool/public/resource_view/open.php?file=0060c93e3ecebee5c21aea66c7be751c.pdf
- https://www.cyvs.cy.edu.tw/ischool/public/resource_view/open.php?file=f85f48e4d5fa4d5a4839cec4462350b0.pdf

## 查閱摘要

函文檢送2024年7月23日版經費及行政實務說明；附件第一點調整2019年6月21日臺教學(三)字第1080088013號函的支應規定。外聘專家調查會議出席費當時上限為每次2,500元；稿費記載每千字1,100至1,600元，並註明日後主計總處修正時依其規定。
一般公務支給與大專校院自籌收入另訂支用規定須分開。附件第二點第五款另列國立大學校務基金與私立大學校內程序，不得截取第一點就斷言所有校內人員在任何財源下都不能支領。
附件第三點要求安排內外場行政人力、處理訪談紀錄聽打、公差假與代課，以及防治教育執行費用。紀錄與報到支援不等於授權承辦人訪查案情。
以上金額是所讀2024年資料，並未重新驗證為2026年現行核銷費率。

## 使用限制

作為找到原文及辨識程序變更的入口。正式引用須開啟原始來源，引用原函說明段落及附件頁碼；不得把本摘要當逐字函文，也不得據摘要主旨創設義務。現行作業另查後續函令及有效法規。

### OC2024-04｜来源卡（編製資料，非原函）

- record_id：OC2024-04
- source_id：OC2024-04
- source_path：sources/circulars/official-notes/OC2024-04.md
- source_year：2024
- publication_date：2024-10-29
- publication_date_raw：2024-10-29
- document_number：臺教學（三）字第1132804741A號令
- number_key：臺教學(三)字第1132804741A號
- serial：1132804741A
- subject_raw：〔索引摘要〕核釋校園性別事件防治準則第32條第3項
- source_line_start：1
- source_line_end：25
- text_sha256：38a6a63987270c25fba8a71882b74b8fe2d76cc79efc6a8eeff25f214a2d18e3
- content_kind：external_official_reading_note
- representation：external_reading_summary
- same_document_record_ids：["C2024-007"]
- issuer：教育部
- issuer_note：外部查閱已核對發文機關。
- current_effect_review：not_exhaustively_verified
- current_effect_note：收錄、查無停止適用紀錄及檢索排名，均不等於現行有效；須併讀已整理關係及適用時法。
- known_relation_ids：["CR-014", "CR-015", "CR-023", "CR-031", "CR-035", "CR-040"]
- quality_issue_ids：["QDUP-005"]
- official_urls：["https://edu.law.moe.gov.tw/LawContent.aspx?id=GL002312&kw="]
- effective_date：None
- effective_date_note：發文日期不自動充作施行或停止適用日期；另見逐項關係紀錄。
- topics：["人事與議處", "年度業務與受教權", "法規沿革與適用", "申復與救濟", "身分與管轄"]

前後函與同號關係：
- relation_id：CR-014
- from_number：臺教學（三）字第1132804741A號令
- to_number：臺訓(三)字第1010245259號
- relation_type：ceases_entire_letter
- scope：解釋令第二點明示該兩函自即日起停止適用
- effective_on：2024-10-29
- effective_date_basis：函令明示，含後函確認的較早日期
- notes：已於教育部主管法規共用系統核對解釋令全文。
- review_basis：external_official_text_read; local_note_only
- scope_review：來源文字可支持的關係；不是所有後續法規及函令的完整效力審查
- from_record_id：OC2024-04
- announced_on：2024-10-29
- to_record_ids：["C2012-043"]
- target_presence：indexed_primary_entry
- evidence：{"record_id": "OC2024-04", "source_path": "sources/circulars/official-notes/OC2024-04.md", "line_start": 20, "line_end": 20, "exact_text": "第二點載明本令自即日生效，並使2012年12月26日臺訓（三）字第1010245259號函及2013年8月20日臺教學（三）字第1020114961號函自即日起停止適用。", "content_kind": "external_official_reading_note"}
- official_urls：["https://edu.law.moe.gov.tw/LawContent.aspx?id=GL002312&kw="]

- relation_id：CR-015
- from_number：臺教學（三）字第1132804741A號令
- to_number：臺教學(三)字第1020114961號
- relation_type：ceases_entire_letter
- scope：解釋令第二點明示該兩函自即日起停止適用
- effective_on：2024-10-29
- effective_date_basis：函令明示，含後函確認的較早日期
- notes：已於教育部主管法規共用系統核對解釋令全文。
- review_basis：external_official_text_read; local_note_only
- scope_review：來源文字可支持的關係；不是所有後續法規及函令的完整效力審查
- from_record_id：OC2024-04
- announced_on：2024-10-29
- to_record_ids：["C2013-009"]
- target_presence：indexed_primary_entry
- evidence：{"record_id": "OC2024-04", "source_path": "sources/circulars/official-notes/OC2024-04.md", "line_start": 20, "line_end": 20, "exact_text": "第二點載明本令自即日生效，並使2012年12月26日臺訓（三）字第1010245259號函及2013年8月20日臺教學（三）字第1020114961號函自即日起停止適用。", "content_kind": "external_official_reading_note"}
- official_urls：["https://edu.law.moe.gov.tw/LawContent.aspx?id=GL002312&kw="]

- relation_id：CR-023
- from_number：臺教學(三)字第1132804741B號
- from_record_id：C2024-008
- to_number：臺教學(三)字第1132804741A號
- relation_type：forwards
- scope：同日解釋令函送及學生救濟例示；A號目錄摘要與B號全文分開
- effective_on：None
- effective_date_basis：不自發文日推定施行日期；按所述變更範圍及適用時點審查
- notes：
- review_basis：user_uploaded_transcription
- scope_review：對照來源文字所支持的關係，不代表歷年函示效力全面查核
- announced_on：2024-10-29
- to_record_ids：["OC2024-04", "C2024-007"]
- target_presence：indexed_primary_entry
- evidence：{"record_id": "C2024-008", "source_path": "sources/circulars/uploaded/2024(1).md", "line_start": 180, "line_end": 182, "exact_text": "- 發文日期：2024-10-29\n- 發文字號：臺教學(三)字第1132804741B號\n- 主旨：檢送「校園性別事件防治準則」（以下簡稱防治準則）第32條 第3項規定解釋令1份，請查照。", "content_kind": "user_uploaded_transcription"}
- official_urls：[]

- relation_id：CR-031
- from_number：臺教學(三)字第1140017674號
- from_record_id：C2025-003
- to_number：臺教學(三)字第1132804741A號
- relation_type：supplements
- scope：跨校調查與議處之通知救濟、回報資料銜接
- effective_on：None
- effective_date_basis：不自發文日推定施行日期；按所述變更範圍及適用時點審查
- notes：
- review_basis：user_uploaded_transcription
- scope_review：對照來源文字所支持的關係，不代表歷年函示效力全面查核
- announced_on：2025-03-04
- to_record_ids：["OC2024-04", "C2024-007"]
- target_presence：indexed_primary_entry
- evidence：{"record_id": "C2025-003", "source_path": "sources/circulars/uploaded/2025(1).md", "line_start": 269, "line_end": 271, "exact_text": "- 發文日期：2025-03-04\n- 發文字號：臺教學(三)字第1140017674號\n- 主旨：有關本部113 年10 月29 日臺教學（三）字第1132804741A號令核釋 「校園性別事件防治準則（以下簡稱防治準則）第32條第3 項 規定」及本部「校園性別事件回復填報及統計管理系統」陳報 作業事項，請依說明辦理，請查照。", "content_kind": "user_uploaded_transcription"}
- official_urls：[]

- relation_id：CR-035
- from_number：臺教學(三)字第1140134739號
- from_record_id：C2026-001
- to_number：臺教學(三)字第1132804741A號
- relation_type：supplements
- scope：調查小組組成恆定及議處權責異動、畢業升學例外
- effective_on：None
- effective_date_basis：不自發文日推定施行日期；按所述變更範圍及適用時點審查
- notes：
- review_basis：user_uploaded_transcription
- scope_review：對照來源文字所支持的關係，不代表歷年函示效力全面查核
- announced_on：2026-01-22
- to_record_ids：["OC2024-04", "C2024-007"]
- target_presence：indexed_primary_entry
- evidence：{"record_id": "C2026-001", "source_path": "sources/circulars/uploaded/2026(1).md", "line_start": 14, "line_end": 14, "exact_text": "二、查本部113年5月21日臺教學(三)字第1130037236號函（諒達）釋示「校園性別事件防治準則（以下簡稱防治準則）第12條第1項規定校園性別事件案之行為人現所屬學校派代表參與調查定義」在案；次查本部113 年10 月29 日臺教學( 三) 字第1132804741A號令（以下簡稱本部113年10月29日令）核釋防治準則第32條第3項規定，如有防治準則第12條第2項規定情形，由事件管轄學校完成調查屬實者，應將調查報告及處理建議移送行為人現所屬學校（即議處權責學校）作成終局處理結果時，應由議處權責學校（或機關）以書面通知申請人、被害人、檢舉人及行為人，向議處權責學校（或機關）提起申復及救濟。", "content_kind": "user_uploaded_transcription"}
- official_urls：[]

- relation_id：CR-040
- from_number：臺教學(三)字第1152801934號
- from_record_id：C2026-006
- to_number：臺教學(三)字第1132804741A號
- relation_type：supplements
- scope：同一教職員工多案之併案議處條件、理由與限縮報告提供
- effective_on：None
- effective_date_basis：不自發文日推定施行日期；按所述變更範圍及適用時點審查
- notes：
- review_basis：user_uploaded_transcription
- scope_review：對照來源文字所支持的關係，不代表歷年函示效力全面查核
- announced_on：2026-06-23
- to_record_ids：["OC2024-04", "C2024-007"]
- target_presence：indexed_primary_entry
- evidence：{"record_id": "C2026-006", "source_path": "sources/circulars/uploaded/2026(1).md", "line_start": 237, "line_end": 241, "exact_text": "說明：\n一、依115年2月9日本部第12屆性別平等教育委員會（以下簡稱性平會）校園性別事件防治組第1次會議決議辦理。\n二、性別平等教育法（以下簡稱性平法）第34條第4項規定：「調查發現同一行為人對不同被害人有發生類似校園性別事件時，得併案調查。」經併案調查時，得就事情情節綜合評價判斷予以議處，俾落實本部112年9月26日臺教學（三）字第1122803970A號函（諒達）示教職員工之性別事件情節輕重判斷基準。\n三、查校園性別事件防治準則（以下簡稱防治準則）第11條規定略以，校園性別事件之被害人、其法定代理人或實際照顧者（以下簡稱申請人）、檢舉人，向行為人於行為發生時所屬之學校（事件管轄學校）申請調查或檢舉，容有不同校園性別事件由不同事件管轄學校調查處理之情形，未得依性平法第34條第4項規定併案調查；次查本部113年10月29日臺教學（三）字第1132804741A號令（諒達）核釋防治準則第32條第3項規定，如有防治準則第12條第2項規定情形，由行為人現所屬學校予以終局議處。\n四、旨揭行為人所涉不同校園性別事件，應併案審議議處之程序如下：", "content_kind": "user_uploaded_transcription"}
- official_urls：[]

品質與同號提示：
- issue_id：CQNEW-010
- kind：catalog_summary_not_full_letter
- finding：本條目本身是官方目錄摘要／來源摘錄整理，不是公文全文。
- handling：保留查找入口；具體義務、例外、停止適用須另讀可支持的原函或另標外部查閱來源。
- verified_scope：已閱讀使用者原稿；未靜默修正或聲稱官方全文相同性
- record_ids：["C2024-007"]
- evidence：[{"record_id": "C2024-007", "source_path": "sources/circulars/uploaded/2024(1).md", "line_start": 170, "line_end": 170, "exact_text": "## 來源摘錄整理", "content_kind": "user_uploaded_transcription"}]

- issue_id：QDUP-005
- kind：multiple_representations_of_same_document
- record_ids：["OC2024-04", "C2024-007"]
- same_normalized_text：False
- finding：同一主文號有多個來源位置；保留全部，不能算成不同函件。
- handling：精確文號檢索回傳全部條目；正式引用選定來源位置。

### 查閱摘要原文

# 臺教學（三）字第1132804741A號令｜官方查閱摘要

- 發文日期：2024-10-29
- 發文字號：臺教學（三）字第1132804741A號令
- 主旨：〔索引摘要〕核釋校園性別事件防治準則第32條第3項
- 發文機關：教育部
- 查閱日期：2026-09-06
- 資料性質：本次外部研究摘要，非使用者附件，非官方函令全文或逐字轉錄。
- 查閱範圍：教育部主管法規共用系統之解釋令全文頁已閱；頁面所列學生例示附件未讀，不據此重建例示。
- 全年完整性：2024年選錄，未取得使用者2024年度檔，不代表全年函示全集。
- 原件收錄：否；網路工具可閱，執行環境下載失敗，未在本套件保存PDF或HTML原件。

## 原始來源

- https://edu.law.moe.gov.tw/LawContent.aspx?id=GL002312&kw=

## 查閱摘要

解釋令第一點區分事件管轄學校與議處權責學校是否相同。依防治準則第12條第2項，原校完成調查並移送行為人現所屬學校，由後者作成終局結果的情形，應由議處權責學校或機關書面通知，並以該議處權責學校或機關為申復及申訴救濟之對象。仍須另核對法定救濟種類、身分及向主管機關申復的特別規定。
第二點載明本令自即日生效，並使2012年12月26日臺訓（三）字第1010245259號函及2013年8月20日臺教學（三）字第1020114961號函自即日起停止適用。
這是明示停止適用關係，不是僅依新舊函日期推定。舊函留作歷史脈絡，不能從搜尋結果刪除，也不能直接作為現在的救濟教示。

## 使用限制

作為找到原文及辨識程序變更的入口。正式引用須開啟原始來源，引用原函說明段落及附件頁碼；不得把本摘要當逐字函文，也不得據摘要主旨創設義務。現行作業另查後續函令及有效法規。

### OC2024-05｜来源卡（編製資料，非原函）

- record_id：OC2024-05
- source_id：OC2024-05
- source_path：sources/circulars/official-notes/OC2024-05.md
- source_year：2024
- publication_date：2024-12-04
- publication_date_raw：2024-12-04
- document_number：臺教學(三)字第1132805502號
- number_key：臺教學(三)字第1132805502號
- serial：1132805502
- subject_raw：〔索引摘要〕主管機關申復流程圖修正及雙方申復時點不同之處理
- source_line_start：1
- source_line_end：26
- text_sha256：5ac2ce2bcb55ef7177719f1093d7015b508912b78ea39428bfb93086f64294c9
- content_kind：external_official_reading_note
- representation：external_reading_summary
- same_document_record_ids：["C2024-011"]
- issuer：教育部
- issuer_note：外部查閱已核對發文機關。
- current_effect_review：not_exhaustively_verified
- current_effect_note：收錄、查無停止適用紀錄及檢索排名，均不等於現行有效；須併讀已整理關係及適用時法。
- known_relation_ids：["CR-016", "CR-027"]
- quality_issue_ids：["QDUP-006"]
- official_urls：["https://www.cyvs.cy.edu.tw/ischool/public/resource_view/open.php?file=ab9ea83db007de4ecc8f8db4391f21a9.pdf", "https://www.cyvs.cy.edu.tw/ischool/public/resource_view/open.php?file=ce4ef9a5a1fc20e83292387327bf5034.pdf"]
- effective_date：None
- effective_date_note：發文日期不自動充作施行或停止適用日期；另見逐項關係紀錄。
- topics：["法規沿革與適用", "申復與救濟", "年度業務與受教權"]

前後函與同號關係：
- relation_id：CR-016
- from_number：臺教學(三)字第1132805502號
- to_number：臺教學（三）字第1130801903號
- relation_type：modifies_part
- scope：向主管機關申復審議流程圖；1131118修版
- effective_on：None
- effective_date_basis：未自發文日推定法定施行日；適用時點另核
- notes：前函及原版流程圖未收錄；不能宣稱已逐格比對新舊圖。
- review_basis：external_official_text_read; local_note_only
- scope_review：來源文字可支持的關係；不是所有後續法規及函令的完整效力審查
- from_record_id：OC2024-05
- announced_on：2024-12-04
- to_record_ids：[]
- target_presence：reference_only_no_primary_text
- evidence：{"record_id": "OC2024-05", "source_path": "sources/circulars/official-notes/OC2024-05.md", "line_start": 20, "line_end": 20, "exact_text": "本函修正2024年4月18日臺教學（三）字第1130801903號函所附主管機關申復流程圖。原函全文未收入本套件；只建立本函明示的修正關係，不反向重建原圖。", "content_kind": "external_official_reading_note"}
- official_urls：["https://www.cyvs.cy.edu.tw/ischool/public/resource_view/open.php?file=ab9ea83db007de4ecc8f8db4391f21a9.pdf", "https://www.cyvs.cy.edu.tw/ischool/public/resource_view/open.php?file=ce4ef9a5a1fc20e83292387327bf5034.pdf"]

- relation_id：CR-027
- from_number：臺教學(三)字第1132805502號
- from_record_id：C2024-011
- to_number：臺教學(三)字第1132801903號
- relation_type：modifies_part
- scope：申復有理由交回學校及40日流程；原稿疑有缺頁，不反向補為原文
- effective_on：None
- effective_date_basis：不自發文日推定施行日期；按所述變更範圍及適用時點審查
- notes：
- review_basis：user_uploaded_transcription
- scope_review：對照來源文字所支持的關係，不代表歷年函示效力全面查核
- announced_on：2024-12-04
- to_record_ids：["C2024-002"]
- target_presence：indexed_primary_entry
- evidence：{"record_id": "C2024-011", "source_path": "sources/circulars/uploaded/2024(1).md", "line_start": 285, "line_end": 286, "exact_text": "說明：一丶旨揭流程圖原係本部因應性平法第37條第1項但書規定，擬訂申復審議及審議結果處置流程，提供各地方政府及各級學校參考運用。後續審酌原列交回學校依法處理（重啟調查、重為決定）段恐未能符應性平法第37條第3項後段所定限學校於40 日內完成調查之規定，爰予修正經主管機關申復審議為有理由者，逕交回學校依法處理（如流程圖左下所列）。\n二、另針對校園性別事件雙方當事人提出申復之時點有落差時（例如接獲處理結果第1日、第30日方分別提出）之申復審議時程疑義，請依下列說明辨理：（一）雙方當事人（教職員工生／生）僅向學校提出申復，但提出申復時點落差過大，難以於30日之申復審議時程併案審議時，請學校分別審議。另審酌係對渠等所涉同一校園性別事件之處理結果提出申復，為避免對同一事件產生歧異之審議結果，爰建議由同一組申復審議小紐成員審議並分別回應申復人所提事由。", "content_kind": "user_uploaded_transcription"}
- official_urls：[]

品質與同號提示：
- issue_id：CQNEW-016
- kind：partial_transcription_possible
- finding：原稿說明二僅見（一），與先前官方查閱摘要涉及另一分流的內容不齊；另有主旨文號轉錄瑕疵。
- handling：原稿與OC2024-05並存，不把摘要補插成原稿的（二）；正式逐字引用應回查原件。
- verified_scope：已閱讀使用者原稿；未靜默修正或聲稱官方全文相同性
- record_ids：["C2024-011"]
- evidence：[{"record_id": "C2024-011", "source_path": "sources/circulars/uploaded/2024(1).md", "line_start": 279, "line_end": 281, "exact_text": "- 發文日期：2024-12-04\n- 發文字號：臺教學(三)字第1132805502號\n- 主旨：修正本部113年4月18日臺教學（三）字第113馗801903號函（諒 達）訂之「性平法第37條第1項但書規定向主管機關中復審議 流程圖」1份（如附件），並清依說明處理性別平等教育法 （以下簡稱性平法）第37條第1項但書所定申復案件，靖查照 並周知所屬。", "content_kind": "user_uploaded_transcription"}]

- issue_id：QDUP-006
- kind：multiple_representations_of_same_document
- record_ids：["OC2024-05", "C2024-011"]
- same_normalized_text：False
- finding：同一主文號有多個來源位置；保留全部，不能算成不同函件。
- handling：精確文號檢索回傳全部條目；正式引用選定來源位置。

### 查閱摘要原文

# 臺教學(三)字第1132805502號｜官方查閱摘要

- 發文日期：2024-12-04
- 發文字號：臺教學(三)字第1132805502號
- 主旨：〔索引摘要〕主管機關申復流程圖修正及雙方申復時點不同之處理
- 發文機關：教育部
- 查閱日期：2026-09-06
- 資料性質：本次外部研究摘要，非使用者附件，非官方函令全文或逐字轉錄。
- 查閱範圍：函2頁及1131118修流程圖1頁均已閱；函第2頁與流程圖以影像核對。
- 全年完整性：2024年選錄，未取得使用者2024年度檔，不代表全年函示全集。
- 原件收錄：否；網路工具可閱，執行環境下載失敗，未在本套件保存PDF或HTML原件。

## 原始來源

- https://www.cyvs.cy.edu.tw/ischool/public/resource_view/open.php?file=ab9ea83db007de4ecc8f8db4391f21a9.pdf
- https://www.cyvs.cy.edu.tw/ischool/public/resource_view/open.php?file=ce4ef9a5a1fc20e83292387327bf5034.pdf

## 查閱摘要

本函修正2024年4月18日臺教學（三）字第1130801903號函所附主管機關申復流程圖。原函全文未收入本套件；只建立本函明示的修正關係，不反向重建原圖。
雙方僅向學校申復，收件時點差距致不能在各自30日期間內併案審議時，函示分別審議，並建議由同一組成員處理且分別回應事由。行為人先向學校申復，而申請人或被害人向主管機關申復時，依函示辦理聯繫及移報併案，不等候後案以任意重算前案期限。
附件把有理由案件交回學校依法處理，並區分重新調查、重為決定及必要時主管機關改核等路徑；不得把所有分支都當成重啟調查。40日期間應連同法條、交回決定及分支讀取。

## 使用限制

作為找到原文及辨識程序變更的入口。正式引用須開啟原始來源，引用原函說明段落及附件頁碼；不得把本摘要當逐字函文，也不得據摘要主旨創設義務。現行作業另查後續函令及有效法規。

### OC2026-01｜来源卡（編製資料，非原函）

- record_id：OC2026-01
- source_id：OC2026-01
- source_path：sources/circulars/official-notes/OC2026-01.md
- source_year：2026
- publication_date：2026-07-31
- publication_date_raw：2026-07-31
- document_number：臺教學(三)字第1152803124號
- number_key：臺教學(三)字第1152803124號
- serial：1152803124
- subject_raw：簡化調查處理程序之函發與通報日期適用範圍
- source_line_start：1
- source_line_end：17
- text_sha256：8adc53bbf3301affe736f5bc84bcd47460d9c972295facf94a05dd13bda4fbf3
- content_kind：external_official_reading_note
- representation：external_reading_summary
- same_document_record_ids：[]
- issuer：教育部
- issuer_note：外部查閱已核對發文機關。
- current_effect_review：not_exhaustively_verified
- current_effect_note：收錄、查無停止適用紀錄及檢索排名，均不等於現行有效；須併讀已整理關係及適用時法。
- known_relation_ids：["CR-042"]
- quality_issue_ids：[]
- official_urls：["https://gender.usc.edu.tw/p/405-1057-37212,c972.php?Lang=zh-tw"]
- effective_date：None
- effective_date_note：發文日期不自動充作施行或停止適用日期；另見逐項關係紀錄。
- topics：["簡化調查處理程序", "通報與保護", "人事與議處", "收件與受理", "法規沿革與適用", "申復與救濟", "調查與證據"]

前後函與同號關係：
- relation_id：CR-042
- from_number：臺教學(三)字第1152803124號
- from_record_id：OC2026-01
- to_number：台訓(三)字第0990120627號
- relation_type：supplements
- scope：簡化調查處理程序與2010年不成立調查小組之歷史銜接
- effective_on：None
- effective_date_basis：不自發文日推定施行日期；按所述變更範圍及適用時點審查
- notes：
- review_basis：external_official_reading_note
- scope_review：對照來源文字所支持的關係，不代表歷年函示效力全面查核
- announced_on：2026-07-31
- to_record_ids：["C2010-010"]
- target_presence：indexed_primary_entry
- evidence：{"record_id": "OC2026-01", "source_path": "sources/circulars/official-notes/OC2026-01.md", "line_start": 15, "line_end": 15, "exact_text": "函文援引99年8月12日台訓(三)第0990120627號函的不成立小組處理方式；此為歷史銜接，不是宣告該舊函全文停止適用。主要程序為受理分流、雙方書面或言詞陳述答辯、性平會審議並提出報告；可委任人才庫資格人員一名撰寫初稿。議處、結果通知及救濟仍依性平法辦理；救濟後重新調查之指定情形應成立調查小組。", "content_kind": "external_official_reading_note"}
- official_urls：["https://gender.usc.edu.tw/p/405-1057-37212,c972.php?Lang=zh-tw"]

品質與同號提示：
本資料集未登記特定問題；不代表已逐字核原件。

### 查閱摘要原文

# OC2026-01｜官方來函查閱摘要

- 發文日期：2026-07-31
- 發文字號：臺教學(三)字第1152803124號
- 主旨：簡化調查處理程序之函發與通報日期適用範圍
- 查閱日期：2026-09-06
- 發文機關：教育部
- 刊載來源：實踐大學性別平等教育委員會網站（收文學校官方網頁）
- 原文網址：https://gender.usc.edu.tw/p/405-1057-37212,c972.php?Lang=zh-tw

本頁為學校官方網站刊載之教育部來函，查閱範圍包括主旨與說明一至五。這是查閱摘要，非官方函令全文；不改寫使用者提供的八頁附件。

主旨明定適用自115年8月1日起通報之事件。判斷日期為通報日期，不是行為發生日、申請日或開會日。函文另以學生行為人、案情明確及不成立調查小組為運用前提；教職員工行為人依法應成立調查小組，不適用。

函文援引99年8月12日台訓(三)第0990120627號函的不成立小組處理方式；此為歷史銜接，不是宣告該舊函全文停止適用。主要程序為受理分流、雙方書面或言詞陳述答辯、性平會審議並提出報告；可委任人才庫資格人員一名撰寫初稿。議處、結果通知及救濟仍依性平法辦理；救濟後重新調查之指定情形應成立調查小組。

附件逐項規範、流程圖及原範本以 SP2026-01（使用者提供PDF）為主；函發日與「通報日期」門檻由本查閱來源補足。未取得官方附件下載檔作二進位相同性比對，不宣稱使用者PDF與該站附件逐位元相同。

### OC2026-02｜来源卡（編製資料，非原函）

- record_id：OC2026-02
- source_id：OC2026-02
- source_path：sources/circulars/official-notes/OC2026-02.md
- source_year：2026
- publication_date：2026-08-24
- publication_date_raw：2026-08-24
- document_number：臺教學(三)字第1152803608號
- number_key：臺教學(三)字第1152803608號
- serial：1152803608
- subject_raw：教師解聘停聘報核時與最終結果之救濟教示
- source_line_start：1
- source_line_end：17
- text_sha256：1052cb3888e39abfa89a7e8c6e062cd764d69211a35a2acbb695f6bd8d4277d9
- content_kind：external_official_reading_note
- representation：external_reading_summary
- same_document_record_ids：[]
- issuer：教育部
- issuer_note：外部查閱已核對發文機關。
- current_effect_review：not_exhaustively_verified
- current_effect_note：收錄、查無停止適用紀錄及檢索排名，均不等於現行有效；須併讀已整理關係及適用時法。
- known_relation_ids：["CR-043"]
- quality_issue_ids：[]
- official_urls：["https://gender.usc.edu.tw/p/405-1057-37682,c972.php?Lang=zh-tw"]
- effective_date：None
- effective_date_note：發文日期不自動充作施行或停止適用日期；另見逐項關係紀錄。
- topics：["人事與議處", "申復與救濟", "身分與管轄"]

前後函與同號關係：
- relation_id：CR-043
- from_number：臺教學(三)字第1152803608號
- from_record_id：OC2026-02
- to_number：臺教學(三)字第1132804859號
- relation_type：reaffirms
- scope：教師解聘停聘報核時通知與雙方均未申復時最終通知再教示
- effective_on：None
- effective_date_basis：不自發文日推定施行日期；按所述變更範圍及適用時點審查
- notes：
- review_basis：external_official_reading_note
- scope_review：對照來源文字所支持的關係，不代表歷年函示效力全面查核
- announced_on：2026-08-24
- to_record_ids：["C2024-009"]
- target_presence：indexed_primary_entry
- evidence：{"record_id": "OC2026-02", "source_path": "sources/circulars/official-notes/OC2026-02.md", "line_start": 13, "line_end": 13, "exact_text": "本函重申113年11月4日臺教學（三）字第1132804859號函之救濟管轄與處理。教師解聘、停聘決議報請主管教育行政機關核准時，人事單位應同步以附理由書面通知當事人，教示通知次日起三十日內申復；申請人及被害人的通知得由性平會秘書單位另行辦理。", "content_kind": "external_official_reading_note"}
- official_urls：["https://gender.usc.edu.tw/p/405-1057-37682,c972.php?Lang=zh-tw"]

品質與同號提示：
本資料集未登記特定問題；不代表已逐字核原件。

### 查閱摘要原文

# OC2026-02｜官方來函查閱摘要

- 發文日期：2026-08-24
- 發文字號：臺教學(三)字第1152803608號
- 主旨：教師解聘停聘報核時與最終結果之救濟教示
- 查閱日期：2026-09-06
- 發文機關：教育部
- 刊載來源：實踐大學性別平等教育委員會網站（收文學校官方網頁）
- 原文網址：https://gender.usc.edu.tw/p/405-1057-37682,c972.php?Lang=zh-tw

本頁為學校官方網站刊載之教育部來函，查閱範圍為主旨及說明一至三。這是查閱摘要，非官方函令全文。

本函重申113年11月4日臺教學（三）字第1132804859號函之救濟管轄與處理。教師解聘、停聘決議報請主管教育行政機關核准時，人事單位應同步以附理由書面通知當事人，教示通知次日起三十日內申復；申請人及被害人的通知得由性平會秘書單位另行辦理。

前一申復時點通知後，雙方均未提出申復，於主管機關最終核准、學校通知最終處理結果時，仍應教示申復。條件不是「不論是否已申復一律再申復一次」，也不免除同一案件同一標的及重為決定的個別審查。

這是對既有教師報核流程之重申，不是為所有學生事件建立報核前救濟階段。
