# LAW-U18｜大學法

資料集：CGE-NB-1.3.0.1；編製日：2026-09-09。此日期不是法律查核日。

## 來源與版本

- source_id：U18
- filename：大學法.json
- path：sources/uploaded/大學法.json
- sha256：f079db7d44be395db93fb2fe5f6f54773e3b545bfdc16065f09bde3d97924967
- regulation_id：tw-university-act
- name：大學法
- version：{"id": "tw-university-act-20191211", "label": "修正日期：民國 108 年 12 月 11 日", "promulgationDate": "2019-12-11", "effectiveDate": "2019-12-13", "effectiveDateNote": "本版本施行條文明定自公布（發布）日施行，依中央法規標準法第13條，自公布（發布）之日起算至第三日起發生效力，故施行日為公布（發布）日之後二日。 另依第42條第2項，中華民國九十九年八月十九日修正之第25條，其施行日期由行政院定之。", "status": "effective"}
- article_count：44
- source_kind：user_uploaded_ai_normalized_json
- review_status：attachment_reference_not_full_current_audit
- review_notes：[]
- official_source_ids：[]
- normalization_warnings：["跨法規連結「授權訂定施行細則」之目標法規（大學法施行細則）未包含於本次來源，targetRegulationId 保留 null，待該法規匯入後再行連結。", "來源 PDF未印出官方法規代碼，code 依規範填「UNKNOWN」。", "以下法規經條文明文引用，但未包含於本次匯入批次，targetRegulationId 暫留 null，待該等法規匯入後可依名稱自動或人工連結：師資培育法。"]
- processed_at：2026-07-22T00:00:00Z
- authoritative_current_full_text：False

- id：tw-university-act
- code：UNKNOWN
- name：大學法
- shortName：大學法
- jurisdiction：TW
- authority：教育部
- aliases：[]
- version：{"id": "tw-university-act-20191211", "label": "修正日期：民國 108 年 12 月 11 日", "promulgationDate": "2019-12-11", "effectiveDate": "2019-12-13", "effectiveDateNote": "本版本施行條文明定自公布（發布）日施行，依中央法規標準法第13條，自公布（發布）之日起算至第三日起發生效力，故施行日為公布（發布）日之後二日。 另依第42條第2項，中華民國九十九年八月十九日修正之第25條，其施行日期由行政院定之。", "status": "effective"}
- structure：[{"id": "chapter-1", "type": "chapter", "label": "第 一 章 總則", "parentId": null, "sortOrder": 0}, {"id": "chapter-2", "type": "chapter", "label": "第 二 章 設立及類別", "parentId": null, "sortOrder": 1}, {"id": "chapter-3", "type": "chapter", "label": "第 三 章 組織及會議", "parentId": null, "sortOrder": 2}, {"id": "chapter-4", "type": "chapter", "label": "第 四 章 教師分級及聘用", "parentId": null, "sortOrder": 3}, {"id": "chapter-5", "type": "chapter", "label": "第 五 章 學生事務", "parentId": null, "sortOrder": 4}, {"id": "chapter-6", "type": "chapter", "label": "第 六 章 附則", "parentId": null, "sortOrder": 5}]
- legalConcepts：[{"id": "teacher-employment-framework", "name": "教師任用與聘任法律框架", "description": "彙整各級學校教師之資格、任用、聘任、解聘與不適任處理所涉之法規。", "aliases": ["教師任用"], "tags": ["教師", "任用", "聘任"], "role": "supporting", "sortOrder": 3}]
- crossRegulationLinks：[{"id": "link-tw-university-act-1", "conceptId": "teacher-employment-framework", "sourceArticleId": null, "label": "授權訂定施行細則", "relationType": "authorization", "conditionText": "本法施行細則，由教育部定之。", "targetRegulationId": "tw-university-act-enforcement-rules", "targetRegulationNames": ["大學法施行細則"], "targetArticleNumber": null, "triggerTerms": ["施行細則"], "linkMode": "manual", "sortOrder": 0}, {"conceptId": "teacher-employment-framework", "sourceArticleId": "article-19", "label": "引用教師法", "relationType": "application", "conditionText": "大學除依教師法規定外，得於學校章則中增列教師權利義務，並得基於學術研究發展需要，另定教師停聘或不續聘之規定，經校務會議審議通過後實施，並納入聘約。", "targetRegulationId": "tw-teachers-act", "targetRegulationNames": ["教師法"], "targetArticleNumber": null, "triggerTerms": ["大學除依"], "linkMode": "automatic", "id": "link-tw-university-act-cite-2", "sortOrder": 1}, {"conceptId": "teacher-employment-framework", "sourceArticleId": "article-37", "label": "引用教育人員任用條例", "relationType": "application", "conditionText": "教育人員任用條例第二十五條、第二十六條及第三十七條規定與本法相牴觸之部分，應不再適用。", "targetRegulationId": "tw-educational-personnel-employment-act", "targetRegulationNames": ["教育人員任用條例"], "targetArticleNumber": "25", "triggerTerms": [], "linkMode": "automatic", "id": "link-tw-university-act-cite-3", "sortOrder": 2}, {"conceptId": "teacher-employment-framework", "sourceArticleId": "article-40", "label": "引用師資培育法", "relationType": "exception", "conditionText": "1   師資培育之大學與私立大學之設立、組織及教育設施，除師資培育法、私立學校法另有規定者外，適用本法之規定。", "targetRegulationId": null, "targetRegulationNames": ["師資培育法"], "targetArticleNumber": null, "triggerTerms": ["除"], "linkMode": "automatic_or_manual", "id": "link-tw-university-act-cite-4", "sortOrder": 3}]
- definedTerms：[{"id": "tw-university-act-term-1", "name": "大學", "aliases": [], "definition": "依本法設立並授予學士以上學位之高等教育機構。", "definitionArticleId": "article-2", "definitionText": "本法所稱大學，指依本法設立並授予學士以上學位之高等教育機構。", "scope": "regulation", "targetRegulationNames": [], "sortOrder": 0}]

正規化概念、跨法連結與處理狀態不是獨立法源；下面逐條保留來源plainText，未以本次日期重寫。

## U18-A1｜第 1 條

1   大學以研究學術，培育人才，提升文化，服務社會，促進國家發展為宗旨。
2   大學應受學術自由之保障，並在法律規定範圍內，享有自治權。

來源條目欄位（正規化資料）：
- id：article-1
- articleNumber：1
- displayNumber：第 1 條
- title：None
- structureId：chapter-1
- metadata：{"source": "全國法規資料庫 大學法（PDF：大學法.pdf）", "lastModified": "2019-12-11"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   大學以研究學術，培育人才，提升文化，服務社會，促進國家發展為宗旨。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   大學應受學術自由之保障，並在法律規定範圍內，享有自治權。"
  }
]
```

## U18-A2｜第 2 條

本法所稱大學，指依本法設立並授予學士以上學位之高等教育機構。

來源條目欄位（正規化資料）：
- id：article-2
- articleNumber：2
- displayNumber：第 2 條
- title：None
- structureId：chapter-1
- metadata：{"source": "全國法規資料庫 大學法（PDF：大學法.pdf）", "lastModified": "2019-12-11"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": null,
    "text": "本法所稱大學，指依本法設立並授予學士以上學位之高等教育機構。"
  }
]
```

## U18-A3｜第 3 條

本法之主管機關為教育部。

來源條目欄位（正規化資料）：
- id：article-3
- articleNumber：3
- displayNumber：第 3 條
- title：None
- structureId：chapter-1
- metadata：{"source": "全國法規資料庫 大學法（PDF：大學法.pdf）", "lastModified": "2019-12-11"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": null,
    "text": "本法之主管機關為教育部。"
  }
]
```

## U18-A4｜第 4 條

1   大學分為國立、直轄市立、縣（市）立（以下簡稱公立）及私立。
2   國立大學及私立大學之設立、變更或停辦，由教育部依照教育政策，並審察各地實際情形核定或調整之；直轄市立、縣（市）立大學之設立、變更或停辦，由各級政府依序報經教育部核定或調整之。私立大學並應依私立學校法之規定辦理。
3   為均衡區域之專科學校教育，教育部得就未設有專科部之縣（市），核准大學附設專科部。
4   大學得設立分校、分部。
5   大學及其分校、分部、附設專科部設立標準、變更或停辦之要件、核准程序及其他應遵行事項之辦法，由教育部定之。

來源條目欄位（正規化資料）：
- id：article-4
- articleNumber：4
- displayNumber：第 4 條
- title：None
- structureId：chapter-2
- metadata：{"source": "全國法規資料庫 大學法（PDF：大學法.pdf）", "lastModified": "2019-12-11"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   大學分為國立、直轄市立、縣（市）立（以下簡稱公立）及私立。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   國立大學及私立大學之設立、變更或停辦，由教育部依照教育政策，並審察各地實際情形核定或調整之；直轄市立、縣（市）立大學之設立、變更或停辦，由各級政府依序報經教育部核定或調整之。私立大學並應依私立學校法之規定辦理。"
  },
  {
    "type": "paragraph",
    "number": "3",
    "text": "3   為均衡區域之專科學校教育，教育部得就未設有專科部之縣（市），核准大學附設專科部。"
  },
  {
    "type": "paragraph",
    "number": "4",
    "text": "4   大學得設立分校、分部。"
  },
  {
    "type": "paragraph",
    "number": "5",
    "text": "5   大學及其分校、分部、附設專科部設立標準、變更或停辦之要件、核准程序及其他應遵行事項之辦法，由教育部定之。"
  }
]
```

## U18-A5｜第 5 條

1   大學應定期對教學、研究、服務、輔導、校務行政及學生參與等事項，進行自我評鑑；其評鑑規定，由各大學定之。
2   教育部為促進各大學之發展，應組成評鑑委員會或委託學術團體或專業評鑑機構，定期辦理大學評鑑，並公告其結果，作為學校調整發展之參考；其評鑑應符合多元、專業原則，相關評鑑辦法由教育部定之。

來源條目欄位（正規化資料）：
- id：article-5
- articleNumber：5
- displayNumber：第 5 條
- title：None
- structureId：chapter-2
- metadata：{"source": "全國法規資料庫 大學法（PDF：大學法.pdf）", "lastModified": "2019-12-11"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   大學應定期對教學、研究、服務、輔導、校務行政及學生參與等事項，進行自我評鑑；其評鑑規定，由各大學定之。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   教育部為促進各大學之發展，應組成評鑑委員會或委託學術團體或專業評鑑機構，定期辦理大學評鑑，並公告其結果，作為學校調整發展之參考；其評鑑應符合多元、專業原則，相關評鑑辦法由教育部定之。"
  }
]
```

## U18-A6｜第 6 條

1   大學得跨校組成大學系統或成立研究中心。
2   前項大學系統之組織及運作等事項之辦法，由教育部定之。
3   大學跨校研究中心之組織及運作方式等事項之規定，由大學共同訂定，報教育部備查。

來源條目欄位（正規化資料）：
- id：article-6
- articleNumber：6
- displayNumber：第 6 條
- title：None
- structureId：chapter-2
- metadata：{"source": "全國法規資料庫 大學法（PDF：大學法.pdf）", "lastModified": "2019-12-11"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   大學得跨校組成大學系統或成立研究中心。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   前項大學系統之組織及運作等事項之辦法，由教育部定之。"
  },
  {
    "type": "paragraph",
    "number": "3",
    "text": "3   大學跨校研究中心之組織及運作方式等事項之規定，由大學共同訂定，報教育部備查。"
  }
]
```

## U18-A7｜第 7 條

1   大學得擬訂合併計畫，國立大學經校務會議同意，直轄市立、縣（市）立大學經所屬地方政府同意，私立大學經董事會同意，報教育部核定後執行。
2   教育部得衡酌高等教育整體發展、教育資源分布、學校地緣位置等條件，並輔以經費補助及行政協助方式，擬訂國立大學合併計畫報行政院核定後，由各該國立大學執行。
3   前項合併之條件、程序、經費補助與行政協助方式、合併計畫內容、合併國立大學之權利與義務及其他相關事項之辦法，由教育部定之。

來源條目欄位（正規化資料）：
- id：article-7
- articleNumber：7
- displayNumber：第 7 條
- title：None
- structureId：chapter-2
- metadata：{"source": "全國法規資料庫 大學法（PDF：大學法.pdf）", "lastModified": "2019-12-11"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   大學得擬訂合併計畫，國立大學經校務會議同意，直轄市立、縣（市）立大學經所屬地方政府同意，私立大學經董事會同意，報教育部核定後執行。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   教育部得衡酌高等教育整體發展、教育資源分布、學校地緣位置等條件，並輔以經費補助及行政協助方式，擬訂國立大學合併計畫報行政院核定後，由各該國立大學執行。"
  },
  {
    "type": "paragraph",
    "number": "3",
    "text": "3   前項合併之條件、程序、經費補助與行政協助方式、合併計畫內容、合併國立大學之權利與義務及其他相關事項之辦法，由教育部定之。"
  }
]
```

## U18-A8｜第 8 條

1   大學置校長一人，綜理校務，負校務發展之責，對外代表大學；並得置副校長，襄助校長推動校務，由校長聘任之，其人數、聘期及資格，由各大學組織規程定之。
2   校長之資格，依有關法律之規定，並得由外國人擔任之，不受國籍法、私立學校法及就業服務法有關國籍及就業規定之限制。

來源條目欄位（正規化資料）：
- id：article-8
- articleNumber：8
- displayNumber：第 8 條
- title：None
- structureId：chapter-3
- metadata：{"source": "全國法規資料庫 大學法（PDF：大學法.pdf）", "lastModified": "2019-12-11"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   大學置校長一人，綜理校務，負校務發展之責，對外代表大學；並得置副校長，襄助校長推動校務，由校長聘任之，其人數、聘期及資格，由各大學組織規程定之。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   校長之資格，依有關法律之規定，並得由外國人擔任之，不受國籍法、私立學校法及就業服務法有關國籍及就業規定之限制。"
  }
]
```

## U18-A9｜第 9 條

1   新任公立大學校長之產生，應於現任校長任期屆滿十個月前或因故出缺後二個月內，由學校組成校長遴選委員會，經公開徵求程序遴選出校長後，由教育部或各該所屬地方政府聘任之。
2   前項委員會各類成員之比例與產生方式如下：
一、學校校務會議推選之學校代表占全體委員總額五分之二。
二、學校推薦校友代表及社會公正人士占全體委員總額五分之二。
三、其餘委員由教育部或各該所屬地方政府遴派之代表擔任之。
3   公立大學校長遴選委員會之組織、運作及其他應遵行事項之辦法，國立者，由教育部定之；直轄市立、縣（市）立者，由各該所屬地方政府定之。私立大學校長由董事會組織校長遴選委員會遴選，經董事會圈選，報請教育部核准聘任之。
4   前項校長遴選委員會之組成，任一性別委員應占委員總數三分之一以上。
5   公立大學校長任期四年，期滿得續聘；其續聘之程序、次數及任期未屆滿前之去職方式，由大學組織規程定之；私立大學校長之任期及續聘，由大學組織規程定之。
6   教育部及各該所屬地方政府應於校長聘期屆滿一年前進行評鑑，作為大學決定是否續聘之參考。
7   公立大學校長於教育部或各該所屬地方政府進行前項續聘評鑑程序時表達無續任意願，或參加續聘未獲通過者，不得參加原學校新任校長遴選。

來源條目欄位（正規化資料）：
- id：article-9
- articleNumber：9
- displayNumber：第 9 條
- title：None
- structureId：chapter-3
- metadata：{"source": "全國法規資料庫 大學法（PDF：大學法.pdf）", "lastModified": "2019-12-11"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   新任公立大學校長之產生，應於現任校長任期屆滿十個月前或因故出缺後二個月內，由學校組成校長遴選委員會，經公開徵求程序遴選出校長後，由教育部或各該所屬地方政府聘任之。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   前項委員會各類成員之比例與產生方式如下："
  },
  {
    "type": "item",
    "number": "一",
    "text": "一、學校校務會議推選之學校代表占全體委員總額五分之二。"
  },
  {
    "type": "item",
    "number": "二",
    "text": "二、學校推薦校友代表及社會公正人士占全體委員總額五分之二。"
  },
  {
    "type": "item",
    "number": "三",
    "text": "三、其餘委員由教育部或各該所屬地方政府遴派之代表擔任之。"
  },
  {
    "type": "paragraph",
    "number": "3",
    "text": "3   公立大學校長遴選委員會之組織、運作及其他應遵行事項之辦法，國立者，由教育部定之；直轄市立、縣（市）立者，由各該所屬地方政府定之。私立大學校長由董事會組織校長遴選委員會遴選，經董事會圈選，報請教育部核准聘任之。"
  },
  {
    "type": "paragraph",
    "number": "4",
    "text": "4   前項校長遴選委員會之組成，任一性別委員應占委員總數三分之一以上。"
  },
  {
    "type": "paragraph",
    "number": "5",
    "text": "5   公立大學校長任期四年，期滿得續聘；其續聘之程序、次數及任期未屆滿前之去職方式，由大學組織規程定之；私立大學校長之任期及續聘，由大學組織規程定之。"
  },
  {
    "type": "paragraph",
    "number": "6",
    "text": "6   教育部及各該所屬地方政府應於校長聘期屆滿一年前進行評鑑，作為大學決定是否續聘之參考。"
  },
  {
    "type": "paragraph",
    "number": "7",
    "text": "7   公立大學校長於教育部或各該所屬地方政府進行前項續聘評鑑程序時表達無續任意願，或參加續聘未獲通過者，不得參加原學校新任校長遴選。"
  }
]
```

## U18-A10｜第 10 條

1   新設立之大學校長，國立者，由教育部組織遴選小組直接選聘；其餘公立者，由該主管政府遴選二人至三人層報教育部組織遴選小組擇聘之。私立者，由董事會遴選報請教育部核准聘任之。
2   前項遴選小組之組成，任一性別委員應占委員總數三分之一以上。

來源條目欄位（正規化資料）：
- id：article-10
- articleNumber：10
- displayNumber：第 10 條
- title：None
- structureId：chapter-3
- metadata：{"source": "全國法規資料庫 大學法（PDF：大學法.pdf）", "lastModified": "2019-12-11"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   新設立之大學校長，國立者，由教育部組織遴選小組直接選聘；其餘公立者，由該主管政府遴選二人至三人層報教育部組織遴選小組擇聘之。私立者，由董事會遴選報請教育部核准聘任之。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   前項遴選小組之組成，任一性別委員應占委員總數三分之一以上。"
  }
]
```

## U18-A11｜第 11 條

1   大學下設學院或單獨設研究所，學院下得設學系或研究所。
2   大學得設跨系、所、院之學分學程或學位學程。

來源條目欄位（正規化資料）：
- id：article-11
- articleNumber：11
- displayNumber：第 11 條
- title：None
- structureId：chapter-3
- metadata：{"source": "全國法規資料庫 大學法（PDF：大學法.pdf）", "lastModified": "2019-12-11"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   大學下設學院或單獨設研究所，學院下得設學系或研究所。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   大學得設跨系、所、院之學分學程或學位學程。"
  }
]
```

## U18-A12｜第 12 條

大學之學生人數規模應與大學之資源條件相符，其標準由教育部定之；並得作為各大學規劃增設及調整院、系、所、學程與招生名額之審酌依據。

來源條目欄位（正規化資料）：
- id：article-12
- articleNumber：12
- displayNumber：第 12 條
- title：None
- structureId：chapter-3
- metadata：{"source": "全國法規資料庫 大學法（PDF：大學法.pdf）", "lastModified": "2019-12-11"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": null,
    "text": "大學之學生人數規模應與大學之資源條件相符，其標準由教育部定之；並得作為各大學規劃增設及調整院、系、所、學程與招生名額之審酌依據。"
  }
]
```

## U18-A13｜第 13 條

1   大學各學院置院長一人，綜理院務；各學系置主任一人，單獨設立之研究所置所長一人，辦理系、所務。大學並得置學位學程主任，辦理學程事務。
2   院長、系主任、所長及學位學程主任等學術主管，採任期制，其產生方式如下：
一、院長，依該校組織規程規定之程序，就教授中選出，報請校長聘請兼任之。
二、系主任、所長及學位學程主任，依該校組織規程規定之程序，就副教授以上之教師中選出，報請校長聘請兼任之。但藝術類與技術類之系、所及學位學程之主任、所長，得聘請副教授級以上之專業技術人員兼任之。
3   大學為因應校務發展之需要，達一定規模、學務繁重之學院、系、所及學程，得置副主管，以輔佐主管推動學務。
4   院長、系主任、所長、學位學程主任與副主管之任期、續聘、解聘之程序及其他應遵行事項，於大學組織規程定之。
5   第二項之學術主管職務，得由外國籍教師兼任。

來源條目欄位（正規化資料）：
- id：article-13
- articleNumber：13
- displayNumber：第 13 條
- title：None
- structureId：chapter-3
- metadata：{"source": "全國法規資料庫 大學法（PDF：大學法.pdf）", "lastModified": "2019-12-11"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   大學各學院置院長一人，綜理院務；各學系置主任一人，單獨設立之研究所置所長一人，辦理系、所務。大學並得置學位學程主任，辦理學程事務。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   院長、系主任、所長及學位學程主任等學術主管，採任期制，其產生方式如下："
  },
  {
    "type": "item",
    "number": "一",
    "text": "一、院長，依該校組織規程規定之程序，就教授中選出，報請校長聘請兼任之。"
  },
  {
    "type": "item",
    "number": "二",
    "text": "二、系主任、所長及學位學程主任，依該校組織規程規定之程序，就副教授以上之教師中選出，報請校長聘請兼任之。但藝術類與技術類之系、所及學位學程之主任、所長，得聘請副教授級以上之專業技術人員兼任之。"
  },
  {
    "type": "paragraph",
    "number": "3",
    "text": "3   大學為因應校務發展之需要，達一定規模、學務繁重之學院、系、所及學程，得置副主管，以輔佐主管推動學務。"
  },
  {
    "type": "paragraph",
    "number": "4",
    "text": "4   院長、系主任、所長、學位學程主任與副主管之任期、續聘、解聘之程序及其他應遵行事項，於大學組織規程定之。"
  },
  {
    "type": "paragraph",
    "number": "5",
    "text": "5   第二項之學術主管職務，得由外國籍教師兼任。"
  }
]
```

## U18-A14｜第 14 條

1   大學為達成第一條所定之目的，得設各種行政單位或召開各種會議；行政單位之名稱、會議之任務、職掌、分工、行政主管之資格及其他應遵行事項，於大學組織規程定之。
2   國立大學各級行政主管人員，得遴聘教學或研究人員兼任，或由職員擔任，並於各校組織規程定之。
3   大學為因應校務發展之需要，達一定規模、業務繁重之單位，得置副主管，遴聘教學或研究人員兼任，或由職員擔任，以輔佐主管推動業務；其資格及其他應遵行事項，由大學組織規程定之。
4   國立大學職員之任用，適用公務人員、教育人員相關法律之規定；人事、會計人員之任用，並應依人事、會計有關法令之規定。
5   國立大學非主管職務之職員，得以契約進用，不受前項規定之限制，其權利義務於契約明定。

來源條目欄位（正規化資料）：
- id：article-14
- articleNumber：14
- displayNumber：第 14 條
- title：None
- structureId：chapter-3
- metadata：{"source": "全國法規資料庫 大學法（PDF：大學法.pdf）", "lastModified": "2019-12-11"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   大學為達成第一條所定之目的，得設各種行政單位或召開各種會議；行政單位之名稱、會議之任務、職掌、分工、行政主管之資格及其他應遵行事項，於大學組織規程定之。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   國立大學各級行政主管人員，得遴聘教學或研究人員兼任，或由職員擔任，並於各校組織規程定之。"
  },
  {
    "type": "paragraph",
    "number": "3",
    "text": "3   大學為因應校務發展之需要，達一定規模、業務繁重之單位，得置副主管，遴聘教學或研究人員兼任，或由職員擔任，以輔佐主管推動業務；其資格及其他應遵行事項，由大學組織規程定之。"
  },
  {
    "type": "paragraph",
    "number": "4",
    "text": "4   國立大學職員之任用，適用公務人員、教育人員相關法律之規定；人事、會計人員之任用，並應依人事、會計有關法令之規定。"
  },
  {
    "type": "paragraph",
    "number": "5",
    "text": "5   國立大學非主管職務之職員，得以契約進用，不受前項規定之限制，其權利義務於契約明定。"
  }
]
```

## U18-A15｜第 15 條

1   大學設校務會議，議決校務重大事項，以校長、副校長、教師代表、學術與行政主管、研究人員代表、職員代表、學生代表及其他有關人員代表組織之。
2   前項人員，除校長及副校長外，其人數及產生方式如下：
一、教師代表應經選舉產生，人數不得少於全體會議人數二分之一；教師代表中具備教授或副教授資格者，以不少於教師代表人數三分之二為原則。
二、學生代表應經選舉產生，人數不得少於全體會議人數十分之一。
三、其餘出、列席人員之產生方式及比例，於各大學組織規程定之。
3   依前項第一款及第二款規定計算，遇有小數點時，採無條件進位法，取整數計算。
4   校務會議由校長召開，每學期至少召開一次；經校務會議應出席人數五分之一以上請求召開臨時校務會議時，校長應於十五日內召開之。
5   校務會議必要時，得設各種委員會或專案小組，處理校務會議交議事項；其名稱、任務及組成方式，於各大學組織規程定之。

來源條目欄位（正規化資料）：
- id：article-15
- articleNumber：15
- displayNumber：第 15 條
- title：None
- structureId：chapter-3
- metadata：{"source": "全國法規資料庫 大學法（PDF：大學法.pdf）", "lastModified": "2019-12-11"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   大學設校務會議，議決校務重大事項，以校長、副校長、教師代表、學術與行政主管、研究人員代表、職員代表、學生代表及其他有關人員代表組織之。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   前項人員，除校長及副校長外，其人數及產生方式如下："
  },
  {
    "type": "item",
    "number": "一",
    "text": "一、教師代表應經選舉產生，人數不得少於全體會議人數二分之一；教師代表中具備教授或副教授資格者，以不少於教師代表人數三分之二為原則。"
  },
  {
    "type": "item",
    "number": "二",
    "text": "二、學生代表應經選舉產生，人數不得少於全體會議人數十分之一。"
  },
  {
    "type": "item",
    "number": "三",
    "text": "三、其餘出、列席人員之產生方式及比例，於各大學組織規程定之。"
  },
  {
    "type": "paragraph",
    "number": "3",
    "text": "3   依前項第一款及第二款規定計算，遇有小數點時，採無條件進位法，取整數計算。"
  },
  {
    "type": "paragraph",
    "number": "4",
    "text": "4   校務會議由校長召開，每學期至少召開一次；經校務會議應出席人數五分之一以上請求召開臨時校務會議時，校長應於十五日內召開之。"
  },
  {
    "type": "paragraph",
    "number": "5",
    "text": "5   校務會議必要時，得設各種委員會或專案小組，處理校務會議交議事項；其名稱、任務及組成方式，於各大學組織規程定之。"
  }
]
```

## U18-A16｜第 16 條

校務會議審議下列事項：
一、校務發展計畫及預算。
二、組織規程及各種重要章則。
三、學院、學系、研究所及附設機構之設立、變更與停辦。
四、教務、學生事務、總務、研究及其他校內重要事項。
五、有關教學評鑑辦法之研議。
六、校務會議所設委員會或專案小組決議事項。
七、會議提案及校長提議事項。

來源條目欄位（正規化資料）：
- id：article-16
- articleNumber：16
- displayNumber：第 16 條
- title：None
- structureId：chapter-3
- metadata：{"source": "全國法規資料庫 大學法（PDF：大學法.pdf）", "lastModified": "2019-12-11"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": null,
    "text": "校務會議審議下列事項："
  },
  {
    "type": "item",
    "number": "一",
    "text": "一、校務發展計畫及預算。"
  },
  {
    "type": "item",
    "number": "二",
    "text": "二、組織規程及各種重要章則。"
  },
  {
    "type": "item",
    "number": "三",
    "text": "三、學院、學系、研究所及附設機構之設立、變更與停辦。"
  },
  {
    "type": "item",
    "number": "四",
    "text": "四、教務、學生事務、總務、研究及其他校內重要事項。"
  },
  {
    "type": "item",
    "number": "五",
    "text": "五、有關教學評鑑辦法之研議。"
  },
  {
    "type": "item",
    "number": "六",
    "text": "六、校務會議所設委員會或專案小組決議事項。"
  },
  {
    "type": "item",
    "number": "七",
    "text": "七、會議提案及校長提議事項。"
  }
]
```

## U18-A17｜第 17 條

1   大學教師分教授、副教授、助理教授、講師，從事授課、研究及輔導。
2   大學得設講座，由教授主持。
3   大學為教學及研究工作，得置助教協助之。
4   大學得延聘研究人員從事研究及專業技術人員擔任教學工作；其分級、資格、聘任、解聘、停聘、不續聘、申訴、待遇、福利、進修、退休、撫卹、資遣、年資晉薪及其他權益事項之辦法，由教育部定之。

來源條目欄位（正規化資料）：
- id：article-17
- articleNumber：17
- displayNumber：第 17 條
- title：None
- structureId：chapter-4
- metadata：{"source": "全國法規資料庫 大學法（PDF：大學法.pdf）", "lastModified": "2019-12-11"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   大學教師分教授、副教授、助理教授、講師，從事授課、研究及輔導。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   大學得設講座，由教授主持。"
  },
  {
    "type": "paragraph",
    "number": "3",
    "text": "3   大學為教學及研究工作，得置助教協助之。"
  },
  {
    "type": "paragraph",
    "number": "4",
    "text": "4   大學得延聘研究人員從事研究及專業技術人員擔任教學工作；其分級、資格、聘任、解聘、停聘、不續聘、申訴、待遇、福利、進修、退休、撫卹、資遣、年資晉薪及其他權益事項之辦法，由教育部定之。"
  }
]
```

## U18-A18｜第 18 條

大學教師之聘任，分為初聘、續聘及長期聘任三種；其聘任應本公平、公正、公開之原則辦理。大學教師之初聘，並應於傳播媒體或學術刊物公告徵聘資訊。教師之聘任資格及程序，依有關法律之規定。

來源條目欄位（正規化資料）：
- id：article-18
- articleNumber：18
- displayNumber：第 18 條
- title：None
- structureId：chapter-4
- metadata：{"source": "全國法規資料庫 大學法（PDF：大學法.pdf）", "lastModified": "2019-12-11"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": null,
    "text": "大學教師之聘任，分為初聘、續聘及長期聘任三種；其聘任應本公平、公正、公開之原則辦理。大學教師之初聘，並應於傳播媒體或學術刊物公告徵聘資訊。教師之聘任資格及程序，依有關法律之規定。"
  }
]
```

## U18-A19｜第 19 條

大學除依教師法規定外，得於學校章則中增列教師權利義務，並得基於學術研究發展需要，另定教師停聘或不續聘之規定，經校務會議審議通過後實施，並納入聘約。

來源條目欄位（正規化資料）：
- id：article-19
- articleNumber：19
- displayNumber：第 19 條
- title：None
- structureId：chapter-4
- metadata：{"source": "全國法規資料庫 大學法（PDF：大學法.pdf）", "lastModified": "2019-12-11"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": null,
    "text": "大學除依教師法規定外，得於學校章則中增列教師權利義務，並得基於學術研究發展需要，另定教師停聘或不續聘之規定，經校務會議審議通過後實施，並納入聘約。"
  }
]
```

## U18-A20｜第 20 條

1   大學教師之聘任、升等、停聘、解聘、不續聘及資遣原因之認定等事項，應經教師評審委員會審議。
2   學校教師評審委員會之分級、組成方式及運作規定，經校務會議審議通過後實施。

來源條目欄位（正規化資料）：
- id：article-20
- articleNumber：20
- displayNumber：第 20 條
- title：None
- structureId：chapter-4
- metadata：{"source": "全國法規資料庫 大學法（PDF：大學法.pdf）", "lastModified": "2019-12-11"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   大學教師之聘任、升等、停聘、解聘、不續聘及資遣原因之認定等事項，應經教師評審委員會審議。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   學校教師評審委員會之分級、組成方式及運作規定，經校務會議審議通過後實施。"
  }
]
```

## U18-A21｜第 21 條

1   大學應建立教師評鑑制度，對於教師之教學、研究、輔導及服務成效進行評鑑，作為教師升等、續聘、長期聘任、停聘、不續聘及獎勵之重要參考。
2   前項評鑑方法、程序及具體措施等規定，經校務會議審議通過後實施。

來源條目欄位（正規化資料）：
- id：article-21
- articleNumber：21
- displayNumber：第 21 條
- title：None
- structureId：chapter-4
- metadata：{"source": "全國法規資料庫 大學法（PDF：大學法.pdf）", "lastModified": "2019-12-11"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   大學應建立教師評鑑制度，對於教師之教學、研究、輔導及服務成效進行評鑑，作為教師升等、續聘、長期聘任、停聘、不續聘及獎勵之重要參考。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   前項評鑑方法、程序及具體措施等規定，經校務會議審議通過後實施。"
  }
]
```

## U18-A22｜第 22 條

1   大學設教師申訴評議委員會，評議有關教師解聘，停聘及其他決定不服之申訴；其組成方式及運作等規定，經校務會議審議通過後實施。
2   申訴評議委員會之裁決，不影響當事人提起司法爭訟之權利。

來源條目欄位（正規化資料）：
- id：article-22
- articleNumber：22
- displayNumber：第 22 條
- title：None
- structureId：chapter-4
- metadata：{"source": "全國法規資料庫 大學法（PDF：大學法.pdf）", "lastModified": "2019-12-11"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   大學設教師申訴評議委員會，評議有關教師解聘，停聘及其他決定不服之申訴；其組成方式及運作等規定，經校務會議審議通過後實施。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   申訴評議委員會之裁決，不影響當事人提起司法爭訟之權利。"
  }
]
```

## U18-A23｜第 23 條

1   曾在公立或已立案之私立高級中等學校或同等學校畢業，或具有同等學力，得入學修讀學士學位。
2   取得學士學位，或具有同等學力，得入學修讀碩士學位。
3   取得碩士學位，或具有同等學力，得入學修讀博士學位。但修讀學士學位之應屆畢業生成績優異者或修讀碩士學位研究生成績優異者，得申請逕修讀博士學位。
4   前三項同等學力之認定標準及前項修讀學士學位應屆畢業生、修讀碩士學位研究生逕修讀博士學位辦法，由教育部定之。

來源條目欄位（正規化資料）：
- id：article-23
- articleNumber：23
- displayNumber：第 23 條
- title：None
- structureId：chapter-5
- metadata：{"source": "全國法規資料庫 大學法（PDF：大學法.pdf）", "lastModified": "2019-12-11"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   曾在公立或已立案之私立高級中等學校或同等學校畢業，或具有同等學力，得入學修讀學士學位。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   取得學士學位，或具有同等學力，得入學修讀碩士學位。"
  },
  {
    "type": "paragraph",
    "number": "3",
    "text": "3   取得碩士學位，或具有同等學力，得入學修讀博士學位。但修讀學士學位之應屆畢業生成績優異者或修讀碩士學位研究生成績優異者，得申請逕修讀博士學位。"
  },
  {
    "type": "paragraph",
    "number": "4",
    "text": "4   前三項同等學力之認定標準及前項修讀學士學位應屆畢業生、修讀碩士學位研究生逕修讀博士學位辦法，由教育部定之。"
  }
]
```

## U18-A24｜第 24 條

1   大學招生，應本公平、公正、公開原則單獨或聯合他校辦理；其招生（包括考試）方式、名額、考生身分認定、利益迴避、成績複查、考生申訴處理程序及其他應遵行事項之規定，由大學擬訂，報教育部核定後實施。
2   大學為辦理招生或聯合招生，得組成大學招生委員會或聯合會，聯合會並就前項事項共同協商擬訂，報教育部核定後實施；大學招生委員會或聯合會，得就考試相關業務，委託學術專業團體或財團法人辦理。
3   前項大學招生委員會或聯合會之組織、任務、委託學術專業團體或財團法人之資格條件、業務範圍、責任及其他相關事項，由大學或聯合會訂定，報教育部備查。
4   設有藝術系（所）之大學，其學生入學資格及招生（包括考試）方式，依藝術教育法及相關規定辦理。
5   大學辦理之各項入學考試，應訂定試場規則及違規處理規定，並明定於招生簡章。
6   考生參加各項入學考試，有違反試場秩序及考試公平性等情事者，依相關法律、前項考試試場規則與違規處理規定及各校學則規定辦理。

來源條目欄位（正規化資料）：
- id：article-24
- articleNumber：24
- displayNumber：第 24 條
- title：None
- structureId：chapter-5
- metadata：{"source": "全國法規資料庫 大學法（PDF：大學法.pdf）", "lastModified": "2019-12-11"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   大學招生，應本公平、公正、公開原則單獨或聯合他校辦理；其招生（包括考試）方式、名額、考生身分認定、利益迴避、成績複查、考生申訴處理程序及其他應遵行事項之規定，由大學擬訂，報教育部核定後實施。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   大學為辦理招生或聯合招生，得組成大學招生委員會或聯合會，聯合會並就前項事項共同協商擬訂，報教育部核定後實施；大學招生委員會或聯合會，得就考試相關業務，委託學術專業團體或財團法人辦理。"
  },
  {
    "type": "paragraph",
    "number": "3",
    "text": "3   前項大學招生委員會或聯合會之組織、任務、委託學術專業團體或財團法人之資格條件、業務範圍、責任及其他相關事項，由大學或聯合會訂定，報教育部備查。"
  },
  {
    "type": "paragraph",
    "number": "4",
    "text": "4   設有藝術系（所）之大學，其學生入學資格及招生（包括考試）方式，依藝術教育法及相關規定辦理。"
  },
  {
    "type": "paragraph",
    "number": "5",
    "text": "5   大學辦理之各項入學考試，應訂定試場規則及違規處理規定，並明定於招生簡章。"
  },
  {
    "type": "paragraph",
    "number": "6",
    "text": "6   考生參加各項入學考試，有違反試場秩序及考試公平性等情事者，依相關法律、前項考試試場規則與違規處理規定及各校學則規定辦理。"
  }
]
```

## U18-A25｜第 25 條

1   重大災害地區學生、政府派赴國外工作人員子女、參加國際性學科或術科競賽成績優良學生、運動成績優良學生、退伍軍人、蒙藏學生、依國籍法第四條第一項第一款至第三款申請歸化經許可者、僑生、大陸地區學生及外國學生進入大學修讀學位，不受前條公開名額、方式之限制。
2   前項大陸地區學生，不得進入經教育部會商各有關機關認定公告涉及國家安全、機密之院、系、所及學位學程修讀。
3   第一項學生進入大學修讀學位之名額、方式、資格、辦理時程、招生委員會組成方式、錄取原則及其他有關考生權利義務事項之辦法，除大陸地區學生部分由教育部擬訂，報請行政院核定外，其餘由教育部定之。

來源條目欄位（正規化資料）：
- id：article-25
- articleNumber：25
- displayNumber：第 25 條
- title：None
- structureId：chapter-5
- metadata：{"source": "全國法規資料庫 大學法（PDF：大學法.pdf）", "lastModified": "2019-12-11"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   重大災害地區學生、政府派赴國外工作人員子女、參加國際性學科或術科競賽成績優良學生、運動成績優良學生、退伍軍人、蒙藏學生、依國籍法第四條第一項第一款至第三款申請歸化經許可者、僑生、大陸地區學生及外國學生進入大學修讀學位，不受前條公開名額、方式之限制。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   前項大陸地區學生，不得進入經教育部會商各有關機關認定公告涉及國家安全、機密之院、系、所及學位學程修讀。"
  },
  {
    "type": "paragraph",
    "number": "3",
    "text": "3   第一項學生進入大學修讀學位之名額、方式、資格、辦理時程、招生委員會組成方式、錄取原則及其他有關考生權利義務事項之辦法，除大陸地區學生部分由教育部擬訂，報請行政院核定外，其餘由教育部定之。"
  }
]
```

## U18-A26｜第 26 條

1   學生修讀學士學位之修業期限，以四年為原則。但得視系、所、學院、學程之性質延長一年至二年，並得視系、所、學院、學程之實際需要另增加實習半年至二年；修讀碩士學位之修業期限為一年至四年；修讀博士學位之修業期限為二年至七年。
2   前項修業期限得予縮短或延長，其資格條件、申請程序之規定，由大學訂定，報教育部備查。
3   身心障礙學生修讀學士學位，因身心狀況及學習需要，得延長修業期限，至多四年，並不適用因學業成績退學之規定。
4   學生因懷孕、分娩或撫育三歲以下子女，得延長修業期限。
5   第一項學士學位畢業應修學分數及學分之計算，由教育部定之；碩士學位與博士學位畢業應修學分數及獲得學位所需通過之各項考核規定，由大學訂定，報教育部備查。

來源條目欄位（正規化資料）：
- id：article-26
- articleNumber：26
- displayNumber：第 26 條
- title：None
- structureId：chapter-5
- metadata：{"source": "全國法規資料庫 大學法（PDF：大學法.pdf）", "lastModified": "2019-12-11"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   學生修讀學士學位之修業期限，以四年為原則。但得視系、所、學院、學程之性質延長一年至二年，並得視系、所、學院、學程之實際需要另增加實習半年至二年；修讀碩士學位之修業期限為一年至四年；修讀博士學位之修業期限為二年至七年。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   前項修業期限得予縮短或延長，其資格條件、申請程序之規定，由大學訂定，報教育部備查。"
  },
  {
    "type": "paragraph",
    "number": "3",
    "text": "3   身心障礙學生修讀學士學位，因身心狀況及學習需要，得延長修業期限，至多四年，並不適用因學業成績退學之規定。"
  },
  {
    "type": "paragraph",
    "number": "4",
    "text": "4   學生因懷孕、分娩或撫育三歲以下子女，得延長修業期限。"
  },
  {
    "type": "paragraph",
    "number": "5",
    "text": "5   第一項學士學位畢業應修學分數及學分之計算，由教育部定之；碩士學位與博士學位畢業應修學分數及獲得學位所需通過之各項考核規定，由大學訂定，報教育部備查。"
  }
]
```

## U18-A27｜第 27 條

學生修畢學分學程所規定之學分者，大學應發給學程學分證明；學生修畢學位學程所規定之學分，經考核成績及格者，大學應依法授予學位。

來源條目欄位（正規化資料）：
- id：article-27
- articleNumber：27
- displayNumber：第 27 條
- title：None
- structureId：chapter-5
- metadata：{"source": "全國法規資料庫 大學法（PDF：大學法.pdf）", "lastModified": "2019-12-11"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": null,
    "text": "學生修畢學分學程所規定之學分者，大學應發給學程學分證明；學生修畢學位學程所規定之學分，經考核成績及格者，大學應依法授予學位。"
  }
]
```

## U18-A28｜第 28 條

1   大學學生修讀本校或他校輔系、雙主修、學程、跨校選修課程、保留入學資格、轉學、轉系（組）所、轉學程、休學、退學、開除學籍、成績考核、學分抵免與暑期修課、國外學歷之採認、服兵役與出國有關學籍處理、雙重學籍及其他與學籍有關事項，由大學列入學則，報教育部備查。
2   前項國外學歷之採認原則、認定程序及其他應遵行事項之辦法，由教育部定之。

來源條目欄位（正規化資料）：
- id：article-28
- articleNumber：28
- displayNumber：第 28 條
- title：None
- structureId：chapter-5
- metadata：{"source": "全國法規資料庫 大學法（PDF：大學法.pdf）", "lastModified": "2019-12-11"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   大學學生修讀本校或他校輔系、雙主修、學程、跨校選修課程、保留入學資格、轉學、轉系（組）所、轉學程、休學、退學、開除學籍、成績考核、學分抵免與暑期修課、國外學歷之採認、服兵役與出國有關學籍處理、雙重學籍及其他與學籍有關事項，由大學列入學則，報教育部備查。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   前項國外學歷之採認原則、認定程序及其他應遵行事項之辦法，由教育部定之。"
  }
]
```

## U18-A29｜第 29 條

大學在學學生經核准得同時在國內外大學修讀學位，各大學應依相關法令規定，將相關事項納入學則規範，並報教育部備查。

來源條目欄位（正規化資料）：
- id：article-29
- articleNumber：29
- displayNumber：第 29 條
- title：None
- structureId：chapter-5
- metadata：{"source": "全國法規資料庫 大學法（PDF：大學法.pdf）", "lastModified": "2019-12-11"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": null,
    "text": "大學在學學生經核准得同時在國內外大學修讀學位，各大學應依相關法令規定，將相關事項納入學則規範，並報教育部備查。"
  }
]
```

## U18-A30｜第 30 條

依本法規定修讀各級學位，得以遠距教學方式修習部分科目學分；其學分採認比率、要件及其他相關事項之辦法，由教育部定之。

來源條目欄位（正規化資料）：
- id：article-30
- articleNumber：30
- displayNumber：第 30 條
- title：None
- structureId：chapter-5
- metadata：{"source": "全國法規資料庫 大學法（PDF：大學法.pdf）", "lastModified": "2019-12-11"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": null,
    "text": "依本法規定修讀各級學位，得以遠距教學方式修習部分科目學分；其學分採認比率、要件及其他相關事項之辦法，由教育部定之。"
  }
]
```

## U18-A31｜第 31 條

1   大學得辦理推廣教育，以修讀科目或學分為原則。但修滿系、所規定學分，考核成績合格，並經入學考試合格者，得依前條規定，授予學位。
2   前項推廣教育實施辦法，由教育部定之。

來源條目欄位（正規化資料）：
- id：article-31
- articleNumber：31
- displayNumber：第 31 條
- title：None
- structureId：chapter-5
- metadata：{"source": "全國法規資料庫 大學法（PDF：大學法.pdf）", "lastModified": "2019-12-11"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   大學得辦理推廣教育，以修讀科目或學分為原則。但修滿系、所規定學分，考核成績合格，並經入學考試合格者，得依前條規定，授予學位。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   前項推廣教育實施辦法，由教育部定之。"
  }
]
```

## U18-A32｜第 32 條

大學為確保學生學習效果，並建立學生行為規範，應訂定學則及獎懲規定，並報教育部備查。

來源條目欄位（正規化資料）：
- id：article-32
- articleNumber：32
- displayNumber：第 32 條
- title：None
- structureId：chapter-5
- metadata：{"source": "全國法規資料庫 大學法（PDF：大學法.pdf）", "lastModified": "2019-12-11"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": null,
    "text": "大學為確保學生學習效果，並建立學生行為規範，應訂定學則及獎懲規定，並報教育部備查。"
  }
]
```

## U18-A33｜第 33 條

1   大學為增進教育效果，應由經選舉產生之學生代表出席與其學業、生活及訂定獎懲有關規章之會議。
2   大學應輔導學生成立由全校學生選舉產生之學生會及其他相關自治組織，以增進學生在校學習效果及自治能力。
3   學生為前項學生會當然會員，學生會得向會員收取會費；學校應依學生會請求，代收會費。
4   大學應建立學生申訴制度，受理學生、學生會及其他相關學生自治組織不服學校之懲處、行政處分或其他措施及決議之事件，以保障學生權益。
5   前四項之辦法，於各大學組織規程定之。

來源條目欄位（正規化資料）：
- id：article-33
- articleNumber：33
- displayNumber：第 33 條
- title：None
- structureId：chapter-5
- metadata：{"source": "全國法規資料庫 大學法（PDF：大學法.pdf）", "lastModified": "2019-12-11"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   大學為增進教育效果，應由經選舉產生之學生代表出席與其學業、生活及訂定獎懲有關規章之會議。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   大學應輔導學生成立由全校學生選舉產生之學生會及其他相關自治組織，以增進學生在校學習效果及自治能力。"
  },
  {
    "type": "paragraph",
    "number": "3",
    "text": "3   學生為前項學生會當然會員，學生會得向會員收取會費；學校應依學生會請求，代收會費。"
  },
  {
    "type": "paragraph",
    "number": "4",
    "text": "4   大學應建立學生申訴制度，受理學生、學生會及其他相關學生自治組織不服學校之懲處、行政處分或其他措施及決議之事件，以保障學生權益。"
  },
  {
    "type": "paragraph",
    "number": "5",
    "text": "5   前四項之辦法，於各大學組織規程定之。"
  }
]
```

## U18-A33-1｜第 33-1 條

1   學校受理前條第四項申訴事件時，應秉持客觀、公正、專業之原則，給予申訴人充分陳述意見及答辯之機會。
2   學校應以書面或其他適當方式告知申訴人申訴評議決定及不服該決定之相關救濟程序。
3   學生申訴制度應列入學生手冊，廣為宣導。

來源條目欄位（正規化資料）：
- id：article-33-1
- articleNumber：33-1
- displayNumber：第 33-1 條
- title：None
- structureId：chapter-5
- metadata：{"source": "全國法規資料庫 大學法（PDF：大學法.pdf）", "lastModified": "2019-12-11"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   學校受理前條第四項申訴事件時，應秉持客觀、公正、專業之原則，給予申訴人充分陳述意見及答辯之機會。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   學校應以書面或其他適當方式告知申訴人申訴評議決定及不服該決定之相關救濟程序。"
  },
  {
    "type": "paragraph",
    "number": "3",
    "text": "3   學生申訴制度應列入學生手冊，廣為宣導。"
  }
]
```

## U18-A33-2｜第 33-2 條

1   前條申訴人就學校所為之行政處分，經向學校提起申訴而不服其決定，得依法提起訴願。
2   申訴人就學校所為行政處分以外之懲處、其他措施或決議，經向學校提起申訴而不服其決定，得按其性質依法提起訴訟，請求救濟。

來源條目欄位（正規化資料）：
- id：article-33-2
- articleNumber：33-2
- displayNumber：第 33-2 條
- title：None
- structureId：chapter-5
- metadata：{"source": "全國法規資料庫 大學法（PDF：大學法.pdf）", "lastModified": "2019-12-11"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   前條申訴人就學校所為之行政處分，經向學校提起申訴而不服其決定，得依法提起訴願。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   申訴人就學校所為行政處分以外之懲處、其他措施或決議，經向學校提起申訴而不服其決定，得按其性質依法提起訴訟，請求救濟。"
  }
]
```

## U18-A34｜第 34 條

大學應辦理學生團體保險；其範圍、金額、繳費方式、期程、給付標準、權利義務及其他相關事項之規定，由各校定之。遇學生需保險理賠時，各校應主動協助辦理。

來源條目欄位（正規化資料）：
- id：article-34
- articleNumber：34
- displayNumber：第 34 條
- title：None
- structureId：chapter-5
- metadata：{"source": "全國法規資料庫 大學法（PDF：大學法.pdf）", "lastModified": "2019-12-11"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": null,
    "text": "大學應辦理學生團體保險；其範圍、金額、繳費方式、期程、給付標準、權利義務及其他相關事項之規定，由各校定之。遇學生需保險理賠時，各校應主動協助辦理。"
  }
]
```

## U18-A35｜第 35 條

1   大學向學生收取費用之項目、用途及數額，不得逾教育部之規定。
2   政府為協助學生就讀大學，應辦理學生就學貸款；貸款項目包括學雜費、實習費、書籍費、住宿費、生活費、學生團體保險費及海外研修費等相關費用；其貸款條件、額度、權利義務及其他應遵行事項之辦法，由教育部定之。

來源條目欄位（正規化資料）：
- id：article-35
- articleNumber：35
- displayNumber：第 35 條
- title：None
- structureId：chapter-5
- metadata：{"source": "全國法規資料庫 大學法（PDF：大學法.pdf）", "lastModified": "2019-12-11"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   大學向學生收取費用之項目、用途及數額，不得逾教育部之規定。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   政府為協助學生就讀大學，應辦理學生就學貸款；貸款項目包括學雜費、實習費、書籍費、住宿費、生活費、學生團體保險費及海外研修費等相關費用；其貸款條件、額度、權利義務及其他應遵行事項之辦法，由教育部定之。"
  }
]
```

## U18-A36｜第 36 條

各大學應依本法規定，擬訂組織規程，報教育部核定後實施。

來源條目欄位（正規化資料）：
- id：article-36
- articleNumber：36
- displayNumber：第 36 條
- title：None
- structureId：chapter-6
- metadata：{"source": "全國法規資料庫 大學法（PDF：大學法.pdf）", "lastModified": "2019-12-11"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": null,
    "text": "各大學應依本法規定，擬訂組織規程，報教育部核定後實施。"
  }
]
```

## U18-A37｜第 37 條

教育人員任用條例第二十五條、第二十六條及第三十七條規定與本法相牴觸之部分，應不再適用。

來源條目欄位（正規化資料）：
- id：article-37
- articleNumber：37
- displayNumber：第 37 條
- title：None
- structureId：chapter-6
- metadata：{"source": "全國法規資料庫 大學法（PDF：大學法.pdf）", "lastModified": "2019-12-11"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": null,
    "text": "教育人員任用條例第二十五條、第二十六條及第三十七條規定與本法相牴觸之部分，應不再適用。"
  }
]
```

## U18-A38｜第 38 條

大學為發揮教育、訓練、研究、服務之功能，得與政府機關、事業機關、民間團體、學術研究機構等辦理產學合作；其實施辦法，由教育部定之。

來源條目欄位（正規化資料）：
- id：article-38
- articleNumber：38
- displayNumber：第 38 條
- title：None
- structureId：chapter-6
- metadata：{"source": "全國法規資料庫 大學法（PDF：大學法.pdf）", "lastModified": "2019-12-11"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": null,
    "text": "大學為發揮教育、訓練、研究、服務之功能，得與政府機關、事業機關、民間團體、學術研究機構等辦理產學合作；其實施辦法，由教育部定之。"
  }
]
```

## U18-A39｜第 39 條

大學對校務資訊，除依法應予保密者外，以主動公開為原則，並得應人民申請提供之。

來源條目欄位（正規化資料）：
- id：article-39
- articleNumber：39
- displayNumber：第 39 條
- title：None
- structureId：chapter-6
- metadata：{"source": "全國法規資料庫 大學法（PDF：大學法.pdf）", "lastModified": "2019-12-11"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": null,
    "text": "大學對校務資訊，除依法應予保密者外，以主動公開為原則，並得應人民申請提供之。"
  }
]
```

## U18-A40｜第 40 條

1   師資培育之大學與私立大學之設立、組織及教育設施，除師資培育法、私立學校法另有規定者外，適用本法之規定。
2   中央及直轄市政府，得設立空中大學；其組織及教育設施，另以法律定之。

來源條目欄位（正規化資料）：
- id：article-40
- articleNumber：40
- displayNumber：第 40 條
- title：None
- structureId：chapter-6
- metadata：{"source": "全國法規資料庫 大學法（PDF：大學法.pdf）", "lastModified": "2019-12-11"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   師資培育之大學與私立大學之設立、組織及教育設施，除師資培育法、私立學校法另有規定者外，適用本法之規定。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   中央及直轄市政府，得設立空中大學；其組織及教育設施，另以法律定之。"
  }
]
```

## U18-A41｜第 41 條

本法施行細則，由教育部定之。

來源條目欄位（正規化資料）：
- id：article-41
- articleNumber：41
- displayNumber：第 41 條
- title：None
- structureId：chapter-6
- metadata：{"source": "全國法規資料庫 大學法（PDF：大學法.pdf）", "lastModified": "2019-12-11"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": null,
    "text": "本法施行細則，由教育部定之。"
  }
]
```

## U18-A42｜第 42 條

1   本法自公布日施行。
2   本法中華民國九十九年八月十九日修正之第二十五條，其施行日期，由行政院定之。

來源條目欄位（正規化資料）：
- id：article-42
- articleNumber：42
- displayNumber：第 42 條
- title：None
- structureId：chapter-6
- metadata：{"source": "全國法規資料庫 大學法（PDF：大學法.pdf）", "lastModified": "2019-12-11"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   本法自公布日施行。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   本法中華民國九十九年八月十九日修正之第二十五條，其施行日期，由行政院定之。"
  }
]
```

## 來源其他資料

- schemaVersion：1.3.0
- processing：{"normalizedBy": "ai", "processedAt": "2026-07-22T00:00:00Z", "sourceType": "document", "warnings": ["跨法規連結「授權訂定施行細則」之目標法規（大學法施行細則）未包含於本次來源，targetRegulationId 保留 null，待該法規匯入後再行連結。", "來源 PDF未印出官方法規代碼，code 依規範填「UNKNOWN」。", "以下法規經條文明文引用，但未包含於本次匯入批次，targetRegulationId 暫留 null，待該等法規匯入後可依名稱自動或人工連結：師資培育法。"]}