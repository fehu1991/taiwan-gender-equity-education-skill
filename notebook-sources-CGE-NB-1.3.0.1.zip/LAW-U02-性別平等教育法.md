# LAW-U02｜性別平等教育法

資料集：CGE-NB-1.3.0.1；編製日：2026-09-09。此日期不是法律查核日。

## 來源與版本

- source_id：U02
- filename：性別平等教育法.json
- path：sources/uploaded/性別平等教育法.json
- sha256：94993a31ee21916ef1e3fbd6b128db0a8e7e0af4f239d25b85e3c46dd7ca6581
- regulation_id：tw-gender-equity-education-act
- name：性別平等教育法
- version：{"id": "tw-gender-equity-education-act-20230816", "label": "修正日期：民國 112 年 08 月 16 日", "promulgationDate": "2023-08-16", "effectiveDate": "2023-08-18", "effectiveDateNote": "本版本施行條文明定自公布（發布）日施行，依中央法規標準法第13條，自公布（發布）之日起算至第三日起發生效力，故施行日為公布（發布）日之後二日。 另依第48條，第2條第2項、第3條第2款、第3款第4目、第5條第2項、第7條至第9條、第21條、第29條、第30條、第33條第2項前段但書、第3項、第37條、第40條、第44條自中華民國一百十三年三月八日（2024-03-08）施行。", "status": "effective"}
- article_count：48
- source_kind：user_uploaded_ai_normalized_json
- review_status：core_rules_checked_not_full_diff
- review_notes：[]
- official_source_ids：["W01"]
- normalization_warnings：["來源 PDF未印出官方法規代碼，code 依規範填「UNKNOWN」。"]
- processed_at：2026-07-22T00:00:00Z
- authoritative_current_full_text：False

- id：tw-gender-equity-education-act
- code：UNKNOWN
- name：性別平等教育法
- shortName：性別平等教育法
- jurisdiction：TW
- authority：教育部
- aliases：["性平法", "性平教育法"]
- version：{"id": "tw-gender-equity-education-act-20230816", "label": "修正日期：民國 112 年 08 月 16 日", "promulgationDate": "2023-08-16", "effectiveDate": "2023-08-18", "effectiveDateNote": "本版本施行條文明定自公布（發布）日施行，依中央法規標準法第13條，自公布（發布）之日起算至第三日起發生效力，故施行日為公布（發布）日之後二日。 另依第48條，第2條第2項、第3條第2款、第3款第4目、第5條第2項、第7條至第9條、第21條、第29條、第30條、第33條第2項前段但書、第3項、第37條、第40條、第44條自中華民國一百十三年三月八日（2024-03-08）施行。", "status": "effective"}
- structure：[{"id": "chapter-1", "type": "chapter", "label": "第 一 章 總則", "parentId": null, "sortOrder": 0}, {"id": "chapter-2", "type": "chapter", "label": "第 二 章 學習環境及資源", "parentId": null, "sortOrder": 1}, {"id": "chapter-3", "type": "chapter", "label": "第 三 章 課程、教材及教學", "parentId": null, "sortOrder": 2}, {"id": "chapter-4", "type": "chapter", "label": "第 四 章 校園性別事件之防治", "parentId": null, "sortOrder": 3}, {"id": "chapter-5", "type": "chapter", "label": "第 五 章 申請調查及救濟", "parentId": null, "sortOrder": 4}, {"id": "chapter-6", "type": "chapter", "label": "第 六 章 罰則", "parentId": null, "sortOrder": 5}, {"id": "chapter-7", "type": "chapter", "label": "第 七 章 附則", "parentId": null, "sortOrder": 6}]
- legalConcepts：[{"id": "gender-equity-campus-framework", "name": "校園性別事件處理法律框架", "description": "彙整校園性侵害、性騷擾及性霸凌事件之防治、調查與處理程序所涉之法規，包含性別平等教育法及其授權訂定之準則與學校校內規定。", "aliases": ["校園性別事件"], "tags": ["校園", "性別事件", "性平教育"], "role": "primary", "sortOrder": 0}, {"id": "sexual-harassment-prevention-framework", "name": "性騷擾防治法律框架", "description": "彙整我國性騷擾之定義、防治義務、申訴調查程序與相關罰則所涉之法規；並涵蓋依場域與當事人身分關係而分流適用之性別平等工作法與性別平等教育法。", "aliases": ["性騷擾防治"], "tags": ["性騷擾", "防治", "申訴"], "role": "supporting", "sortOrder": 5}, {"id": "child-youth-protection-framework", "name": "兒童及少年保護法律框架", "description": "彙整兒童及少年之福利、權益保障與性剝削防制所涉之法規。", "aliases": ["兒少保護"], "tags": ["兒童", "少年", "保護"], "role": "related", "sortOrder": 6}, {"id": "sexual-assault-prevention-framework", "name": "性侵害犯罪防治法律框架", "description": "彙整性侵害犯罪之防治、被害人保護與加害人處遇所涉之法規。", "aliases": ["性侵害防治"], "tags": ["性侵害", "被害人保護"], "role": "related", "sortOrder": 7}, {"id": "teacher-employment-framework", "name": "教師任用與聘任法律框架", "description": "彙整各級學校教師之資格、任用、聘任、解聘與不適任處理所涉之法規。", "aliases": ["教師任用"], "tags": ["教師", "任用", "聘任"], "role": "related", "sortOrder": 8}]
- crossRegulationLinks：[{"id": "link-tw-gender-equity-education-act-1", "conceptId": "gender-equity-campus-framework", "sourceArticleId": null, "label": "授權訂定施行細則", "relationType": "authorization", "conditionText": "本法施行細則，由中央主管機關定之。", "targetRegulationId": "tw-gender-equity-education-act-enforcement-rules", "targetRegulationNames": ["性別平等教育法施行細則"], "targetArticleNumber": null, "triggerTerms": ["施行細則"], "linkMode": "automatic", "sortOrder": 0}, {"id": "link-tw-gender-equity-education-act-2", "conceptId": "gender-equity-campus-framework", "sourceArticleId": null, "label": "授權訂定防治準則", "relationType": "authorization", "conditionText": "校園性別事件之防治、調查及處理程序，依本法授權訂定之校園性別事件防治準則辦理。", "targetRegulationId": "tw-campus-gender-incident-prevention-standards", "targetRegulationNames": ["校園性別事件防治準則"], "targetArticleNumber": null, "triggerTerms": ["防治準則"], "linkMode": "automatic_or_manual", "sortOrder": 1}, {"conceptId": "gender-equity-campus-framework", "sourceArticleId": "article-1", "label": "引用性別平等工作法", "relationType": "application", "conditionText": "2   校園性騷擾事件之適用範圍依本法規定處理，因當事人身分關係不在本法規定之適用範圍者，視其情形分別適用性別平等工作法或性騷擾防治法。", "targetRegulationId": "tw-gender-equality-employment-act", "targetRegulationNames": ["性別平等工作法"], "targetArticleNumber": null, "triggerTerms": ["分別適用"], "linkMode": "automatic", "id": "link-tw-gender-equity-education-act-cite-3", "sortOrder": 2}, {"conceptId": "sexual-harassment-prevention-framework", "sourceArticleId": "article-1", "label": "引用性騷擾防治法", "relationType": "application", "conditionText": "2   校園性騷擾事件之適用範圍依本法規定處理，因當事人身分關係不在本法規定之適用範圍者，視其情形分別適用性別平等工作法或性騷擾防治法。", "targetRegulationId": "tw-sexual-harassment-prevention-act", "targetRegulationNames": ["性騷擾防治法"], "targetArticleNumber": null, "triggerTerms": ["工作法或"], "linkMode": "automatic", "id": "link-tw-gender-equity-education-act-cite-4", "sortOrder": 3}, {"conceptId": "sexual-assault-prevention-framework", "sourceArticleId": "article-3", "label": "引用性侵害犯罪防治法", "relationType": "application", "conditionText": "（一）性侵害：指性侵害犯罪防治法所稱性侵害犯罪之行為。", "targetRegulationId": "tw-sexual-assault-crime-prevention-act", "targetRegulationNames": ["性侵害犯罪防治法"], "targetArticleNumber": null, "triggerTerms": ["侵害：指"], "linkMode": "automatic", "id": "link-tw-gender-equity-education-act-cite-5", "sortOrder": 4}, {"conceptId": "sexual-assault-prevention-framework", "sourceArticleId": "article-22", "label": "引用性侵害犯罪防治法", "relationType": "application", "conditionText": "二、依性侵害犯罪防治法、兒童及少年福利與權益保障法、身心障礙者權益保障法及其他相關法律規定向當地直轄市、縣（市）社政主管機關通報。", "targetRegulationId": "tw-sexual-assault-crime-prevention-act", "targetRegulationNames": ["性侵害犯罪防治法"], "targetArticleNumber": null, "triggerTerms": ["\n二、依"], "linkMode": "automatic", "id": "link-tw-gender-equity-education-act-cite-6", "sortOrder": 5}, {"conceptId": "child-youth-protection-framework", "sourceArticleId": "article-22", "label": "引用兒童及少年福利與權益保障法", "relationType": "application", "conditionText": "二、依性侵害犯罪防治法、兒童及少年福利與權益保障法、身心障礙者權益保障法及其他相關法律規定向當地直轄市、縣（市）社政主管機關通報。", "targetRegulationId": "tw-child-youth-welfare-rights-protection-act", "targetRegulationNames": ["兒童及少年福利與權益保障法"], "targetArticleNumber": null, "triggerTerms": ["防治法、"], "linkMode": "automatic", "id": "link-tw-gender-equity-education-act-cite-7", "sortOrder": 6}, {"conceptId": "child-youth-protection-framework", "sourceArticleId": "article-29", "label": "引用兒童及少年性剝削防制條例", "relationType": "application", "conditionText": "3   非屬依第一項規定予以解聘、免職、終止契約關係或終止運用關係之人員，有性侵害行為或有終身不得聘任、任用、進用或運用必要之性騷擾、性霸凌、校長或教職員工違反與性或性別有關之專業倫理、違反兒童及少年性交易防制條例、兒童及少年性剝削防制條例之行為，經學校性別平等教育委員會查證屬實者，不得聘任、任用、進用或運用；已聘任、任用、進用或運用者，學校應予解聘、免職、終止契約關係或終止運用關係；非屬終身不得聘任、任用、進用或運用必要之性騷擾、性霸凌、校長或教職員工違反與性或性別有關之專業倫理、違反兒童及少年性交易防制條例、兒童及少年性剝削防制條例之行為，經學校性別平等教育委員會查證屬實並議決一年至四年不得聘任、任用、進用或運用者，於該議決期間，亦同。", "targetRegulationId": "tw-child-youth-sexual-exploitation-prevention-act", "targetRegulationNames": ["兒童及少年性剝削防制條例"], "targetArticleNumber": null, "triggerTerms": ["制條例、"], "linkMode": "automatic", "id": "link-tw-gender-equity-education-act-cite-8", "sortOrder": 7}, {"conceptId": "sexual-assault-prevention-framework", "sourceArticleId": "article-30", "label": "引用性侵害犯罪防治法", "relationType": "application", "conditionText": "2   學校聘任、任用教育人員或進用、運用其他人員前，應依性侵害犯罪防治法之規定，查詢其有無性侵害之犯罪紀錄，及依第四項所定辦法查詢是否曾有性侵害、性騷擾、性霸凌、校長或教職員工違反與性或性別有關之專業倫理、違反兒童及少年性交易防制條例、兒童及少年性剝削防制條例之行為；已聘任、任用、進用或運用者，應定期查詢。", "targetRegulationId": "tw-sexual-assault-crime-prevention-act", "targetRegulationNames": ["性侵害犯罪防治法"], "targetArticleNumber": null, "triggerTerms": ["前，應依"], "linkMode": "automatic", "id": "link-tw-gender-equity-education-act-cite-9", "sortOrder": 8}, {"conceptId": "child-youth-protection-framework", "sourceArticleId": "article-30", "label": "引用兒童及少年性剝削防制條例", "relationType": "application", "conditionText": "2   學校聘任、任用教育人員或進用、運用其他人員前，應依性侵害犯罪防治法之規定，查詢其有無性侵害之犯罪紀錄，及依第四項所定辦法查詢是否曾有性侵害、性騷擾、性霸凌、校長或教職員工違反與性或性別有關之專業倫理、違反兒童及少年性交易防制條例、兒童及少年性剝削防制條例之行為；已聘任、任用、進用或運用者，應定期查詢。", "targetRegulationId": "tw-child-youth-sexual-exploitation-prevention-act", "targetRegulationNames": ["兒童及少年性剝削防制條例"], "targetArticleNumber": null, "triggerTerms": ["制條例、"], "linkMode": "automatic", "id": "link-tw-gender-equity-education-act-cite-10", "sortOrder": 9}, {"conceptId": "sexual-harassment-prevention-framework", "sourceArticleId": "article-30", "label": "引用性騷擾防治法", "relationType": "penalty", "conditionText": "3   主管機關協助學校辦理前項查詢，得使用中央社政主管機關建立之依兒童及少年性剝削防制條例，或性騷擾防治法第二十七條規定，受行政處罰者之資料，及中央勞工主管機關依性別平等工作法建立性騷擾防治事件之資料。", "targetRegulationId": "tw-sexual-harassment-prevention-act", "targetRegulationNames": ["性騷擾防治法"], "targetArticleNumber": "27", "triggerTerms": ["條例，或"], "linkMode": "automatic", "id": "link-tw-gender-equity-education-act-cite-11", "sortOrder": 10}, {"conceptId": "gender-equity-campus-framework", "sourceArticleId": "article-30", "label": "引用性別平等工作法", "relationType": "application", "conditionText": "3   主管機關協助學校辦理前項查詢，得使用中央社政主管機關建立之依兒童及少年性剝削防制條例，或性騷擾防治法第二十七條規定，受行政處罰者之資料，及中央勞工主管機關依性別平等工作法建立性騷擾防治事件之資料。", "targetRegulationId": "tw-gender-equality-employment-act", "targetRegulationNames": ["性別平等工作法"], "targetArticleNumber": null, "triggerTerms": ["管機關依"], "linkMode": "automatic", "id": "link-tw-gender-equity-education-act-cite-12", "sortOrder": 11}, {"conceptId": "teacher-employment-framework", "sourceArticleId": "article-30", "label": "引用教師法", "relationType": "application", "conditionText": "5   前條各項之人員適用教師法、教育人員任用條例、公務人員相關法律或陸海空軍相關法律者，其解聘、停聘、免職、撤職、停職或退伍，依各該法律規定辦理，並適用前四項規定；其未解聘、免職、撤職或退伍者，應調離學校現職。", "targetRegulationId": "tw-teachers-act", "targetRegulationNames": ["教師法"], "targetArticleNumber": null, "triggerTerms": ["人員適用"], "linkMode": "automatic", "id": "link-tw-gender-equity-education-act-cite-13", "sortOrder": 12}, {"conceptId": "teacher-employment-framework", "sourceArticleId": "article-30", "label": "引用教育人員任用條例", "relationType": "application", "conditionText": "5   前條各項之人員適用教師法、教育人員任用條例、公務人員相關法律或陸海空軍相關法律者，其解聘、停聘、免職、撤職、停職或退伍，依各該法律規定辦理，並適用前四項規定；其未解聘、免職、撤職或退伍者，應調離學校現職。", "targetRegulationId": "tw-educational-personnel-employment-act", "targetRegulationNames": ["教育人員任用條例"], "targetArticleNumber": null, "triggerTerms": ["教師法、"], "linkMode": "automatic", "id": "link-tw-gender-equity-education-act-cite-14", "sortOrder": 13}, {"conceptId": "gender-equity-campus-framework", "sourceArticleId": "article-33", "label": "引用行政程序法", "relationType": "penalty", "conditionText": "6   行政程序法有關管轄、移送、迴避、送達、補正等相關規定，於本法適用或準用之。", "targetRegulationId": "tw-administrative-procedure-act", "targetRegulationNames": ["行政程序法"], "targetArticleNumber": null, "triggerTerms": ["6   "], "linkMode": "automatic", "id": "link-tw-gender-equity-education-act-cite-15", "sortOrder": 14}, {"conceptId": "gender-equity-campus-framework", "sourceArticleId": "article-35", "label": "引用陸海空軍軍官士官任職條例", "relationType": "application", "conditionText": "1   學校校長涉及校園性別事件，經學校主管機關所設之性別平等教育委員會認情節重大，有於調查期間先行調整或停止其職務之必要者，得由學校主管機關調整或停止其職務。但校長為軍職人員者，依陸海空軍軍官士官任職條例及相關規定辦理。", "targetRegulationId": "tw-armed-forces-officers-nco-appointment-act", "targetRegulationNames": ["陸海空軍軍官士官任職條例"], "targetArticleNumber": null, "triggerTerms": ["員者，依"], "linkMode": "automatic", "id": "link-tw-gender-equity-education-act-cite-16", "sortOrder": 15}, {"conceptId": "teacher-employment-framework", "sourceArticleId": "article-39", "label": "引用教師法", "relationType": "application", "conditionText": "一、學校校長、教師：依教師法或相關法規之規定。", "targetRegulationId": "tw-teachers-act", "targetRegulationNames": ["教師法"], "targetArticleNumber": null, "triggerTerms": ["教師：依"], "linkMode": "automatic", "id": "link-tw-gender-equity-education-act-cite-17", "sortOrder": 16}, {"conceptId": "teacher-employment-framework", "sourceArticleId": "article-39", "label": "引用教育人員任用條例", "relationType": "application", "conditionText": "二、公立學校依公務人員任用法任用之職員及中華民國七十四年五月三日教育人員任用條例施行前未納入銓敘之職員：依公務人員保障法之規定。", "targetRegulationId": "tw-educational-personnel-employment-act", "targetRegulationNames": ["教育人員任用條例"], "targetArticleNumber": null, "triggerTerms": ["五月三日"], "linkMode": "automatic", "id": "link-tw-gender-equity-education-act-cite-18", "sortOrder": 17}, {"conceptId": "sexual-harassment-prevention-framework", "sourceArticleId": "article-45", "label": "引用性騷擾防治法", "relationType": "application", "conditionText": "性騷擾防治法第十條、第二十五條及第二十六條之規定，於本法所定校園性別事件，適用之。", "targetRegulationId": "tw-sexual-harassment-prevention-act", "targetRegulationNames": ["性騷擾防治法"], "targetArticleNumber": "10", "triggerTerms": [], "linkMode": "automatic", "id": "link-tw-gender-equity-education-act-cite-19", "sortOrder": 18}]
- definedTerms：[{"id": "competent-authority", "name": "主管機關", "aliases": [], "definition": "在中央為教育部；在直轄市為直轄市政府；在縣（市）為縣（市）政府。", "definitionArticleId": "article-2", "definitionText": "1   本法所稱主管機關：在中央為教育部；在直轄市為直轄市政府；在縣（市）為縣（市）政府。", "scope": "regulation", "targetRegulationNames": [], "sortOrder": 0}, {"id": "gender-equity-education", "name": "性別平等教育", "aliases": [], "definition": "指以教育方式教導尊重多元性別差異，消除性別歧視，促進性別地位之實質平等。", "definitionArticleId": "article-3", "definitionText": "一、性別平等教育：指以教育方式教導尊重多元性別差異，消除性別歧視，促進性別地位之實質平等。", "scope": "regulation", "targetRegulationNames": [], "sortOrder": 1}, {"id": "campus-gender-incident", "name": "校園性別事件", "aliases": [], "definition": "指事件之一方為學校校長、教師、職員、工友或學生，他方為學生，並有下列情形之一者：。", "definitionArticleId": "article-3", "definitionText": "三、校園性別事件：指事件之一方為學校校長、教師、職員、工友或學生，他方為學生，並有下列情形之一者：", "scope": "regulation", "targetRegulationNames": [], "sortOrder": 2}, {"id": "gender-identity", "name": "性別認同", "aliases": [], "definition": "指個人對自我歸屬性別之認知及接受。", "definitionArticleId": "article-3", "definitionText": "四、性別認同：指個人對自我歸屬性別之認知及接受。", "scope": "regulation", "targetRegulationNames": [], "sortOrder": 3}]

正規化概念、跨法連結與處理狀態不是獨立法源；下面逐條保留來源plainText，未以本次日期重寫。

## U02-A1｜第 1 條

1   為促進性別地位之實質平等，消除性別歧視，維護人格尊嚴，厚植並建立性別平等之教育資源與環境，特制定本法。
2   校園性騷擾事件之適用範圍依本法規定處理，因當事人身分關係不在本法規定之適用範圍者，視其情形分別適用性別平等工作法或性騷擾防治法。

來源條目欄位（正規化資料）：
- id：article-1
- articleNumber：1
- displayNumber：第 1 條
- title：None
- structureId：chapter-1
- metadata：{"source": "全國法規資料庫 性別平等教育法（PDF：法規-性別平等教育法.pdf）", "lastModified": "2023-08-16"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   為促進性別地位之實質平等，消除性別歧視，維護人格尊嚴，厚植並建立性別平等之教育資源與環境，特制定本法。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   校園性騷擾事件之適用範圍依本法規定處理，因當事人身分關係不在本法規定之適用範圍者，視其情形分別適用性別平等工作法或性騷擾防治法。"
  }
]
```

## U02-A2｜第 2 條

1   本法所稱主管機關：在中央為教育部；在直轄市為直轄市政府；在縣（市）為縣（市）政府。
2   本法所定事項，於軍事學校、預備學校、警察各級學校及少年矯正學校辦理時，以其所屬主管機關為本法所稱主管機關。
3   本法所定事項涉及各目的事業主管機關業務時，各該機關應配合辦理。

來源條目欄位（正規化資料）：
- id：article-2
- articleNumber：2
- displayNumber：第 2 條
- title：None
- structureId：chapter-1
- metadata：{"source": "全國法規資料庫 性別平等教育法（PDF：法規-性別平等教育法.pdf）", "lastModified": "2023-08-16"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   本法所稱主管機關：在中央為教育部；在直轄市為直轄市政府；在縣（市）為縣（市）政府。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   本法所定事項，於軍事學校、預備學校、警察各級學校及少年矯正學校辦理時，以其所屬主管機關為本法所稱主管機關。"
  },
  {
    "type": "paragraph",
    "number": "3",
    "text": "3   本法所定事項涉及各目的事業主管機關業務時，各該機關應配合辦理。"
  }
]
```

## U02-A3｜第 3 條

本法用詞，定義如下：
一、性別平等教育：指以教育方式教導尊重多元性別差異，消除性別歧視，促進性別地位之實質平等。
二、學校、教師、職員、工友及學生：
（一）學校：指公私立各級學校、軍事學校、預備學校、警察各級學校及少年矯正學校。
（二）教師：指專任教師、兼任教師、代理教師、代課教師、教官、運用於協助教學之志願服務人員、實際執行教學之教育實習人員、實習場域之實習指導人員及其他執行教學或研究之人員。
（三）職員、工友：指前目教師以外，固定、定期執行學校事務人員、運用於協助學校事務之志願服務人員、學生事務創新人員及其他經中央主管機關指定者。
（四）學生：指具有學籍、學制轉銜期間未具學籍者、接受進修推廣教育者、交換學生、教育實習學生或研修生及其他經中央主管機關指定者。
三、校園性別事件：指事件之一方為學校校長、教師、職員、工友或學生，他方為學生，並有下列情形之一者：
（一）性侵害：指性侵害犯罪防治法所稱性侵害犯罪之行為。
（二）性騷擾：指符合下列情形之一，且未達性侵害之程度者：1.以明示或暗示之方式，從事不受歡迎且與性或性別有關之言詞或行為，致影響他人之人格尊嚴、學習、或工作之機會或表現者。2.以性或性別有關之行為，作為自己或他人獲得、喪失或減損其學習或工作有關權益之條件者。
（三）性霸凌：指透過語言、肢體或其他暴力，對於他人之性別特徵、性別特質、性傾向或性別認同進行貶抑、攻擊或威脅之行為且非屬性騷擾者。
（四）校長或教職員工違反與性或性別有關之專業倫理行為：指校長或教職員工與未成年學生發展親密關係，或利用不對等之權勢關係，於執行教學、指導、訓練、評鑑、管理、輔導學生或提供學生工作機會時，在與性或性別有關之人際互動上，發展有違專業倫理之關係。
四、性別認同：指個人對自我歸屬性別之認知及接受。

來源條目欄位（正規化資料）：
- id：article-3
- articleNumber：3
- displayNumber：第 3 條
- title：None
- structureId：chapter-1
- metadata：{"source": "全國法規資料庫 性別平等教育法（PDF：法規-性別平等教育法.pdf）", "lastModified": "2023-08-16"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": null,
    "text": "本法用詞，定義如下："
  },
  {
    "type": "item",
    "number": "一",
    "text": "一、性別平等教育：指以教育方式教導尊重多元性別差異，消除性別歧視，促進性別地位之實質平等。"
  },
  {
    "type": "item",
    "number": "二",
    "text": "二、學校、教師、職員、工友及學生："
  },
  {
    "type": "subitem",
    "number": "一",
    "text": "（一）學校：指公私立各級學校、軍事學校、預備學校、警察各級學校及少年矯正學校。"
  },
  {
    "type": "subitem",
    "number": "二",
    "text": "（二）教師：指專任教師、兼任教師、代理教師、代課教師、教官、運用於協助教學之志願服務人員、實際執行教學之教育實習人員、實習場域之實習指導人員及其他執行教學或研究之人員。"
  },
  {
    "type": "subitem",
    "number": "三",
    "text": "（三）職員、工友：指前目教師以外，固定、定期執行學校事務人員、運用於協助學校事務之志願服務人員、學生事務創新人員及其他經中央主管機關指定者。"
  },
  {
    "type": "subitem",
    "number": "四",
    "text": "（四）學生：指具有學籍、學制轉銜期間未具學籍者、接受進修推廣教育者、交換學生、教育實習學生或研修生及其他經中央主管機關指定者。"
  },
  {
    "type": "item",
    "number": "三",
    "text": "三、校園性別事件：指事件之一方為學校校長、教師、職員、工友或學生，他方為學生，並有下列情形之一者："
  },
  {
    "type": "subitem",
    "number": "一",
    "text": "（一）性侵害：指性侵害犯罪防治法所稱性侵害犯罪之行為。"
  },
  {
    "type": "subitem",
    "number": "二",
    "text": "（二）性騷擾：指符合下列情形之一，且未達性侵害之程度者：1.以明示或暗示之方式，從事不受歡迎且與性或性別有關之言詞或行為，致影響他人之人格尊嚴、學習、或工作之機會或表現者。2.以性或性別有關之行為，作為自己或他人獲得、喪失或減損其學習或工作有關權益之條件者。"
  },
  {
    "type": "subitem",
    "number": "三",
    "text": "（三）性霸凌：指透過語言、肢體或其他暴力，對於他人之性別特徵、性別特質、性傾向或性別認同進行貶抑、攻擊或威脅之行為且非屬性騷擾者。"
  },
  {
    "type": "subitem",
    "number": "四",
    "text": "（四）校長或教職員工違反與性或性別有關之專業倫理行為：指校長或教職員工與未成年學生發展親密關係，或利用不對等之權勢關係，於執行教學、指導、訓練、評鑑、管理、輔導學生或提供學生工作機會時，在與性或性別有關之人際互動上，發展有違專業倫理之關係。"
  },
  {
    "type": "item",
    "number": "四",
    "text": "四、性別認同：指個人對自我歸屬性別之認知及接受。"
  }
]
```

## U02-A4｜第 4 條

中央主管機關應設性別平等教育委員會，其任務如下：
一、研擬全國性之性別平等教育相關法規、政策及年度實施計畫。
二、協調及整合相關資源，協助並補助地方主管機關及所主管學校、社教機構落實性別平等教育之實施與發展。
三、督導考核地方主管機關及所主管學校、社教機構性別平等教育相關工作之實施。
四、推動性別平等教育之課程、教學、評量與相關問題之研究與發展。
五、規劃及辦理性別平等教育人員之培訓。
六、提供性別平等教育相關事項之諮詢服務及調查、處理與本法有關之案件。
七、推動全國性有關性別平等之家庭教育及社會教育。
八、其他關於全國性之性別平等教育事務。

來源條目欄位（正規化資料）：
- id：article-4
- articleNumber：4
- displayNumber：第 4 條
- title：None
- structureId：chapter-1
- metadata：{"source": "全國法規資料庫 性別平等教育法（PDF：法規-性別平等教育法.pdf）", "lastModified": "2023-08-16"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": null,
    "text": "中央主管機關應設性別平等教育委員會，其任務如下："
  },
  {
    "type": "item",
    "number": "一",
    "text": "一、研擬全國性之性別平等教育相關法規、政策及年度實施計畫。"
  },
  {
    "type": "item",
    "number": "二",
    "text": "二、協調及整合相關資源，協助並補助地方主管機關及所主管學校、社教機構落實性別平等教育之實施與發展。"
  },
  {
    "type": "item",
    "number": "三",
    "text": "三、督導考核地方主管機關及所主管學校、社教機構性別平等教育相關工作之實施。"
  },
  {
    "type": "item",
    "number": "四",
    "text": "四、推動性別平等教育之課程、教學、評量與相關問題之研究與發展。"
  },
  {
    "type": "item",
    "number": "五",
    "text": "五、規劃及辦理性別平等教育人員之培訓。"
  },
  {
    "type": "item",
    "number": "六",
    "text": "六、提供性別平等教育相關事項之諮詢服務及調查、處理與本法有關之案件。"
  },
  {
    "type": "item",
    "number": "七",
    "text": "七、推動全國性有關性別平等之家庭教育及社會教育。"
  },
  {
    "type": "item",
    "number": "八",
    "text": "八、其他關於全國性之性別平等教育事務。"
  }
]
```

## U02-A5｜第 5 條

1   直轄市、縣（市）主管機關應設性別平等教育委員會，其任務如下：
一、研擬地方之性別平等教育相關法規、政策及年度實施計畫。
二、協調及整合相關資源，並協助所主管學校、社教機構落實性別平等教育之實施與發展。
三、督導考核所主管學校、社教機構性別平等教育相關工作之實施。
四、推動性別平等教育之課程、教學、評量及相關問題之研究發展。
五、提供所主管學校、社教機構性別平等教育相關事項之諮詢服務及調查、處理與本法有關之案件。
六、辦理所主管學校教育人員及相關人員之在職進修。
七、推動地方有關性別平等之家庭教育及社會教育。
八、其他關於地方之性別平等教育事務。
2   軍事學校、預備學校、警察各級學校及少年矯正學校之主管機關應設性別平等教育委員會，其任務如下：
一、提供相關資源，協助所主管學校落實性別平等教育之實施及發展。
二、督導考核所主管學校性別平等教育相關工作之實施。
三、前條第五款、第六款及其他關於所主管學校之性別平等教育事務。

來源條目欄位（正規化資料）：
- id：article-5
- articleNumber：5
- displayNumber：第 5 條
- title：None
- structureId：chapter-1
- metadata：{"source": "全國法規資料庫 性別平等教育法（PDF：法規-性別平等教育法.pdf）", "lastModified": "2023-08-16"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   直轄市、縣（市）主管機關應設性別平等教育委員會，其任務如下："
  },
  {
    "type": "item",
    "number": "一",
    "text": "一、研擬地方之性別平等教育相關法規、政策及年度實施計畫。"
  },
  {
    "type": "item",
    "number": "二",
    "text": "二、協調及整合相關資源，並協助所主管學校、社教機構落實性別平等教育之實施與發展。"
  },
  {
    "type": "item",
    "number": "三",
    "text": "三、督導考核所主管學校、社教機構性別平等教育相關工作之實施。"
  },
  {
    "type": "item",
    "number": "四",
    "text": "四、推動性別平等教育之課程、教學、評量及相關問題之研究發展。"
  },
  {
    "type": "item",
    "number": "五",
    "text": "五、提供所主管學校、社教機構性別平等教育相關事項之諮詢服務及調查、處理與本法有關之案件。"
  },
  {
    "type": "item",
    "number": "六",
    "text": "六、辦理所主管學校教育人員及相關人員之在職進修。"
  },
  {
    "type": "item",
    "number": "七",
    "text": "七、推動地方有關性別平等之家庭教育及社會教育。"
  },
  {
    "type": "item",
    "number": "八",
    "text": "八、其他關於地方之性別平等教育事務。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   軍事學校、預備學校、警察各級學校及少年矯正學校之主管機關應設性別平等教育委員會，其任務如下："
  },
  {
    "type": "item",
    "number": "一",
    "text": "一、提供相關資源，協助所主管學校落實性別平等教育之實施及發展。"
  },
  {
    "type": "item",
    "number": "二",
    "text": "二、督導考核所主管學校性別平等教育相關工作之實施。"
  },
  {
    "type": "item",
    "number": "三",
    "text": "三、前條第五款、第六款及其他關於所主管學校之性別平等教育事務。"
  }
]
```

## U02-A6｜第 6 條

學校應設性別平等教育委員會，其任務如下：
一、統整學校各單位相關資源，擬訂性別平等教育實施計畫，落實並檢視其實施成果。
二、規劃或辦理學生、教職員工及家長性別平等教育相關活動。
三、研發並推廣性別平等教育之課程、教學及評量。
四、研擬性別平等教育實施與校園性別事件之防治規定，建立機制，並協調及整合相關資源。
五、調查及處理與本法有關之案件。
六、規劃及建立性別平等之安全校園空間。
七、推動社區有關性別平等之家庭教育與社會教育。
八、其他關於學校或社區之性別平等教育事務。

來源條目欄位（正規化資料）：
- id：article-6
- articleNumber：6
- displayNumber：第 6 條
- title：None
- structureId：chapter-1
- metadata：{"source": "全國法規資料庫 性別平等教育法（PDF：法規-性別平等教育法.pdf）", "lastModified": "2023-08-16"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": null,
    "text": "學校應設性別平等教育委員會，其任務如下："
  },
  {
    "type": "item",
    "number": "一",
    "text": "一、統整學校各單位相關資源，擬訂性別平等教育實施計畫，落實並檢視其實施成果。"
  },
  {
    "type": "item",
    "number": "二",
    "text": "二、規劃或辦理學生、教職員工及家長性別平等教育相關活動。"
  },
  {
    "type": "item",
    "number": "三",
    "text": "三、研發並推廣性別平等教育之課程、教學及評量。"
  },
  {
    "type": "item",
    "number": "四",
    "text": "四、研擬性別平等教育實施與校園性別事件之防治規定，建立機制，並協調及整合相關資源。"
  },
  {
    "type": "item",
    "number": "五",
    "text": "五、調查及處理與本法有關之案件。"
  },
  {
    "type": "item",
    "number": "六",
    "text": "六、規劃及建立性別平等之安全校園空間。"
  },
  {
    "type": "item",
    "number": "七",
    "text": "七、推動社區有關性別平等之家庭教育與社會教育。"
  },
  {
    "type": "item",
    "number": "八",
    "text": "八、其他關於學校或社區之性別平等教育事務。"
  }
]
```

## U02-A7｜第 7 條

1   中央主管機關之性別平等教育委員會，置委員十七人至二十三人，採任期制，以教育部部長為主任委員，委員應具性別平等意識，且不得有違反性別平等之行為，其中女性委員應占委員總數二分之一以上；性別平等教育相關領域之專家學者、民間團體代表、學生代表及實務工作者之委員合計，應占委員總數三分之二以上。
2   前項性別平等教育委員會每三個月應至少開會一次，並應由專人處理有關業務；其組織、會議、委員資格、任期、解聘事由、解聘程序及其他相關事項之辦法，由中央主管機關定之。

來源條目欄位（正規化資料）：
- id：article-7
- articleNumber：7
- displayNumber：第 7 條
- title：None
- structureId：chapter-1
- metadata：{"source": "全國法規資料庫 性別平等教育法（PDF：法規-性別平等教育法.pdf）", "lastModified": "2023-08-16"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   中央主管機關之性別平等教育委員會，置委員十七人至二十三人，採任期制，以教育部部長為主任委員，委員應具性別平等意識，且不得有違反性別平等之行為，其中女性委員應占委員總數二分之一以上；性別平等教育相關領域之專家學者、民間團體代表、學生代表及實務工作者之委員合計，應占委員總數三分之二以上。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   前項性別平等教育委員會每三個月應至少開會一次，並應由專人處理有關業務；其組織、會議、委員資格、任期、解聘事由、解聘程序及其他相關事項之辦法，由中央主管機關定之。"
  }
]
```

## U02-A8｜第 8 條

1   直轄市、縣（市）主管機關之性別平等教育委員會，置委員九人至二十三人，採任期制，以直轄市、縣（市）首長為主任委員，委員應具性別平等意識，且不得有違反性別平等之行為，其中女性委員應占委員總數二分之一以上；性別平等教育相關領域專家學者、民間團體代表、學生代表及實務工作者之委員合計，應占委員總數三分之一以上。
2   前項性別平等教育委員會每三個月應至少開會一次，並應由專人處理有關業務；其組織、會議、委員資格、任期、解聘事由、解聘程序及其他相關事項之準則，由中央主管機關定之；直轄市、縣（市）主管機關應依準則，訂定所設性別平等教育委員會相關自治法規。
3   軍事學校、預備學校、警察各級學校及少年矯正學校主管機關之性別平等教育委員會，置委員九人至二十三人，採任期制，以學校主管機關首長為主任委員，委員應具性別平等意識，且不得有違反性別平等之行為，其中女性委員應占委員總數二分之一以上；性別平等教育相關領域專家學者之委員，應占委員總數二分之一以上。
4   前項性別平等教育委員會每三個月應至少開會一次，並應由專人處理有關業務；其組織、會議、委員資格、任期、解聘事由、解聘程序、得委任所屬機關辦理之事項及其他相關事項之辦法，由學校主管機關定之。

來源條目欄位（正規化資料）：
- id：article-8
- articleNumber：8
- displayNumber：第 8 條
- title：None
- structureId：chapter-1
- metadata：{"source": "全國法規資料庫 性別平等教育法（PDF：法規-性別平等教育法.pdf）", "lastModified": "2023-08-16"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   直轄市、縣（市）主管機關之性別平等教育委員會，置委員九人至二十三人，採任期制，以直轄市、縣（市）首長為主任委員，委員應具性別平等意識，且不得有違反性別平等之行為，其中女性委員應占委員總數二分之一以上；性別平等教育相關領域專家學者、民間團體代表、學生代表及實務工作者之委員合計，應占委員總數三分之一以上。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   前項性別平等教育委員會每三個月應至少開會一次，並應由專人處理有關業務；其組織、會議、委員資格、任期、解聘事由、解聘程序及其他相關事項之準則，由中央主管機關定之；直轄市、縣（市）主管機關應依準則，訂定所設性別平等教育委員會相關自治法規。"
  },
  {
    "type": "paragraph",
    "number": "3",
    "text": "3   軍事學校、預備學校、警察各級學校及少年矯正學校主管機關之性別平等教育委員會，置委員九人至二十三人，採任期制，以學校主管機關首長為主任委員，委員應具性別平等意識，且不得有違反性別平等之行為，其中女性委員應占委員總數二分之一以上；性別平等教育相關領域專家學者之委員，應占委員總數二分之一以上。"
  },
  {
    "type": "paragraph",
    "number": "4",
    "text": "4   前項性別平等教育委員會每三個月應至少開會一次，並應由專人處理有關業務；其組織、會議、委員資格、任期、解聘事由、解聘程序、得委任所屬機關辦理之事項及其他相關事項之辦法，由學校主管機關定之。"
  }
]
```

## U02-A9｜第 9 條

1   學校之性別平等教育委員會，置委員五人至二十一人，採任期制，以校長為主任委員，委員應具性別平等意識，且不得有違反性別平等之行為，其中女性委員應占委員總數二分之一以上，並得聘教師代表、職工代表、家長代表、學生代表及性別平等教育相關領域之專家學者為委員。
2   前項性別平等教育委員會每學期應至少開會一次，並應由專人處理有關業務；其組織、會議、委員資格、任期、解聘事由、解聘程序及其他相關事項之準則，由中央主管機關定之；學校應依準則，訂定所設性別平等教育委員會相關規定。

來源條目欄位（正規化資料）：
- id：article-9
- articleNumber：9
- displayNumber：第 9 條
- title：None
- structureId：chapter-1
- metadata：{"source": "全國法規資料庫 性別平等教育法（PDF：法規-性別平等教育法.pdf）", "lastModified": "2023-08-16"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   學校之性別平等教育委員會，置委員五人至二十一人，採任期制，以校長為主任委員，委員應具性別平等意識，且不得有違反性別平等之行為，其中女性委員應占委員總數二分之一以上，並得聘教師代表、職工代表、家長代表、學生代表及性別平等教育相關領域之專家學者為委員。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   前項性別平等教育委員會每學期應至少開會一次，並應由專人處理有關業務；其組織、會議、委員資格、任期、解聘事由、解聘程序及其他相關事項之準則，由中央主管機關定之；學校應依準則，訂定所設性別平等教育委員會相關規定。"
  }
]
```

## U02-A10｜第 10 條

主管機關及學校每年應參考所設之性別平等教育委員會所擬各項實施方案編列經費預算。

來源條目欄位（正規化資料）：
- id：article-10
- articleNumber：10
- displayNumber：第 10 條
- title：None
- structureId：chapter-1
- metadata：{"source": "全國法規資料庫 性別平等教育法（PDF：法規-性別平等教育法.pdf）", "lastModified": "2023-08-16"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": null,
    "text": "主管機關及學校每年應參考所設之性別平等教育委員會所擬各項實施方案編列經費預算。"
  }
]
```

## U02-A11｜第 11 條

主管機關應督導考核所主管學校、社教機構或下級機關辦理性別平等教育相關工作，並提供必要之協助；其績效優良者，應給予獎勵，績效不良者，應予糾正並輔導改進。

來源條目欄位（正規化資料）：
- id：article-11
- articleNumber：11
- displayNumber：第 11 條
- title：None
- structureId：chapter-1
- metadata：{"source": "全國法規資料庫 性別平等教育法（PDF：法規-性別平等教育法.pdf）", "lastModified": "2023-08-16"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": null,
    "text": "主管機關應督導考核所主管學校、社教機構或下級機關辦理性別平等教育相關工作，並提供必要之協助；其績效優良者，應給予獎勵，績效不良者，應予糾正並輔導改進。"
  }
]
```

## U02-A12｜第 12 條

1   學校應提供性別平等之學習環境，尊重及考量學生與教職員工之不同性別、性別特質、性別認同或性傾向，並建立安全之校園空間。
2   學校應訂定性別平等教育實施規定，並公告周知。

來源條目欄位（正規化資料）：
- id：article-12
- articleNumber：12
- displayNumber：第 12 條
- title：None
- structureId：chapter-2
- metadata：{"source": "全國法規資料庫 性別平等教育法（PDF：法規-性別平等教育法.pdf）", "lastModified": "2023-08-16"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   學校應提供性別平等之學習環境，尊重及考量學生與教職員工之不同性別、性別特質、性別認同或性傾向，並建立安全之校園空間。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   學校應訂定性別平等教育實施規定，並公告周知。"
  }
]
```

## U02-A13｜第 13 條

學校之招生及就學許可不得有性別、性別特質、性別認同或性傾向之差別待遇。但基於歷史傳統、特定教育目標或其他非因性別因素之正當理由，經該管主管機關核准而設置之學校、班級、課程者，不在此限。

來源條目欄位（正規化資料）：
- id：article-13
- articleNumber：13
- displayNumber：第 13 條
- title：None
- structureId：chapter-2
- metadata：{"source": "全國法規資料庫 性別平等教育法（PDF：法規-性別平等教育法.pdf）", "lastModified": "2023-08-16"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": null,
    "text": "學校之招生及就學許可不得有性別、性別特質、性別認同或性傾向之差別待遇。但基於歷史傳統、特定教育目標或其他非因性別因素之正當理由，經該管主管機關核准而設置之學校、班級、課程者，不在此限。"
  }
]
```

## U02-A14｜第 14 條

1   學校不得因學生之性別、性別特質、性別認同或性傾向而給予教學、活動、評量、獎懲、福利及服務上之差別待遇。但性質僅適合特定性別、性別特質、性別認同或性傾向者，不在此限。
2   學校應對因性別、性別特質、性別認同或性傾向而處於不利處境之學生積極提供協助，以改善其處境。

來源條目欄位（正規化資料）：
- id：article-14
- articleNumber：14
- displayNumber：第 14 條
- title：None
- structureId：chapter-2
- metadata：{"source": "全國法規資料庫 性別平等教育法（PDF：法規-性別平等教育法.pdf）", "lastModified": "2023-08-16"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   學校不得因學生之性別、性別特質、性別認同或性傾向而給予教學、活動、評量、獎懲、福利及服務上之差別待遇。但性質僅適合特定性別、性別特質、性別認同或性傾向者，不在此限。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   學校應對因性別、性別特質、性別認同或性傾向而處於不利處境之學生積極提供協助，以改善其處境。"
  }
]
```

## U02-A15｜第 15 條

學校應積極維護懷孕學生之受教權，並提供必要之協助。

來源條目欄位（正規化資料）：
- id：article-15
- articleNumber：15
- displayNumber：第 15 條
- title：None
- structureId：chapter-2
- metadata：{"source": "全國法規資料庫 性別平等教育法（PDF：法規-性別平等教育法.pdf）", "lastModified": "2023-08-16"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": null,
    "text": "學校應積極維護懷孕學生之受教權，並提供必要之協助。"
  }
]
```

## U02-A16｜第 16 條

教職員工之職前教育、新進人員培訓、在職進修及教育行政主管人員之儲訓課程，應納入性別平等教育之內容；其中師資培育之大學之教育專業課程，應有性別平等教育相關課程。

來源條目欄位（正規化資料）：
- id：article-16
- articleNumber：16
- displayNumber：第 16 條
- title：None
- structureId：chapter-2
- metadata：{"source": "全國法規資料庫 性別平等教育法（PDF：法規-性別平等教育法.pdf）", "lastModified": "2023-08-16"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": null,
    "text": "教職員工之職前教育、新進人員培訓、在職進修及教育行政主管人員之儲訓課程，應納入性別平等教育之內容；其中師資培育之大學之教育專業課程，應有性別平等教育相關課程。"
  }
]
```

## U02-A17｜第 17 條

學校之考績委員會、申訴評議委員會、教師評審委員會及主管機關之教師申訴評議委員會之組成，任一性別委員應占委員總數三分之一以上。但學校之考績委員會及教師評審委員會因該校任一性別教師人數少於委員總數三分之一者，不在此限。

來源條目欄位（正規化資料）：
- id：article-17
- articleNumber：17
- displayNumber：第 17 條
- title：None
- structureId：chapter-2
- metadata：{"source": "全國法規資料庫 性別平等教育法（PDF：法規-性別平等教育法.pdf）", "lastModified": "2023-08-16"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": null,
    "text": "學校之考績委員會、申訴評議委員會、教師評審委員會及主管機關之教師申訴評議委員會之組成，任一性別委員應占委員總數三分之一以上。但學校之考績委員會及教師評審委員會因該校任一性別教師人數少於委員總數三分之一者，不在此限。"
  }
]
```

## U02-A18｜第 18 條

1   學校之課程設置及活動設計，應鼓勵學生發揮潛能，不得因性別而有差別待遇。
2   國民中小學除應將性別平等教育融入課程外，每學期應實施性別平等教育相關課程或活動至少四小時。
3   高級中等學校及專科學校五年制前三年應將性別平等教育融入課程。
4   大專校院應廣開性別研究相關課程。
5   學校應發展符合性別平等之課程規劃與評量方式。

來源條目欄位（正規化資料）：
- id：article-18
- articleNumber：18
- displayNumber：第 18 條
- title：None
- structureId：chapter-3
- metadata：{"source": "全國法規資料庫 性別平等教育法（PDF：法規-性別平等教育法.pdf）", "lastModified": "2023-08-16"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   學校之課程設置及活動設計，應鼓勵學生發揮潛能，不得因性別而有差別待遇。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   國民中小學除應將性別平等教育融入課程外，每學期應實施性別平等教育相關課程或活動至少四小時。"
  },
  {
    "type": "paragraph",
    "number": "3",
    "text": "3   高級中等學校及專科學校五年制前三年應將性別平等教育融入課程。"
  },
  {
    "type": "paragraph",
    "number": "4",
    "text": "4   大專校院應廣開性別研究相關課程。"
  },
  {
    "type": "paragraph",
    "number": "5",
    "text": "5   學校應發展符合性別平等之課程規劃與評量方式。"
  }
]
```

## U02-A19｜第 19 條

學校教材之編寫、審查及選用，應符合性別平等教育原則；教材內容應平衡反映不同性別之歷史貢獻及生活經驗，並呈現多元之性別觀點。

來源條目欄位（正規化資料）：
- id：article-19
- articleNumber：19
- displayNumber：第 19 條
- title：None
- structureId：chapter-3
- metadata：{"source": "全國法規資料庫 性別平等教育法（PDF：法規-性別平等教育法.pdf）", "lastModified": "2023-08-16"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": null,
    "text": "學校教材之編寫、審查及選用，應符合性別平等教育原則；教材內容應平衡反映不同性別之歷史貢獻及生活經驗，並呈現多元之性別觀點。"
  }
]
```

## U02-A20｜第 20 條

1   教師使用教材及從事教育活動時，應具備性別平等意識，破除性別刻板印象，避免性別偏見及性別歧視。
2   教師應鼓勵學生修習非傳統性別之學科領域。

來源條目欄位（正規化資料）：
- id：article-20
- articleNumber：20
- displayNumber：第 20 條
- title：None
- structureId：chapter-3
- metadata：{"source": "全國法規資料庫 性別平等教育法（PDF：法規-性別平等教育法.pdf）", "lastModified": "2023-08-16"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   教師使用教材及從事教育活動時，應具備性別平等意識，破除性別刻板印象，避免性別偏見及性別歧視。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   教師應鼓勵學生修習非傳統性別之學科領域。"
  }
]
```

## U02-A21｜第 21 條

1   為預防與處理校園性別事件，中央主管機關應訂定校園性別事件之防治準則；其內容應包括學校安全規劃、校內外教學與活動及人際互動注意事項、校長及教職員工與性或性別有關專業倫理事項、主動迴避陳報事項、校園性別事件之處理機制、程序及救濟方法。
2   學校應依前項準則訂定防治規定，並公告周知；高級中等以上學校應依前項訂定相關規定或專業倫理規範，並公告周知。
3   學校應積極推動校園性別事件之防治教育，以提升學校校長、教師、職員、工友及學生尊重他人與自己性或身體自主之知能，每年定期舉辦校園性別事件防治之教育宣導活動，並評鑑其實施成效。

來源條目欄位（正規化資料）：
- id：article-21
- articleNumber：21
- displayNumber：第 21 條
- title：None
- structureId：chapter-4
- metadata：{"source": "全國法規資料庫 性別平等教育法（PDF：法規-性別平等教育法.pdf）", "lastModified": "2023-08-16"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   為預防與處理校園性別事件，中央主管機關應訂定校園性別事件之防治準則；其內容應包括學校安全規劃、校內外教學與活動及人際互動注意事項、校長及教職員工與性或性別有關專業倫理事項、主動迴避陳報事項、校園性別事件之處理機制、程序及救濟方法。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   學校應依前項準則訂定防治規定，並公告周知；高級中等以上學校應依前項訂定相關規定或專業倫理規範，並公告周知。"
  },
  {
    "type": "paragraph",
    "number": "3",
    "text": "3   學校應積極推動校園性別事件之防治教育，以提升學校校長、教師、職員、工友及學生尊重他人與自己性或身體自主之知能，每年定期舉辦校園性別事件防治之教育宣導活動，並評鑑其實施成效。"
  }
]
```

## U02-A22｜第 22 條

1   學校校長、教師、職員或工友知悉服務學校發生疑似校園性別事件，應立即通報學校防治規定所定學校權責人員，並由學校權責人員依下列規定辦理，至遲不得超過二十四小時：
一、向學校主管機關通報。
二、依性侵害犯罪防治法、兒童及少年福利與權益保障法、身心障礙者權益保障法及其他相關法律規定向當地直轄市、縣（市）社政主管機關通報。
2   學校校長、教師、職員或工友不得偽造、變造、湮滅或隱匿他人所犯校園性別事件之證據。
3   學校或主管機關處理校園性別事件，應將該事件交由所設之性別平等教育委員會調查處理，任何人不得另設調查機制，違反者其調查無效。

來源條目欄位（正規化資料）：
- id：article-22
- articleNumber：22
- displayNumber：第 22 條
- title：None
- structureId：chapter-4
- metadata：{"source": "全國法規資料庫 性別平等教育法（PDF：法規-性別平等教育法.pdf）", "lastModified": "2023-08-16"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   學校校長、教師、職員或工友知悉服務學校發生疑似校園性別事件，應立即通報學校防治規定所定學校權責人員，並由學校權責人員依下列規定辦理，至遲不得超過二十四小時："
  },
  {
    "type": "item",
    "number": "一",
    "text": "一、向學校主管機關通報。"
  },
  {
    "type": "item",
    "number": "二",
    "text": "二、依性侵害犯罪防治法、兒童及少年福利與權益保障法、身心障礙者權益保障法及其他相關法律規定向當地直轄市、縣（市）社政主管機關通報。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   學校校長、教師、職員或工友不得偽造、變造、湮滅或隱匿他人所犯校園性別事件之證據。"
  },
  {
    "type": "paragraph",
    "number": "3",
    "text": "3   學校或主管機關處理校園性別事件，應將該事件交由所設之性別平等教育委員會調查處理，任何人不得另設調查機制，違反者其調查無效。"
  }
]
```

## U02-A23｜第 23 條

1   學校或主管機關調查處理校園性別事件時，應秉持客觀、公正、專業之原則，給予雙方當事人充分陳述意見及答辯之機會。但應避免重複詢問。
2   當事人及檢舉人之姓名或其他足以辨識身分之資料，除有調查之必要或基於公共安全之考量者外，應予保密。

來源條目欄位（正規化資料）：
- id：article-23
- articleNumber：23
- displayNumber：第 23 條
- title：None
- structureId：chapter-4
- metadata：{"source": "全國法規資料庫 性別平等教育法（PDF：法規-性別平等教育法.pdf）", "lastModified": "2023-08-16"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   學校或主管機關調查處理校園性別事件時，應秉持客觀、公正、專業之原則，給予雙方當事人充分陳述意見及答辯之機會。但應避免重複詢問。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   當事人及檢舉人之姓名或其他足以辨識身分之資料，除有調查之必要或基於公共安全之考量者外，應予保密。"
  }
]
```

## U02-A24｜第 24 條

學校或主管機關於調查處理校園性別事件期間，應採取必要之處置，以保障當事人之受教權或工作權，且不得運用不對等之權力與地位，對被害人有足以影響其受教權、工作權或申請調查之行為。

來源條目欄位（正規化資料）：
- id：article-24
- articleNumber：24
- displayNumber：第 24 條
- title：None
- structureId：chapter-4
- metadata：{"source": "全國法規資料庫 性別平等教育法（PDF：法規-性別平等教育法.pdf）", "lastModified": "2023-08-16"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": null,
    "text": "學校或主管機關於調查處理校園性別事件期間，應採取必要之處置，以保障當事人之受教權或工作權，且不得運用不對等之權力與地位，對被害人有足以影響其受教權、工作權或申請調查之行為。"
  }
]
```

## U02-A25｜第 25 條

1   學校或主管機關處理校園性別事件，應告知當事人及其法定代理人或實際照顧者其得主張之權益及各種救濟途徑，或轉介至相關機構處理，並依其需求，提供心理諮商與輔導等各類專業服務，必要時，應提供保護措施、法律協助、社會福利資源轉介服務或其他協助；對檢舉人有受侵害之虞者，並應提供必要之保護措施或其他協助。
2   前項心理諮商與輔導、保護措施、法律協助或其他協助，學校或主管機關得委請醫師、臨床心理師、諮商心理師、社會工作師或律師等專業人員為之。
3   學生為性侵害、性騷擾或性霸凌事件被害人，而非屬本法適用範圍者，學生所屬學校得準用前二項規定辦理。

來源條目欄位（正規化資料）：
- id：article-25
- articleNumber：25
- displayNumber：第 25 條
- title：None
- structureId：chapter-4
- metadata：{"source": "全國法規資料庫 性別平等教育法（PDF：法規-性別平等教育法.pdf）", "lastModified": "2023-08-16"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   學校或主管機關處理校園性別事件，應告知當事人及其法定代理人或實際照顧者其得主張之權益及各種救濟途徑，或轉介至相關機構處理，並依其需求，提供心理諮商與輔導等各類專業服務，必要時，應提供保護措施、法律協助、社會福利資源轉介服務或其他協助；對檢舉人有受侵害之虞者，並應提供必要之保護措施或其他協助。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   前項心理諮商與輔導、保護措施、法律協助或其他協助，學校或主管機關得委請醫師、臨床心理師、諮商心理師、社會工作師或律師等專業人員為之。"
  },
  {
    "type": "paragraph",
    "number": "3",
    "text": "3   學生為性侵害、性騷擾或性霸凌事件被害人，而非屬本法適用範圍者，學生所屬學校得準用前二項規定辦理。"
  }
]
```

## U02-A26｜第 26 條

1   校園性別事件經學校或主管機關調查屬實後，應依相關法律或法規規定自行或將行為人移送其他權責機關，予以申誡、記過、解聘、停聘、不續聘、免職、終止契約關係、終止運用關係或其他適當之懲處。
2   學校、主管機關或其他權責機關為校園性別事件之懲處時，應命行為人接受心理諮商與輔導之處置，並得命其為下列一款或數款之處置。但終身不得聘任、任用、進用或運用之人員，不在此限：
一、經被害人、其法定代理人或實際照顧者之同意，向被害人道歉。法定代理人或實際照顧者同意時，應以兒童及少年之最佳利益為優先考量，並依其心智成熟程度權衡其意見。
二、接受八小時之性別平等教育相關課程。
三、其他符合教育目的之措施。
3   前項心理諮商與輔導，學校或主管機關得委請醫師、臨床心理師、諮商心理師、社會工作師等專業人員為之。
4   校園性騷擾、性霸凌、校長或教職員工違反與性或性別有關之專業倫理行為情節輕微者，學校、主管機關或其他權責機關得僅依第二項規定為必要之處置。
5   第一項懲處涉及行為人身分之改變時，應給予其書面陳述意見之機會。
6   第二項之處置，應由該懲處之學校或主管機關執行，執行時並應採取必要之措施，以確保行為人之配合遵守。
7   第二項第一款之處置，當事人均為學生時，學校得善用修復式正義或其他輔導策略，促進修復關係。

來源條目欄位（正規化資料）：
- id：article-26
- articleNumber：26
- displayNumber：第 26 條
- title：None
- structureId：chapter-4
- metadata：{"source": "全國法規資料庫 性別平等教育法（PDF：法規-性別平等教育法.pdf）", "lastModified": "2023-08-16"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   校園性別事件經學校或主管機關調查屬實後，應依相關法律或法規規定自行或將行為人移送其他權責機關，予以申誡、記過、解聘、停聘、不續聘、免職、終止契約關係、終止運用關係或其他適當之懲處。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   學校、主管機關或其他權責機關為校園性別事件之懲處時，應命行為人接受心理諮商與輔導之處置，並得命其為下列一款或數款之處置。但終身不得聘任、任用、進用或運用之人員，不在此限："
  },
  {
    "type": "item",
    "number": "一",
    "text": "一、經被害人、其法定代理人或實際照顧者之同意，向被害人道歉。法定代理人或實際照顧者同意時，應以兒童及少年之最佳利益為優先考量，並依其心智成熟程度權衡其意見。"
  },
  {
    "type": "item",
    "number": "二",
    "text": "二、接受八小時之性別平等教育相關課程。"
  },
  {
    "type": "item",
    "number": "三",
    "text": "三、其他符合教育目的之措施。"
  },
  {
    "type": "paragraph",
    "number": "3",
    "text": "3   前項心理諮商與輔導，學校或主管機關得委請醫師、臨床心理師、諮商心理師、社會工作師等專業人員為之。"
  },
  {
    "type": "paragraph",
    "number": "4",
    "text": "4   校園性騷擾、性霸凌、校長或教職員工違反與性或性別有關之專業倫理行為情節輕微者，學校、主管機關或其他權責機關得僅依第二項規定為必要之處置。"
  },
  {
    "type": "paragraph",
    "number": "5",
    "text": "5   第一項懲處涉及行為人身分之改變時，應給予其書面陳述意見之機會。"
  },
  {
    "type": "paragraph",
    "number": "6",
    "text": "6   第二項之處置，應由該懲處之學校或主管機關執行，執行時並應採取必要之措施，以確保行為人之配合遵守。"
  },
  {
    "type": "paragraph",
    "number": "7",
    "text": "7   第二項第一款之處置，當事人均為學生時，學校得善用修復式正義或其他輔導策略，促進修復關係。"
  }
]
```

## U02-A27｜第 27 條

學校或主管機關調查校園性別事件過程中，得視情況就相關事項、處理方式及原則予以說明，並得於事件處理完成後，經被害人、其法定代理人或實際照顧者之同意，將事件之有無、樣態及處理方式予以公布。但不得揭露當事人之姓名或其他足以識別其身分之資料。

來源條目欄位（正規化資料）：
- id：article-27
- articleNumber：27
- displayNumber：第 27 條
- title：None
- structureId：chapter-4
- metadata：{"source": "全國法規資料庫 性別平等教育法（PDF：法規-性別平等教育法.pdf）", "lastModified": "2023-08-16"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": null,
    "text": "學校或主管機關調查校園性別事件過程中，得視情況就相關事項、處理方式及原則予以說明，並得於事件處理完成後，經被害人、其法定代理人或實際照顧者之同意，將事件之有無、樣態及處理方式予以公布。但不得揭露當事人之姓名或其他足以識別其身分之資料。"
  }
]
```

## U02-A28｜第 28 條

1   學校或主管機關應建立校園性別事件之檔案資料。
2   行為人如為學生者，轉至其他學校就讀時，主管機關及原就讀之學校認為有追蹤輔導之必要者，應於知悉後一個月內，通報行為人次一就讀之學校。
3   行為人為學生以外者，轉至其他學校服務時，主管機關及原服務之學校應追蹤輔導，並應通報行為人次一服務之學校。
4   接獲前二項通報之學校，應對行為人實施必要之追蹤輔導，非有正當理由，不得公布行為人之姓名或其他足以識別其身分之資料。
5   第一項檔案資料之建立、保存方式、保存年限、銷毀、運用與第二項及第三項之通報及其他相關事項，於依第二十一條第一項所定防治準則定之。

來源條目欄位（正規化資料）：
- id：article-28
- articleNumber：28
- displayNumber：第 28 條
- title：None
- structureId：chapter-4
- metadata：{"source": "全國法規資料庫 性別平等教育法（PDF：法規-性別平等教育法.pdf）", "lastModified": "2023-08-16"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   學校或主管機關應建立校園性別事件之檔案資料。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   行為人如為學生者，轉至其他學校就讀時，主管機關及原就讀之學校認為有追蹤輔導之必要者，應於知悉後一個月內，通報行為人次一就讀之學校。"
  },
  {
    "type": "paragraph",
    "number": "3",
    "text": "3   行為人為學生以外者，轉至其他學校服務時，主管機關及原服務之學校應追蹤輔導，並應通報行為人次一服務之學校。"
  },
  {
    "type": "paragraph",
    "number": "4",
    "text": "4   接獲前二項通報之學校，應對行為人實施必要之追蹤輔導，非有正當理由，不得公布行為人之姓名或其他足以識別其身分之資料。"
  },
  {
    "type": "paragraph",
    "number": "5",
    "text": "5   第一項檔案資料之建立、保存方式、保存年限、銷毀、運用與第二項及第三項之通報及其他相關事項，於依第二十一條第一項所定防治準則定之。"
  }
]
```

## U02-A29｜第 29 條

1   學校聘任、任用之教育人員或進用、運用之其他人員，經學校性別平等教育委員會或依法組成之相關委員會調查確認有下列各款情形之一者，學校應予解聘、免職、終止契約關係或終止運用關係：
一、有性侵害行為，或有終身不得聘任、任用、進用或運用必要之性騷擾、性霸凌、校長或教職員工違反與性或性別有關之專業倫理行為。
二、有性騷擾、性霸凌、校長或教職員工違反與性或性別有關之專業倫理行為，而有必要予以解聘、免職、終止契約關係或終止運用關係，並經審酌案件情節，議決一年至四年不得聘任、任用、進用或運用。
2   有前項第一款情事者，各級學校均不得聘任、任用、進用或運用，已聘任、任用、進用或運用者，學校應予解聘、免職、終止契約關係或終止運用關係；有前項第二款情事者，於該議決一年至四年不得聘任、任用、進用或運用期間，亦同。
3   非屬依第一項規定予以解聘、免職、終止契約關係或終止運用關係之人員，有性侵害行為或有終身不得聘任、任用、進用或運用必要之性騷擾、性霸凌、校長或教職員工違反與性或性別有關之專業倫理、違反兒童及少年性交易防制條例、兒童及少年性剝削防制條例之行為，經學校性別平等教育委員會查證屬實者，不得聘任、任用、進用或運用；已聘任、任用、進用或運用者，學校應予解聘、免職、終止契約關係或終止運用關係；非屬終身不得聘任、任用、進用或運用必要之性騷擾、性霸凌、校長或教職員工違反與性或性別有關之專業倫理、違反兒童及少年性交易防制條例、兒童及少年性剝削防制條例之行為，經學校性別平等教育委員會查證屬實並議決一年至四年不得聘任、任用、進用或運用者，於該議決期間，亦同。

來源條目欄位（正規化資料）：
- id：article-29
- articleNumber：29
- displayNumber：第 29 條
- title：None
- structureId：chapter-4
- metadata：{"source": "全國法規資料庫 性別平等教育法（PDF：法規-性別平等教育法.pdf）", "lastModified": "2023-08-16"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   學校聘任、任用之教育人員或進用、運用之其他人員，經學校性別平等教育委員會或依法組成之相關委員會調查確認有下列各款情形之一者，學校應予解聘、免職、終止契約關係或終止運用關係："
  },
  {
    "type": "item",
    "number": "一",
    "text": "一、有性侵害行為，或有終身不得聘任、任用、進用或運用必要之性騷擾、性霸凌、校長或教職員工違反與性或性別有關之專業倫理行為。"
  },
  {
    "type": "item",
    "number": "二",
    "text": "二、有性騷擾、性霸凌、校長或教職員工違反與性或性別有關之專業倫理行為，而有必要予以解聘、免職、終止契約關係或終止運用關係，並經審酌案件情節，議決一年至四年不得聘任、任用、進用或運用。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   有前項第一款情事者，各級學校均不得聘任、任用、進用或運用，已聘任、任用、進用或運用者，學校應予解聘、免職、終止契約關係或終止運用關係；有前項第二款情事者，於該議決一年至四年不得聘任、任用、進用或運用期間，亦同。"
  },
  {
    "type": "paragraph",
    "number": "3",
    "text": "3   非屬依第一項規定予以解聘、免職、終止契約關係或終止運用關係之人員，有性侵害行為或有終身不得聘任、任用、進用或運用必要之性騷擾、性霸凌、校長或教職員工違反與性或性別有關之專業倫理、違反兒童及少年性交易防制條例、兒童及少年性剝削防制條例之行為，經學校性別平等教育委員會查證屬實者，不得聘任、任用、進用或運用；已聘任、任用、進用或運用者，學校應予解聘、免職、終止契約關係或終止運用關係；非屬終身不得聘任、任用、進用或運用必要之性騷擾、性霸凌、校長或教職員工違反與性或性別有關之專業倫理、違反兒童及少年性交易防制條例、兒童及少年性剝削防制條例之行為，經學校性別平等教育委員會查證屬實並議決一年至四年不得聘任、任用、進用或運用者，於該議決期間，亦同。"
  }
]
```

## U02-A30｜第 30 條

1   有前條各項情事者，主管機關及學校應辦理通報、資訊之蒐集及查詢。
2   學校聘任、任用教育人員或進用、運用其他人員前，應依性侵害犯罪防治法之規定，查詢其有無性侵害之犯罪紀錄，及依第四項所定辦法查詢是否曾有性侵害、性騷擾、性霸凌、校長或教職員工違反與性或性別有關之專業倫理、違反兒童及少年性交易防制條例、兒童及少年性剝削防制條例之行為；已聘任、任用、進用或運用者，應定期查詢。
3   主管機關協助學校辦理前項查詢，得使用中央社政主管機關建立之依兒童及少年性剝削防制條例，或性騷擾防治法第二十七條規定，受行政處罰者之資料，及中央勞工主管機關依性別平等工作法建立性騷擾防治事件之資料。
4   前三項之通報、資訊之蒐集、查詢、處理、利用及其他相關事項之辦法，由中央主管機關定之。
5   前條各項之人員適用教師法、教育人員任用條例、公務人員相關法律或陸海空軍相關法律者，其解聘、停聘、免職、撤職、停職或退伍，依各該法律規定辦理，並適用前四項規定；其未解聘、免職、撤職或退伍者，應調離學校現職。
6   前項以外人員，涉有前條第一項或第三項情形，於調查期間，學校或主管機關應經性別平等教育委員會決議令其暫時停職；停職原因消滅後復職者，其未發給之薪資應依相關規定予以補發。

來源條目欄位（正規化資料）：
- id：article-30
- articleNumber：30
- displayNumber：第 30 條
- title：None
- structureId：chapter-4
- metadata：{"source": "全國法規資料庫 性別平等教育法（PDF：法規-性別平等教育法.pdf）", "lastModified": "2023-08-16"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   有前條各項情事者，主管機關及學校應辦理通報、資訊之蒐集及查詢。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   學校聘任、任用教育人員或進用、運用其他人員前，應依性侵害犯罪防治法之規定，查詢其有無性侵害之犯罪紀錄，及依第四項所定辦法查詢是否曾有性侵害、性騷擾、性霸凌、校長或教職員工違反與性或性別有關之專業倫理、違反兒童及少年性交易防制條例、兒童及少年性剝削防制條例之行為；已聘任、任用、進用或運用者，應定期查詢。"
  },
  {
    "type": "paragraph",
    "number": "3",
    "text": "3   主管機關協助學校辦理前項查詢，得使用中央社政主管機關建立之依兒童及少年性剝削防制條例，或性騷擾防治法第二十七條規定，受行政處罰者之資料，及中央勞工主管機關依性別平等工作法建立性騷擾防治事件之資料。"
  },
  {
    "type": "paragraph",
    "number": "4",
    "text": "4   前三項之通報、資訊之蒐集、查詢、處理、利用及其他相關事項之辦法，由中央主管機關定之。"
  },
  {
    "type": "paragraph",
    "number": "5",
    "text": "5   前條各項之人員適用教師法、教育人員任用條例、公務人員相關法律或陸海空軍相關法律者，其解聘、停聘、免職、撤職、停職或退伍，依各該法律規定辦理，並適用前四項規定；其未解聘、免職、撤職或退伍者，應調離學校現職。"
  },
  {
    "type": "paragraph",
    "number": "6",
    "text": "6   前項以外人員，涉有前條第一項或第三項情形，於調查期間，學校或主管機關應經性別平等教育委員會決議令其暫時停職；停職原因消滅後復職者，其未發給之薪資應依相關規定予以補發。"
  }
]
```

## U02-A31｜第 31 條

1   校園性別事件之被害人、其法定代理人或實際照顧者得以書面向行為人所屬學校申請調查。但行為人現為或曾為學校之校長時，應向學校主管機關申請調查。
2   任何人知悉前項之事件時，得依其規定程序向學校或主管機關檢舉之。
3   學校及主管機關不得因被害人或任何人申請調查、檢舉或協助他人申請調查、檢舉，而予以不利之處分或措施。

來源條目欄位（正規化資料）：
- id：article-31
- articleNumber：31
- displayNumber：第 31 條
- title：None
- structureId：chapter-5
- metadata：{"source": "全國法規資料庫 性別平等教育法（PDF：法規-性別平等教育法.pdf）", "lastModified": "2023-08-16"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   校園性別事件之被害人、其法定代理人或實際照顧者得以書面向行為人所屬學校申請調查。但行為人現為或曾為學校之校長時，應向學校主管機關申請調查。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   任何人知悉前項之事件時，得依其規定程序向學校或主管機關檢舉之。"
  },
  {
    "type": "paragraph",
    "number": "3",
    "text": "3   學校及主管機關不得因被害人或任何人申請調查、檢舉或協助他人申請調查、檢舉，而予以不利之處分或措施。"
  }
]
```

## U02-A32｜第 32 條

1   學校或主管機關於接獲調查申請或檢舉時，應於二十日內以書面通知申請人、被害人或檢舉人是否受理。
2   學校或主管機關於接獲調查申請或檢舉時，有下列情形之一者，應不予受理：
一、非屬本法所規定之事項者。
二、申請人或檢舉人未具真實姓名。
三、同一事件已處理完畢者。
3   前項不受理之書面通知，應敘明理由。
4   申請人、被害人或檢舉人於第一項之期限內未收到通知或接獲不受理通知之次日起二十日內，得以書面具明理由，向學校或主管機關申復。

來源條目欄位（正規化資料）：
- id：article-32
- articleNumber：32
- displayNumber：第 32 條
- title：None
- structureId：chapter-5
- metadata：{"source": "全國法規資料庫 性別平等教育法（PDF：法規-性別平等教育法.pdf）", "lastModified": "2023-08-16"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   學校或主管機關於接獲調查申請或檢舉時，應於二十日內以書面通知申請人、被害人或檢舉人是否受理。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   學校或主管機關於接獲調查申請或檢舉時，有下列情形之一者，應不予受理："
  },
  {
    "type": "item",
    "number": "一",
    "text": "一、非屬本法所規定之事項者。"
  },
  {
    "type": "item",
    "number": "二",
    "text": "二、申請人或檢舉人未具真實姓名。"
  },
  {
    "type": "item",
    "number": "三",
    "text": "三、同一事件已處理完畢者。"
  },
  {
    "type": "paragraph",
    "number": "3",
    "text": "3   前項不受理之書面通知，應敘明理由。"
  },
  {
    "type": "paragraph",
    "number": "4",
    "text": "4   申請人、被害人或檢舉人於第一項之期限內未收到通知或接獲不受理通知之次日起二十日內，得以書面具明理由，向學校或主管機關申復。"
  }
]
```

## U02-A33｜第 33 條

1   學校或主管機關接獲前條第一項之申請或檢舉後，除有前條第二項所定事由外，應於三日內交由所設之性別平等教育委員會調查處理。
2   學校或主管機關之性別平等教育委員會處理前項事件時，得成立調查小組調查之；必要時，調查小組成員得一部或全部外聘，但行為人為校長、教師、職員或工友者，應成立調查小組，且其成員應全部外聘。本法於中華民國一百零七年十二月三十日修正生效前，調查小組成員全部外聘者，其組成及完成之調查報告均為合法。
3   調查小組成員應具性別平等意識，女性成員不得少於成員總數二分之一，且其成員中具校園性別事件調查專業素養之專家學者人數，於學校應占成員總數三分之一以上，於主管機關應占成員總數二分之一以上，成員資格由中央主管機關另定之。
4   校園性別事件當事人分屬不同學校時，前項調查小組成員，應有被害人現所屬學校之代表。但被害人、其法定代理人或實際照顧者要求不得通知被害人現就讀學校，且經性別平等教育委員會認定無通知必要者，不在此限。
5   性別平等教育委員會或調查小組依本法規定進行調查時，行為人、申請人及受邀協助調查之人或單位，應予配合，並提供相關資料，不得規避、妨礙或拒絕。
6   行政程序法有關管轄、移送、迴避、送達、補正等相關規定，於本法適用或準用之。

來源條目欄位（正規化資料）：
- id：article-33
- articleNumber：33
- displayNumber：第 33 條
- title：None
- structureId：chapter-5
- metadata：{"source": "全國法規資料庫 性別平等教育法（PDF：法規-性別平等教育法.pdf）", "lastModified": "2023-08-16"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   學校或主管機關接獲前條第一項之申請或檢舉後，除有前條第二項所定事由外，應於三日內交由所設之性別平等教育委員會調查處理。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   學校或主管機關之性別平等教育委員會處理前項事件時，得成立調查小組調查之；必要時，調查小組成員得一部或全部外聘，但行為人為校長、教師、職員或工友者，應成立調查小組，且其成員應全部外聘。本法於中華民國一百零七年十二月三十日修正生效前，調查小組成員全部外聘者，其組成及完成之調查報告均為合法。"
  },
  {
    "type": "paragraph",
    "number": "3",
    "text": "3   調查小組成員應具性別平等意識，女性成員不得少於成員總數二分之一，且其成員中具校園性別事件調查專業素養之專家學者人數，於學校應占成員總數三分之一以上，於主管機關應占成員總數二分之一以上，成員資格由中央主管機關另定之。"
  },
  {
    "type": "paragraph",
    "number": "4",
    "text": "4   校園性別事件當事人分屬不同學校時，前項調查小組成員，應有被害人現所屬學校之代表。但被害人、其法定代理人或實際照顧者要求不得通知被害人現就讀學校，且經性別平等教育委員會認定無通知必要者，不在此限。"
  },
  {
    "type": "paragraph",
    "number": "5",
    "text": "5   性別平等教育委員會或調查小組依本法規定進行調查時，行為人、申請人及受邀協助調查之人或單位，應予配合，並提供相關資料，不得規避、妨礙或拒絕。"
  },
  {
    "type": "paragraph",
    "number": "6",
    "text": "6   行政程序法有關管轄、移送、迴避、送達、補正等相關規定，於本法適用或準用之。"
  }
]
```

## U02-A34｜第 34 條

1   性別平等教育委員會之調查處理，不受該事件司法程序進行之影響。
2   性別平等教育委員會為調查處理時，應衡酌雙方當事人之權力差距。
3   調查發現行為人於不同學校有發生疑似校園性別事件之虞，應就行為人發生疑似行為之時間、樣態等，通知其現職及曾服務之學校配合進行事件普查，被通知學校不得拒絕。
4   調查發現同一行為人對不同被害人有發生疑似校園性別事件時，得併案調查。

來源條目欄位（正規化資料）：
- id：article-34
- articleNumber：34
- displayNumber：第 34 條
- title：None
- structureId：chapter-5
- metadata：{"source": "全國法規資料庫 性別平等教育法（PDF：法規-性別平等教育法.pdf）", "lastModified": "2023-08-16"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   性別平等教育委員會之調查處理，不受該事件司法程序進行之影響。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   性別平等教育委員會為調查處理時，應衡酌雙方當事人之權力差距。"
  },
  {
    "type": "paragraph",
    "number": "3",
    "text": "3   調查發現行為人於不同學校有發生疑似校園性別事件之虞，應就行為人發生疑似行為之時間、樣態等，通知其現職及曾服務之學校配合進行事件普查，被通知學校不得拒絕。"
  },
  {
    "type": "paragraph",
    "number": "4",
    "text": "4   調查發現同一行為人對不同被害人有發生疑似校園性別事件時，得併案調查。"
  }
]
```

## U02-A35｜第 35 條

1   學校校長涉及校園性別事件，經學校主管機關所設之性別平等教育委員會認情節重大，有於調查期間先行調整或停止其職務之必要者，得由學校主管機關調整或停止其職務。但校長為軍職人員者，依陸海空軍軍官士官任職條例及相關規定辦理。
2   依前項規定停職之人員，其校園性別事件之調查結果未認定所涉行為屬實，或經認定所涉行為屬實但未依公務人員、教育人員或其他相關法律予以停職、免職、解聘、停聘或不續聘者，得依本法或其他法律申請復職，及補發停職期間之本俸（薪）、年功俸（薪）或相當之給與。
3   學校及主管機關於知悉校長、學校聘任或任用之教職員、公務人員或軍職人員涉有校園性別事件，且依法辦理其停聘、解聘、不續聘、移送懲戒、送請監察院審查、依法核予停職或免職期間，不得受理其退休（伍）或資遣案之申請。

來源條目欄位（正規化資料）：
- id：article-35
- articleNumber：35
- displayNumber：第 35 條
- title：None
- structureId：chapter-5
- metadata：{"source": "全國法規資料庫 性別平等教育法（PDF：法規-性別平等教育法.pdf）", "lastModified": "2023-08-16"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   學校校長涉及校園性別事件，經學校主管機關所設之性別平等教育委員會認情節重大，有於調查期間先行調整或停止其職務之必要者，得由學校主管機關調整或停止其職務。但校長為軍職人員者，依陸海空軍軍官士官任職條例及相關規定辦理。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   依前項規定停職之人員，其校園性別事件之調查結果未認定所涉行為屬實，或經認定所涉行為屬實但未依公務人員、教育人員或其他相關法律予以停職、免職、解聘、停聘或不續聘者，得依本法或其他法律申請復職，及補發停職期間之本俸（薪）、年功俸（薪）或相當之給與。"
  },
  {
    "type": "paragraph",
    "number": "3",
    "text": "3   學校及主管機關於知悉校長、學校聘任或任用之教職員、公務人員或軍職人員涉有校園性別事件，且依法辦理其停聘、解聘、不續聘、移送懲戒、送請監察院審查、依法核予停職或免職期間，不得受理其退休（伍）或資遣案之申請。"
  }
]
```

## U02-A36｜第 36 條

1   學校或主管機關性別平等教育委員會應於受理申請或檢舉後二個月內完成調查。必要時，得延長之，延長以二次為限，每次不得逾一個月，並應通知申請人、被害人、檢舉人及行為人。
2   性別平等教育委員會調查完成後，應將調查報告及處理建議，以書面向其所屬學校或主管機關提出報告。
3   學校或主管機關應於接獲前項調查報告後二個月內，自行或移送相關權責機關依本法或相關法律或法規規定議處，並將處理之結果，以書面載明事實及理由通知申請人、被害人、檢舉人及行為人。
4   學校或主管機關為前項議處前，得要求性別平等教育委員會之代表列席說明。

來源條目欄位（正規化資料）：
- id：article-36
- articleNumber：36
- displayNumber：第 36 條
- title：None
- structureId：chapter-5
- metadata：{"source": "全國法規資料庫 性別平等教育法（PDF：法規-性別平等教育法.pdf）", "lastModified": "2023-08-16"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   學校或主管機關性別平等教育委員會應於受理申請或檢舉後二個月內完成調查。必要時，得延長之，延長以二次為限，每次不得逾一個月，並應通知申請人、被害人、檢舉人及行為人。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   性別平等教育委員會調查完成後，應將調查報告及處理建議，以書面向其所屬學校或主管機關提出報告。"
  },
  {
    "type": "paragraph",
    "number": "3",
    "text": "3   學校或主管機關應於接獲前項調查報告後二個月內，自行或移送相關權責機關依本法或相關法律或法規規定議處，並將處理之結果，以書面載明事實及理由通知申請人、被害人、檢舉人及行為人。"
  },
  {
    "type": "paragraph",
    "number": "4",
    "text": "4   學校或主管機關為前項議處前，得要求性別平等教育委員會之代表列席說明。"
  }
]
```

## U02-A37｜第 37 條

1   申請人、被害人及行為人對於前條第三項處理之結果有不服者，得於收到書面通知次日起三十日內，以書面具明理由向學校或主管機關申復。但行為人為校長、教師、職員或工友者，申請人或被害人得逕向主管機關申復。
2   前項申復以一次為限。
3   學校或主管機關經申復審議結果發現調查程序有重大瑕疵或有足以影響原調查認定之新事實、新證據時，得要求性別平等教育委員會重新調查；屬依第一項但書向主管機關申復者，應限期於四十日內完成調查。
4   主管機關經依第一項但書申復審議結果發現，學校之處理結果，有違法或不當，必要時，得依所設性別平等教育委員會之處理建議，對學校之處理結果，逕行改核或敘明理由交回學校依法處理，並追究相關人員責任。

來源條目欄位（正規化資料）：
- id：article-37
- articleNumber：37
- displayNumber：第 37 條
- title：None
- structureId：chapter-5
- metadata：{"source": "全國法規資料庫 性別平等教育法（PDF：法規-性別平等教育法.pdf）", "lastModified": "2023-08-16"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   申請人、被害人及行為人對於前條第三項處理之結果有不服者，得於收到書面通知次日起三十日內，以書面具明理由向學校或主管機關申復。但行為人為校長、教師、職員或工友者，申請人或被害人得逕向主管機關申復。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   前項申復以一次為限。"
  },
  {
    "type": "paragraph",
    "number": "3",
    "text": "3   學校或主管機關經申復審議結果發現調查程序有重大瑕疵或有足以影響原調查認定之新事實、新證據時，得要求性別平等教育委員會重新調查；屬依第一項但書向主管機關申復者，應限期於四十日內完成調查。"
  },
  {
    "type": "paragraph",
    "number": "4",
    "text": "4   主管機關經依第一項但書申復審議結果發現，學校之處理結果，有違法或不當，必要時，得依所設性別平等教育委員會之處理建議，對學校之處理結果，逕行改核或敘明理由交回學校依法處理，並追究相關人員責任。"
  }
]
```

## U02-A38｜第 38 條

性別平等教育委員會於接獲前條學校或主管機關重新調查之要求時，應另組調查小組；其調查處理程序，依本法之相關規定。

來源條目欄位（正規化資料）：
- id：article-38
- articleNumber：38
- displayNumber：第 38 條
- title：None
- structureId：chapter-5
- metadata：{"source": "全國法規資料庫 性別平等教育法（PDF：法規-性別平等教育法.pdf）", "lastModified": "2023-08-16"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": null,
    "text": "性別平等教育委員會於接獲前條學校或主管機關重新調查之要求時，應另組調查小組；其調查處理程序，依本法之相關規定。"
  }
]
```

## U02-A39｜第 39 條

1   申請人、被害人或行為人對學校或主管機關之申復結果不服，得於接獲書面通知之次日起三十日內，依下列規定提起救濟。但法律別有規定者，從其規定：
一、學校校長、教師：依教師法或相關法規之規定。
二、公立學校依公務人員任用法任用之職員及中華民國七十四年五月三日教育人員任用條例施行前未納入銓敘之職員：依公務人員保障法之規定。
三、學校學生：依規定向所屬學校提起申訴。
2   前項救濟，應俟申復決定作成後，始得提起。

來源條目欄位（正規化資料）：
- id：article-39
- articleNumber：39
- displayNumber：第 39 條
- title：None
- structureId：chapter-5
- metadata：{"source": "全國法規資料庫 性別平等教育法（PDF：法規-性別平等教育法.pdf）", "lastModified": "2023-08-16"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   申請人、被害人或行為人對學校或主管機關之申復結果不服，得於接獲書面通知之次日起三十日內，依下列規定提起救濟。但法律別有規定者，從其規定："
  },
  {
    "type": "item",
    "number": "一",
    "text": "一、學校校長、教師：依教師法或相關法規之規定。"
  },
  {
    "type": "item",
    "number": "二",
    "text": "二、公立學校依公務人員任用法任用之職員及中華民國七十四年五月三日教育人員任用條例施行前未納入銓敘之職員：依公務人員保障法之規定。"
  },
  {
    "type": "item",
    "number": "三",
    "text": "三、學校學生：依規定向所屬學校提起申訴。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   前項救濟，應俟申復決定作成後，始得提起。"
  }
]
```

## U02-A40｜第 40 條

1   學校主管機關於學校調查處理校園性別事件時，應對學校提供諮詢服務、輔導協助、適法監督或予以糾正。
2   學校主管機關認學校性別平等教育委員會未依法召開會議、召開會議後應審議而未審議、調查有程序或實體瑕疵，或調查處理結果有適法疑義時，於學校申復程序完成前發現，應敘明理由，通知學校於申復程序中合併處理；未及於申復程序中合併處理，或屆申復期限未提出申復，應敘明理由，限期交回學校性別平等教育委員會審議。
3   主管機關依前項規定交回學校性別平等教育委員會審議後，學校性別平等教育委員會屆期未依法審議、審議結果仍有違法或不當之虞者，主管機關得敘明理由逕行提交所設性別平等教育委員會審議，其決議視同學校性別平等教育委員會之決議。
4   有前項情事之學校，經主管機關審議認有違失者，主管機關應納入學校評鑑、扣減獎（補）助或行政考核之依據，並追究相關人員責任。

來源條目欄位（正規化資料）：
- id：article-40
- articleNumber：40
- displayNumber：第 40 條
- title：None
- structureId：chapter-5
- metadata：{"source": "全國法規資料庫 性別平等教育法（PDF：法規-性別平等教育法.pdf）", "lastModified": "2023-08-16"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   學校主管機關於學校調查處理校園性別事件時，應對學校提供諮詢服務、輔導協助、適法監督或予以糾正。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   學校主管機關認學校性別平等教育委員會未依法召開會議、召開會議後應審議而未審議、調查有程序或實體瑕疵，或調查處理結果有適法疑義時，於學校申復程序完成前發現，應敘明理由，通知學校於申復程序中合併處理；未及於申復程序中合併處理，或屆申復期限未提出申復，應敘明理由，限期交回學校性別平等教育委員會審議。"
  },
  {
    "type": "paragraph",
    "number": "3",
    "text": "3   主管機關依前項規定交回學校性別平等教育委員會審議後，學校性別平等教育委員會屆期未依法審議、審議結果仍有違法或不當之虞者，主管機關得敘明理由逕行提交所設性別平等教育委員會審議，其決議視同學校性別平等教育委員會之決議。"
  },
  {
    "type": "paragraph",
    "number": "4",
    "text": "4   有前項情事之學校，經主管機關審議認有違失者，主管機關應納入學校評鑑、扣減獎（補）助或行政考核之依據，並追究相關人員責任。"
  }
]
```

## U02-A41｜第 41 條

1   學校及主管機關對於與本法事件有關之事實認定，應依據其所設性別平等教育委員會之調查報告。
2   法院對於前項事實之認定，應審酌各級性別平等教育委員會之調查報告。

來源條目欄位（正規化資料）：
- id：article-41
- articleNumber：41
- displayNumber：第 41 條
- title：None
- structureId：chapter-5
- metadata：{"source": "全國法規資料庫 性別平等教育法（PDF：法規-性別平等教育法.pdf）", "lastModified": "2023-08-16"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   學校及主管機關對於與本法事件有關之事實認定，應依據其所設性別平等教育委員會之調查報告。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   法院對於前項事實之認定，應審酌各級性別平等教育委員會之調查報告。"
  }
]
```

## U02-A42｜第 42 條

1   校園性別事件之行為人為學校校長、教師、職員或工友，學生因該事件受有損害者，行為人應負損害賠償責任。
2   前項情形，雖非財產上之損害，亦得請求賠償相當之金額，其名譽被侵害者，並得請求回復名譽之適當處分。
3   依前二項規定負損害賠償責任，法院並得因被害人之請求，依侵害情節，酌定損害額一倍至三倍之懲罰性賠償金；行為人為校長者，得酌定損害額三倍至五倍之懲罰性賠償金。

來源條目欄位（正規化資料）：
- id：article-42
- articleNumber：42
- displayNumber：第 42 條
- title：None
- structureId：chapter-5
- metadata：{"source": "全國法規資料庫 性別平等教育法（PDF：法規-性別平等教育法.pdf）", "lastModified": "2023-08-16"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   校園性別事件之行為人為學校校長、教師、職員或工友，學生因該事件受有損害者，行為人應負損害賠償責任。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   前項情形，雖非財產上之損害，亦得請求賠償相當之金額，其名譽被侵害者，並得請求回復名譽之適當處分。"
  },
  {
    "type": "paragraph",
    "number": "3",
    "text": "3   依前二項規定負損害賠償責任，法院並得因被害人之請求，依侵害情節，酌定損害額一倍至三倍之懲罰性賠償金；行為人為校長者，得酌定損害額三倍至五倍之懲罰性賠償金。"
  }
]
```

## U02-A43｜第 43 條

1   學校校長、教師、職員或工友有下列情形之一者，處新臺幣三萬元以上十五萬元以下罰鍰：
一、無正當理由，違反第二十二條第一項規定，未於二十四小時內，向學校權責人員或學校主管機關通報。
二、違反第二十二條第二項規定，偽造、變造、湮滅或隱匿他人所犯校園性騷擾、性霸凌、校長或教職員工違反與性或性別有關之專業倫理事件之證據。
2   學校違反第二十二條第三項、第二十三條第二項、第二十四條後段、第二十七條但書、第二十八條第四項或第三十一條第三項規定者，處新臺幣一萬元以上十五萬元以下罰鍰；其他人員違反者，亦同。
3   學校違反第十三條、第十四條、第十五條、第十七條或第二十一條第二項規定者，處新臺幣一萬元以上十萬元以下罰鍰。
4   行為人違反第二十六條第六項不配合執行第二項序文、第二款、第三款之處置，或第三十三條第五項不配合調查，而無正當理由者，由學校報請主管機關處新臺幣一萬元以上五萬元以下罰鍰，並得按次處罰至其配合或提供相關資料為止。但行為人為學校校長時，由主管機關逕予處罰。
5   學校校長或學校財團法人董事怠於行使職權，致學校未依第二十六條第一項、第二項序文、第二款、第三款或第六項規定，執行行為人第二十六條第二項第一款以外之懲處或處置，或採取必要之措施確保行為人配合遵守者，處校長或董事新臺幣一萬元以上五萬元以下罰鍰。

來源條目欄位（正規化資料）：
- id：article-43
- articleNumber：43
- displayNumber：第 43 條
- title：None
- structureId：chapter-6
- metadata：{"source": "全國法規資料庫 性別平等教育法（PDF：法規-性別平等教育法.pdf）", "lastModified": "2023-08-16"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   學校校長、教師、職員或工友有下列情形之一者，處新臺幣三萬元以上十五萬元以下罰鍰："
  },
  {
    "type": "item",
    "number": "一",
    "text": "一、無正當理由，違反第二十二條第一項規定，未於二十四小時內，向學校權責人員或學校主管機關通報。"
  },
  {
    "type": "item",
    "number": "二",
    "text": "二、違反第二十二條第二項規定，偽造、變造、湮滅或隱匿他人所犯校園性騷擾、性霸凌、校長或教職員工違反與性或性別有關之專業倫理事件之證據。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   學校違反第二十二條第三項、第二十三條第二項、第二十四條後段、第二十七條但書、第二十八條第四項或第三十一條第三項規定者，處新臺幣一萬元以上十五萬元以下罰鍰；其他人員違反者，亦同。"
  },
  {
    "type": "paragraph",
    "number": "3",
    "text": "3   學校違反第十三條、第十四條、第十五條、第十七條或第二十一條第二項規定者，處新臺幣一萬元以上十萬元以下罰鍰。"
  },
  {
    "type": "paragraph",
    "number": "4",
    "text": "4   行為人違反第二十六條第六項不配合執行第二項序文、第二款、第三款之處置，或第三十三條第五項不配合調查，而無正當理由者，由學校報請主管機關處新臺幣一萬元以上五萬元以下罰鍰，並得按次處罰至其配合或提供相關資料為止。但行為人為學校校長時，由主管機關逕予處罰。"
  },
  {
    "type": "paragraph",
    "number": "5",
    "text": "5   學校校長或學校財團法人董事怠於行使職權，致學校未依第二十六條第一項、第二項序文、第二款、第三款或第六項規定，執行行為人第二十六條第二項第一款以外之懲處或處置，或採取必要之措施確保行為人配合遵守者，處校長或董事新臺幣一萬元以上五萬元以下罰鍰。"
  }
]
```

## U02-A44｜第 44 條

1   學校校長、教師、職員或工友違反第二十二條第一項所定疑似校園性侵害事件之通報規定，致再度發生校園性侵害事件；或偽造、變造、湮滅或隱匿他人所犯校園性侵害事件之證據，經學校或有關機關查證屬實者，應依法予以解聘、免職、終止契約關係或終止運用關係。
2   學校校長、教師、職員或工友，偽造、變造、湮滅或隱匿他人所犯校園性騷擾、性霸凌及校長或教職員工違反與性或性別有關之專業倫理之證據，經學校或有關機關查證屬實，有解聘、免職、終止契約關係或終止運用關係之必要者，應依相關法規辦理。
3   學校或主管機關對違反前二項規定之人員，應依法告發。

來源條目欄位（正規化資料）：
- id：article-44
- articleNumber：44
- displayNumber：第 44 條
- title：None
- structureId：chapter-6
- metadata：{"source": "全國法規資料庫 性別平等教育法（PDF：法規-性別平等教育法.pdf）", "lastModified": "2023-08-16"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": "1",
    "text": "1   學校校長、教師、職員或工友違反第二十二條第一項所定疑似校園性侵害事件之通報規定，致再度發生校園性侵害事件；或偽造、變造、湮滅或隱匿他人所犯校園性侵害事件之證據，經學校或有關機關查證屬實者，應依法予以解聘、免職、終止契約關係或終止運用關係。"
  },
  {
    "type": "paragraph",
    "number": "2",
    "text": "2   學校校長、教師、職員或工友，偽造、變造、湮滅或隱匿他人所犯校園性騷擾、性霸凌及校長或教職員工違反與性或性別有關之專業倫理之證據，經學校或有關機關查證屬實，有解聘、免職、終止契約關係或終止運用關係之必要者，應依相關法規辦理。"
  },
  {
    "type": "paragraph",
    "number": "3",
    "text": "3   學校或主管機關對違反前二項規定之人員，應依法告發。"
  }
]
```

## U02-A45｜第 45 條

性騷擾防治法第十條、第二十五條及第二十六條之規定，於本法所定校園性別事件，適用之。

來源條目欄位（正規化資料）：
- id：article-45
- articleNumber：45
- displayNumber：第 45 條
- title：None
- structureId：chapter-7
- metadata：{"source": "全國法規資料庫 性別平等教育法（PDF：法規-性別平等教育法.pdf）", "lastModified": "2023-08-16"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": null,
    "text": "性騷擾防治法第十條、第二十五條及第二十六條之規定，於本法所定校園性別事件，適用之。"
  }
]
```

## U02-A46｜第 46 條

本法中華民國一百十二年七月二十八日修正之本條文施行前，已受理之校園性別事件尚未終結者，及修正施行前已發生而於修正施行後受理者，均依修正施行後之規定終結之。但已進行之程序，其效力不受影響。

來源條目欄位（正規化資料）：
- id：article-46
- articleNumber：46
- displayNumber：第 46 條
- title：None
- structureId：chapter-7
- metadata：{"source": "全國法規資料庫 性別平等教育法（PDF：法規-性別平等教育法.pdf）", "lastModified": "2023-08-16"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": null,
    "text": "本法中華民國一百十二年七月二十八日修正之本條文施行前，已受理之校園性別事件尚未終結者，及修正施行前已發生而於修正施行後受理者，均依修正施行後之規定終結之。但已進行之程序，其效力不受影響。"
  }
]
```

## U02-A47｜第 47 條

本法施行細則，由中央主管機關定之。

來源條目欄位（正規化資料）：
- id：article-47
- articleNumber：47
- displayNumber：第 47 條
- title：None
- structureId：chapter-7
- metadata：{"source": "全國法規資料庫 性別平等教育法（PDF：法規-性別平等教育法.pdf）", "lastModified": "2023-08-16"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": null,
    "text": "本法施行細則，由中央主管機關定之。"
  }
]
```

## U02-A48｜第 48 條

本法施行日期，除第二條第二項、第三條第二款、第三款第四目、第五條第二項、第七條至第九條、第二十一條、第二十九條、第三十條、第三十三條第二項前段但書、第三項、第三十七條、第四十條、第四十四條自中華民國一百十三年三月八日施行外，自公布日施行。

來源條目欄位（正規化資料）：
- id：article-48
- articleNumber：48
- displayNumber：第 48 條
- title：None
- structureId：chapter-7
- metadata：{"source": "全國法規資料庫 性別平等教育法（PDF：法規-性別平等教育法.pdf）", "lastModified": "2023-08-16"}

來源結構內容（非新增解釋）：
```json
[
  {
    "type": "paragraph",
    "number": null,
    "text": "本法施行日期，除第二條第二項、第三條第二款、第三款第四目、第五條第二項、第七條至第九條、第二十一條、第二十九條、第三十條、第三十三條第二項前段但書、第三項、第三十七條、第四十條、第四十四條自中華民國一百十三年三月八日施行外，自公布日施行。"
  }
]
```

## 來源其他資料

- schemaVersion：1.3.0
- processing：{"normalizedBy": "ai", "processedAt": "2026-07-22T00:00:00Z", "sourceType": "document", "warnings": ["來源 PDF未印出官方法規代碼，code 依規範填「UNKNOWN」。"]}