# 01｜CIRCULAR-INDEX

資料集：CGE-NB-1.3.0.1；編製日：2026-09-09。此日期不是法律查核日。

此目錄不是函釋全文。精確文號須回讀各來源；重號及原稿年度不是不同發文年度的推論依據。


## C2004-001｜院臺教字第0930030325號

- publication_date：2004-06-29
- publication_date_raw：2004-06-29
- subject_raw：(30325-0.TIF，共一個電子檔案) 主旨：函送制定性別平等教育法條文一份，請查照。
- source_year：2004
- source_path：sources/circulars/uploaded/2004(1).md
- source_line_start：3
- source_line_end：117
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：["CQ-001"]

## C2004-002｜台訓（三）字第0930087101A號

- publication_date：2004-07-22
- publication_date_raw：2004-07-22
- subject_raw：函送奉 總統九十三年六月二十三日華總一義字第09300111761號令公布之「性別平等教育法」條文乙份（附件一），惠請轉頒所屬學校知悉，請 查照。
- source_year：2004
- source_path：sources/circulars/uploaded/2004(1).md
- source_line_start：118
- source_line_end：296
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2004-003｜台訓（三）字第0930104969號

- publication_date：2004-08-20
- publication_date_raw：2004-08-20
- subject_raw：有關本部八十六年函頒之「教育部兩性平等教育委員會設置要點」、「兩性平等教育實施方案」及「各級學校兩性平等教育實施要點」等相關規定，自即日起均予停止適用，請 查照。
- source_year：2004
- source_path：sources/circulars/uploaded/2004(1).md
- source_line_start：297
- source_line_end：311
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2004-004｜台訓（三）字第0930119614號

- publication_date：2004-09-10
- publication_date_raw：2004-09-10
- subject_raw：所送函轉所屬有關本部八十六年函頒之「教育部兩性平等教育委員會設置要點」、「兩性平等教育實施方案」及「各級學校兩性平等教育實施要點」等規定停止適用乙文，經查漏列本部函文說明三部分，爰仍請轉知所屬知悉，請 查照。
- source_year：2004
- source_path：sources/circulars/uploaded/2004(1).md
- source_line_start：312
- source_line_end：325
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2004-005｜台訓（三）字第0930109395A號

- publication_date：2004-09-29
- publication_date_raw：2004-09-29
- subject_raw：為「性別平等教育法」之公布施行，貴校依本部八十八年函頒「大專校院及國立中小學校園性騷擾及性侵害處理原則」訂定及成立之「校園性騷擾及性侵害處理與防治實施要點」及「性騷擾及性侵害處理委員會」（或小組）或相關委員會，其適用事宜之補充詳細說明，請查照。
- source_year：2004
- source_path：sources/circulars/uploaded/2004(1).md
- source_line_start：326
- source_line_end：355
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2004-006｜台訓（三）字第0930150829號

- publication_date：2004-12-03
- publication_date_raw：2004-12-03
- subject_raw：教育部 令
- source_year：2004
- source_path：sources/circulars/uploaded/2004(1).md
- source_line_start：356
- source_line_end：367
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2004-007｜台訓(三)字第0930154875號

- publication_date：2004-12-21
- publication_date_raw：2004-12-21
- subject_raw：有關 貴校請釋性騷擾事件處理及對「性別平等教育法」第三十二條疑義乙案，復如說明，請 查照。
- source_year：2004
- source_path：sources/circulars/uploaded/2004(1).md
- source_line_start：368
- source_line_end：387
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2005-001｜台訓(三)字第0940002669號

- publication_date：2005-01-21
- publication_date_raw：2005-01-21
- subject_raw：有關性別平等教育法第十六條第一項所稱學校之考績委員會，係指以教師為考核範圍之教師成績考核委員會，未含依公務人員考績法第十五條及考績委員會組織規程第二條所組成之考績委員會，請 查照。
- source_year：2005
- source_path：sources/circulars/uploaded/2005(1).md
- source_line_start：3
- source_line_end：23
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：["CQ-002"]

## C2005-002｜台訓(三)字第0940031134號

- publication_date：2005-03-17
- publication_date_raw：2005-03-17
- subject_raw：來文釋復「性別平等教育法」第16條規定之適用疑義乙節，仍請貴府依法定時限內完成教師申訴評議委員會之改組，復如說明，請 查照。
- source_year：2005
- source_path：sources/circulars/uploaded/2005(1).md
- source_line_start：24
- source_line_end：38
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2005-003｜台國(二)字第0940039183號

- publication_date：2005-03-31
- publication_date_raw：2005-03-31
- subject_raw：配合性別平等教育法之公布，原九年一貫課程「兩性教育」議題修改為「性別平等教育」議題，請 查照。
- source_year：2005
- source_path：sources/circulars/uploaded/2005(1).md
- source_line_start：39
- source_line_end：57
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2005-004｜台國(三)字第0940050598號

- publication_date：2005-04-21
- publication_date_raw：2005-04-21
- subject_raw：為加強幼稚園教職員工對「性別平等教育法」及「性騷擾防治法」之認識與了解，並落實性別平等教育，請 貴局(府)於幼稚園教師研習與園長會議中，將「性別平等教育法」及「性騷擾防治法」列為研習及宣導重點，請 查照。
- source_year：2005
- source_path：sources/circulars/uploaded/2005(1).md
- source_line_start：58
- source_line_end：69
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2005-005｜台高(二)字第0940071739號

- publication_date：2005-06-06
- publication_date_raw：2005-06-06
- subject_raw：**：請各校依性別平等教育法第14條規定，維護懷孕學生受教權，相關事宜建議納入學則等相關規範，請 查照。 **說明**
- source_year：2005
- source_path：sources/circulars/uploaded/2005(1).md
- source_line_start：70
- source_line_end：84
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2005-006｜台中(二)字第0940085358號

- publication_date：2005-07-05
- publication_date_raw：2005-07-05
- subject_raw：**：有關鼓勵各校積極落實「性別平等教育法」之精神，並促進性別地位之實質平等乙案，請 查照辦理。 **說明**
- source_year：2005
- source_path：sources/circulars/uploaded/2005(1).md
- source_line_start：85
- source_line_end：98
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2005-007｜童保字第0940053249號

- publication_date：2005-07-06
- publication_date_raw：2005-07-06
- subject_raw：**：有關大部函請釋示兒童及少年遭受性騷擾是否屬於兒童及少年福利法第34條第1項應於24小時通報之行為範疇乙案，復如說明，請 查照。 **說明**
- source_year：2005
- source_path：sources/circulars/uploaded/2005(1).md
- source_line_start：99
- source_line_end：117
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2005-008｜台學審字第0940084065號

- publication_date：2005-07-07
- publication_date_raw：2005-07-07
- subject_raw：**：有關性別平等教育法第16條校教評會任一性別委員組成規定適用疑義一案，建議依說明辦理。 **說明**
- source_year：2005
- source_path：sources/circulars/uploaded/2005(1).md
- source_line_start：118
- source_line_end：131
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2005-009｜台訓(三)字第0940094332號

- publication_date：2005-07-08
- publication_date_raw：2005-07-08
- subject_raw：**：內政部函釋示略以，「兒童及少年性騷擾事件應屬違反兒童及少年福利法第30條第14款規定行為，請督導所屬學校於知悉該等情事時應依該法規定於24小時內即時通報直轄市、縣(市)主管機關，俾及時保護遭受危害身心安全或健康兒童及少年，請 查照。」 **說明**：依內政部94年7月6日童保字第0940053249號函辦理(如附)。
- source_year：2005
- source_path：sources/circulars/uploaded/2005(1).md
- source_line_start：132
- source_line_end：143
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2005-010｜台訓(三)字第0940154767號

- publication_date：2005-11-10
- publication_date_raw：2005-11-10
- subject_raw：檢送本部「校園性侵害或性騷擾事件調查處理流程參考圖」（如附件），請參考運用並依說明事項辦理，請 查照。
- source_year：2005
- source_path：sources/circulars/uploaded/2005(1).md
- source_line_start：144
- source_line_end：161
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2006-001｜台訓(三)字第0950003798A號

- publication_date：2006-01-16
- publication_date_raw：2006-01-16
- subject_raw：為匡正稱呼女性教師為「先生」此一違反性別平權與性別主流化之作法，於公文、邀請函、信件、職務或其他聘書之製發時，請以受文者之職務稱謂或逕以「老師」、「委員」為稱謂辦理發聘，請 查照並轉知所屬。
- source_year：2006
- source_path：sources/circulars/uploaded/2006(1).md
- source_line_start：3
- source_line_end：133
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2006-002｜台人(二)字第0950030898號

- publication_date：2006-03-22
- publication_date_raw：2006-03-22
- subject_raw：重申教師涉及性騷擾或性侵害事件，致有解聘、停聘或不續聘情事時，學校相關處理作業，請 查照。
- source_year：2006
- source_path：sources/circulars/uploaded/2006(1).md
- source_line_start：134
- source_line_end：154
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2006-003｜台訓(三)字第0950054809號

- publication_date：2006-04-17
- publication_date_raw：2006-04-17
- subject_raw：本部業訂定「校園性侵害或性騷擾事件調查專業人員培訓課程」及「校園性侵害或性騷擾行為人防治教育課程」（課程總表如附件1、2），請參考運用，請 查照。
- source_year：2006
- source_path：sources/circulars/uploaded/2006(1).md
- source_line_start：155
- source_line_end：168
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2006-004｜台訓(三)字第0950056596A號

- publication_date：2006-04-18
- publication_date_raw：2006-04-18
- subject_raw：請 貴府（局）協助轉知所屬各級學校於舉辦學生選拔或甄選等類似活動前，應將相關計畫提送學校性別平等教育委員會審視，以確認活動內涵符合性別平等教育法第12條之立法意旨，請 查照。
- source_year：2006
- source_path：sources/circulars/uploaded/2006(1).md
- source_line_start：169
- source_line_end：201
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2006-005｜台訓(三)字第0950054312號

- publication_date：2006-04-21
- publication_date_raw：2006-04-21
- subject_raw：為落實兒童少年保護、家庭暴力及性侵害事件責任通報制度，請依說明事項辦理，請 查照。
- source_year：2006
- source_path：sources/circulars/uploaded/2006(1).md
- source_line_start：202
- source_line_end：216
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2006-006｜台訓(三)字第0950054859號

- publication_date：2006-04-24
- publication_date_raw：2006-04-24
- subject_raw：貴機關（學校）依兩性工作平等法或性別平等教育法處理性騷擾事件時，若其符合性騷擾防治法第12條、第24條及第25條所定情形者，請依說明辦理，請 查照。
- source_year：2006
- source_path：sources/circulars/uploaded/2006(1).md
- source_line_start：217
- source_line_end：231
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2006-007｜台訓(三)字第0950072394A號

- publication_date：2006-05-16
- publication_date_raw：2006-05-16
- subject_raw：邇來本部於督導各級學校處理校園性侵害或性騷擾事件時，發現部分共同缺失，請轉知所屬依說明辦理，請 查照。
- source_year：2006
- source_path：sources/circulars/uploaded/2006(1).md
- source_line_start：232
- source_line_end：250
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2006-008｜台訓(三)字第0950087330A號

- publication_date：2006-06-13
- publication_date_raw：2006-06-13
- subject_raw：有關校安通報涉及兒童少年保護事件(18歲以下)或安全維護事件中遭性侵害或猥褻(18歲以上)之案件，請督責所屬學校知悉該等情事時，應依法於24小時內通報轄區社政主管機關，俾及時保護學生免於遭受身心危害，請 查照。
- source_year：2006
- source_path：sources/circulars/uploaded/2006(1).md
- source_line_start：251
- source_line_end：273
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2006-009｜台人(二)字第0950120582號

- publication_date：2006-08-17
- publication_date_raw：2006-08-17
- subject_raw：內政部函，有關性騷擾事件已由加害人所屬單位調查結果成立，並已函送主管機關辦理，申訴人尚非不得撤回申訴，並應填具撤回申請書向主管機關申請撤回一案，請 查照。
- source_year：2006
- source_path：sources/circulars/uploaded/2006(1).md
- source_line_start：274
- source_line_end：289
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2006-010｜台訓(三)字第0950122279號

- publication_date：2006-08-17
- publication_date_raw：2006-08-17
- subject_raw：檢送「各級學校執行行政事務或庶務之人員適用兩性工作平等法或性騷擾防治法說明一覽表」，請惠示卓見，請查照。
- source_year：2006
- source_path：sources/circulars/uploaded/2006(1).md
- source_line_start：290
- source_line_end：337
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2006-011｜台訓(三)字第0950132320號

- publication_date：2006-09-15
- publication_date_raw：2006-09-15
- subject_raw：有關各級學校處理校園性侵害或性騷擾事件適用法律之疑義，本部說明如附件，請查照。
- source_year：2006
- source_path：sources/circulars/uploaded/2006(1).md
- source_line_start：338
- source_line_end：412
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：["CR-001"]
- quality_issue_ids：[]

## C2006-012｜台訓(三)字第0950135475號

- publication_date：2006-09-19
- publication_date_raw：2006-09-19
- subject_raw：貴校函致本部釋示性別平等教育法第31條所訂處理期間，究屬強制規定（即逾越期間對性騷擾加害人即不得處理），抑或屬訓示規定（學校縱有逾限處理，基於保護學生權益，仍得繼續處理）乙節，復如說明，請查照。
- source_year：2006
- source_path：sources/circulars/uploaded/2006(1).md
- source_line_start：413
- source_line_end：428
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2006-013｜台訓(三)字第0950143671號

- publication_date：2006-10-05
- publication_date_raw：2006-10-05
- subject_raw：貴府函請本部釋示校園中涉及性騷擾防治法第25條強制觸摸罪時之適法處理程序乙案，復如說明，請查照。
- source_year：2006
- source_path：sources/circulars/uploaded/2006(1).md
- source_line_start：429
- source_line_end：444
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2006-014｜台人(一)字第0950160137號

- publication_date：2006-11-13
- publication_date_raw：2006-11-13
- subject_raw：各級學校校長遴選委員會之組成應考量性別比例，遴選委員並應具性別平等意識，請查照。
- source_year：2006
- source_path：sources/circulars/uploaded/2006(1).md
- source_line_start：445
- source_line_end：459
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2006-015｜台訓(三)字第0950189771A號

- publication_date：2006-12-15
- publication_date_raw：2006-12-15
- subject_raw：主旨：檢送「中小學行政人員及教師性別平等教育研習課程」資料1份，請於規劃96年度性別平等教育研習計畫時確實參酌，俾完善設計課程與時數，請 查照。
- source_year：2006
- source_path：sources/circulars/uploaded/2006(1).md
- source_line_start：460
- source_line_end：629
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2007-001｜台訓(三)字第0960009278號

- publication_date：2007-01-19
- publication_date_raw：2007-01-19
- subject_raw：有關「替代役執行職務被性騷擾時，是否適用兩性工作平等法」1案，檢附行政院勞工委員會函復影本乙份(如附件)，請 查照並轉知所屬。
- source_year：2007
- source_path：sources/circulars/uploaded/2007(1).md
- source_line_start：3
- source_line_end：21
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2007-002｜台訓(三)字第0960008995號

- publication_date：2007-01-22
- publication_date_raw：2007-01-22
- subject_raw：貴府函釋「具性侵害或性騷擾事件調查專業素養之專家學者資格」案，復如說明，請 查照。
- source_year：2007
- source_path：sources/circulars/uploaded/2007(1).md
- source_line_start：22
- source_line_end：36
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2007-003｜台訓(三)字第0960009237號

- publication_date：2007-01-24
- publication_date_raw：2007-01-24
- subject_raw：有關性別平等教育法(以下簡稱性平法)第32條申復機制與第34條申訴救濟之適用疑義案，請依說明事項辦理，並請轉知業務相關人員及所屬學校。
- source_year：2007
- source_path：sources/circulars/uploaded/2007(1).md
- source_line_start：37
- source_line_end：60
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2007-004｜台訓(三)字第0960010800C號

- publication_date：2007-02-01
- publication_date_raw：2007-02-01
- subject_raw：檢送「性別平等教育法」第28條第2項及「校園性侵害或性騷擾防治準則」第10條第1項所定行為人之「所屬學校」解釋令1份如附件，請 查照。
- source_year：2007
- source_path：sources/circulars/uploaded/2007(1).md
- source_line_start：61
- source_line_end：74
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2007-005｜台訓(三)字第0960014237號

- publication_date：2007-02-02
- publication_date_raw：2007-02-02
- subject_raw：邇來發現各級學校於填列校安通報單時，將足資識別學生身分資訊詳註於通報單內，為依法善盡保密之責及確實執行通報規定，請依說明辦理，請 查照並轉知所屬。
- source_year：2007
- source_path：sources/circulars/uploaded/2007(1).md
- source_line_start：75
- source_line_end：90
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2007-006｜台訓(三)字第0960001718號

- publication_date：2007-02-06
- publication_date_raw：2007-02-06
- subject_raw：修正「教育部就各級學校處理校園性侵害或性騷擾事件適用說明一覽表」第11項所列調查費之標準案，請參酌於事件調查時據以支給相關費用，請查照並轉知所屬。
- source_year：2007
- source_path：sources/circulars/uploaded/2007(1).md
- source_line_start：91
- source_line_end：110
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：["CR-001"]
- quality_issue_ids：[]

## C2007-007｜台訓(三)字第0960031355號

- publication_date：2007-03-08
- publication_date_raw：2007-03-08
- subject_raw：為宣達加強家庭暴力防治網絡工作人員人身安全保障，並請學校研議避免教師成為性侵害加害人之相關措施乙案，請依說明事項辦理，並請轉知所屬學校或人員，請查照。
- source_year：2007
- source_path：sources/circulars/uploaded/2007(1).md
- source_line_start：111
- source_line_end：125
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2007-008｜台訓(三)字第0960053157號

- publication_date：2007-05-02
- publication_date_raw：2007-05-02
- subject_raw：貴校函釋已獲入學資格但尚未辦理註冊之新生，於期間參加系、所舉辦之活動，發生性騷擾或性侵害事件時，學校是否有權責依「性別平等教育法」（以下簡稱性平法）及「校園性侵害或性騷擾防治準則」處理乙案，復如說明，請查照。
- source_year：2007
- source_path：sources/circulars/uploaded/2007(1).md
- source_line_start：126
- source_line_end：140
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2007-009｜台訓(三)字第0960057668B號

- publication_date：2007-05-07
- publication_date_raw：2007-05-07
- subject_raw：為協助學校處理校園性侵害或性騷擾事件之行為人（教師部分）依性別平等教育法（以下簡稱性平法）第32條第1項提起申復所生之程序疑義，請依說明辦理，請查照並轉知。
- source_year：2007
- source_path：sources/circulars/uploaded/2007(1).md
- source_line_start：141
- source_line_end：159
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：["CR-002"]
- quality_issue_ids：[]

## C2007-010｜台訓(三)字第0960053159C號

- publication_date：2007-05-15
- publication_date_raw：2007-05-15
- subject_raw：保存年限：教育部 令
- source_year：2007
- source_path：sources/circulars/uploaded/2007(1).md
- source_line_start：160
- source_line_end：176
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2007-011｜台訓(三)字第0960053159D號

- publication_date：2007-05-15
- publication_date_raw：2007-05-15
- subject_raw：有關「性別平等教育法」第27條第2項加害人為學生之通報疑義，業經本部96年5月15日以台訓(三)字第0960053159C號令解釋如附影本，請 查照並轉知所屬。
- source_year：2007
- source_path：sources/circulars/uploaded/2007(1).md
- source_line_start：177
- source_line_end：198
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2007-012｜台訓(三)字第0960075387號

- publication_date：2007-05-18
- publication_date_raw：2007-05-18
- subject_raw：邇來發現貴轄學校報送兒童及少年保護校安通報案，查有共同疏誤（詳如附件），務請督促檢討改善，以確實執行通報規定，並提升所屬兒童及少年保護案件之專業知能，請 查照。
- source_year：2007
- source_path：sources/circulars/uploaded/2007(1).md
- source_line_start：199
- source_line_end：212
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2007-013｜台訓(三)字第0960096372號

- publication_date：2007-06-25
- publication_date_raw：2007-06-25
- subject_raw：為協助學校或主管機關調查處理校園性侵害或性騷擾事件，請同意轄區分局承辦相關業務員警受邀擔任該事件調查委員，惠允並請轉知下屬機關配合辦理。
- source_year：2007
- source_path：sources/circulars/uploaded/2007(1).md
- source_line_start：213
- source_line_end：231
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2007-014｜台人(二)字第0960083752號

- publication_date：2007-06-26
- publication_date_raw：2007-06-26
- subject_raw：有關教師法第14條第1項第6款所稱「有關機關」疑義一案，請 查照。
- source_year：2007
- source_path：sources/circulars/uploaded/2007(1).md
- source_line_start：232
- source_line_end：249
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2007-015｜台人（二）字第0960106621B號

- publication_date：2007-07-12
- publication_date_raw：2007-07-12
- subject_raw：教師涉及性侵害或性騷擾事件，經學校教師評審委員會依教師法相關規定審議時，有關其陳述意見（或提供書面說明）執行疑義一案，請 查照。
- source_year：2007
- source_path：sources/circulars/uploaded/2007(1).md
- source_line_start：250
- source_line_end：261
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2007-016｜台人（二）字第0960113507號

- publication_date：2007-07-24
- publication_date_raw：2007-07-24
- subject_raw：為保障私立學校教師之工作權，請依教師請假規則及兩性工作平等法相關規定，核予教師娩假、陪產假及育嬰留職停薪，請 查照轉知。
- source_year：2007
- source_path：sources/circulars/uploaded/2007(1).md
- source_line_start：262
- source_line_end：276
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2007-017｜台訓（三）字第0960115057號

- publication_date：2007-07-27
- publication_date_raw：2007-07-27
- subject_raw：為協助學校或教育主管機關調查處理校園性侵害或性騷擾事件，本部已商請內政部警政署同意，並由該署函示各直轄市、縣市警察局應同意轄區分局承辦相關業務員警受邀擔任該事件調查委員，請 查照並函轉所屬學校知照。
- source_year：2007
- source_path：sources/circulars/uploaded/2007(1).md
- source_line_start：277
- source_line_end：294
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2007-018｜台人（二）字第0960115435號

- publication_date：2007-07-31
- publication_date_raw：2007-07-31
- subject_raw：茲為避免不得任用之教師應聘擔任教職，請確依教育人員任用條例第31條規定辦理，其已任用者，應報請主管教育行政機關核准後，予以解聘，請 查照。
- source_year：2007
- source_path：sources/circulars/uploaded/2007(1).md
- source_line_start：295
- source_line_end：306
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2007-019｜台訓（三）字第0960129236號

- publication_date：2007-08-22
- publication_date_raw：2007-08-22
- subject_raw：開學在即，請學校加強規劃性別平等教育之教育及宣導計畫，以落實推動性別平等教育，請 查照並轉知所屬確實辦理。
- source_year：2007
- source_path：sources/circulars/uploaded/2007(1).md
- source_line_start：307
- source_line_end：321
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2007-020｜台人(二)字第0960135969號

- publication_date：2007-09-06
- publication_date_raw：2007-09-06
- subject_raw：有關違反兩性工作平等法事件，其加害嫌疑人為學校校長時，其申訴及再申訴調查審理結果，除函復當事人雙方及雇主（學校），建請副知各主管教育行政機關，俾利後續追蹤及辦理懲處事宜，請 查照惠復。
- source_year：2007
- source_path：sources/circulars/uploaded/2007(1).md
- source_line_start：322
- source_line_end：339
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2007-021｜台訓(三)字第0960134646號

- publication_date：2007-09-06
- publication_date_raw：2007-09-06
- subject_raw：檢送「持續推動友善校園--四要三沒有--保護學生免於傷害七原則」(如附件)，請配合宣導並轉知所屬學校檢視與落實辦理，請 查照。
- source_year：2007
- source_path：sources/circulars/uploaded/2007(1).md
- source_line_start：340
- source_line_end：369
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2007-022｜台人(二)字第0960115337號

- publication_date：2007-09-10
- publication_date_raw：2007-09-10
- subject_raw：有關設置全國不適任教師通報系統網路，供學校在網路查詢，防制具教育人員任用條例第31條不得聘任之教師應聘，是否合於電腦處理個人資料保護法第7條第1款「於法令規定職掌必要範圍內」規定一案，請 釋示惠復。
- source_year：2007
- source_path：sources/circulars/uploaded/2007(1).md
- source_line_start：370
- source_line_end：392
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2007-023｜台人(二)字第0960137929號

- publication_date：2007-09-11
- publication_date_raw：2007-09-11
- subject_raw：有關學校處理教師涉及校園性侵害或性騷擾事件時，請依性別平等教育法相關規定辦理，請 查照。
- source_year：2007
- source_path：sources/circulars/uploaded/2007(1).md
- source_line_start：393
- source_line_end：408
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2007-024｜台訓(三)字第0960147632號

- publication_date：2007-10-03
- publication_date_raw：2007-10-03
- subject_raw：學校或主管機關調查處理校園性侵害或性騷擾事件時，負責處理事件之所有人員，應嚴守依法保密之義務，請 查照並轉知所屬學校。
- source_year：2007
- source_path：sources/circulars/uploaded/2007(1).md
- source_line_start：409
- source_line_end：426
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2007-025｜台人(二)字第0960158936號

- publication_date：2007-10-22
- publication_date_raw：2007-10-22
- subject_raw：有關教師涉及性侵害或性騷擾事件，經學校教師評審委員會依教師法相關規定審議時，應如何「陳述意見」疑義一案，請 查照。
- source_year：2007
- source_path：sources/circulars/uploaded/2007(1).md
- source_line_start：427
- source_line_end：440
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2007-026｜台訓(三)字第0960166505號

- publication_date：2007-11-06
- publication_date_raw：2007-11-06
- subject_raw：貴市函報校安通報事件(68733號)「校園學生事務與輔導事件處理情形回報表」1份，復如說明，請 查照。
- source_year：2007
- source_path：sources/circulars/uploaded/2007(1).md
- source_line_start：441
- source_line_end：463
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2007-027｜台訓(三)字第0960154562號

- publication_date：2007-11-07
- publication_date_raw：2007-11-07
- subject_raw：依性別平等教育法組成之性別平等教育委員會及調查小組，其性別比例除依法達到女性人數應占成員總數二分之一以上之規定外，應請衡酌性別平等參與之原則，以實現立法意旨，請查照並轉知所屬。
- source_year：2007
- source_path：sources/circulars/uploaded/2007(1).md
- source_line_start：464
- source_line_end：478
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2007-028｜台訓(三)字第0960158956號

- publication_date：2007-11-09
- publication_date_raw：2007-11-09
- subject_raw：校園發生性侵害事件如涉刑責，學校與警察機關均依法進行調查；學校仍應依法啟動調查程序，並邀請性侵害防治網絡相關人員協助調查，以避免對被害者造成二度傷害，請查照並轉知所屬。
- source_year：2007
- source_path：sources/circulars/uploaded/2007(1).md
- source_line_start：479
- source_line_end：495
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2007-029｜台訓(三)字第0960169133號

- publication_date：2007-12-03
- publication_date_raw：2007-12-03
- subject_raw：依幼稚園教育法施行細則第2條規定，幼稚園為實施幼稚園教育之機構，非屬性別平等教育法第2條所稱之學校，請查照並轉知所屬。
- source_year：2007
- source_path：sources/circulars/uploaded/2007(1).md
- source_line_start：496
- source_line_end：510
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2007-030｜台國(一)字第0960188713號

- publication_date：2007-12-05
- publication_date_raw：2007-12-05
- subject_raw：據96年12月4日報載臺中縣某國中4名學生聯合對另1名男學生玩「阿魯巴」遊戲，造成該名學生身心受創乙案，請積極督促所屬學校嚴格禁止類此遊戲，並對於校園霸凌、校園性侵害及性騷擾事件落實督導責任，請 查照。
- source_year：2007
- source_path：sources/circulars/uploaded/2007(1).md
- source_line_start：511
- source_line_end：524
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2007-031｜台訓(三)字第0960164362B號

- publication_date：2007-12-17
- publication_date_raw：2007-12-17
- subject_raw：為避免校園性侵害或性騷擾事件調查處理過程中，教師(加害人)以辭職或退休規避懲處，應請依性別平等教育法規定確實完成法定程序，請 查照並轉知所屬依法辦理。
- source_year：2007
- source_path：sources/circulars/uploaded/2007(1).md
- source_line_start：525
- source_line_end：536
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2007-032｜台訓(三)字第0960174119號

- publication_date：2007-12-17
- publication_date_raw：2007-12-17
- subject_raw：檢送「研商各級學校處理性騷擾事件因應不同法律規範之競合問題會議」會議紀錄及「我國現有與性騷擾防治相關法律之比較」（如附件），請據以依法處理校園中各類型性騷擾事件並轉知所屬。
- source_year：2007
- source_path：sources/circulars/uploaded/2007(1).md
- source_line_start：537
- source_line_end：621
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2007-033｜台訓(三)字第0960173397號

- publication_date：2007-12-31
- publication_date_raw：2007-12-31
- subject_raw：為依法落實維護懷孕學生之受教權，建請修訂學則及學生請假規定，納入懷孕學生請假及彈性處理成績考核等相關規定，請 查照。
- source_year：2007
- source_path：sources/circulars/uploaded/2007(1).md
- source_line_start：622
- source_line_end：639
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2008-001｜台訓(三)字第0970005877號

- publication_date：2008-01-10
- publication_date_raw：2008-01-10
- subject_raw：寒假在即，請學校加強性別平等教育相關課程內涵之教育宣導（包含網路使用之安全教育），以維護學生人身安全，請查照並轉知所屬確實辦理。
- source_year：2008
- source_path：sources/circulars/uploaded/2008(1).md
- source_line_start：3
- source_line_end：21
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2008-002｜警署刑防字第0970015621號

- publication_date：2008-01-21
- publication_date_raw：2008-01-21
- subject_raw：為協助學校或教育主管機關調查校園性侵害或性騷擾事件，請指派實際處理相關案件員警參與其性別平等委員會協助調查，請 照辦。
- source_year：2008
- source_path：sources/circulars/uploaded/2008(1).md
- source_line_start：22
- source_line_end：36
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2008-003｜台訓(三)字第0970008025號

- publication_date：2008-01-25
- publication_date_raw：2008-01-25
- subject_raw：有關遭受校園性侵害或性騷擾之被害人秘密轉學適應後，再轉至他校就讀時，學校之學生輔導紀錄表及個案處遇計畫移轉疑義乙案，復如說明，請 查照。
- source_year：2008
- source_path：sources/circulars/uploaded/2008(1).md
- source_line_start：37
- source_line_end：51
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2008-004｜台訓(三)字第0970005171號

- publication_date：2008-02-01
- publication_date_raw：2008-02-01
- subject_raw：有關校園性侵害或性騷擾防治準則(以下簡稱準則)第13條所定收件單位之處理流程相關疑義，請依說明事項辦理，並請轉知所屬學校。
- source_year：2008
- source_path：sources/circulars/uploaded/2008(1).md
- source_line_start：52
- source_line_end：68
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：["CQ-008"]

## C2008-005｜台訓(三)字第0970012857號

- publication_date：2008-02-14
- publication_date_raw：2008-02-14
- subject_raw：所詢性別平等教育法及性騷擾之定義疑義，復如說明，請 查照。
- source_year：2008
- source_path：sources/circulars/uploaded/2008(1).md
- source_line_start：69
- source_line_end：84
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2008-006｜台訓(三)字第0970010913A號

- publication_date：2008-03-28
- publication_date_raw：2008-03-28
- subject_raw：國立大學校院之專案計畫教學人員因性別平等教育法(以下簡稱性平法)調查處理之事件致懲處，其對申復結果不服時之救濟適用身分及管道，請依說明辦理，並請周知。
- source_year：2008
- source_path：sources/circulars/uploaded/2008(1).md
- source_line_start：85
- source_line_end：100
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2008-007｜台社(一)字第0970049527號

- publication_date：2008-04-01
- publication_date_raw：2008-04-01
- subject_raw：為落實「性別平等教育法」，提供性別平等之教育資源與環境，請 貴校依說明辦理，請 查照。
- source_year：2008
- source_path：sources/circulars/uploaded/2008(1).md
- source_line_start：101
- source_line_end：121
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2008-008｜台人(二)字第0970055926號

- publication_date：2008-04-18
- publication_date_raw：2008-04-18
- subject_raw：有關教師涉及校園性侵害或性騷擾事件，於調查處理期間應確依性別平等教育法及教師法之規定辦理，避免教師以辭職或退休規避懲處責任，請 查照。
- source_year：2008
- source_path：sources/circulars/uploaded/2008(1).md
- source_line_start：122
- source_line_end：137
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2008-009｜台人(二)字第0970061584號

- publication_date：2008-05-06
- publication_date_raw：2008-05-06
- subject_raw：所詢性別平等教育法之申復與教師法申訴制度之執行疑義一案，請 查照。
- source_year：2008
- source_path：sources/circulars/uploaded/2008(1).md
- source_line_start：138
- source_line_end：154
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2008-010｜台國(四)字第0970118270號

- publication_date：2008-07-03
- publication_date_raw：2008-07-03
- subject_raw：建請各縣市政府於辦理所屬學校教師申請遷調作業之相關規定中，比照97年臺閩地區公立國民中小學暨幼稚園教師介聘他縣市服務作業要點第5點規定訂定，請 查照。
- source_year：2008
- source_path：sources/circulars/uploaded/2008(1).md
- source_line_start：155
- source_line_end：166
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2008-011｜台訓(三)字第0970120746號

- publication_date：2008-07-09
- publication_date_raw：2008-07-09
- subject_raw：檢送「學校處理性別平等教育暨校園性侵害或性騷擾等相關案件檢核表」，供學校於依法辦理該等案件時據以檢核處理流程，請 查照。
- source_year：2008
- source_path：sources/circulars/uploaded/2008(1).md
- source_line_start：167
- source_line_end：239
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2008-012｜台中(一)字第0970131719號

- publication_date：2008-07-14
- publication_date_raw：2008-07-14
- subject_raw：有關「高級中學學生成績考查辦法」修正案增列學生產假之疑義,復如說明,請 查照。
- source_year：2008
- source_path：sources/circulars/uploaded/2008(1).md
- source_line_start：240
- source_line_end：263
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2008-013｜台軍(二)字第0970138401號

- publication_date：2008-07-16
- publication_date_raw：2008-07-16
- subject_raw：檢送本部「防制學生將校園霸凌與不雅影片上傳網站散布預防輔導作法暨相關法治教育」參考資料,請加強宣導,以防止類似事件發生,維護校園安全,請查照。
- source_year：2008
- source_path：sources/circulars/uploaded/2008(1).md
- source_line_start：264
- source_line_end：427
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2008-014｜台訓(三)字第0970130738號

- publication_date：2008-07-17
- publication_date_raw：2008-07-17
- subject_raw：修正「教育部性別平等教育委員會設置要點」部分規定,並自即日起生效,請 查照。
- source_year：2008
- source_path：sources/circulars/uploaded/2008(1).md
- source_line_start：428
- source_line_end：471
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2008-015｜台人(二)字第0970144492號

- publication_date：2008-08-01
- publication_date_raw：2008-08-01
- subject_raw：本部已建置具教育人員任用條例第31條規定情事之教師通報網路查詢系統,名稱為「全國不適任教師查詢系統」——置於「全國不適任教師資訊網」下,請 查照。
- source_year：2008
- source_path：sources/circulars/uploaded/2008(1).md
- source_line_start：472
- source_line_end：492
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2008-016｜台軍(二)字第0970150306號

- publication_date：2008-08-12
- publication_date_raw：2008-08-12
- subject_raw：檢送本部「防制學生將校園霸凌與不雅影片上傳網站散布預防輔導作法暨相關法治教育」參考資料補充說明,請查照。
- source_year：2008
- source_path：sources/circulars/uploaded/2008(1).md
- source_line_start：493
- source_line_end：662
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2008-017｜台人(二)字第0970175761號

- publication_date：2008-09-08
- publication_date_raw：2008-09-08
- subject_raw：學校擬聘任專責、兼職人員認有必要時，得依性侵害犯罪加害人登記報到及查閱辦法第12條規定，向目的事業主管機關申請核轉所在地直轄市、縣(市)主管機關查閱應徵者有無性侵害犯罪加害人登記資料，以杜絕有性侵害犯行之加害人進入校園擔任教職，請 查照。
- source_year：2008
- source_path：sources/circulars/uploaded/2008(1).md
- source_line_start：663
- source_line_end：674
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2008-018｜童保字第0970053335號

- publication_date：2008-09-23
- publication_date_raw：2008-09-23
- subject_raw：有關兒童及少年遭受性騷擾事件，責任通報人員適用表單乙案，復如說明二，請 查照。
- source_year：2008
- source_path：sources/circulars/uploaded/2008(1).md
- source_line_start：675
- source_line_end：691
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2008-019｜台訓(三)字第0970190427號

- publication_date：2008-09-26
- publication_date_raw：2008-09-26
- subject_raw：轉知內政部兒童局函復有關兒童及少年遭受性騷擾事件時，係屬兒童及少年福利法第30條第14款規定之行為，教育人員應以現行「家庭暴力與兒童少年保護事件通報表(非性侵害事件)」進行責任通報，請查照並轉知所屬。
- source_year：2008
- source_path：sources/circulars/uploaded/2008(1).md
- source_line_start：692
- source_line_end：706
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2008-020｜台訓(三)字第0970197713號

- publication_date：2008-10-14
- publication_date_raw：2008-10-14
- subject_raw：內政部兒童局函修正兒童及少年遭受性騷擾事件，責任通報人員適用表單乙案，其適用法條應為兒童及少年福利法第30條第15款，請查照並轉知所屬。
- source_year：2008
- source_path：sources/circulars/uploaded/2008(1).md
- source_line_start：707
- source_line_end：721
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2008-021｜台訓(三)字第0970205573號

- publication_date：2008-10-17
- publication_date_raw：2008-10-17
- subject_raw：法務部函釋學校處理校園性侵害或性騷擾事件時，請員警提供有關當事人之身分資訊及相關案情資料，有無違反偵查不公開疑義乙節，惠請轉知所屬警察機關，以利員警參與校園性侵害或性騷擾事件之調查，請 查照。
- source_year：2008
- source_path：sources/circulars/uploaded/2008(1).md
- source_line_start：722
- source_line_end：736
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2008-022｜台訓(二)字第0970203879號

- publication_date：2008-10-20
- publication_date_raw：2008-10-20
- subject_raw：請轉知所屬學校於訂定學生服裝相關規範前，應廣納學生及家長意見，循民主參與程序訂定；並應符合教育基本法與性別平等教育法等相關法令之精神，尊重人性價值，破除性別刻板印象；給予學生多元之選擇，並尊重其抉擇，請 查照。
- source_year：2008
- source_path：sources/circulars/uploaded/2008(1).md
- source_line_start：737
- source_line_end：749
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2008-023｜台人(二)字第0970210970號

- publication_date：2008-11-05
- publication_date_raw：2008-11-05
- subject_raw：所詢教師涉及校園性侵害或性騷擾案，學校教師評審委員會得否做成停聘之決議疑義一案，復請 查照。
- source_year：2008
- source_path：sources/circulars/uploaded/2008(1).md
- source_line_start：750
- source_line_end：768
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2008-024｜警署刑防字第0970126881號

- publication_date：2008-11-13
- publication_date_raw：2008-11-13
- subject_raw：員警擔任性別平等教育委員會委員，受邀就調查處理校園性侵害或性騷擾事件提供專業意見時，應依說明四、五列示原則辦理，請 查照。
- source_year：2008
- source_path：sources/circulars/uploaded/2008(1).md
- source_line_start：769
- source_line_end：787
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2008-025｜台訓(三)字第0970231446號

- publication_date：2008-11-19
- publication_date_raw：2008-11-19
- subject_raw：轉知內政部警政署通函各縣市政府警察局，有關員警受邀就調查處理校園性侵害或性騷擾事件時，提供專業意見之原則(來函影本如附件)，請 查照並轉知所屬。
- source_year：2008
- source_path：sources/circulars/uploaded/2008(1).md
- source_line_start：788
- source_line_end：801
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2009-001｜台社(一)字第0980001204號

- publication_date：2009-01-07
- publication_date_raw：2009-01-07
- subject_raw：為依法落實維護懷孕學生受受教權，請儘速修訂學則及學生請假規定，納入懷孕學生請假及彈性處理成績考核等相關規定，請 貴校依說明辦理，請 查照。
- source_year：2009
- source_path：sources/circulars/uploaded/2009(1).md
- source_line_start：3
- source_line_end：26
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2009-002｜台訓(三)字第0980006204B號

- publication_date：2009-01-19
- publication_date_raw：2009-01-19
- subject_raw：參與教育實習課程之實習生如發生校園性侵害或性騷擾事件，請依性別平等教育法之規定調查處理，請查照並轉知所屬。
- source_year：2009
- source_path：sources/circulars/uploaded/2009(1).md
- source_line_start：27
- source_line_end：38
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2009-003｜台訓(三)字第0970253734號

- publication_date：2009-01-20
- publication_date_raw：2009-01-20
- subject_raw：符合校園性侵害或性騷擾調查專業人員資格之學校人員以專家學者身分跨校受邀參與會議，應屬邀請學校以外之外聘專家學者，得支給出席費，請查照並轉知所屬。
- source_year：2009
- source_path：sources/circulars/uploaded/2009(1).md
- source_line_start：39
- source_line_end：54
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2009-004｜台人(二)字第0980022773號

- publication_date：2009-02-20
- publication_date_raw：2009-02-20
- subject_raw：所詢退休後教師於任教期間涉性侵害或性騷擾案件相關疑義一案，復請 查照。
- source_year：2009
- source_path：sources/circulars/uploaded/2009(1).md
- source_line_start：55
- source_line_end：71
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2009-005｜童保字第0980053069號

- publication_date：2009-03-30
- publication_date_raw：2009-03-30
- subject_raw：有關校園兒童及少年性騷擾事件，係違反兒童及少年福利法第30條相關規定，仍屬同法第34條第1項應於24小時通報之行為範疇，請 查照。
- source_year：2009
- source_path：sources/circulars/uploaded/2009(1).md
- source_line_start：72
- source_line_end：89
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：["CR-018"]
- quality_issue_ids：[]

## C2009-006｜台訓(三)字第0980053278號

- publication_date：2009-04-02
- publication_date_raw：2009-04-02
- subject_raw：函轉內政部兒童局函示(如附件影本)有關校園兒童及少年性騷擾事件，係違反兒童及少年福利法(以下簡稱兒少法)第30條相關規定，仍屬同法第34條第1項應於24小時通報之行為範疇，請 查照並轉知所屬照辦。
- source_year：2009
- source_path：sources/circulars/uploaded/2009(1).md
- source_line_start：90
- source_line_end：107
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：["CR-018"]
- quality_issue_ids：[]

## C2009-007｜台訓(三)字第0980082127號

- publication_date：2009-05-14
- publication_date_raw：2009-05-14
- subject_raw：為加強保護學生免於遭受性霸凌、性侵害或性騷擾之傷害，本部重申「持續推動友善校園--四要三沒有--保護學生免於傷害七原則」（如附件1），請落實宣導並轉知所屬學校依說明事項辦理，請 查照。
- source_year：2009
- source_path：sources/circulars/uploaded/2009(1).md
- source_line_start：108
- source_line_end：123
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2009-008｜台訓(三)字第0980091516號

- publication_date：2009-06-11
- publication_date_raw：2009-06-11
- subject_raw：台端於本（98）年5月22日至行政院人事行政局局長民意電子信箱詢問，教師因校園性侵害或性騷擾事件延遲法定通報等情乙案，經轉交本部，復如說明二，請 查照。
- source_year：2009
- source_path：sources/circulars/uploaded/2009(1).md
- source_line_start：124
- source_line_end：141
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2009-009｜台人(二)字第0980103310號

- publication_date：2009-06-19
- publication_date_raw：2009-06-19
- subject_raw：全國不適任教師資訊網之「全國不適任教師查詢系統」已擴充建置完竣，請 查照轉知。
- source_year：2009
- source_path：sources/circulars/uploaded/2009(1).md
- source_line_start：142
- source_line_end：163
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2009-010｜台訓(三)字第0980176141號

- publication_date：2009-10-16
- publication_date_raw：2009-10-16
- subject_raw：貴府函請本部就校園性侵害或性騷擾防治準則第23條第3項「學校」認定之權責單位疑義釋疑乙節，復如說明，請查照。
- source_year：2009
- source_path：sources/circulars/uploaded/2009(1).md
- source_line_start：164
- source_line_end：180
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2009-011｜台訓(三)字第0980179886號

- publication_date：2009-10-19
- publication_date_raw：2009-10-19
- subject_raw：師資培育大學參與教育實習課程之實習生，於學校擔任教育實習人員因校園性侵害或性騷擾事件經申請調查或檢舉時，由實習學校受理並邀該師資培育大學參與調查，請查照並轉知所屬。
- source_year：2009
- source_path：sources/circulars/uploaded/2009(1).md
- source_line_start：181
- source_line_end：196
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2009-012｜台訓(三)字第0980194269號

- publication_date：2009-11-19
- publication_date_raw：2009-11-19
- subject_raw：有關教師違反專業倫理(如涉及婚外情等私德爭議)案件之調查處理程序，請依說明辦理並轉知所屬。
- source_year：2009
- source_path：sources/circulars/uploaded/2009(1).md
- source_line_start：197
- source_line_end：211
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2009-013｜台人(二)字第0980205883號

- publication_date：2009-12-04
- publication_date_raw：2009-12-04
- subject_raw：教師法第14條及第39條條文修正案，業奉 總統98年11月25日華總一義字第09800292191號令公布，請 查照。
- source_year：2009
- source_path：sources/circulars/uploaded/2009(1).md
- source_line_start：212
- source_line_end：231
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2009-014｜台人(二)字第0980216714號

- publication_date：2009-12-24
- publication_date_raw：2009-12-24
- subject_raw：有關教師解聘、停聘或不續聘案如事證明確，而系(所)、院級教師評審委員會所作決議確有違法令或顯然不當時，請依說明三辦理，請 查照。
- source_year：2009
- source_path：sources/circulars/uploaded/2009(1).md
- source_line_start：232
- source_line_end：247
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2009-015｜台人(一)字第0980223652號

- publication_date：2009-12-30
- publication_date_raw：2009-12-30
- subject_raw：檢送本部委託國立高雄師範大學研究之「性別友善之校長遴選提問原則」25冊，以供辦理校長遴選時，面談校長候選人時提問之參考，請 查照。
- source_year：2009
- source_path：sources/circulars/uploaded/2009(1).md
- source_line_start：248
- source_line_end：260
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2010-001｜台訓(三)字第0980221501號

- publication_date：2010-01-12
- publication_date_raw：2010-01-12
- subject_raw：有關校園性騷擾案件加害人(教職員工生)離開校園或教育體系後，是否持續列管、由何單位(機關)列管，請依說明三辦理並轉知所屬。
- source_year：2010
- source_path：sources/circulars/uploaded/2010(1).md
- source_line_start：3
- source_line_end：17
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2010-002｜台訓(三)字第0990006170號

- publication_date：2010-01-19
- publication_date_raw：2010-01-19
- subject_raw：請配合修正教育人員通報調查處理及獎懲作業規定，並建立貴單位提供貴屬學校及社教機構校園性侵害或性騷擾及兒童少年保護案件諮詢服務管道，請查照，並依說明事項辦理。
- source_year：2010
- source_path：sources/circulars/uploaded/2010(1).md
- source_line_start：18
- source_line_end：39
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2010-003｜台人(二)字第0990008399號

- publication_date：2010-01-27
- publication_date_raw：2010-01-27
- subject_raw：所詢教師涉性騷擾事件，學校教師評審委員會得否變更性別平等教育委員會之懲處建議疑義一案，復請 查照。
- source_year：2010
- source_path：sources/circulars/uploaded/2010(1).md
- source_line_start：40
- source_line_end：56
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2010-004｜台高(四)字第0990042812號

- publication_date：2010-03-16
- publication_date_raw：2010-03-16
- subject_raw：為落實推動校園性別平等教育，惠請依說明辦理，請 查照。
- source_year：2010
- source_path：sources/circulars/uploaded/2010(1).md
- source_line_start：57
- source_line_end：77
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2010-005｜台訓(三)字第0990052704號

- publication_date：2010-04-29
- publication_date_raw：2010-04-29
- subject_raw：有關校園性侵害或性騷擾事件之調查權歸屬、受害人或法定代理人無意願申請調查及於調查結束是否提供調查報告予加害人等疑義，請依說明辦理並轉知所屬。
- source_year：2010
- source_path：sources/circulars/uploaded/2010(1).md
- source_line_start：78
- source_line_end：93
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2010-006｜台國(一)字第0990071213號

- publication_date：2010-04-30
- publication_date_raw：2010-04-30
- subject_raw：請轉知貴轄國民中學及國民小學，如遇法定通報個案事件，請各國民中小學行政單位協同個案當事人之班級導師，於24小時內進行到府家庭訪問，請 查照。
- source_year：2010
- source_path：sources/circulars/uploaded/2010(1).md
- source_line_start：94
- source_line_end：111
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2010-007｜台訓(三)字第0990057923號

- publication_date：2010-05-03
- publication_date_raw：2010-05-03
- subject_raw：有關校園性侵害或性騷擾事件之行為人(教師部分)依性別平等教育法(以下簡稱性平法)第32條第1項規定提起申復程序疑義，請依說明辦理並轉知所屬。
- source_year：2010
- source_path：sources/circulars/uploaded/2010(1).md
- source_line_start：112
- source_line_end：126
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2010-008｜台訓(三)字第0990066934號

- publication_date：2010-05-27
- publication_date_raw：2010-05-27
- subject_raw：有關學校為調查校園性侵害事件，邀請社工人員參與恐不適當案，復如說明，請 查照。
- source_year：2010
- source_path：sources/circulars/uploaded/2010(1).md
- source_line_start：127
- source_line_end：144
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2010-009｜台訓(三)字第0990106602號

- publication_date：2010-07-16
- publication_date_raw：2010-07-16
- subject_raw：學生因性侵害事件被羈押期間衍生之休學及懲處疑義，請依說明辦理並轉知所屬，請 查照。
- source_year：2010
- source_path：sources/circulars/uploaded/2010(1).md
- source_line_start：145
- source_line_end：161
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2010-010｜台訓(三)字第0990120627號

- publication_date：2010-08-12
- publication_date_raw：2010-08-12
- subject_raw：針對學校處理校園性侵害或性騷擾事件因案情明確不成立調查小組，可否以性平會紀錄代替調查報告乙節，請依說明辦理並轉知所屬。
- source_year：2010
- source_path：sources/circulars/uploaded/2010(1).md
- source_line_start：162
- source_line_end：175
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：["CR-042"]
- quality_issue_ids：[]

## C2010-011｜台人(二)字第0990129437號

- publication_date：2010-08-18
- publication_date_raw：2010-08-18
- subject_raw：所詢教師法第14條及性別平等教育法第22條、第26條規定適用疑義一案，復請 查照。
- source_year：2010
- source_path：sources/circulars/uploaded/2010(1).md
- source_line_start：176
- source_line_end：190
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2010-012｜台訓(三)字第0990132074號

- publication_date：2010-08-30
- publication_date_raw：2010-08-30
- subject_raw：彰化縣政府函請本部就學校教師因涉性侵害事件遭解聘申復案衍生相關疑義之釋疑案，復如說明，請查照並轉知所屬。
- source_year：2010
- source_path：sources/circulars/uploaded/2010(1).md
- source_line_start：191
- source_line_end：209
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2010-013｜台人(二)字第0990137046號

- publication_date：2010-09-07
- publication_date_raw：2010-09-07
- subject_raw：所詢教師退休後始經學校性別平等教育委員會調查確認於任教期間涉有校園性侵害案件，學校得否依教師法第14條規定予以解聘疑義1案，復請 查照。
- source_year：2010
- source_path：sources/circulars/uploaded/2010(1).md
- source_line_start：210
- source_line_end：234
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2010-014｜台訓(三)字第0990131235D號

- publication_date：2010-09-10
- publication_date_raw：2010-09-10
- subject_raw：「教育部處理性別平等教育法申復案件作業要點」(如附件)，業經本部於中華民國99年9月10日以台訓(三)字第0990131235C號令訂定發布，請 查照並轉知所屬。
- source_year：2010
- source_path：sources/circulars/uploaded/2010(1).md
- source_line_start：235
- source_line_end：284
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2010-015｜台人(二)字第0990152624號

- publication_date：2010-09-14
- publication_date_raw：2010-09-14
- subject_raw：有關所詢教師法第14條第4項相關執行疑義一案，復請 查照。
- source_year：2010
- source_path：sources/circulars/uploaded/2010(1).md
- source_line_start：285
- source_line_end：301
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2010-016｜台訓(三)字第0990158324號

- publication_date：2010-09-15
- publication_date_raw：2010-09-15
- subject_raw：為協助性別平等教育業務的規劃與運作，建議大專校院性別平等教育委員會執行秘書由主任秘書或具整合校務功能之行政主管擔任，請 查照。
- source_year：2010
- source_path：sources/circulars/uploaded/2010(1).md
- source_line_start：302
- source_line_end：313
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2010-017｜台訓(三)字第0990159267號

- publication_date：2010-09-27
- publication_date_raw：2010-09-27
- subject_raw：有關大專校院現行住宿門禁及點名事宜，建議學校應以民主參與原則，訂定與修正住宿管理相關規定，請 查照。
- source_year：2010
- source_path：sources/circulars/uploaded/2010(1).md
- source_line_start：314
- source_line_end：327
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2010-018｜臺訓(三)字第0990203486號

- publication_date：2010-11-26
- publication_date_raw：2010-11-26
- subject_raw：所詢學校性平案件相關處理流程及檢舉人權益等相關疑義之釋示，復如說明，請 查照。
- source_year：2010
- source_path：sources/circulars/uploaded/2010(1).md
- source_line_start：328
- source_line_end：344
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2010-019｜臺人(二)字第0990205321號

- publication_date：2010-12-06
- publication_date_raw：2010-12-06
- subject_raw：教師法第14條之3條文修正案，業奉 總統99年11月24日華總一義字第09900317081號令公布，請 查照。
- source_year：2010
- source_path：sources/circulars/uploaded/2010(1).md
- source_line_start：345
- source_line_end：359
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2010-020｜臺人(二)字第0990168704號

- publication_date：2010-12-07
- publication_date_raw：2010-12-07
- subject_raw：有關所詢教師退休後始經學校性別平等教育委員會調查確認於任教期間涉有校園性侵害案件，依教師法第14條規定予以解聘，其解聘生效起始日、退休金給付與繳回等相關疑義一案，復如說明，請 查照。
- source_year：2010
- source_path：sources/circulars/uploaded/2010(1).md
- source_line_start：360
- source_line_end：374
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2010-021｜臺訓(三)字第0990184700號

- publication_date：2010-12-29
- publication_date_raw：2010-12-29
- subject_raw：依校園性侵害或性騷擾防治準則(以下簡稱準則)第19條第1款，就「彈性處理」當事人之出缺勤紀錄或成績考核乙節，請依說明辦理並轉知所屬，請 查照。
- source_year：2010
- source_path：sources/circulars/uploaded/2010(1).md
- source_line_start：375
- source_line_end：397
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2011-001｜臺訓(三)字第0990227673號

- publication_date：2011-01-25
- publication_date_raw：2011-01-25
- subject_raw：康寧醫護管理專科學校函請本部釋示有關校園性騷擾事件之處理疑義案，請依說明辦理，請 查照並轉知所屬。
- source_year：2011
- source_path：sources/circulars/uploaded/2011(1).md
- source_line_start：3
- source_line_end：22
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：["CR-003"]
- quality_issue_ids：[]

## C2011-002｜臺訓(三)字第1000902022號

- publication_date：2011-02-08
- publication_date_raw：2011-02-08
- subject_raw：請學校對於校內符合校園性侵害或性騷擾事件調查專業資格者參與校內外調查工作，於不影響公務時，應予鼓勵支持，請查照並轉知所屬。
- source_year：2011
- source_path：sources/circulars/uploaded/2011(1).md
- source_line_start：23
- source_line_end：39
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2011-003｜臺訓(三)字第1000023881號

- publication_date：2011-02-14
- publication_date_raw：2011-02-14
- subject_raw：「校園性侵害或性騷擾防治準則」（以下簡稱本準則），業經本部於中華民國100年2月10日以臺參字第1000010432C號令修正發布施行（如附件），請查照並轉知所屬。
- source_year：2011
- source_path：sources/circulars/uploaded/2011(1).md
- source_line_start：40
- source_line_end：54
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2011-004｜臺訓(三)字第1000043228號

- publication_date：2011-03-15
- publication_date_raw：2011-03-15
- subject_raw：請於修訂學校之校園性侵害或性騷擾防治規定時，將校內通報校園性侵害或性騷擾事件之權責分工納入學校防治規定中定之，請查照並轉知所屬。
- source_year：2011
- source_path：sources/circulars/uploaded/2011(1).md
- source_line_start：55
- source_line_end：69
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2011-005｜臺人(二)字第1000069551A號

- publication_date：2011-04-28
- publication_date_raw：2011-04-28
- subject_raw：建請貴校將刑法第227條有關對未滿十四歲及十四歲以上未滿十六歲之男女性交、猥褻罪規定，優先納入貴校教師聘約，以提醒教師避免觸法，請 查照。
- source_year：2011
- source_path：sources/circulars/uploaded/2011(1).md
- source_line_start：70
- source_line_end：81
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2011-006｜臺人處字第1000062237號

- publication_date：2011-04-29
- publication_date_raw：2011-04-29
- subject_raw：公務人員保障暨培訓委員會函，有關公務人員就性騷擾事件，依公務人員保障法提起救濟相關事宜一案，請 查照。
- source_year：2011
- source_path：sources/circulars/uploaded/2011(1).md
- source_line_start：82
- source_line_end：105
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2011-007｜臺訓(三)字第1000073788號

- publication_date：2011-05-12
- publication_date_raw：2011-05-12
- subject_raw：有關學校調查處理校園性侵害事件邀請各直轄市、縣（市）家防中心社工人員以專家證人身分協助調查乙案，請依說明辦理，並請 查照。
- source_year：2011
- source_path：sources/circulars/uploaded/2011(1).md
- source_line_start：106
- source_line_end：124
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2011-008｜臺訓(三)字第1000090521B號

- publication_date：2011-05-26
- publication_date_raw：2011-05-26
- subject_raw：近日媒體披露多起學生懷孕產子疑棄嬰致死案件，請學校提交所設性別平等教育委員會研議相關之教育宣導及防治措施，請 查照並轉知所屬。
- source_year：2011
- source_path：sources/circulars/uploaded/2011(1).md
- source_line_start：125
- source_line_end：142
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2011-009｜臺訓(三)字第1000078907號

- publication_date：2011-05-31
- publication_date_raw：2011-05-31
- subject_raw：貴局函請本部釋示有關駐區督學列席督導學校性別平等教育委員會會議，審議師生間之校園性侵害或性騷擾事件之可行運作方式及角色功能定位案，復如說明，請 查照。
- source_year：2011
- source_path：sources/circulars/uploaded/2011(1).md
- source_line_start：143
- source_line_end：158
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2011-010｜臺人(二)字第1000092420號

- publication_date：2011-06-09
- publication_date_raw：2011-06-09
- subject_raw：有關教師涉及性騷擾案件，經學校性別平等教育委員會完成調查並認定性騷擾行為成立建議予以解聘或不續聘，學校教師評審委員會審議程序等相關疑義一案，復如說明，請 查照。
- source_year：2011
- source_path：sources/circulars/uploaded/2011(1).md
- source_line_start：159
- source_line_end：175
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2011-011｜臺人(二)字第1000090837號

- publication_date：2011-06-23
- publication_date_raw：2011-06-23
- subject_raw：有關教師疑涉教師法第14條第1項第9款情形經停聘接受調查未能確認有性侵害行為，學校教評會得否不予回復聘任一案，復如說明，請 查照。
- source_year：2011
- source_path：sources/circulars/uploaded/2011(1).md
- source_line_start：176
- source_line_end：189
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2011-012｜臺訓(三)字第1000079751B號

- publication_date：2011-06-23
- publication_date_raw：2011-06-23
- subject_raw：國立高雄海洋科技大學函請本部就性別平等教育委員會（以下簡稱性平會）委員兼任教師評審委員會（以下簡稱教評會）之迴避疑義釋示案，請 查照並請轉知所屬依說明辦理。
- source_year：2011
- source_path：sources/circulars/uploaded/2011(1).md
- source_line_start：190
- source_line_end：207
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2011-013｜臺訓(三)字第1000109280號

- publication_date：2011-06-28
- publication_date_raw：2011-06-28
- subject_raw：性別平等教育法部分條文修正案，業奉 總統100年6月22日華總一義字第10000131071號令公布，其施行日期，由行政院定之，請查照並轉知所屬。
- source_year：2011
- source_path：sources/circulars/uploaded/2011(1).md
- source_line_start：208
- source_line_end：229
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2011-014｜臺訓(三)字第1000089490號

- publication_date：2011-06-29
- publication_date_raw：2011-06-29
- subject_raw：桃園縣政府就該縣學校處理校園性平案件之相關疑義，請 本部釋示案，復如說明，請 查照並請周知所屬。
- source_year：2011
- source_path：sources/circulars/uploaded/2011(1).md
- source_line_start：230
- source_line_end：247
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2011-015｜臺訓(三)字第1000109290號

- publication_date：2011-07-26
- publication_date_raw：2011-07-26
- subject_raw：有關貴市南港高級中學處理校園性侵害或性騷擾事件被申請人提出申請資料調閱疑義案，復如說明，請 查照。
- source_year：2011
- source_path：sources/circulars/uploaded/2011(1).md
- source_line_start：248
- source_line_end：267
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2011-016｜臺訓(三)字第1000164631號

- publication_date：2011-09-19
- publication_date_raw：2011-09-19
- subject_raw：請依據性別平等教育法及其子法等相關規定，落實推動性別平等教育，詳如說明，請 查照。
- source_year：2011
- source_path：sources/circulars/uploaded/2011(1).md
- source_line_start：268
- source_line_end：302
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2011-017｜臺訓(三)字第1000156654號

- publication_date：2011-10-04
- publication_date_raw：2011-10-04
- subject_raw：有關學校駐衛警，如涉性侵害或性騷擾案件審議期間，得否辦理退職及是否屬性別平等教育法第2條第5款定義之職員疑義案，請依說明辦理並轉知所屬，請 查照。
- source_year：2011
- source_path：sources/circulars/uploaded/2011(1).md
- source_line_start：303
- source_line_end：320
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2011-018｜臺訓(三)字第1000170857B號

- publication_date：2011-10-31
- publication_date_raw：2011-10-31
- subject_raw：有關學校處理性騷擾防治法、性別平等教育法及性別工作平等法（以下簡稱三法）所涉之性騷擾事件之單一處理機制，請 查照並依說明辦理及轉知所屬。
- source_year：2011
- source_path：sources/circulars/uploaded/2011(1).md
- source_line_start：321
- source_line_end：350
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：["CR-029"]
- quality_issue_ids：[]

## C2011-019｜臺人(二)字第1000226726C號

- publication_date：2011-12-21
- publication_date_raw：2011-12-21
- subject_raw：教育人員任用條例第31條修正條文業經總統於本（100）年11月30日公布施行，教師法第14條條文亦配合修正並經立法院於同年12月14日三讀通過，各校於人員進用前應確實查詢有無不得任用之情事，請 查照（轉知）。
- source_year：2011
- source_path：sources/circulars/uploaded/2011(1).md
- source_line_start：351
- source_line_end：366
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2012-001｜臺訓(三)字第1000234453號

- publication_date：2012-01-13
- publication_date_raw：2012-01-13
- subject_raw：有關學校校園性侵害或性騷擾事件調查委員於調查完成後，因涉民事爭訟，向學校主張或維護其法律上利益而申請所參與調查案之訪談紀錄及調查報告等資料之調閱權限疑義，請參考說明三辦理並轉知所屬，請查照。
- source_year：2012
- source_path：sources/circulars/uploaded/2012(1).md
- source_line_start：3
- source_line_end：24
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2012-002｜臺訓(三)字第1010017130號

- publication_date：2012-02-04
- publication_date_raw：2012-02-04
- subject_raw：18歲以上學生遭受性騷擾事件，非屬兒童及少年保護事件，僅需向學校所屬主管機關通報，毋須通報各地方社政主管機關，再請轉知所屬通報權責窗口人員據以辦理，請查照。
- source_year：2012
- source_path：sources/circulars/uploaded/2012(1).md
- source_line_start：25
- source_line_end：40
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2012-003｜臺訓(三)字第1010008320B號

- publication_date：2012-02-24
- publication_date_raw：2012-02-24
- subject_raw：有關校園性侵害、性騷擾及性霸凌案件申復及申訴提起時點，請確依說明辦理並轉知所屬，請 查照。
- source_year：2012
- source_path：sources/circulars/uploaded/2012(1).md
- source_line_start：41
- source_line_end：57
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2012-004｜臺國(四)字第1010034923號

- publication_date：2012-03-01
- publication_date_raw：2012-03-01
- subject_raw：檢送本部修訂「國民中小學校園性侵害及性騷擾事件直轄市、縣市政府（教育局處）檢視表」乙份，請惠依說明辦理，請 查照。
- source_year：2012
- source_path：sources/circulars/uploaded/2012(1).md
- source_line_start：58
- source_line_end：72
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2012-005｜臺人(二)字第1010019698A號

- publication_date：2012-03-05
- publication_date_raw：2012-03-05
- subject_raw：有關教師法第14條第4項所定停聘執行一案，請 查照。
- source_year：2012
- source_path：sources/circulars/uploaded/2012(1).md
- source_line_start：73
- source_line_end：89
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2012-006｜臺人(二)字第1010019698B號

- publication_date：2012-03-05
- publication_date_raw：2012-03-05
- subject_raw：教師涉及校園性侵害案件，服務學校依101年1月4日修正公布之教師法第14條第4項規定由教師評審委員會審議停聘時，因性別平等教育委員會尚未完成事實調查及認定，爰教師評審委員會審酌行為人之陳述意見時，僅限於「停聘」部分，不涉及事實調查及認定，請 查照轉知。
- source_year：2012
- source_path：sources/circulars/uploaded/2012(1).md
- source_line_start：90
- source_line_end：101
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2012-007｜臺國(四)字第1010038391號

- publication_date：2012-03-06
- publication_date_raw：2012-03-06
- subject_raw：有關 貴轄學校於發生疑似校園性侵害或性騷擾案件之危機事件處理機制，應予以建立，請 查照。
- source_year：2012
- source_path：sources/circulars/uploaded/2012(1).md
- source_line_start：102
- source_line_end：115
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2012-008｜臺訓(三)字第1010023124號

- publication_date：2012-03-13
- publication_date_raw：2012-03-13
- subject_raw：臺北市政府教育局函詢有關校園性侵害或性騷擾事件之申請人或行為人，依性別平等教育法（以下簡稱性平法）第34條第1項第5款規定提起救濟程序相關疑義乙案，請依說明辦理並轉知所屬，請 查照。
- source_year：2012
- source_path：sources/circulars/uploaded/2012(1).md
- source_line_start：116
- source_line_end：130
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2012-009｜臺訓(三)字第1010035573號

- publication_date：2012-03-15
- publication_date_raw：2012-03-15
- subject_raw：有關校園性騷擾案件涉身分改變時，加害人提出陳述意見之實務運作疑義，請依說明辦理並轉知所屬，請 查照。
- source_year：2012
- source_path：sources/circulars/uploaded/2012(1).md
- source_line_start：131
- source_line_end：148
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2012-010｜臺人(二)字第1010053736號

- publication_date：2012-03-27
- publication_date_raw：2012-03-27
- subject_raw：各級公私立學校應確依性別平等教育法第27條第4項規定，於每學期開學前或於任用教育人員或進用其他專職、兼職人員前，查閱其有無性侵害犯罪紀錄，以維護校園安全，請 查照。
- source_year：2012
- source_path：sources/circulars/uploaded/2012(1).md
- source_line_start：149
- source_line_end：165
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2012-011｜臺人(二)字第1010055934號

- publication_date：2012-03-29
- publication_date_raw：2012-03-29
- subject_raw：為避免日前曾獲特殊優良教師之教師涉嫌性侵等行為不檢 情事再次發生，請貴局（府）就自行辦理之師鐸獎或特殊 優良教師遴選要件及過程，訂定更詳細之認定標準及審查 流程，嚴格審查被推薦人之品德操守，請 查照。
- source_year：2012
- source_path：sources/circulars/uploaded/2012(1).md
- source_line_start：166
- source_line_end：177
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2012-012｜臺訓(三)字第1010049898號

- publication_date：2012-04-05
- publication_date_raw：2012-04-05
- subject_raw：請轉知所屬學校及教師實施性別平等教育相關議題教學時，應依課程綱要審慎使用教學媒材，並依說明辦理，請 查照。
- source_year：2012
- source_path：sources/circulars/uploaded/2012(1).md
- source_line_start：178
- source_line_end：195
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2012-013｜臺訓(三)字第1010039771號

- publication_date：2012-04-09
- publication_date_raw：2012-04-09
- subject_raw：有關國立交通大學所提教師涉校園性侵害或性騷擾案件申 復時點疑義案，復如說明，並修正本部96年5月7日臺訓(三) 字第0960057668B號函示之申復提起時點，請 查照並轉知 所屬。
- source_year：2012
- source_path：sources/circulars/uploaded/2012(1).md
- source_line_start：196
- source_line_end：216
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：["CR-002"]
- quality_issue_ids：[]

## C2012-014｜臺訓(三)字第1010054761號

- publication_date：2012-04-17
- publication_date_raw：2012-04-17
- subject_raw：有關臺北市政府教育局函詢校園性侵害、性騷擾或性霸凌事件發生於學制轉銜期間，其行為人之懲處適用相關疑義案，復如說明，請 查照並轉知所屬。
- source_year：2012
- source_path：sources/circulars/uploaded/2012(1).md
- source_line_start：217
- source_line_end：233
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2012-015｜臺訓(三)字第1010089413號

- publication_date：2012-05-18
- publication_date_raw：2012-05-18
- subject_raw：內政部函知「性侵害犯罪加害人登記報到查閱辦法」（以 下簡稱原查閱辦法）修正為「性侵害犯罪加害人登記報到 查訪及查閱辦法」（以下簡稱修正查閱辦法），並經該部 101年4月30日台內警字第1010890248號令修正發布（如附 件），請據以辦理該犯罪紀錄查閱事宜並轉知所屬，請 查照。
- source_year：2012
- source_path：sources/circulars/uploaded/2012(1).md
- source_line_start：234
- source_line_end：255
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2012-016｜臺訓(三)字第1010101395號

- publication_date：2012-06-04
- publication_date_raw：2012-06-04
- subject_raw：「校園性侵害或性騷擾防治準則」業經本部於中華民國101年5月24日以臺參字第1010081429C號令修正發布施行，並將名稱修正為「校園性侵害性騷擾或性霸凌防治準則」（修正條文對照表如附件1，以下簡稱本準則），請查照並轉知所屬。
- source_year：2012
- source_path：sources/circulars/uploaded/2012(1).md
- source_line_start：256
- source_line_end：273
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2012-017｜臺人(二)字第1010116733號

- publication_date：2012-06-29
- publication_date_raw：2012-06-29
- subject_raw：內政部函有關性侵害犯罪加害人登記資料查閱申請相關事宜，請 查照。
- source_year：2012
- source_path：sources/circulars/uploaded/2012(1).md
- source_line_start：274
- source_line_end：413
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2012-018｜臺訓(三)字第1010116308號

- publication_date：2012-07-24
- publication_date_raw：2012-07-24
- subject_raw：檢送本部所定「學校處理學生間發生刑法第二百二十七條 事件應注意事項」（如附件，包括處理流程、通知書範例 及會議紀錄參考範例），請學校參考據以處理學生間發生 刑法第227條之事件，請查照並轉知所屬。
- source_year：2012
- source_path：sources/circulars/uploaded/2012(1).md
- source_line_start：414
- source_line_end：429
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2012-019｜臺訓(三)字第1010130782號

- publication_date：2012-07-31
- publication_date_raw：2012-07-31
- subject_raw：貴府針對「教育部處理性別平等教育法申復案件作業要點」所定之申復補正期限，及「校園性侵害性騷擾或性霸凌防治準則」（以下簡稱防治準則）中審議結果完成期限疑義，請本部釋示乙案，復如說明，請 查照。
- source_year：2012
- source_path：sources/circulars/uploaded/2012(1).md
- source_line_start：430
- source_line_end：448
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2012-020｜臺訓(三)字第1010141422號

- publication_date：2012-08-01
- publication_date_raw：2012-08-01
- subject_raw：本部重申若校園性侵害、性騷擾或性霸凌事件之當事人應 提申復卻誤提申訴時，應請受理後移轉予申復業務之管轄 權責單位併通知申復人，請 查照並轉知所屬。
- source_year：2012
- source_path：sources/circulars/uploaded/2012(1).md
- source_line_start：449
- source_line_end：466
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2012-021｜臺訓(三)字第1010157381號

- publication_date：2012-09-13
- publication_date_raw：2012-09-13
- subject_raw：貴府請本部釋示學校性別平等教育委員會（以下簡稱性平會）處理性別工作平等法所定之性騷擾事件所成立之調查小組得否均為外聘疑義案，復如說明，請 查照。
- source_year：2012
- source_path：sources/circulars/uploaded/2012(1).md
- source_line_start：467
- source_line_end：483
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2012-022｜臺訓(三)字第1010156729號

- publication_date：2012-09-26
- publication_date_raw：2012-09-26
- subject_raw：各級學校依據性別平等教育法第12條第2項所定之性別平等 教育實施規定、依據同法第20條第2項與校園性侵害性騷擾 或性霸凌防治準則所定之防治規定，及依據性騷擾防治法 第7條與性別工作平等法第13條訂定性騷擾防治措施（包含 三法整合之處理機制）等校內章則，屬校務重大事項，應 請提交校務會議議決，請 查照並轉知所屬。 說明
- source_year：2012
- source_path：sources/circulars/uploaded/2012(1).md
- source_line_start：484
- source_line_end：501
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2012-023｜臺訓(三)字第1010173657號

- publication_date：2012-10-01
- publication_date_raw：2012-10-01
- subject_raw：貴局函為就貴市社會局家庭暴力暨性侵害防治中心欲調閱 所屬某國小性平案件全文性之調查報告（含原始調查報告 及學校性平會議決之調查報告），請本部釋示乙案，復如 說明，請 查照。
- source_year：2012
- source_path：sources/circulars/uploaded/2012(1).md
- source_line_start：502
- source_line_end：515
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2012-024｜臺訓(三)字第1010166748號

- publication_date：2012-10-02
- publication_date_raw：2012-10-02
- subject_raw：貴府所詢有關學校之性別平等教育委員會（以下簡稱性平 會）與依校園性侵害性騷擾或性霸凌防治準則（以下簡稱 防治準則）第31條成立之審議小組之法律位階，以及停聘 與解聘、不續聘之法律效果之釋疑案，復如說明，請 查 照。
- source_year：2012
- source_path：sources/circulars/uploaded/2012(1).md
- source_line_start：516
- source_line_end：533
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2012-025｜臺訓(三)字第1010176992號

- publication_date：2012-10-08
- publication_date_raw：2012-10-08
- subject_raw：所詢有關性別平等教育法（以下簡稱性平法）第27條規定 加害人通報疑義一案，復如說明，請 查照。
- source_year：2012
- source_path：sources/circulars/uploaded/2012(1).md
- source_line_start：534
- source_line_end：552
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2012-026｜臺訓(三)字第1010190118號

- publication_date：2012-10-08
- publication_date_raw：2012-10-08
- subject_raw：性別平等教育法（以下簡稱性平法）第36條所定罰鍰之裁 處，由核准學校設立之各該主管機關處罰之，請 查照並 轉知所屬。
- source_year：2012
- source_path：sources/circulars/uploaded/2012(1).md
- source_line_start：553
- source_line_end：575
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2012-027｜臺訓(三)字第1010156726B號

- publication_date：2012-10-11
- publication_date_raw：2012-10-11
- subject_raw：有關校園性侵害、性騷擾或性霸凌事件經調查屬實並認定 成立者得否撤銷已授予之學位疑義，請依說明辦理，請 查照。
- source_year：2012
- source_path：sources/circulars/uploaded/2012(1).md
- source_line_start：576
- source_line_end：594
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2012-028｜臺訓(三)字第1010191724號

- publication_date：2012-10-16
- publication_date_raw：2012-10-16
- subject_raw：有關學生於校外實習（建教合作）期間遭性騷擾之處理機 制，請依說明辦理，請查照。
- source_year：2012
- source_path：sources/circulars/uploaded/2012(1).md
- source_line_start：595
- source_line_end：611
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2012-029｜臺訓(三)字第1010189442號

- publication_date：2012-10-18
- publication_date_raw：2012-10-18
- subject_raw：貴府函請本部釋示有關校園性侵害或性騷擾事件重啟調查 後，前次調查處理及救濟程序中之會議紀錄得否提供當事 人及利害關係人閱卷疑義，復如說明，請 查照。
- source_year：2012
- source_path：sources/circulars/uploaded/2012(1).md
- source_line_start：612
- source_line_end：628
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2012-030｜臺訓(三)字第1010192656號

- publication_date：2012-10-19
- publication_date_raw：2012-10-19
- subject_raw：貴局所詢學校性別平等教育委員會（以下簡稱性平會）遇 家內性侵害、性騷擾或性霸凌事件，其進行調查做事實認 定之處理方式案，復如說明，請 查照。
- source_year：2012
- source_path：sources/circulars/uploaded/2012(1).md
- source_line_start：629
- source_line_end：649
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2012-031｜臺訓(一)字第1010196408A號

- publication_date：2012-10-25
- publication_date_raw：2012-10-25
- subject_raw：請督導轄屬公私立學校於規範學生服裝儀容時，應符合性別平等教育法之規定，請 查照。
- source_year：2012
- source_path：sources/circulars/uploaded/2012(1).md
- source_line_start：650
- source_line_end：667
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2012-032｜臺訓(三)字第1010196103號

- publication_date：2012-10-31
- publication_date_raw：2012-10-31
- subject_raw：貴府所詢學校處理性別平等教育法事件衍生有關申復審議 小組成員之法律專業之界定乙案，復如說明，請 查照。
- source_year：2012
- source_path：sources/circulars/uploaded/2012(1).md
- source_line_start：668
- source_line_end：681
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2012-033｜臺訓(三)字第1010204252號

- publication_date：2012-10-31
- publication_date_raw：2012-10-31
- subject_raw：有關校園性侵害、性騷擾或性霸凌事件調查小組於調查報 告簽名之效力、事件結案之定義，及強化跨校案件之調查 品質，請依說明辦理並周知所屬，請 查照。
- source_year：2012
- source_path：sources/circulars/uploaded/2012(1).md
- source_line_start：682
- source_line_end：700
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2012-034｜臺訓(三)字第1010211490號

- publication_date：2012-11-15
- publication_date_raw：2012-11-15
- subject_raw：所詢貴縣—國中校安通報疑似校園性侵害事件（通報序 號：—），有關「派員協助調查之代表」學校疑義， 復如說明，請 查照。
- source_year：2012
- source_path：sources/circulars/uploaded/2012(1).md
- source_line_start：701
- source_line_end：715
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2012-035｜臺訓(三)字第1010204600號

- publication_date：2012-11-16
- publication_date_raw：2012-11-16
- subject_raw：貴府所詢有關校園性別事件認定疑義乙案，復如說明，請 查照。
- source_year：2012
- source_path：sources/circulars/uploaded/2012(1).md
- source_line_start：716
- source_line_end：731
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2012-036｜臺訓(三)字第1010211343號

- publication_date：2012-11-16
- publication_date_raw：2012-11-16
- subject_raw：所詢學校性別平等教育委員會（以下簡稱性平會）處理校 園性侵害性騷擾或性霸凌案件，是否得以調查小組之調查 報告就其認同之處作成結論，而為其性平會之調查報告疑 義，復如說明，請 查照。
- source_year：2012
- source_path：sources/circulars/uploaded/2012(1).md
- source_line_start：732
- source_line_end：751
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2012-037｜臺訓(三)字第1010216000號

- publication_date：2012-11-21
- publication_date_raw：2012-11-21
- subject_raw：所詢本部101年10月11日臺訓(三)字第1010156726B號函示 （諒達），有關校園性侵害、性騷擾或性霸凌事件經調查 屬實並認定成立者得否撤銷已授予之學位疑義，復如說明， 請 查照。
- source_year：2012
- source_path：sources/circulars/uploaded/2012(1).md
- source_line_start：752
- source_line_end：769
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2012-038｜臺訓(三)字第1010208869號

- publication_date：2012-11-28
- publication_date_raw：2012-11-28
- subject_raw：所詢教師涉性侵害事件之懲處法源依據、懲處種類，復如 說明，請 查照。
- source_year：2012
- source_path：sources/circulars/uploaded/2012(1).md
- source_line_start：770
- source_line_end：792
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2012-039｜臺訓(三)字第1010224026號

- publication_date：2012-12-04
- publication_date_raw：2012-12-04
- subject_raw：為台北市女性權益促進會函知本部學校處理懷孕學生事件 相關疑義，請各級學校依據說明辦理，請 查照並轉知所 屬。
- source_year：2012
- source_path：sources/circulars/uploaded/2012(1).md
- source_line_start：793
- source_line_end：816
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2012-040｜臺訓(三)字第1010225455號

- publication_date：2012-12-06
- publication_date_raw：2012-12-06
- subject_raw：貴校所詢學生不服性別平等教育委員會（以下簡稱性平會） 調查結果，提出申訴後，學校之學生申訴評議委員會（以 下簡稱學生申評會）是否得調閱性平案件調查資料乙節， 復如說明，請 查照。
- source_year：2012
- source_path：sources/circulars/uploaded/2012(1).md
- source_line_start：817
- source_line_end：836
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2012-041｜臺訓(三)字第1010235996號

- publication_date：2012-12-11
- publication_date_raw：2012-12-11
- subject_raw：轉知內政部兒童局101年11月14日召開「研商防治兒少安置 教養機構性侵害事件─建立跨機關合作機制會議紀錄」（ 如附件），請 查照並轉知所屬。
- source_year：2012
- source_path：sources/circulars/uploaded/2012(1).md
- source_line_start：837
- source_line_end：856
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2012-042｜臺訓(三)字第1010229209號

- publication_date：2012-12-12
- publication_date_raw：2012-12-12
- subject_raw：貴局函詢有關學生因校園性侵害或性騷擾事件記過懲處，該事件經法院無罪判決確定是否得予以撤銷行政懲處及救濟途徑之疑義，復如說明，請 查照。
- source_year：2012
- source_path：sources/circulars/uploaded/2012(1).md
- source_line_start：857
- source_line_end：874
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2012-043｜臺訓(三)字第1010245259號

- publication_date：2012-12-26
- publication_date_raw：2012-12-26
- subject_raw：有關校園性侵害、性騷擾或性霸凌事件調查屬實後，學校 執行懲處時，行為人已轉學或於下一學制就讀時，懲處執 行之疑義，請依說明辦理，請查照並轉知所屬。
- source_year：2012
- source_path：sources/circulars/uploaded/2012(1).md
- source_line_start：875
- source_line_end：892
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：["CR-014", "CR-024"]
- quality_issue_ids：[]

## C2013-001｜臺教學(三)字第1020018126號

- publication_date：2013-02-20
- publication_date_raw：2013-02-20
- subject_raw：所報貴校陳報「校園性侵害性騷擾及性霸凌統計管理系統」序號 △ 性平案件遭退回原因疑義案，復如說明，請查照。
- source_year：2013
- source_path：sources/circulars/uploaded/2013(1).md
- source_line_start：3
- source_line_end：24
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2013-002｜臺教學(三)字第1020030946號

- publication_date：2013-03-06
- publication_date_raw：2013-03-06
- subject_raw：為釐清學校調查處理由地方政府教育局（處）聘用之特教 學生交通車司機、物理治療師、專業輔導人員等跨校服務 人員（或可能包括其他由主管機關聘用跨學校執行教學或 提供專業服務之人員）之管轄權爭議案，請依說明辦理並 轉知所屬，請 查照。
- source_year：2013
- source_path：sources/circulars/uploaded/2013(1).md
- source_line_start：25
- source_line_end：43
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2013-003｜臺教人(四)字第1020031871號

- publication_date：2013-04-03
- publication_date_raw：2013-04-03
- subject_raw：所詢學校教師如涉性侵害或性騷擾，於案件調查期間，因病同意先行中止性別平等教育委員會調查，嗣後符合應即退休條件時，得否辦理退休疑義一案，復如說明，請查照。
- source_year：2013
- source_path：sources/circulars/uploaded/2013(1).md
- source_line_start：44
- source_line_end：59
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2013-004｜臺教學(三)字第1020040168號

- publication_date：2013-04-12
- publication_date_raw：2013-04-12
- subject_raw：貴局所詢有關學校校園性侵害或性騷擾事件之行為人教師兼該等事件之通報權責人員，其未依規定通報，致有延遲通報情事者，是否涉有違失之釋示案，復如說明，請查照。
- source_year：2013
- source_path：sources/circulars/uploaded/2013(1).md
- source_line_start：60
- source_line_end：77
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2013-005｜臺教學(三)字第1020058205號

- publication_date：2013-04-18
- publication_date_raw：2013-04-18
- subject_raw：轉知內政部102年3月21日召開各直轄市縣（市）政府接獲 身心障礙者與兒童及少年性侵害案件處理流程研商會議決 議事項如說明二，請積極配合辦理，以利家庭暴力及性侵 害防治網絡合作，請查照並轉知所屬。
- source_year：2013
- source_path：sources/circulars/uploaded/2013(1).md
- source_line_start：78
- source_line_end：96
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2013-006｜臺教人(三)字第1020084747號

- publication_date：2013-07-11
- publication_date_raw：2013-07-11
- subject_raw：所詢教師因性別平等事件遭解聘提起申復之後續處理方式 一案，復如說明，請查照。
- source_year：2013
- source_path：sources/circulars/uploaded/2013(1).md
- source_line_start：97
- source_line_end：115
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2013-007｜臺教學(三)字第1020080238號

- publication_date：2013-07-16
- publication_date_raw：2013-07-16
- subject_raw：有關學校因受理檢舉而調查之校園性侵害、性騷擾或性霸 凌事件（以下簡稱校園事件）處理結果是否通知被害人疑 義，請依說明辦理並轉知所屬，請 查照。
- source_year：2013
- source_path：sources/circulars/uploaded/2013(1).md
- source_line_start：116
- source_line_end：132
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：["CR-038"]
- quality_issue_ids：[]

## C2013-008｜臺教學(三)字第1020114975號

- publication_date：2013-08-19
- publication_date_raw：2013-08-19
- subject_raw：新北市政府教育局函請本部釋示有關校園性騷擾事件之處 理疑義案，請依說明辦理，請 查照並轉知所屬。
- source_year：2013
- source_path：sources/circulars/uploaded/2013(1).md
- source_line_start：133
- source_line_end：157
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：["CR-003"]
- quality_issue_ids：[]

## C2013-009｜臺教學(三)字第1020114961號

- publication_date：2013-08-20
- publication_date_raw：2013-08-20
- subject_raw：有關校園性侵害、性騷擾或性霸凌事件（以下簡稱校園性 別事件）之申訴階段，申訴人已非行為時所屬學校之學生 時，其申訴案件之管轄權疑義，復如說明，請 查照。
- source_year：2013
- source_path：sources/circulars/uploaded/2013(1).md
- source_line_start：158
- source_line_end：176
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：["CR-015", "CR-025"]
- quality_issue_ids：[]

## C2013-010｜臺教人(三)字第1020142773號

- publication_date：2013-10-31
- publication_date_raw：2013-10-31
- subject_raw：有關102年7月10日修正公布之教師法第14條第4項相關執行 疑義一案，復如說明，請 查照。
- source_year：2013
- source_path：sources/circulars/uploaded/2013(1).md
- source_line_start：177
- source_line_end：194
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2013-011｜臺教學(三)字第1020164059號

- publication_date：2013-11-07
- publication_date_raw：2013-11-07
- subject_raw：有關學校調查處理校園性侵害、性騷擾或性霸凌事件之保 密及相關處理疑義，請依說明辦理並周知所屬，請 查照。
- source_year：2013
- source_path：sources/circulars/uploaded/2013(1).md
- source_line_start：195
- source_line_end：208
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2013-012｜臺教學(三)字第1020168370號

- publication_date：2013-12-12
- publication_date_raw：2013-12-12
- subject_raw：所詢學校校安通報發生於性別平等教育法（以下簡稱性平 法）施行前之教師疑涉性騷擾學生事件之適用法律規定及 調查程序相關疑義，請依說明辦理，請 查照。
- source_year：2013
- source_path：sources/circulars/uploaded/2013(1).md
- source_line_start：209
- source_line_end：226
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2013-013｜臺教學(三)字第1020165630號

- publication_date：2013-12-24
- publication_date_raw：2013-12-24
- subject_raw：檢送「各級學校非屬性別平等教育法所定性騷擾事件之申 訴及處理流程說明」資料乙份（如附件），請查照並周知 據以辦理。
- source_year：2013
- source_path：sources/circulars/uploaded/2013(1).md
- source_line_start：227
- source_line_end：279
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：["CR-028"]
- quality_issue_ids：[]

## C2013-014｜臺教學(三)字第1020177619號

- publication_date：2013-12-24
- publication_date_raw：2013-12-24
- subject_raw：有關校園性侵害性騷擾或性霸凌防治準則（以下簡稱防治 準則）第9條第2項第3款學生定義之相關疑義，請 查照並 依說明辦理及周知所屬。
- source_year：2013
- source_path：sources/circulars/uploaded/2013(1).md
- source_line_start：280
- source_line_end：295
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2014-001｜臺教學(三)字第1020195705號

- publication_date：2014-01-02
- publication_date_raw：2014-01-02
- subject_raw：貴署函請本部釋示有關臺東縣政府所詢鄉立幼兒園發生疑 似性霸凌事件，後續通報及處理程序適用法規疑義案，復 如說明，請 查照。
- source_year：2014
- source_path：sources/circulars/uploaded/2014(1).md
- source_line_start：3
- source_line_end：23
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2014-002｜臺教學(三)字第1020190069號

- publication_date：2014-01-13
- publication_date_raw：2014-01-13
- subject_raw：有關發生於性別平等教育法（以下簡稱性平法）施行前之教師疑似性騷擾學生事件之相關疑義，詳如說明，請查照並周知所屬。
- source_year：2014
- source_path：sources/circulars/uploaded/2014(1).md
- source_line_start：24
- source_line_end：40
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2014-003｜臺教學(三)字第1030041317號

- publication_date：2014-03-26
- publication_date_raw：2014-03-26
- subject_raw：所詢臺中市政府教育局函為學生間偶發不當碰觸行為，得 否以雙方家長協調會議紀錄及放棄申請調查切結書代替校 園性別事件調查報告案等疑義事件，復如說明，請 查照。
- source_year：2014
- source_path：sources/circulars/uploaded/2014(1).md
- source_line_start：41
- source_line_end：59
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2014-004｜臺教學(三)字第1030052676號

- publication_date：2014-04-28
- publication_date_raw：2014-04-28
- subject_raw：所詢依性別平等教育法（以下簡稱性平法）第32條規定，申請人或行為人對於處理結果不服，得提起申復期間之相關疑義案，復如說明，請查照。
- source_year：2014
- source_path：sources/circulars/uploaded/2014(1).md
- source_line_start：60
- source_line_end：74
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：["CQ-007"]

## C2014-005｜臺教學(三)字第1030902914號

- publication_date：2014-05-26
- publication_date_raw：2014-05-26
- subject_raw：有關校園性侵害、性騷擾或性霸凌事件被害人或其法定代 理人不願意申請調查之處理及陳報本部「校園性侵害性騷 擾或性霸凌回復填報系統」（以下簡稱回報系統）之相關 疑義，請依說明辦理並轉知所屬，請 查照。
- source_year：2014
- source_path：sources/circulars/uploaded/2014(1).md
- source_line_start：75
- source_line_end：93
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2014-006｜臺教學(三)字第1030066452號

- publication_date：2014-05-29
- publication_date_raw：2014-05-29
- subject_raw：有關新北市政府教育局所詢其轄屬○○高中未滿18歲之學 生間合意發生刑法第227條之行為，致生校園性別事件程序疑 義案，請依說明辦理，請 查照並轉知所屬。
- source_year：2014
- source_path：sources/circulars/uploaded/2014(1).md
- source_line_start：94
- source_line_end：131
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2014-007｜臺教學(三)字第1030076075號

- publication_date：2014-05-29
- publication_date_raw：2014-05-29
- subject_raw：有關學制轉銜期間被害人或其法定代理人申請調查性侵害、 性騷擾或性霸凌事件之處理疑義，請依說明辦理，請 查 照並轉知所屬。
- source_year：2014
- source_path：sources/circulars/uploaded/2014(1).md
- source_line_start：132
- source_line_end：152
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2014-008｜臺教學(三)字第1030070852號

- publication_date：2014-06-03
- publication_date_raw：2014-06-03
- subject_raw：貴校函釋有關「校園性侵害性騷擾或性霸凌事件」檢舉人 是否可撤回申請調查乙案，復如說明，請 查照。
- source_year：2014
- source_path：sources/circulars/uploaded/2014(1).md
- source_line_start：153
- source_line_end：166
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2014-009｜臺教學(三)字第1030077620號

- publication_date：2014-06-11
- publication_date_raw：2014-06-11
- subject_raw：有關跨校校園性侵害、性騷擾或性霸凌事件，事件管轄學 校是否提供匿名版調查報告予被害人學校疑義，請依說明 辦理並轉知所屬，請 查照。
- source_year：2014
- source_path：sources/circulars/uploaded/2014(1).md
- source_line_start：167
- source_line_end：183
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2014-010｜臺教學(三)字第1030077657號

- publication_date：2014-06-25
- publication_date_raw：2014-06-25
- subject_raw：所詢本部退回貴校陳報「校園性侵害性騷擾或性霸凌事件統計管理系統」校安通報序號██████████████████████████████████████性平事件之疑義案，復如說明，請 查照。
- source_year：2014
- source_path：sources/circulars/uploaded/2014(1).md
- source_line_start：184
- source_line_end：206
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2014-011｜臺教學(三)字第1030116929號

- publication_date：2014-08-06
- publication_date_raw：2014-08-06
- subject_raw：所詢有關學校處理性別平等案件程序及疑義乙案，復如說 明，請 查照。
- source_year：2014
- source_path：sources/circulars/uploaded/2014(1).md
- source_line_start：207
- source_line_end：223
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2014-012｜臺教學(三)字第1030114831號

- publication_date：2014-08-11
- publication_date_raw：2014-08-11
- subject_raw：有關跨校校園性侵害、性騷擾或性霸凌事件，申請人學校 所派具備調查專業人員資格者參與事件管轄學校之調查會 議支領出席費相關疑義，請依說明辦理，請 查照並轉知 所屬。
- source_year：2014
- source_path：sources/circulars/uploaded/2014(1).md
- source_line_start：224
- source_line_end：242
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2014-013｜臺教學(三)字第1030126297號

- publication_date：2014-09-09
- publication_date_raw：2014-09-09
- subject_raw：所詢申請人依性別平等教育法（以下簡稱性平法）、行政程序法及校園性侵害性騷擾或性霸凌防治準則（以下簡稱防治準則）等相關規定，提出申請迴避之執行疑義，復如說明，請 查照。
- source_year：2014
- source_path：sources/circulars/uploaded/2014(1).md
- source_line_start：243
- source_line_end：260
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2014-014｜臺教師(二)字第1030133855號

- publication_date：2014-10-01
- publication_date_raw：2014-10-01
- subject_raw：貴校函請釋示有關碩士師資生疑似涉校園性侵害事件是否應中止教育實習資格，並靜候調查一案，復如說明，請查照。 言兌明
- source_year：2014
- source_path：sources/circulars/uploaded/2014(1).md
- source_line_start：261
- source_line_end：285
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2014-015｜臺教學(三)字第1030166366號

- publication_date：2014-11-24
- publication_date_raw：2014-11-24
- subject_raw：所詢依據性別平等教育法（以下簡稱性平法）第36條規定， 學校延遲通報校園性侵害、性騷擾或性霸凌事件之裁罰及 通報時點疑義，復如說明，請 查照。
- source_year：2014
- source_path：sources/circulars/uploaded/2014(1).md
- source_line_start：286
- source_line_end：310
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2014-016｜臺教學(三)字第1030161767號

- publication_date：2014-12-01
- publication_date_raw：2014-12-01
- subject_raw：所詢貴市大寮國中慈輝班發生疑似校園性侵害、性騷擾或 性霸凌事件之管轄權疑義案，復如說明，請 查照。
- source_year：2014
- source_path：sources/circulars/uploaded/2014(1).md
- source_line_start：311
- source_line_end：327
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2014-017｜臺教學(三)字第1030173560號

- publication_date：2014-12-02
- publication_date_raw：2014-12-02
- subject_raw：貴府函詢學校或主管機關之性別平等教育委員會處理校園性侵害性騷擾或性霸凌事件，得成立調查小組調查之，其中涉及校園師生間性平事件，調查小組成員得否全數外聘具調查專業素養之專家學者，俾利學校妥適處理案，請查照。
- source_year：2014
- source_path：sources/circulars/uploaded/2014(1).md
- source_line_start：328
- source_line_end：341
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2015-001｜臺教學(三)字第1030191814號

- publication_date：2015-01-06
- publication_date_raw：2015-01-06
- subject_raw：所詢家長會自辦之課後社團運動教練疑似性侵害學生，是否適用性別平等教育法案，復如說明，請 查照。
- source_year：2015
- source_path：sources/circulars/uploaded/2015(1).md
- source_line_start：3
- source_line_end：21
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2015-002｜臺教學(三)字第1030188561A號

- publication_date：2015-01-13
- publication_date_raw：2015-01-13
- subject_raw：請各地方政府及學校加強性騷擾之防治工作，於辦理外包業務（如學生健康檢查、校外教學、交通車、校園清潔業務等）時，應於服務契約明訂禁止廠商之服務人員有性騷擾或性侵害學生情事，且應列明違反之罰則等規範，並請列為重點宣導事項，以落實保護學生之人身安全，請查照並轉知所屬。
- source_year：2015
- source_path：sources/circulars/uploaded/2015(1).md
- source_line_start：22
- source_line_end：39
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2015-003｜臺教學(三)字第1040028094號

- publication_date：2015-03-30
- publication_date_raw：2015-03-30
- subject_raw：有關學校人員延遲法定通報之裁罰疑義及跨校案件法定通 報之處理事宜，請依說明辦理並轉知所屬，請 查照。
- source_year：2015
- source_path：sources/circulars/uploaded/2015(1).md
- source_line_start：40
- source_line_end：66
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2015-004｜臺教學(三)字第1040042214A號

- publication_date：2015-04-21
- publication_date_raw：2015-04-21
- subject_raw：有關學校之軍訓教官涉校園性侵害、性騷擾或性霸凌事件 （以下簡稱校園性別事件）時，服務學校應否比照教師法 第14條第4項規定辦理，以維學生身心安全與受教權益，請 依說明辦理，請查照並轉知所屬。
- source_year：2015
- source_path：sources/circulars/uploaded/2015(1).md
- source_line_start：67
- source_line_end：84
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：["CR-006"]
- quality_issue_ids：[]

## C2015-005｜臺教學(三)字第1040057917號

- publication_date：2015-05-06
- publication_date_raw：2015-05-06
- subject_raw：有關校園性侵害性騷擾或性霸凌防治準則（以下簡稱防治 準則）第23條第5款規定，申請人撤回申請後能否再度申請 疑義，請依說明辦理並轉知所屬，請查照。
- source_year：2015
- source_path：sources/circulars/uploaded/2015(1).md
- source_line_start：85
- source_line_end：103
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2015-006｜法律字第10403501200號

- publication_date：2015-05-07
- publication_date_raw：2015-05-07
- subject_raw：關於函詢未滿14歲之學生，涉校園性騷擾或性霸凌事件，經學校調查為加害人屬實，學校為該事件之懲處時，有行政罰法第1條、第9條第1項及性別平等教育法第25條第2項適用競合疑義乙案，復如說明二至三，請查照參考。
- source_year：2015
- source_path：sources/circulars/uploaded/2015(1).md
- source_line_start：104
- source_line_end：118
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2015-007｜臺教學(三)字第1040065660號

- publication_date：2015-05-19
- publication_date_raw：2015-05-19
- subject_raw：服務於大專校院之軍訓教官倘涉校園性侵害、性騷擾或性 霸凌事件時，依據本部104年4月21日臺教學（三）字第 1040042214A號函（諒達）說明三規定，請服務學校以書面 通知本部處理該軍訓教官之調職、請假及議處事宜，請查 照。 說明
- source_year：2015
- source_path：sources/circulars/uploaded/2015(1).md
- source_line_start：119
- source_line_end：132
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：["CR-007"]
- quality_issue_ids：[]

## C2015-008｜臺教學(三)字第1040061904號

- publication_date：2015-05-20
- publication_date_raw：2015-05-20
- subject_raw：函轉法務部關於未滿14歲之學生，涉校園性侵害、性騷擾或性霸凌事件（下稱校園性別事件），經學校調查為加害人屬實，學校命令加害人接受性平等教育課程或心理輔導等處置，非屬行政罰乙案（如附件），請查照。
- source_year：2015
- source_path：sources/circulars/uploaded/2015(1).md
- source_line_start：133
- source_line_end：150
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2015-009｜臺教學(三)字第1040065754號

- publication_date：2015-05-22
- publication_date_raw：2015-05-22
- subject_raw：有關學生間於校外實習期間疑似發生性騷擾事件之法規適 用，請依勞動部104年5月14日勞動條4字第1040130811號函 （如附件）釋規定辦理並轉知所屬，請查照。
- source_year：2015
- source_path：sources/circulars/uploaded/2015(1).md
- source_line_start：151
- source_line_end：171
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：["CR-032"]
- quality_issue_ids：[]

## C2015-010｜臺教學(三)字第1040091045號

- publication_date：2015-07-15
- publication_date_raw：2015-07-15
- subject_raw：為釐清性霸凌之定義及提供特殊教育學校與一般學校處理 身心障礙學生（以下簡稱特教生）涉及校園性侵害、性騷 擾或性霸凌事件（以下簡稱校園性別事件）之原則，列如 說明，請查照並轉知所屬據以辦理。
- source_year：2015
- source_path：sources/circulars/uploaded/2015(1).md
- source_line_start：172
- source_line_end：191
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2015-011｜臺教學(三)字第1040113170號

- publication_date：2015-08-19
- publication_date_raw：2015-08-19
- subject_raw：有關留職停薪教師涉校園性侵害、性騷擾或性霸凌事件（ 以下簡稱校園性別事件）之身分認定及適法疑義案，請查 照轉知。
- source_year：2015
- source_path：sources/circulars/uploaded/2015(1).md
- source_line_start：192
- source_line_end：208
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2015-012｜臺教學(三)字第1040122354號

- publication_date：2015-09-15
- publication_date_raw：2015-09-15
- subject_raw：有關函轉民眾詢問校園性別事件處理流程之保密與資料調閱、特色課程兼任教師涉及事件經調查屬實之後續懲處疑義案，復如說明，請據以回復該民眾，請查照。
- source_year：2015
- source_path：sources/circulars/uploaded/2015(1).md
- source_line_start：209
- source_line_end：226
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2015-013｜臺教學(三)字第1040147362號

- publication_date：2015-11-06
- publication_date_raw：2015-11-06
- subject_raw：所詢本部「校園性侵害性騷擾或性霸凌事件通報及調查處 理程序參考流程圖」（以下簡稱流程圖）內容疑義乙案， 復如說明，請查照。
- source_year：2015
- source_path：sources/circulars/uploaded/2015(1).md
- source_line_start：227
- source_line_end：245
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2015-014｜臺教人(三)字第1040143906號

- publication_date：2015-12-03
- publication_date_raw：2015-12-03
- subject_raw：有關教師法第14條第1項第9款及同條第4項與校園性侵害性 騷擾或性霸凌防治準則第25條執行疑義一案，請依說明段 辦理，請查照。
- source_year：2015
- source_path：sources/circulars/uploaded/2015(1).md
- source_line_start：246
- source_line_end：272
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2015-015｜臺教人(三)字第1040154589號

- publication_date：2015-12-14
- publication_date_raw：2015-12-14
- subject_raw：所詢校園發生師對生性侵害、性騷擾或性霸凌事件（以下簡稱性別事件），該名教師於案件調查階段經該校核定進修留職停薪，是否有違相關規定疑義一案，復請查照。
- source_year：2015
- source_path：sources/circulars/uploaded/2015(1).md
- source_line_start：273
- source_line_end：290
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2015-016｜臺教學(三)字第1040133041號

- publication_date：2015-12-16
- publication_date_raw：2015-12-16
- subject_raw：教育部國民及學前教育署函轉民眾所詢，教師涉校園性別 事件請事假接受調查期間是否扣薪疑義案，列如說明，請 查照並轉知所屬據以辦理。
- source_year：2015
- source_path：sources/circulars/uploaded/2015(1).md
- source_line_start：291
- source_line_end：305
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2015-017｜臺教學(三)字第1040163961號

- publication_date：2015-12-28
- publication_date_raw：2015-12-28
- subject_raw：貴處為調查案件需要，請本部於文到7日內就所詢回復案， 復如說明，請查照。
- source_year：2015
- source_path：sources/circulars/uploaded/2015(1).md
- source_line_start：306
- source_line_end：321
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2016-001｜臺教人(三)字第1040154065號

- publication_date：2016-01-11
- publication_date_raw：2016-01-11
- subject_raw：貴校函詢教師法第14條第1項第13款執行疑義一案，復如說 明，請查照。
- source_year：2016
- source_path：sources/circulars/uploaded/2016(1).md
- source_line_start：3
- source_line_end：30
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2016-002｜臺教學(三)字第1050043324號

- publication_date：2016-03-31
- publication_date_raw：2016-03-31
- subject_raw：為利學校通報之落實，性侵害案件應以知悉事件內容中至少有任一方當事人之身分資訊方需進行通報，請查照並轉知所屬。
- source_year：2016
- source_path：sources/circulars/uploaded/2016(1).md
- source_line_start：31
- source_line_end：46
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2016-003｜法檢字第10504500190號

- publication_date：2016-04-21
- publication_date_raw：2016-04-21
- subject_raw：有關學校教師因涉性侵害案件遭地方法院檢察署（下稱地 檢署）聲請羈押獲准，得否同意學校調查小組請求至羈押 處所進行訪談乙事，復如說明二、三，請查照。。
- source_year：2016
- source_path：sources/circulars/uploaded/2016(1).md
- source_line_start：47
- source_line_end：61
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：["CR-017"]
- quality_issue_ids：[]

## C2016-004｜臺教學(三)字第1050056133號

- publication_date：2016-05-10
- publication_date_raw：2016-05-10
- subject_raw：有關學校教師因涉性侵害案件遭地方法院檢察署（下稱地檢署）聲請羈押獲准，得否同意學校調查小組請求至羈押處所進行訪談乙事，請依法務部105年4月21日法檢字第10504500190號函釋（如附件）辦理並轉知所屬，請查照。
- source_year：2016
- source_path：sources/circulars/uploaded/2016(1).md
- source_line_start：62
- source_line_end：75
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：["CR-017"]
- quality_issue_ids：[]

## C2016-005｜臺教學(三)字第1050061866號

- publication_date：2016-05-23
- publication_date_raw：2016-05-23
- subject_raw：有關參與國民教育階段團體實驗教育或機構實驗教育內學 生發生性侵害、性騷擾或性霸凌事件，是否適用性別平等 教育法（以下簡稱性平法）案，請依說明辦理並轉知所屬， 請查照。
- source_year：2016
- source_path：sources/circulars/uploaded/2016(1).md
- source_line_start：76
- source_line_end：93
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2016-006｜臺教學(三)字第1050056734號

- publication_date：2016-06-28
- publication_date_raw：2016-06-28
- subject_raw：本部104年4月21日臺教學(三)字第1040042214A號函示有關 處理軍訓教官涉及校園性侵害、性騷擾或性霸凌事件（以 下簡稱校園性別事件）之議處程序及救濟疑義，請依說明 辦理，請查照並轉知所屬。
- source_year：2016
- source_path：sources/circulars/uploaded/2016(1).md
- source_line_start：94
- source_line_end：117
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：["CR-008"]
- quality_issue_ids：[]

## C2016-007｜臺教學(三)字第1050094722號

- publication_date：2016-07-22
- publication_date_raw：2016-07-22
- subject_raw：所詢有關性別平等教育法（以下簡稱性平法）第25條第4項 所定，「懲處涉及加害人身分之改變時，應給予其書面陳 述意見之機會」應於何時及何單位為之，復如說明，請查 照。
- source_year：2016
- source_path：sources/circulars/uploaded/2016(1).md
- source_line_start：118
- source_line_end：135
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2016-008｜臺教學(三)字第1050095339號

- publication_date：2016-08-04
- publication_date_raw：2016-08-04
- subject_raw：所詢有關性別平等教育法（以下簡稱性平法）第31條之期 日疑義，復如說明，請查照。
- source_year：2016
- source_path：sources/circulars/uploaded/2016(1).md
- source_line_start：136
- source_line_end：150
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2016-009｜臺教學(三)字第1050127705號

- publication_date：2016-09-10
- publication_date_raw：2016-09-10
- subject_raw：重申校園如發生性侵害、性騷擾或性霸凌事件，應確依性 別平等教育法（以下稱性平法）及依校園性侵害性騷擾或 性霸凌防治準則（以下稱防治準則）所定程序調查處理， 請查照並轉知所屬。
- source_year：2016
- source_path：sources/circulars/uploaded/2016(1).md
- source_line_start：151
- source_line_end：170
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2016-010｜衛部護字第1051461876號

- publication_date：2016-09-30
- publication_date_raw：2016-09-30
- subject_raw：有關媒體、網際網路等報導、轉載或其他任何方法公開或 揭露性侵害案件涉有足資識別被害人身分資訊一案，請查 照辦理並配合加強宣導。
- source_year：2016
- source_path：sources/circulars/uploaded/2016(1).md
- source_line_start：171
- source_line_end：186
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2016-011｜勞動條4字第1050025766號

- publication_date：2016-10-31
- publication_date_raw：2016-10-31
- subject_raw：有關私立學校教育人員職場性騷擾案件之申訴程序及權管單位相關疑義乙案，涉本部業務部分，復如說明，請查照。
- source_year：2016
- source_path：sources/circulars/uploaded/2016(1).md
- source_line_start：187
- source_line_end：205
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2016-012｜臺教人(三)字第1050129046號

- publication_date：2016-10-31
- publication_date_raw：2016-10-31
- subject_raw：所詢教師法第14條第1項第13款適用疑義一案，復如說明， 請查照。
- source_year：2016
- source_path：sources/circulars/uploaded/2016(1).md
- source_line_start：206
- source_line_end：223
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2016-013｜臺教人(三)字第1050142481號

- publication_date：2016-11-02
- publication_date_raw：2016-11-02
- subject_raw：有關本部98年12月24日台人（二）字第0980216714號函釋 補充如說明，請查照。
- source_year：2016
- source_path：sources/circulars/uploaded/2016(1).md
- source_line_start：224
- source_line_end：246
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2016-014｜臺教學(三)字第1050165485A號

- publication_date：2016-11-29
- publication_date_raw：2016-11-29
- subject_raw：近期發生學校人員處理未滿18歲學生間疑似校園性騷擾事 件，因先詢問社政單位後未予通報致生遭受裁罰情事，仍 請本權責加強宣導應依法通報事宜，請查照並轉知所屬。
- source_year：2016
- source_path：sources/circulars/uploaded/2016(1).md
- source_line_start：247
- source_line_end：265
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2016-015｜臺教學(三)字第1050165071A號

- publication_date：2016-11-30
- publication_date_raw：2016-11-30
- subject_raw：為避免學校性別平等教育委員會（以下簡稱性平會）以外 人員違法調查處理校園性侵害、性騷擾或性霸凌事件（以 下簡稱校園別事件），請依說明辦理並轉知所屬，請查照。
- source_year：2016
- source_path：sources/circulars/uploaded/2016(1).md
- source_line_start：266
- source_line_end：282
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2016-016｜臺教學(三)字第1050169690號

- publication_date：2016-12-30
- publication_date_raw：2016-12-30
- subject_raw：所詢直轄市、縣市政府所設性別平等教育委員會（以下簡 稱性平會）就多人涉案而被害人及其法定代理人不申請調 查事件，決議請學校應提出檢舉進行調查是否適法案，復 如說明，請查照。
- source_year：2016
- source_path：sources/circulars/uploaded/2016(1).md
- source_line_start：283
- source_line_end：299
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2017-001｜臺教人(三)字第1050181207號

- publication_date：2017-02-06
- publication_date_raw：2017-02-06
- subject_raw：有關教師懲處權之行使期間，參照公務人員類推適用公務員懲戒法相關規定，自違失行為終了之日起逾10年者，不予追究，請查照。
- source_year：2017
- source_path：sources/circulars/uploaded/2017(1).md
- source_line_start：3
- source_line_end：31
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：["CQ-003"]

## C2017-002｜臺教學(三)字第1060014333號

- publication_date：2017-02-08
- publication_date_raw：2017-02-08
- subject_raw：為提升學校權責人員執行校園性侵害、性騷擾或性霸凌事件「社政通報」及「校安通報」之即時性及正確性，請依說明辦理，請查照。
- source_year：2017
- source_path：sources/circulars/uploaded/2017(1).md
- source_line_start：32
- source_line_end：50
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2017-003｜臺教學(三)字第1060065118號

- publication_date：2017-05-25
- publication_date_raw：2017-05-25
- subject_raw：修正本部105年12月9日臺教學（三）字第1050169132號函 （諒達）說明二（二），有關學校調查處理教師涉及校園 性騷擾或性霸凌事件認定非屬情節重大或認定屬違反專業 倫理者，倘認有違反兒童及少年福利與權益保障法（以下 簡稱兒權法）之虞相關處理程序，請查照並轉知所屬知照。
- source_year：2017
- source_path：sources/circulars/uploaded/2017(1).md
- source_line_start：51
- source_line_end：63
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：["CR-004"]
- quality_issue_ids：[]

## C2017-004｜臺教學(三)字第1060077324號

- publication_date：2017-07-12
- publication_date_raw：2017-07-12
- subject_raw：二、本素來文所拍案件為教師於93 年性平法未施行前涉及性騷擾多名女學生，倘經被害人於現今提出申請調查或經媒體報導(視同檢舉) ，則該事件之調查處理及議處之法規依據，請參考本部102 年12 月 12 日臺教學(三)字第1020168370 號及103 年 1 月 13 日臺教學 ( 三) .字第1020190069號函(均諒達)辦理 。
- source_year：2017
- source_path：sources/circulars/uploaded/2017(1).md
- source_line_start：64
- source_line_end：82
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2017-005｜臺教學(三)字第1060092113號

- publication_date：2017-07-26
- publication_date_raw：2017-07-26
- subject_raw：有關學校性別平等教育委員會（以下簡稱性平會）調查處 理校園相關性別事件，事實認定論及「情節重大」之定義 與判斷基準，如說明，請查照並轉知所屬。
- source_year：2017
- source_path：sources/circulars/uploaded/2017(1).md
- source_line_start：83
- source_line_end：107
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：["CR-012"]
- quality_issue_ids：[]

## C2017-006｜臺教學(三)字第1060103361號

- publication_date：2017-07-28
- publication_date_raw：2017-07-28
- subject_raw：有關校園性侵害、性騷擾或性霸凌事件處理相關疑義（涉 及公益之定義、通報、輔導專責人員擔任性平會承辦人等）， 請依說明辦理，請查照並轉所屬知照。
- source_year：2017
- source_path：sources/circulars/uploaded/2017(1).md
- source_line_start：108
- source_line_end：130
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2017-007｜臺教學(三)字第1060187066號

- publication_date：2017-12-25
- publication_date_raw：2017-12-25
- subject_raw：抄本 擋號:係存年限 :
- source_year：2017
- source_path：sources/circulars/uploaded/2017(1).md
- source_line_start：131
- source_line_end：145
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2018-001｜臺教學(三)字第1070000950號

- publication_date：2018-01-22
- publication_date_raw：2018-01-22
- subject_raw：有關執行校園性侵害、性騷擾或性霸凌事件（以下簡稱校 園性別事件）行為人防治教育人員對於該事件之知情範圍， 列如說明，請查照並轉知所屬。
- source_year：2018
- source_path：sources/circulars/uploaded/2018(1).md
- source_line_start：3
- source_line_end：19
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：["CR-011"]
- quality_issue_ids：[]

## C2018-002｜臺教學(三)字第1070026350號

- publication_date：2018-03-09
- publication_date_raw：2018-03-09
- subject_raw：所詢學校性別平等教育委員會（以下簡稱性平會）審議調 查報告疑義案，復如說明，請查照並轉知所屬。
- source_year：2018
- source_path：sources/circulars/uploaded/2018(1).md
- source_line_start：20
- source_line_end：36
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：["CR-019"]
- quality_issue_ids：[]

## C2018-003｜臺教學(三)字第1070029022號

- publication_date：2018-03-23
- publication_date_raw：2018-03-23
- subject_raw：所詢有關性別平等教育法（以下簡稱性平法）第30條第3項 規定適用疑義案，復如說明，請查照。
- source_year：2018
- source_path：sources/circulars/uploaded/2018(1).md
- source_line_start：37
- source_line_end：61
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：["CR-019"]
- quality_issue_ids：[]

## C2018-004｜臺教學(三)字第1070061751C號

- publication_date：2018-06-08
- publication_date_raw：2018-06-08
- subject_raw：檢送性別平等教育法（以下簡稱性平法）第28條第2項但書 及校園性侵害性騷擾或性霸凌防治準則（以下簡稱防治準 則）第10條第1項但書規定解釋令1份如附件，請查照並轉 所屬知照。
- source_year：2018
- source_path：sources/circulars/uploaded/2018(1).md
- source_line_start：62
- source_line_end：75
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2018-005｜臺教學(三)字第1070072925號

- publication_date：2018-06-14
- publication_date_raw：2018-06-14
- subject_raw：所詢有關校園性侵害性騷擾或性霸凌防治準則第10條及第 14條規定適用疑義1案，復如說明，請查照。
- source_year：2018
- source_path：sources/circulars/uploaded/2018(1).md
- source_line_start：76
- source_line_end：94
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2018-006｜臺教學(三)字第1070085885A號

- publication_date：2018-07-04
- publication_date_raw：2018-07-04
- subject_raw：有關參與高級中等教育階段團體實驗教育或機構實驗教育 內學生與該機構或團體之教學人員發生性侵害、性騷擾或 性霸凌事件（以下簡稱校園性別事件），是否適用性別平 等教育法（以下簡稱性平法）之規定案，復如說明，請查 照並轉知所屬。
- source_year：2018
- source_path：sources/circulars/uploaded/2018(1).md
- source_line_start：95
- source_line_end：110
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2018-007｜臺教學(三)字第1070092513號

- publication_date：2018-07-06
- publication_date_raw：2018-07-06
- subject_raw：所詢有關校長疑似涉及性平事件於調查期間，得否比照教 師法第14條第4項規定辦理停聘校長職務疑義，復如說明， 請查照。
- source_year：2018
- source_path：sources/circulars/uploaded/2018(1).md
- source_line_start：111
- source_line_end：127
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2018-008｜臺教人(三)字第1070133288號

- publication_date：2018-08-15
- publication_date_raw：2018-08-15
- subject_raw：所詢教師涉校園性侵害、性騷擾或性霸凌行為之懲處權行 使期間及起算疑義一案，復如說明，請查照。
- source_year：2018
- source_path：sources/circulars/uploaded/2018(1).md
- source_line_start：128
- source_line_end：146
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2018-009｜臺教學(三)字第1070137796A號

- publication_date：2018-09-21
- publication_date_raw：2018-09-21
- subject_raw：有關校園性侵害、性騷擾或性霸凌事件，及教師涉及校園 性侵害性騷擾或性霸凌防治準則（以下簡稱防治準則）第7 條所定違反專業倫理事件（以下統稱校園性別事件），申 請人及行為人不服學校性別平等教育委員會（以下簡稱性 平會）調查結果，提出申復及申訴程序相關疑義，請轉知 所屬依說明辦理，請查照。 說明
- source_year：2018
- source_path：sources/circulars/uploaded/2018(1).md
- source_line_start：147
- source_line_end：163
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2018-010｜臺教學(三)字第1070140014A號

- publication_date：2018-09-21
- publication_date_raw：2018-09-21
- subject_raw：有關性別平等教育法（以下簡稱性平法）所定性霸凌定義 及構成要件，如說明，請轉知所屬據以辦理，請查照。
- source_year：2018
- source_path：sources/circulars/uploaded/2018(1).md
- source_line_start：164
- source_line_end：180
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2018-011｜臺教學(三)字第1070162328號

- publication_date：2018-09-26
- publication_date_raw：2018-09-26
- subject_raw：法官及檢察官不應擔任性別平等教育法（下稱性平法）第30條第2項所定調查小組成員，詳如說明，請查照並轉知所屬知照。
- source_year：2018
- source_path：sources/circulars/uploaded/2018(1).md
- source_line_start：181
- source_line_end：195
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2018-012｜臺教學(三)字第1070181019號

- publication_date：2018-10-31
- publication_date_raw：2018-10-31
- subject_raw：有關貴府函詢校園性侵害、性騷擾或性霸凌事件調查專業人員（下稱調查專業人員）資格者得否適用「教師因公涉訟補助辦法」一案，復如說明，請查照。
- source_year：2018
- source_path：sources/circulars/uploaded/2018(1).md
- source_line_start：196
- source_line_end：213
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2018-013｜臺教學(三)字第1070188895號

- publication_date：2018-11-05
- publication_date_raw：2018-11-05
- subject_raw：有關學校校長涉及校園性侵害、性騷擾或性霸凌事件經調 查屬實解聘案，其提起申復時點疑義案，請查照並轉知所 屬依說明辦理。
- source_year：2018
- source_path：sources/circulars/uploaded/2018(1).md
- source_line_start：214
- source_line_end：230
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2018-014｜臺教學(三)字第1070216209號

- publication_date：2018-12-25
- publication_date_raw：2018-12-25
- subject_raw：所詢有關校園性別事件行為人依法應配合調查，並提供相 關資料疑義案，復如說明，請查照。
- source_year：2018
- source_path：sources/circulars/uploaded/2018(1).md
- source_line_start：231
- source_line_end：250
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2019-001｜臺教學(三)字第1070227698號

- publication_date：2019-01-21
- publication_date_raw：2019-01-21
- subject_raw：有關校園性平事件調查小組進行調查時，當事人或被調查 人要求錄音、錄影及不配合調查時之建議處理方式，請查 照。
- source_year：2019
- source_path：sources/circulars/uploaded/2019(1).md
- source_line_start：3
- source_line_end：19
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2019-002｜臺教學(三)字第1080022818號

- publication_date：2019-02-26
- publication_date_raw：2019-02-26
- subject_raw：有關校園性侵害、性騷擾或性霸凌事件調查小組於調查校 園性別事件過程中主動瞭解學校相關人員有無違反性別平 等教育法（下稱性平法）之疏失案，詳如說明，請查照。
- source_year：2019
- source_path：sources/circulars/uploaded/2019(1).md
- source_line_start：20
- source_line_end：42
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2019-003｜臺教學(三)字第1080019052號

- publication_date：2019-04-10
- publication_date_raw：2019-04-10
- subject_raw：有關校園性侵害、性騷擾或性霸凌事件當事人於事件處理 過程申請閱卷之處理，茲依各程序階段提供補充說明（如 附件一覽表），請據以運用並轉知所屬，請查照。
- source_year：2019
- source_path：sources/circulars/uploaded/2019(1).md
- source_line_start：43
- source_line_end：86
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：["CQ-004"]

## C2019-004｜臺教學(三)字第1080060532號

- publication_date：2019-05-02
- publication_date_raw：2019-05-02
- subject_raw：所詢有關校園性平事件疑似被害人為未成年人時，事件處 理之相關問題（涉及跨校校園性平事件調查小組、性侵害 事件之通知）疑義，復如說明，請查照。
- source_year：2019
- source_path：sources/circulars/uploaded/2019(1).md
- source_line_start：87
- source_line_end：105
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2019-005｜臺教學(三)字第1080088013號

- publication_date：2019-06-21
- publication_date_raw：2019-06-21
- subject_raw：修正本部就各級學校處理校園性侵害性騷擾或性霸凌事件 說明一覽表第11項所列調查相關費用支給說明（如附件）， 請查照並轉知所屬。
- source_year：2019
- source_path：sources/circulars/uploaded/2019(1).md
- source_line_start：106
- source_line_end：130
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：["CR-013", "CR-022"]
- quality_issue_ids：[]

## C2019-006｜臺教授國部字第1080061503號

- publication_date：2019-07-03
- publication_date_raw：2019-07-03
- subject_raw：有關公立高級中等以下學校校長懲處權行使期間規範如說 . . . 明，請查照。 . . .. 說明： . . . 一、查公立高級中等以下學校校長之懲處係依「公立高級中等 . . .. 以下學校校長成績考核辦法」規定辦理，該辦法第7條規 . . 定，校長之懲處分申誡、記過及記大過。 . . .. 二、次查司法院釋字第308號解釋略以：兼任學校行政職務之教 . . . 師，就其兼任之行政職務，有公務員服務法之適用。又司 . . . 法院院字第2757號解釋文意旨略以，公立學校校長受有俸. . . . 給者，為公務員服務…
- source_year：2019
- source_path：sources/circulars/uploaded/2019(1).md
- source_line_start：131
- source_line_end：145
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2019-007｜臺教學(三)字第1080101196號

- publication_date：2019-08-13
- publication_date_raw：2019-08-13
- subject_raw：有關校園性別事件檢舉案重啟調查小組係按性別平等教育 法（以下簡稱性平法）107年12月28日修正前之第30條第3 項規定組成，未有被害人現所屬學校之代表，及被害人或 其法定代理人拒絕通知現就讀學校派代表參與調查之程序 疑義，請依說明辦理並周知所屬，請查照。
- source_year：2019
- source_path：sources/circulars/uploaded/2019(1).md
- source_line_start：146
- source_line_end：163
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2019-008｜臺教學(三)字第1080112231號

- publication_date：2019-08-20
- publication_date_raw：2019-08-20
- subject_raw：有關學校聘任、任用、進用或運用之課後社團人員、代理 . . . 代課鐘點教師或其他外聘非正式教師人員，涉及校園性侵 . . .. 害、性騷擾或性霸凌事件調查處理程序事宜，詳如說明， . . . 請查照。 . . .. 說明： . . 一、復108年7月26日臺教國署學字第1080083099A號函。 . . .. 二、有關學校聘任、任用、進用或運用之課後社團人員、代理 . . . 代課鐘點教師或其他外聘非正式教師人員，倘同時於多所 . . . 學校服務，並涉校園性侵害、性騷擾或性霸凌事件，有性. . . . 別平…
- source_year：2019
- source_path：sources/circulars/uploaded/2019(1).md
- source_line_start：164
- source_line_end：175
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2019-009｜臺教學(三)字第1080108133號

- publication_date：2019-08-22
- publication_date_raw：2019-08-22
- subject_raw：為落實校園性侵害事件之防治及有效防堵涉有性侵害行為 屬實之學校人員，請各級學校依說明落實辦理，並請各級 主管機關加強督導考核學校，請查照。
- source_year：2019
- source_path：sources/circulars/uploaded/2019(1).md
- source_line_start：176
- source_line_end：196
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：["C2019-010"]
- known_relation_ids：[]
- quality_issue_ids：["QDUP-001"]

## C2019-010｜臺教學(三)字第1080108133號

- publication_date：2019-08-22
- publication_date_raw：2019-08-22
- subject_raw：為落實校園性侵害事件之防治及有效防堵涉有性侵害行為 屬實之學校人員，請各級學校依說明落實辦理，並請各級 主管機關加強督導考核學校，請查照。
- source_year：2019
- source_path：sources/circulars/uploaded/2019(1).md
- source_line_start：197
- source_line_end：217
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：["C2019-009"]
- known_relation_ids：[]
- quality_issue_ids：["QDUP-001"]

## C2019-011｜臺教學(三)字第1080122655號

- publication_date：2019-10-15
- publication_date_raw：2019-10-15
- subject_raw：有關各縣市學校軍訓人員不服校園性侵害、性騷擾或性霸 凌事件（以下簡稱校園性別事件）之處理結果，其提起申 復之時點疑義，請依說明辦理，並轉知所屬，請查照。
- source_year：2019
- source_path：sources/circulars/uploaded/2019(1).md
- source_line_start：218
- source_line_end：242
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2019-012｜臺教學(三)字第1080147002號

- publication_date：2019-10-30
- publication_date_raw：2019-10-30
- subject_raw：所詢有關教師不服學校處理事件之結果，依性別平等教育 法（以下簡稱性平法）第32條及第34條提出申復及申訴（ 有理由），後續仍不服學校性別平等教育委員會重為決定 之結果，渠後續應提申復或逕提申訴疑義，復如說明，請 查照。 說明
- source_year：2019
- source_path：sources/circulars/uploaded/2019(1).md
- source_line_start：243
- source_line_end：261
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2019-013｜臺教學(三)字第1080152259號

- publication_date：2019-11-06
- publication_date_raw：2019-11-06
- subject_raw：有關軍公教人員及勞工各類受訓人員參加職前訓練及在職 訓練遭受性騷擾之適用法規，請依說明辦理並轉知所屬， 請查照。
- source_year：2019
- source_path：sources/circulars/uploaded/2019(1).md
- source_line_start：262
- source_line_end：282
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2019-014｜臺教學(三)字第1080159628號

- publication_date：2019-11-08
- publication_date_raw：2019-11-08
- subject_raw：所詢有關已被檢舉調查過之行為人，可否以被害人身分申請調查1案，復如說明，請查照。
- source_year：2019
- source_path：sources/circulars/uploaded/2019(1).md
- source_line_start：283
- source_line_end：303
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2019-015｜臺教學(三)字第1080161722號

- publication_date：2019-11-28
- publication_date_raw：2019-11-28
- subject_raw：有關各級學校教職員工具備校園性侵害性騷擾或性霸凌事 件調查專業人才資格者，受邀參與非本職學校案件之調查 會議，得否以公假應邀出席並同時支領出席費疑義案，請 依說明辦理並轉知所屬，請查照。
- source_year：2019
- source_path：sources/circulars/uploaded/2019(1).md
- source_line_start：304
- source_line_end：320
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2020-001｜臺教學(三)字第1090008404號

- publication_date：2020-01-30
- publication_date_raw：2020-01-30
- subject_raw：有關學校依性別平等教育法（以下稱性平法）第30條第2項 規定組成之調查小組成員，因調查程序而涉訟之權益保障 及提供協助案，請轉知所屬，請查照。
- source_year：2020
- source_path：sources/circulars/uploaded/2020(1).md
- source_line_start：3
- source_line_end：20
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2020-002｜臺教學(三)字第1090026861號

- publication_date：2020-02-26
- publication_date_raw：2020-02-26
- subject_raw：所詢學校接獲「保護令」，是否需於24小時內通報校安中心之疑義，復如說明，請查照。
- source_year：2020
- source_path：sources/circulars/uploaded/2020(1).md
- source_line_start：21
- source_line_end：38
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2020-003｜臺教學(三)字第1090004434號

- publication_date：2020-03-18
- publication_date_raw：2020-03-18
- subject_raw：貴會為保障兒童權利，函請本部就性別平等教育法（以下 簡稱性平法）第24條及第28條規定於實務處理造成個案不 利處境修正法規或釋疑1案，復如說明，請查照。
- source_year：2020
- source_path：sources/circulars/uploaded/2020(1).md
- source_line_start：39
- source_line_end：65
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：["CQ-006"]

## C2020-004｜臺教學(三)字第1090061824號

- publication_date：2020-05-06
- publication_date_raw：2020-05-06
- subject_raw：有關性別平等教育法（下稱性平法）第30條第3項後段及校 園性侵害性騷擾或性霸凌防治準則（下稱防治準則）第23 條第2款規定案，詳如說明，請查照。
- source_year：2020
- source_path：sources/circulars/uploaded/2020(1).md
- source_line_start：66
- source_line_end：84
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2020-005｜臺教學(三)字第1090068583號

- publication_date：2020-05-25
- publication_date_raw：2020-05-25
- subject_raw：言兌明:
- source_year：2020
- source_path：sources/circulars/uploaded/2020(1).md
- source_line_start：85
- source_line_end：100
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2020-006｜臺教學(三)字第1090088223號

- publication_date：2020-07-24
- publication_date_raw：2020-07-24
- subject_raw：有關實習學生經教育實習機構性別平等教育委員會（以下 稱性平會）調查確認有性侵害、性騷擾或性霸凌行為屬實， 相關懲處及處置執行疑義案，請貴管依說明釐明，復請查 照。
- source_year：2020
- source_path：sources/circulars/uploaded/2020(1).md
- source_line_start：101
- source_line_end：126
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2020-007｜臺教學(三)字第1090112970號

- publication_date：2020-08-13
- publication_date_raw：2020-08-13
- subject_raw：貴局函詢學校教師涉及校園性侵害、性騷擾或性霸凌事件 於學校作成解聘決議後，報請主管教育行政機關（以下簡 稱主管機關）核准並同時通知當事人得提起申復之時點疑 義，復如說明，請查照。
- source_year：2020
- source_path：sources/circulars/uploaded/2020(1).md
- source_line_start：127
- source_line_end：144
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2020-008｜臺教學(三)字第1090135683號

- publication_date：2020-09-23
- publication_date_raw：2020-09-23
- subject_raw：有關事件當事人分屬不同學校之疑似校園性侵害、性騷擾 及性霸凌事件（以下簡稱跨校事件）通報作業，請依說明 辦理，請查照。
- source_year：2020
- source_path：sources/circulars/uploaded/2020(1).md
- source_line_start：145
- source_line_end：165
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2020-009｜臺教學(三)字第1090151773號

- publication_date：2020-12-04
- publication_date_raw：2020-12-04
- subject_raw：為落實性別平等教育法（下稱性平法）相關規定，避免學 校性別平等教育委員會（下稱性平會）進用不適任調查成 員之情形一案，請依說明辦理，請查照。
- source_year：2020
- source_path：sources/circulars/uploaded/2020(1).md
- source_line_start：166
- source_line_end：184
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：["CR-033"]
- quality_issue_ids：[]

## C2020-010｜臺教學(三)字第1090152538號

- publication_date：2020-12-04
- publication_date_raw：2020-12-04
- subject_raw：有關所詢校園性別事件調查小組成員是否為公務人員及其 涉訟輔助，復如說明，請查照。
- source_year：2020
- source_path：sources/circulars/uploaded/2020(1).md
- source_line_start：185
- source_line_end：203
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2020-011｜臺教學(三)字第1090164156號

- publication_date：2020-12-25
- publication_date_raw：2020-12-25
- subject_raw：有關函轉臺北市政府教育局函詢校園性別事件案之疑似被 害人拒絕受訪，後續調查程序究應中止或繼續履行疑義案， 復如說明，請查照。
- source_year：2020
- source_path：sources/circulars/uploaded/2020(1).md
- source_line_start：204
- source_line_end：216
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：["CR-010"]
- quality_issue_ids：[]

## C2021-001｜臺教學(三)字第1100012284A號

- publication_date：2021-02-17
- publication_date_raw：2021-02-17
- subject_raw：有關學生進入實習階段前之性騷擾防治宣導教育，請學校 性別平等教育委員會併學生校外實習、建教（產學）合作 學習，列為年度例行工作規劃辦理防治教育宣導，以強化 學生進入職場之性別平等意識，防範相關事件之發生，請 查照並轉知所屬。 說明
- source_year：2021
- source_path：sources/circulars/uploaded/2021(1).md
- source_line_start：3
- source_line_end：24
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2021-002｜臺教學(三)字第1100031108號

- publication_date：2021-03-09
- publication_date_raw：2021-03-09
- subject_raw：本部109年8月13日臺教學（三）字第1090108790號函，自即日起停止適用，請查照。
- source_year：2021
- source_path：sources/circulars/uploaded/2021(1).md
- source_line_start：25
- source_line_end：47
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：["CR-005", "CR-006", "CR-007", "CR-008", "CR-026"]
- quality_issue_ids：[]

## C2021-003｜臺教學(三)字第1100007134號

- publication_date：2021-03-23
- publication_date_raw：2021-03-23
- subject_raw：為配合行政程序法110年1月20日總統華總一義字第 11000004181號令修正公布，茲修正本部102年5月30日臺教 學（三）字第1020082802A號函發布「校園性侵害性騷擾或 性霸凌調查及處理參考手冊Q＆A」，請查照。
- source_year：2021
- source_path：sources/circulars/uploaded/2021(1).md
- source_line_start：48
- source_line_end：65
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：["CR-009", "CR-010"]
- quality_issue_ids：[]

## C2021-004｜臺教學(三)字第1100055289號

- publication_date：2021-06-07
- publication_date_raw：2021-06-07
- subject_raw：所詢行為人為未成年學生，且未依性別平等教育法（以下 簡稱性平法）配合學校調查訪談，相關後續處理方式案， 請查照。
- source_year：2021
- source_path：sources/circulars/uploaded/2021(1).md
- source_line_start：66
- source_line_end：84
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2021-005｜臺教學(三)字第1100078762號

- publication_date：2021-07-09
- publication_date_raw：2021-07-09
- subject_raw：轉知行政院秘書長檢送「數位/網路性別暴力之定義、類型 及其內涵說明」（如附件），請依說明轉知所屬據以辦理 校安通報，請查照。
- source_year：2021
- source_path：sources/circulars/uploaded/2021(1).md
- source_line_start：85
- source_line_end：123
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2021-006｜臺教學(三)字第1100096531號

- publication_date：2021-07-19
- publication_date_raw：2021-07-19
- subject_raw：為學校依據性別平等教育法（下稱性平法）追蹤執行校園 性別事件行為人之處置案，詳如說明，請查照。
- source_year：2021
- source_path：sources/circulars/uploaded/2021(1).md
- source_line_start：124
- source_line_end：143
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2021-007｜臺教學(三)字第1100100684號

- publication_date：2021-09-11
- publication_date_raw：2021-09-11
- subject_raw：有關公立學校之人事人員及主計人員涉及校園性侵害、性 騷擾或性霸凌事件適用法規及靜候調查之相關處理機制案， 請依說明辦理，請查照。
- source_year：2021
- source_path：sources/circulars/uploaded/2021(1).md
- source_line_start：144
- source_line_end：174
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2021-008｜臺教學(三)字第1100082461B號

- publication_date：None
- publication_date_raw：未擷取
- subject_raw：教育部校園性侵害性騷擾或性霸凌調查專業人員培訓及調查專業人才庫建置要點
- source_year：2021
- source_path：sources/circulars/uploaded/2021(1).md
- source_line_start：175
- source_line_end：309
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：["CQ-009"]

## C2022-001｜臺教學(三)字第1112800706號

- publication_date：2022-02-21
- publication_date_raw：2022-02-21
- subject_raw：有關學校違反性別平等教育法（以下簡稱性平法）規定，經主管機關依性平法第28條第1項規定調查，係屬上級機關對下級機關行使監督之職權範圍，受調查學校無申復救濟之適用案，請查照。
- source_year：2022
- source_path：sources/circulars/uploaded/2022(1).md
- source_line_start：3
- source_line_end：17
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2022-002｜臺教學(三)字第1110029777號

- publication_date：2022-04-01
- publication_date_raw：2022-04-01
- subject_raw：有關執行校園性侵害、性騷擾或性霸凌事件行為人心理輔導人員對於該事件之知情範圍，列如說明，請查照並轉知所屬。
- source_year：2022
- source_path：sources/circulars/uploaded/2022(1).md
- source_line_start：18
- source_line_end：34
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：["CR-011"]
- quality_issue_ids：[]

## C2022-003｜臺教學(三)字第1110042353號

- publication_date：2022-05-09
- publication_date_raw：2022-05-09
- subject_raw：檢送本部所訂跟蹤騷擾防制法「校園跟蹤騷擾事件」及性別平 等教育法「校園性騷擾事件」處理機制及流程圖（如附件）， 請轉知所屬據以辦理，請查照。
- source_year：2022
- source_path：sources/circulars/uploaded/2022(1).md
- source_line_start：35
- source_line_end：57
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2022-004｜臺教學(三)字第1110055944號

- publication_date：2022-07-08
- publication_date_raw：2022-07-08
- subject_raw：有關新北市政府教育局及臺南市政府教育局函詢校園性侵害、性騷擾或性霸凌事件疑似行為人行蹤不明或亡故之調查程序疑義案，復如說明，請查照。
- source_year：2022
- source_path：sources/circulars/uploaded/2022(1).md
- source_line_start：58
- source_line_end：80
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：["CQ-005"]

## C2022-005｜臺教學(三)字第1112804310號

- publication_date：2022-07-28
- publication_date_raw：2022-07-28
- subject_raw：有關跨校校園性別事件，經一學校依性別平等教育法（以下簡稱性平法）通報及調查處理，主管機關得免予追究另一學校延遲通報之責任案，請查照。
- source_year：2022
- source_path：sources/circulars/uploaded/2022(1).md
- source_line_start：81
- source_line_end：97
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2022-006｜臺教學(三)字第1112805030號

- publication_date：2022-09-08
- publication_date_raw：2022-09-08
- subject_raw：為查明校園師對生性侵害、性騷擾或性霸凌事件（以下簡稱校園性別事件）真相，並提供可能被害人必要協助，倘事件管轄分涉主管機關及學校時，由主管機關為主要程序管轄，通知疑似行為案涉相關學校配合參與調查，請查照。
- source_year：2022
- source_path：sources/circulars/uploaded/2022(1).md
- source_line_start：98
- source_line_end：114
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2022-007｜臺教人(二)字第1114203261號

- publication_date：2022-10-07
- publication_date_raw：2022-10-07
- subject_raw：檢送「教育部所屬學校公務人員依性別平等教育法第27條之 1第8項規定應調離學校現職之處理流程」1份，請查照配合 辦理。
- source_year：2022
- source_path：sources/circulars/uploaded/2022(1).md
- source_line_start：115
- source_line_end：128
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2023-001｜臺教學(三)字第1120045730號

- publication_date：2023-06-05
- publication_date_raw：2023-06-05
- subject_raw：所詢○○私立○○高級中學校園性別事件之行政調查與臺灣○○地方法院刑事判決司法調查認定不一致，及涉及不適任教師管制期限變更等程序案，復如說明，請查照。
- source_year：2023
- source_path：sources/circulars/uploaded/2023(1).md
- source_line_start：3
- source_line_end：22
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2023-002｜臺教學(三)字第1120057724號

- publication_date：2023-08-21
- publication_date_raw：2023-08-21
- subject_raw：有關校園性別事件經申復審議結果「重為決定」，申請人、被害人及行為人倘仍有不服，應再經申復程序，始得提起申訴、訴願等救濟程序案，請查照。
- source_year：2023
- source_path：sources/circulars/uploaded/2023(1).md
- source_line_start：23
- source_line_end：38
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：["CR-037"]
- quality_issue_ids：[]

## C2023-003｜臺教學(三)字第1122803970A號

- publication_date：2023-09-26
- publication_date_raw：2023-09-26
- subject_raw：修正本部106年7月26日函示教師涉性別事件是否情節重大之判 斷基準，請依說明辦理並轉知所屬，請查照。
- source_year：2023
- source_path：sources/circulars/uploaded/2023(1).md
- source_line_start：39
- source_line_end：64
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：["CR-012", "CR-039"]
- quality_issue_ids：[]

## OC2024-01｜臺教學(三)字第1130037236號

- publication_date：2024-05-21
- publication_date_raw：2024-05-21
- subject_raw：〔索引摘要〕行為人現所屬學校派代表參與調查之定義
- source_year：2024
- source_path：sources/circulars/official-notes/OC2024-01.md
- source_line_start：1
- source_line_end：25
- content_kind：external_official_reading_note
- representation：external_reading_summary
- same_document_record_ids：["C2024-003"]
- known_relation_ids：["CR-034"]
- quality_issue_ids：["QDUP-002"]

## OC2024-02｜臺教學(三)字第1132802434號

- publication_date：2024-06-03
- publication_date_raw：2024-06-03
- subject_raw：〔索引摘要〕調查小組成員應全部外聘之定義
- source_year：2024
- source_path：sources/circulars/official-notes/OC2024-02.md
- source_line_start：1
- source_line_end：25
- content_kind：external_official_reading_note
- representation：external_reading_summary
- same_document_record_ids：["C2024-004"]
- known_relation_ids：[]
- quality_issue_ids：["QDUP-003"]

## OC2024-03｜臺教學(三)字第1132803568號

- publication_date：2024-07-30
- publication_date_raw：2024-07-30
- subject_raw：〔索引摘要〕調查處理經費支應及行政實務處理
- source_year：2024
- source_path：sources/circulars/official-notes/OC2024-03.md
- source_line_start：1
- source_line_end：27
- content_kind：external_official_reading_note
- representation：external_reading_summary
- same_document_record_ids：["C2024-006"]
- known_relation_ids：["CR-013", "CR-022"]
- quality_issue_ids：["QDUP-004"]

## OC2024-04｜臺教學（三）字第1132804741A號令

- publication_date：2024-10-29
- publication_date_raw：2024-10-29
- subject_raw：〔索引摘要〕核釋校園性別事件防治準則第32條第3項
- source_year：2024
- source_path：sources/circulars/official-notes/OC2024-04.md
- source_line_start：1
- source_line_end：25
- content_kind：external_official_reading_note
- representation：external_reading_summary
- same_document_record_ids：["C2024-007"]
- known_relation_ids：["CR-014", "CR-015", "CR-023", "CR-031", "CR-035", "CR-040"]
- quality_issue_ids：["QDUP-005"]

## OC2024-05｜臺教學(三)字第1132805502號

- publication_date：2024-12-04
- publication_date_raw：2024-12-04
- subject_raw：〔索引摘要〕主管機關申復流程圖修正及雙方申復時點不同之處理
- source_year：2024
- source_path：sources/circulars/official-notes/OC2024-05.md
- source_line_start：1
- source_line_end：26
- content_kind：external_official_reading_note
- representation：external_reading_summary
- same_document_record_ids：["C2024-011"]
- known_relation_ids：["CR-016", "CR-027"]
- quality_issue_ids：["QDUP-006"]

## C2024-001｜臺教學(三)字第1132800332號

- publication_date：2024-01-25
- publication_date_raw：2024-01-25
- subject_raw：有關性別平等教育法(以下簡稱性平法)第2章「學習環境 . . . 及資源」及第3章「課程、教材及教學」之調查處理案， . . .. 請查照。 . . . 說明： . . .. 一、依據本部110年9月28日臺教學(三)字第1100131246、 . . 1100131246A號函(諒達)續辦。 . . .. 二、查性平法業經112年8月16日總統華總一義字第11200069321 . . . 號令修正公布，爰本部110年9月28日臺教學(三)字第 . . . 1100131246、1100131246A號函(諒達…
- source_year：2024
- source_path：sources/circulars/uploaded/2024(1).md
- source_line_start：3
- source_line_end：22
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：["CR-020", "CR-021"]
- quality_issue_ids：[]

## C2024-002｜臺教學(三)字第1132801903號

- publication_date：2024-04-18
- publication_date_raw：2024-04-18
- subject_raw：檢送「性平法第37條第1項但書規定向主管機關申復審議流程 圖」1份（如附件），提供各主管機關據以辦理性別平等教育 法（以下簡稱性平法）第37條第1項但書所定申復案件，請查 照並周知所屬。
- source_year：2024
- source_path：sources/circulars/uploaded/2024(1).md
- source_line_start：23
- source_line_end：39
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：["CR-027"]
- quality_issue_ids：[]

## C2024-003｜臺教學(三)字第1130037236號

- publication_date：2024-05-21
- publication_date_raw：2024-05-21
- subject_raw：有關校園性別事件防治準則（以下簡稱防治準則）第12條第1項規定校園性別事件案之行為人現所屬學校派代表參與調查定義案，詳如說明，請查照並轉知所屬。
- source_year：2024
- source_path：sources/circulars/uploaded/2024(1).md
- source_line_start：40
- source_line_end：60
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：["OC2024-01"]
- known_relation_ids：["CR-034"]
- quality_issue_ids：["QDUP-002"]

## C2024-004｜臺教學(三)字第1132802434號

- publication_date：2024-06-03
- publication_date_raw：2024-06-03
- subject_raw：有關釋示性別平等教育法（以下簡稱性平法）第33條第2項規定「其成員應全部外聘」案，請查照。
- source_year：2024
- source_path：sources/circulars/uploaded/2024(1).md
- source_line_start：61
- source_line_end：80
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：["OC2024-02"]
- known_relation_ids：[]
- quality_issue_ids：["QDUP-003"]

## C2024-005｜臺教學(三)字第1132802105號

- publication_date：2024-07-26
- publication_date_raw：2024-07-26
- subject_raw：有關學校接獲衛生福利部保護資訊系統通知之性侵害事件知會 表單是否再進行校安通報，請依說明辦理及周知所屬，請查照
- source_year：2024
- source_path：sources/circulars/uploaded/2024(1).md
- source_line_start：81
- source_line_end：103
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2024-006｜臺教學(三)字第1132803568號

- publication_date：2024-07-30
- publication_date_raw：2024-07-30
- subject_raw：檢送校園性別事件調查處理過程之相關經費支應及行政實務處 理說明1份（如附件），請轉知所屬據以辦理，請查照。
- source_year：2024
- source_path：sources/circulars/uploaded/2024(1).md
- source_line_start：104
- source_line_end：157
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：["OC2024-03"]
- known_relation_ids：["CR-013", "CR-022"]
- quality_issue_ids：["QDUP-004"]

## C2024-007｜臺教學(三)字第1132804741A號

- publication_date：2024-10-29
- publication_date_raw：2024-10-29
- subject_raw：核釋校園性別事件防治準則第三十二條第三項所定申請人、被害人或行為人對事件管轄學校或機關處理之結果不服者，得於收到書面通知次日起三十日內，以書面具明理由向事件管轄學校或機關申復之規定。
- source_year：2024
- source_path：sources/circulars/uploaded/2024(1).md
- source_line_start：158
- source_line_end：177
- content_kind：user_uploaded_transcription
- representation：catalog_summary_only
- same_document_record_ids：["OC2024-04"]
- known_relation_ids：["CR-014", "CR-015", "CR-023", "CR-031", "CR-035", "CR-040"]
- quality_issue_ids：["CQNEW-010", "QDUP-005"]

## C2024-008｜臺教學(三)字第1132804741B號

- publication_date：2024-10-29
- publication_date_raw：2024-10-29
- subject_raw：檢送「校園性別事件防治準則」（以下簡稱防治準則）第32條 第3項規定解釋令1份，請查照。
- source_year：2024
- source_path：sources/circulars/uploaded/2024(1).md
- source_line_start：178
- source_line_end：230
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：["CR-023", "CR-024", "CR-025", "CR-036"]
- quality_issue_ids：[]

## C2024-009｜臺教學(三)字第1132804859號

- publication_date：2024-11-04
- publication_date_raw：2024-11-04
- subject_raw：有關校園性別事件申請人、被害人及行為人（以下簡稱當事 人）依性別平等教育法（以下簡稱性平法）提起申復案件之後 續行政救濟管轄與處理，請依說明辦理並轉知所屬，請查照。
- source_year：2024
- source_path：sources/circulars/uploaded/2024(1).md
- source_line_start：231
- source_line_end：261
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：["CR-026", "CR-043"]
- quality_issue_ids：[]

## C2024-010｜臺教學(三)字第1132805567號

- publication_date：2024-11-27
- publication_date_raw：2024-11-27
- subject_raw：本部接獲有關各大專校院執行性別平等教育專責人力不足之反映意見，為改善此一現象，請各校依說明辦理，請查照。
- source_year：2024
- source_path：sources/circulars/uploaded/2024(1).md
- source_line_start：262
- source_line_end：276
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2024-011｜臺教學(三)字第1132805502號

- publication_date：2024-12-04
- publication_date_raw：2024-12-04
- subject_raw：修正本部113年4月18日臺教學（三）字第113馗801903號函（諒 達）訂之「性平法第37條第1項但書規定向主管機關中復審議 流程圖」1份（如附件），並清依說明處理性別平等教育法 （以下簡稱性平法）第37條第1項但書所定申復案件，靖查照 並周知所屬。
- source_year：2024
- source_path：sources/circulars/uploaded/2024(1).md
- source_line_start：277
- source_line_end：291
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：["OC2024-05"]
- known_relation_ids：["CR-016", "CR-027"]
- quality_issue_ids：["CQNEW-016", "QDUP-006"]

## C2024-012｜臺教學(三)字第1132805149號

- publication_date：2024-12-19
- publication_date_raw：2024-12-19
- subject_raw：為性別平等教育法（以下簡稱性平法）第26條第2項序文「應命行為人接受心理諮商與輔導」明訂具體時數案，請依說明辦理，請查照。
- source_year：2024
- source_path：sources/circulars/uploaded/2024(1).md
- source_line_start：292
- source_line_end：308
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：["CR-041"]
- quality_issue_ids：[]

## C2024-013｜臺教學(三)字第1132802191號

- publication_date：None
- publication_date_raw：未擷取
- subject_raw：教育部「學校校長及教職員工違反與性或性別有關之專業倫理防治指引」
- source_year：2024
- source_path：sources/circulars/uploaded/2024(1).md
- source_line_start：309
- source_line_end：504
- content_kind：user_uploaded_transcription
- representation：attachment_transcription_without_cover_date
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：["CQNEW-013"]

## C2024-014｜臺教學(三)字第1132803074號

- publication_date：None
- publication_date_raw：未擷取
- subject_raw：校園性別事件防治準則第30 條第6 項規定執行程序指引
- source_year：2024
- source_path：sources/circulars/uploaded/2024(1).md
- source_line_start：505
- source_line_end：540
- content_kind：user_uploaded_transcription
- representation：attachment_transcription_without_cover_date
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：["CQNEW-014"]

## C2025-001｜臺教學(三)字第1130122346號

- publication_date：2025-01-09
- publication_date_raw：2025-01-09
- subject_raw：檢送「各級學校校長或教職員工涉職場性騷擾事件」及「各級 學校人員及學生涉性騷擾防治法所定性騷擾事件」申訴及處理 流程說明（如附件），請轉知所屬辦理，以落實校園中性平三 法之規範目的及調查專業權責，請查照。
- source_year：2025
- source_path：sources/circulars/uploaded/2025(1).md
- source_line_start：3
- source_line_end：246
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：["CR-028", "CR-029", "CR-030"]
- quality_issue_ids：[]

## C2025-002｜臺教學(三)字第1142800272號

- publication_date：2025-01-21
- publication_date_raw：2025-01-21
- subject_raw：為落實性別平等教育法第41條第2項及校園性別事件防治準則第31條第1項規定，且依兒童及少年福利與權益保障法第97條規定，以公益性理由公告校園性別事件行為人姓名。
- source_year：2025
- source_path：sources/circulars/uploaded/2025(1).md
- source_line_start：247
- source_line_end：266
- content_kind：user_uploaded_transcription
- representation：catalog_summary_only
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：["CQNEW-011"]

## C2025-003｜臺教學(三)字第1140017674號

- publication_date：2025-03-04
- publication_date_raw：2025-03-04
- subject_raw：有關本部113 年10 月29 日臺教學（三）字第1132804741A號令核釋 「校園性別事件防治準則（以下簡稱防治準則）第32條第3 項 規定」及本部「校園性別事件回復填報及統計管理系統」陳報 作業事項，請依說明辦理，請查照。
- source_year：2025
- source_path：sources/circulars/uploaded/2025(1).md
- source_line_start：267
- source_line_end：295
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：["CR-031"]
- quality_issue_ids：["CQNEW-017"]

## C2025-004｜臺教學(三)字第1142800509號

- publication_date：2025-03-06
- publication_date_raw：2025-03-06
- subject_raw：有關「各級學校性別平等教育委員會設置準則」（以下簡稱設置準則）第7條第2款及第3款規定，委員消極資格之調查或查證程序及解除主任委員職務事項，請依說明辦理，請查照。
- source_year：2025
- source_path：sources/circulars/uploaded/2025(1).md
- source_line_start：296
- source_line_end：318
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2025-005｜臺教學(三)字第1140028039號

- publication_date：2025-03-14
- publication_date_raw：2025-03-14
- subject_raw：有關公私立高級中等以上學校實習生於實瞥期間，遭受實習場 域之實習指導人員（含兼具事業單位最高負貴人）性騷擾之法 令適用及調查處理程序，請依說明辦理，請查照。
- source_year：2025
- source_path：sources/circulars/uploaded/2025(1).md
- source_line_start：319
- source_line_end：367
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：["CR-032"]
- quality_issue_ids：[]

## C2025-006｜臺教學(三)字第1142801195號

- publication_date：2025-03-28
- publication_date_raw：2025-03-28
- subject_raw：有關性別平等教育法（以下簡稱性平法）第29條第3項規定 「經學校性別平等教育委員會（以下簡稱性平會）查證屬 實」之處理期間，應於2個月內完成，請查照。
- source_year：2025
- source_path：sources/circulars/uploaded/2025(1).md
- source_line_start：368
- source_line_end：383
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2025-007｜臺教學(三)字第1142801109號

- publication_date：2025-04-08
- publication_date_raw：2025-04-08
- subject_raw：有關校園性別事件之行政調查認定，請依說明辦理，請查照。
- source_year：2025
- source_path：sources/circulars/uploaded/2025(1).md
- source_line_start：384
- source_line_end：433
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：["CR-033"]
- quality_issue_ids：[]

## C2025-008｜臺教學(三)字第1142803509A號

- publication_date：2025-08-06
- publication_date_raw：2025-08-06
- subject_raw：檢送高級中等學校以下校長或教師知悉服務學校發生疑似校園性侵害事件未依性別平等教育法規定通報，致再度發生校園性侵害事件；或偽造、變造、湮滅或隱匿他人所犯校園性侵害事件之證據，經學校或有關機關查證屬實之調查權責歸屬研析表。
- source_year：2025
- source_path：sources/circulars/uploaded/2025(1).md
- source_line_start：434
- source_line_end：453
- content_kind：user_uploaded_transcription
- representation：catalog_summary_only
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：["CQNEW-012"]

## C2025-009｜臺教學(三)字第1140123332號

- publication_date：2025-12-05
- publication_date_raw：2025-12-05
- subject_raw：貴校函詢跨校校園性別事件受理程序疑義，復如說明，請查照。
- source_year：2025
- source_path：sources/circulars/uploaded/2025(1).md
- source_line_start：454
- source_line_end：473
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：[]

## C2025-010｜臺教學(三)字第1142803509號

- publication_date：None
- publication_date_raw：未擷取
- subject_raw：高級中等學校以下校長或教師「知悉服務學校發生疑似校園性侵害事件，未依性別平等教育法規定通報，致再度發生校園性侵害事件；或偽造、變造、湮滅或隱匿他人所犯校園性侵害事件之證據，經學校或有關機關查證屬實」之調查權責歸屬研析表調查程序 調查權責法規名稱 違法事由 適用及準用對象 處分依據 單位第2 條第4 款：「涉及教師法第14 1. 高級中等以下學校（適用教師法）之教師條第1 項第8 款情事。」（知悉服 2. 高級中等以下學校兼任、代課及代理教師、實第13 條第1 項第高級中等以下學 務學校發生疑似校園性侵害事件， 驗教育教師、專任運動教練及協同教學人員、2 款：「由校事會 解聘，且終校教師解聘不續 未依性別平等教育法規定通報，致 高級中等以下學校職員、教官、學生事務創新議依本辦法規定 校事會議 身不得聘任聘停聘或資遣辦 再度發生校園性侵害事件；或偽造、 人員、工友、運用於協助教學之志願服務人員、組成調查小組進 為教師。法 變造、湮滅或隱匿他人所犯校園性 實際執行教學之學校外聘運動教練、教育實習行調查。」侵害事件之證據，經學校或有關機 人員及其他執行教學、輔導管教或研究之人員關查證屬實） 準用調查程序（第61 條）第2 條第1 項第5 款：「涉及教育公立學校校人員任用條例第31 條第1 項第10長解除職國民小學及國民 款情事。」（知悉服務學校發生疑似 第10 條第1 項：務，並不予中學校長不適任 校園性侵害事件，未依性別平等教 「主管機關應成 1. 國民小學及國民中學校長主管機關 回任教師，事實調查處理辦 育法規定通報，致再度發生校園性 立調查小組調查 2. 高級中等學校校長準用之（第33 條）且終身不得法 侵害事件；或偽造、變造、湮滅或隱 之。」聘任為教育匿他人所犯校園性侵害事件之證人員。據，經有關機關查證屬實）第44 條第1 項：「學校校長、教師、第6 條第5 款：「學除「高級中等以下學校（適用教師法）之教師」、依法予以解職員或工友違反第22 條第1 項所定 校應設性別平等性別平等教育法 性平會 「國民小學及國民中學校長」及相關準用人員以 聘、免職、疑似校園性侵害事件之通報規定， 教育委員會（以下外各級學校人員 終止契約關致再度發生校園性侵害事件；或偽 簡稱性平會），調
- source_year：2025
- source_path：sources/circulars/uploaded/2025(1).md
- source_line_start：474
- source_line_end：493
- content_kind：user_uploaded_transcription
- representation：attachment_transcription_without_cover_date
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：["CQNEW-015", "CQNEW-021"]

## C2026-001｜臺教學(三)字第1140134739號

- publication_date：2026-01-22
- publication_date_raw：2026-01-22
- subject_raw：有關性別平等教育法（以下簡稱性平法）規定校園性別事件調 查及議處期間，當事人所屬學校異動之處理程序，請依說明辦 理，請查照。
- source_year：2026
- source_path：sources/circulars/uploaded/2026(1).md
- source_line_start：3
- source_line_end：31
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：["CR-034", "CR-035", "CR-036"]
- quality_issue_ids：[]

## C2026-002｜臺教學(三)字第1142805931號

- publication_date：2026-01-28
- publication_date_raw：2026-01-28
- subject_raw：有關校園性別事件之保密義務適用範圍及法律責任，請依說明轉知所屬人員並加強宣導，請查照。
- source_year：2026
- source_path：sources/circulars/uploaded/2026(1).md
- source_line_start：32
- source_line_end：50
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：["CQNEW-019"]

## C2026-003｜臺教學(三)字第1152800098號

- publication_date：2026-01-29
- publication_date_raw：2026-01-29
- subject_raw：檢送本部研訂之「發掘校園性別事件潛在被害人方式參考指 引」（如附件），請查照。
- source_year：2026
- source_path：sources/circulars/uploaded/2026(1).md
- source_line_start：51
- source_line_end：189
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：[]
- quality_issue_ids：["CQNEW-018"]

## C2026-004｜臺教學(三)字第1150034731號

- publication_date：2026-04-17
- publication_date_raw：2026-04-17
- subject_raw：有關校園性別事件經申復審議決定「申復有理由」，倘學校性別平等教育委員會（以下簡稱性平會）「重為決定」時，有違背申復審議決定意旨而予以變更（或維持）處分之情事，請各主管機關依說明辦理並轉知所屬，請查照。
- source_year：2026
- source_path：sources/circulars/uploaded/2026(1).md
- source_line_start：190
- source_line_end：205
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：["CR-037"]
- quality_issue_ids：[]

## C2026-005｜臺教學(三)字第1150050033號

- publication_date：2026-06-15
- publication_date_raw：2026-06-15
- subject_raw：為維護校園性別事件被害人知情權益，重申事件管轄學校或事件管轄機關接獲調查申請或檢舉，應依性別平等教育法（以下簡稱性平法）第32條第1項規定，於20日內以書面通知被害人是否受理，請查照。
- source_year：2026
- source_path：sources/circulars/uploaded/2026(1).md
- source_line_start：206
- source_line_end：228
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：["CR-038"]
- quality_issue_ids：[]

## C2026-006｜臺教學(三)字第1152801934號

- publication_date：2026-06-23
- publication_date_raw：2026-06-23
- subject_raw：有關同一行為人（具教職員工身分者）所涉不同校園性別事件，請依說明辦理併案審議議處程序，請查照。
- source_year：2026
- source_path：sources/circulars/uploaded/2026(1).md
- source_line_start：229
- source_line_end：251
- content_kind：user_uploaded_transcription
- representation：source_transcription_not_authenticated_full_original
- same_document_record_ids：[]
- known_relation_ids：["CR-039", "CR-040", "CR-041"]
- quality_issue_ids：["CQNEW-020"]

## OC2026-01｜臺教學(三)字第1152803124號

- publication_date：2026-07-31
- publication_date_raw：2026-07-31
- subject_raw：簡化調查處理程序之函發與通報日期適用範圍
- source_year：2026
- source_path：sources/circulars/official-notes/OC2026-01.md
- source_line_start：1
- source_line_end：17
- content_kind：external_official_reading_note
- representation：external_reading_summary
- same_document_record_ids：[]
- known_relation_ids：["CR-042"]
- quality_issue_ids：[]

## OC2026-02｜臺教學(三)字第1152803608號

- publication_date：2026-08-24
- publication_date_raw：2026-08-24
- subject_raw：教師解聘停聘報核時與最終結果之救濟教示
- source_year：2026
- source_path：sources/circulars/official-notes/OC2026-02.md
- source_line_start：1
- source_line_end：17
- content_kind：external_official_reading_note
- representation：external_reading_summary
- same_document_record_ids：[]
- known_relation_ids：["CR-043"]
- quality_issue_ids：[]
