# 02｜RELATIONS

資料集：CGE-NB-1.3.0.1；編製日：2026-09-09。此日期不是法律查核日。

43條已整理關係與148條文字連結候選保持區分。text_mentions_only不推定修正或失效。

## CR-001

- relation_id：CR-001
- from_number：台訓(三)字第0960001718號
- to_number：台訓(三)字第0950132320號
- relation_type：modifies_part
- scope：適用說明一覽表第11項之調查費項目及標準
- effective_on：None
- effective_date_basis：未自發文日推定法定施行日；適用時點另核
- notes：
- review_basis：user_uploaded_transcription
- scope_review：來源文字可支持的關係；不是所有後續法規及函令的完整效力審查
- from_record_id：C2007-006
- announced_on：2007-02-06
- to_record_ids：["C2006-011"]
- target_presence：indexed_primary_entry
- evidence：{"record_id": "C2007-006", "source_path": "sources/circulars/uploaded/2007(1).md", "line_start": 101, "line_end": 101, "exact_text": "二、因屢接獲學校詢問前揭一覽表第11項所列調查費用支給之相關疑義，復修正旨揭事件調查費用之相關支用項目及標準（如附件），請據以支用相關經費。", "content_kind": "user_uploaded_transcription"}
- official_urls：[]

## CR-002

- relation_id：CR-002
- from_number：臺訓(三)字第1010039771號
- to_number：台訓(三)字第0960057668B號
- relation_type：modifies_part
- scope：申復提起時點；不把後函引用的其他函文一併視為停止適用
- effective_on：None
- effective_date_basis：未自發文日推定法定施行日；適用時點另核
- notes：本函引述當時教師法及裁判見解；現行教師人事程序與救濟仍需另核。
- review_basis：user_uploaded_transcription
- scope_review：來源文字可支持的關係；不是所有後續法規及函令的完整效力審查
- from_record_id：C2012-013
- announced_on：2012-04-09
- to_record_ids：["C2007-009"]
- target_presence：indexed_primary_entry
- evidence：{"record_id": "C2012-013", "source_path": "sources/circulars/uploaded/2012(1).md", "line_start": 213, "line_end": 213, "exact_text": "四、該聯席會議既如上述將學校教評會依法定組織及法定程序決議通過予以解聘、停聘或不續聘，並由該公立學校依法定程序通知當事人者，認定已屬「行政處分」，並認「公立學校教師得對法定生效要件尚未成就之不利益行政處分提起申訴、再申訴以資救濟，乃上開法律所為特別規定。」，又考量私立學校宜為一致處理，爰修正本部96年5月7日臺訓(三)字第0960057668B號函所訂申復之提起時點：「學校教師因具有教師法第14條第1項各款事由之一，經該校教評會依法定組織（教師法第29條第2項參照）及法定程序決議通過予以解聘、停聘或不續聘，並由該公立學校依法定程序通知當事人者」，應屬性別平等教育法第31條第3項所定「處理結果」，得就之提起申復（即學校依據教師法第14條之1規定，於作成教師解聘、停聘或不續聘之決議後，報請主管教育行政機關核准，並同時以書面附理由通知當事人時，當事人即得提起申復）。", "content_kind": "user_uploaded_transcription"}
- official_urls：[]

## CR-003

- relation_id：CR-003
- from_number：臺教學(三)字第1020114975號
- to_number：臺訓(三)字第0990227673號
- relation_type：modifies_part
- scope：說明三（二）第3點：另案由原調查小組續查前先審查檢舉委員迴避
- effective_on：None
- effective_date_basis：未自發文日推定法定施行日；適用時點另核
- notes：不是禁止一切併案，也不是認定凡檢舉者均無須迴避。
- review_basis：user_uploaded_transcription
- scope_review：來源文字可支持的關係；不是所有後續法規及函令的完整效力審查
- from_record_id：C2013-008
- announced_on：2013-08-19
- to_record_ids：["C2011-001"]
- target_presence：indexed_primary_entry
- evidence：{"record_id": "C2013-008", "source_path": "sources/circulars/uploaded/2013(1).md", "line_start": 152, "line_end": 152, "exact_text": "(三)爰修正本部前揭函示說明三（二）第3點為「、、、由原調查小組成員依性平法第28條第3項規定向學校提出檢舉，受理後，由學校性平會決定調查方式，如決議交由同一調查小組併案續為調查時，學校性平會應先行審查該擔任檢舉人之調查小組成員有無應行迴避之事由後，再行決定是否另組新調查小組調查本檢舉案」。", "content_kind": "user_uploaded_transcription"}
- official_urls：[]

## CR-004

- relation_id：CR-004
- from_number：臺教學(三)字第1060065118號
- to_number：臺教學（三）字第1050169132號
- relation_type：modifies_part
- scope：說明二（二）：學校議處與將報告移送社政審議之銜接
- effective_on：None
- effective_date_basis：未自發文日推定法定施行日；適用時點另核
- notes：前函未列為本批獨立主文；後函引述舊段落不等於收錄前函全文。
- review_basis：user_uploaded_transcription
- scope_review：來源文字可支持的關係；不是所有後續法規及函令的完整效力審查
- from_record_id：C2017-003
- announced_on：2017-05-25
- to_record_ids：[]
- target_presence：reference_only_no_primary_text
- evidence：{"record_id": "C2017-003", "source_path": "sources/circulars/uploaded/2017(1).md", "line_start": 60, "line_end": 60, "exact_text": "二、旨揭函文說明二（二）原函釋意見為「如為性騷擾或性霸凌屬實非屬情節重大，或認定教師違反專業倫理之情形，倘認有違反兒權法疑義，建議先將調查報告初稿轉請地方社政主管機關釐清確認有違反兒權法之事實，再錄為調查報告援引之違法依據，並由性平會對學校提出依教師法第線 14條第1項第13款之懲處建議。」，為避免影響學校依性別平等教育法第31條第3項執行議處程序之時程，修正為「教師涉及對未滿18歲學生性騷擾或性霸凌事件，經學校調查屬實者，除依性別平等教育法第31條第3項規定，自行或移權責單位審議懲處外，倘調查結果認該教師對未滿18歲學生之性騷擾或性霸凌行為恐有違反兒童及少年福利與權益保障法第49條各款情形之虞，宜請學校依法將調查報告轉請地方社政主管機關審議裁處。」。", "content_kind": "user_uploaded_transcription"}
- official_urls：[]

## CR-005

- relation_id：CR-005
- from_number：臺教學(三)字第1100031108號
- to_number：臺教學（三）字第1090108790號
- relation_type：ceases_entire_letter
- scope：本函主旨明示前函自即日起停止適用
- effective_on：2021-03-09
- effective_date_basis：函令明示，含後函確認的較早日期
- notes：
- review_basis：user_uploaded_transcription
- scope_review：來源文字可支持的關係；不是所有後續法規及函令的完整效力審查
- from_record_id：C2021-002
- announced_on：2021-03-09
- to_record_ids：[]
- target_presence：reference_only_no_primary_text
- evidence：{"record_id": "C2021-002", "source_path": "sources/circulars/uploaded/2021(1).md", "line_start": 29, "line_end": 29, "exact_text": "- 主旨：本部109年8月13日臺教學（三）字第1090108790號函，自即日起停止適用，請查照。", "content_kind": "user_uploaded_transcription"}
- official_urls：[]

## CR-006

- relation_id：CR-006
- from_number：臺教學(三)字第1100031108號
- to_number：臺教學(三)字第1040042214A號
- relation_type：reaffirms_cessation
- scope：說明三確認該三函仍自109年6月30日停止適用
- effective_on：2020-06-30
- effective_date_basis：函令明示，含後函確認的較早日期
- notes：停止1090108790函，不使這三份先前已停用函恢復適用；關係宣布日與停止適用日分開。
- review_basis：user_uploaded_transcription
- scope_review：來源文字可支持的關係；不是所有後續法規及函令的完整效力審查
- from_record_id：C2021-002
- announced_on：2021-03-09
- to_record_ids：["C2015-004"]
- target_presence：indexed_primary_entry
- evidence：{"record_id": "C2021-002", "source_path": "sources/circulars/uploaded/2021(1).md", "line_start": 44, "line_end": 44, "exact_text": "三、另旨揭函釋所列本部104年4月21日臺教學（三）字第1040042214A號、104年5月19日臺教學（三）字第1040065660號及105年6月28日臺教學（三）字第1050056734號函，仍自109年6月30日停止適用。", "content_kind": "user_uploaded_transcription"}
- official_urls：[]

## CR-007

- relation_id：CR-007
- from_number：臺教學(三)字第1100031108號
- to_number：臺教學(三)字第1040065660號
- relation_type：reaffirms_cessation
- scope：說明三確認該三函仍自109年6月30日停止適用
- effective_on：2020-06-30
- effective_date_basis：函令明示，含後函確認的較早日期
- notes：停止1090108790函，不使這三份先前已停用函恢復適用；關係宣布日與停止適用日分開。
- review_basis：user_uploaded_transcription
- scope_review：來源文字可支持的關係；不是所有後續法規及函令的完整效力審查
- from_record_id：C2021-002
- announced_on：2021-03-09
- to_record_ids：["C2015-007"]
- target_presence：indexed_primary_entry
- evidence：{"record_id": "C2021-002", "source_path": "sources/circulars/uploaded/2021(1).md", "line_start": 44, "line_end": 44, "exact_text": "三、另旨揭函釋所列本部104年4月21日臺教學（三）字第1040042214A號、104年5月19日臺教學（三）字第1040065660號及105年6月28日臺教學（三）字第1050056734號函，仍自109年6月30日停止適用。", "content_kind": "user_uploaded_transcription"}
- official_urls：[]

## CR-008

- relation_id：CR-008
- from_number：臺教學(三)字第1100031108號
- to_number：臺教學(三)字第1050056734號
- relation_type：reaffirms_cessation
- scope：說明三確認該三函仍自109年6月30日停止適用
- effective_on：2020-06-30
- effective_date_basis：函令明示，含後函確認的較早日期
- notes：停止1090108790函，不使這三份先前已停用函恢復適用；關係宣布日與停止適用日分開。
- review_basis：user_uploaded_transcription
- scope_review：來源文字可支持的關係；不是所有後續法規及函令的完整效力審查
- from_record_id：C2021-002
- announced_on：2021-03-09
- to_record_ids：["C2016-006"]
- target_presence：indexed_primary_entry
- evidence：{"record_id": "C2021-002", "source_path": "sources/circulars/uploaded/2021(1).md", "line_start": 44, "line_end": 44, "exact_text": "三、另旨揭函釋所列本部104年4月21日臺教學（三）字第1040042214A號、104年5月19日臺教學（三）字第1040065660號及105年6月28日臺教學（三）字第1050056734號函，仍自109年6月30日停止適用。", "content_kind": "user_uploaded_transcription"}
- official_urls：[]

## CR-009

- relation_id：CR-009
- from_number：臺教學(三)字第1100007134號
- to_number：臺教學（三）字第1020082802A號
- relation_type：modifies_part
- scope：所附調查及處理參考手冊Q&A第63題「何謂新事實新證據」
- effective_on：None
- effective_date_basis：未自發文日推定法定施行日；適用時點另核
- notes：原Q&A未作為獨立主文收錄，不從片段補出全本。
- review_basis：user_uploaded_transcription
- scope_review：來源文字可支持的關係；不是所有後續法規及函令的完整效力審查
- from_record_id：C2021-003
- announced_on：2021-03-23
- to_record_ids：[]
- target_presence：reference_only_no_primary_text
- evidence：{"record_id": "C2021-003", "source_path": "sources/circulars/uploaded/2021(1).md", "line_start": 58, "line_end": 58, "exact_text": "二、爰修正本部102年5月30日臺教學（三）字第1020082802A號函發布「校園性侵害性騷擾或性霸凌調查及處理參考手冊Q ＆A」題63「何謂新事實新證據？」內容，公布於本部性別線平等教育全球資訊網（https://www.gender.edu.tw/）。", "content_kind": "user_uploaded_transcription"}
- official_urls：[]

## CR-010

- relation_id：CR-010
- from_number：臺教學(三)字第1100007134號
- to_number：臺教學(三)字第1090164156號
- relation_type：modifies_part
- scope：說明二：疑似被害人未受訪案件依職權調查，及嗣後新事證
- effective_on：None
- effective_date_basis：未自發文日推定法定施行日；適用時點另核
- notes：
- review_basis：user_uploaded_transcription
- scope_review：來源文字可支持的關係；不是所有後續法規及函令的完整效力審查
- from_record_id：C2021-003
- announced_on：2021-03-23
- to_record_ids：["C2020-011"]
- target_presence：indexed_primary_entry
- evidence：{"record_id": "C2021-003", "source_path": "sources/circulars/uploaded/2021(1).md", "line_start": 60, "line_end": 60, "exact_text": "三、併修正本部109年12月25日臺教學（三）字第1090164156號函說明二（諒達）：依行政程序法第36條規定，行政機關應依職權調查證據，不受當事人主張之拘束，對當事人有利及不利事項一律注意，所詢案內以檢舉進行調查且疑似被害人拒絕受訪情形，為保障雙方當事人權益，學校性別平等教育委員會（下稱性平會）及調查小組應以依職權調", "content_kind": "user_uploaded_transcription"}
- official_urls：[]

## CR-011

- relation_id：CR-011
- from_number：臺教學(三)字第1110029777號
- to_number：臺教學(三)字第1070000950號
- relation_type：supplements
- scope：將防治教育執行者知情範圍的說明，銜接至心理輔導執行者
- effective_on：None
- effective_date_basis：未自發文日推定法定施行日；適用時點另核
- notes：屬知情及保密處理的參照，不是將原函全文停止適用，也不把8小時課程改成一律必須。
- review_basis：user_uploaded_transcription
- scope_review：來源文字可支持的關係；不是所有後續法規及函令的完整效力審查
- from_record_id：C2022-002
- announced_on：2022-04-01
- to_record_ids：["C2018-001"]
- target_presence：indexed_primary_entry
- evidence：{"record_id": "C2022-002", "source_path": "sources/circulars/uploaded/2022(1).md", "line_start": 29, "line_end": 29, "exact_text": "三、參照本部107年1月22日臺教學(三)字第1070000950號書函（諒達）略以：「學校應將執行課程之相關決議以密件通知該執行者，以利其執行防治教育課程。若課程執行者認有必要，亦得向學校提出申請提供與該事件有關之資訊（role/行為人於事件中之行為態樣及事件情境脈絡⋯等），以利其規劃符合該行為人之防治教育課程內涵，有效協助行為人釐清其行為問題與爭議。上開必要資訊之申請提供應經學校性別平等教育委員會（以下簡稱性平會）審酌評估提供之範圍內容（有助於防治教育之執行部分），並請該執行者簽署", "content_kind": "user_uploaded_transcription"}
- official_urls：[]

## CR-012

- relation_id：CR-012
- from_number：臺教學(三)字第1122803970A號
- to_number：臺教學(三)字第1060092113號
- relation_type：modifies_part
- scope：教職員工事件嚴重性及終身或1至4年不得聘任必要性之判斷基準
- effective_on：None
- effective_date_basis：未自發文日推定法定施行日；適用時點另核
- notes：後函另述113年3月8日前後事件範圍；不可將2024年第四類事件構成要件任意回溯。
- review_basis：user_uploaded_transcription
- scope_review：來源文字可支持的關係；不是所有後續法規及函令的完整效力審查
- from_record_id：C2023-003
- announced_on：2023-09-26
- to_record_ids：["C2017-005"]
- target_presence：indexed_primary_entry
- evidence：{"record_id": "C2023-003", "source_path": "sources/circulars/uploaded/2023(1).md", "line_start": 43, "line_end": 43, "exact_text": "- 主旨：修正本部106年7月26日函示教師涉性別事件是否情節重大之判 斷基準，請依說明辦理並轉知所屬，請查照。", "content_kind": "user_uploaded_transcription"}
- official_urls：[]

## CR-013

- relation_id：CR-013
- from_number：臺教學(三)字第1132803568號
- to_number：臺教學(三)字第1080088013號
- relation_type：modifies_part
- scope：校園性別事件調查處理經費支應規定；1130723版附件
- effective_on：None
- effective_date_basis：未自發文日推定法定施行日；適用時點另核
- notes：本套件僅收官方查閱摘要及原件網址，使用時核對附件各財源適用差異。
- review_basis：external_official_text_read; local_note_only
- scope_review：來源文字可支持的關係；不是所有後續法規及函令的完整效力審查
- from_record_id：OC2024-03
- announced_on：2024-07-30
- to_record_ids：["C2019-005"]
- target_presence：indexed_primary_entry
- evidence：{"record_id": "OC2024-03", "source_path": "sources/circulars/official-notes/OC2024-03.md", "line_start": 20, "line_end": 20, "exact_text": "函文檢送2024年7月23日版經費及行政實務說明；附件第一點調整2019年6月21日臺教學(三)字第1080088013號函的支應規定。外聘專家調查會議出席費當時上限為每次2,500元；稿費記載每千字1,100至1,600元，並註明日後主計總處修正時依其規定。", "content_kind": "external_official_reading_note"}
- official_urls：["https://www.cyvs.cy.edu.tw/ischool/public/resource_view/open.php?file=0060c93e3ecebee5c21aea66c7be751c.pdf", "https://www.cyvs.cy.edu.tw/ischool/public/resource_view/open.php?file=f85f48e4d5fa4d5a4839cec4462350b0.pdf"]

## CR-014

- relation_id：CR-014
- from_number：臺教學（三）字第1132804741A號令
- to_number：臺訓(三)字第1010245259號
- relation_type：ceases_entire_letter
- scope：解釋令第二點明示該兩函自即日起停止適用
- effective_on：2024-10-29
- effective_date_basis：函令明示，含後函確認的較早日期
- notes：已於教育部主管法規共用系統核對解釋令全文。
- review_basis：external_official_text_read; local_note_only
- scope_review：來源文字可支持的關係；不是所有後續法規及函令的完整效力審查
- from_record_id：OC2024-04
- announced_on：2024-10-29
- to_record_ids：["C2012-043"]
- target_presence：indexed_primary_entry
- evidence：{"record_id": "OC2024-04", "source_path": "sources/circulars/official-notes/OC2024-04.md", "line_start": 20, "line_end": 20, "exact_text": "第二點載明本令自即日生效，並使2012年12月26日臺訓（三）字第1010245259號函及2013年8月20日臺教學（三）字第1020114961號函自即日起停止適用。", "content_kind": "external_official_reading_note"}
- official_urls：["https://edu.law.moe.gov.tw/LawContent.aspx?id=GL002312&kw="]

## CR-015

- relation_id：CR-015
- from_number：臺教學（三）字第1132804741A號令
- to_number：臺教學(三)字第1020114961號
- relation_type：ceases_entire_letter
- scope：解釋令第二點明示該兩函自即日起停止適用
- effective_on：2024-10-29
- effective_date_basis：函令明示，含後函確認的較早日期
- notes：已於教育部主管法規共用系統核對解釋令全文。
- review_basis：external_official_text_read; local_note_only
- scope_review：來源文字可支持的關係；不是所有後續法規及函令的完整效力審查
- from_record_id：OC2024-04
- announced_on：2024-10-29
- to_record_ids：["C2013-009"]
- target_presence：indexed_primary_entry
- evidence：{"record_id": "OC2024-04", "source_path": "sources/circulars/official-notes/OC2024-04.md", "line_start": 20, "line_end": 20, "exact_text": "第二點載明本令自即日生效，並使2012年12月26日臺訓（三）字第1010245259號函及2013年8月20日臺教學（三）字第1020114961號函自即日起停止適用。", "content_kind": "external_official_reading_note"}
- official_urls：["https://edu.law.moe.gov.tw/LawContent.aspx?id=GL002312&kw="]

## CR-016

- relation_id：CR-016
- from_number：臺教學(三)字第1132805502號
- to_number：臺教學（三）字第1130801903號
- relation_type：modifies_part
- scope：向主管機關申復審議流程圖；1131118修版
- effective_on：None
- effective_date_basis：未自發文日推定法定施行日；適用時點另核
- notes：前函及原版流程圖未收錄；不能宣稱已逐格比對新舊圖。
- review_basis：external_official_text_read; local_note_only
- scope_review：來源文字可支持的關係；不是所有後續法規及函令的完整效力審查
- from_record_id：OC2024-05
- announced_on：2024-12-04
- to_record_ids：[]
- target_presence：reference_only_no_primary_text
- evidence：{"record_id": "OC2024-05", "source_path": "sources/circulars/official-notes/OC2024-05.md", "line_start": 20, "line_end": 20, "exact_text": "本函修正2024年4月18日臺教學（三）字第1130801903號函所附主管機關申復流程圖。原函全文未收入本套件；只建立本函明示的修正關係，不反向重建原圖。", "content_kind": "external_official_reading_note"}
- official_urls：["https://www.cyvs.cy.edu.tw/ischool/public/resource_view/open.php?file=ab9ea83db007de4ecc8f8db4391f21a9.pdf", "https://www.cyvs.cy.edu.tw/ischool/public/resource_view/open.php?file=ce4ef9a5a1fc20e83292387327bf5034.pdf"]

## CR-017

- relation_id：CR-017
- from_number：臺教學(三)字第1050056133號
- to_number：法檢字第10504500190號
- relation_type：forwards
- scope：學校向羈押收容機關請求公務接見之函轉
- effective_on：None
- effective_date_basis：未自發文日推定法定施行日；適用時點另核
- notes：教育部轉函與法務部原函分開計算；現行收容機關接見作業另核。
- review_basis：user_uploaded_transcription
- scope_review：來源文字可支持的關係；不是所有後續法規及函令的完整效力審查
- from_record_id：C2016-004
- announced_on：2016-05-10
- to_record_ids：["C2016-003"]
- target_presence：indexed_primary_entry
- evidence：{"record_id": "C2016-004", "source_path": "sources/circulars/uploaded/2016(1).md", "line_start": 66, "line_end": 66, "exact_text": "- 主旨：有關學校教師因涉性侵害案件遭地方法院檢察署（下稱地檢署）聲請羈押獲准，得否同意學校調查小組請求至羈押處所進行訪談乙事，請依法務部105年4月21日法檢字第10504500190號函釋（如附件）辦理並轉知所屬，請查照。", "content_kind": "user_uploaded_transcription"}
- official_urls：[]

## CR-018

- relation_id：CR-018
- from_number：台訓(三)字第0980053278號
- to_number：童保字第0980053069號
- relation_type：forwards
- scope：兒少性騷擾事件通報之函轉與補充
- effective_on：None
- effective_date_basis：未自發文日推定法定施行日；適用時點另核
- notes：
- review_basis：user_uploaded_transcription
- scope_review：來源文字可支持的關係；不是所有後續法規及函令的完整效力審查
- from_record_id：C2009-006
- announced_on：2009-04-02
- to_record_ids：["C2009-005"]
- target_presence：indexed_primary_entry
- evidence：{"record_id": "C2009-006", "source_path": "sources/circulars/uploaded/2009(1).md", "line_start": 94, "line_end": 94, "exact_text": "- 主旨：函轉內政部兒童局函示(如附件影本)有關校園兒童及少年性騷擾事件，係違反兒童及少年福利法(以下簡稱兒少法)第30條相關規定，仍屬同法第34條第1項應於24小時通報之行為範疇，請 查照並轉知所屬照辦。", "content_kind": "user_uploaded_transcription"}
- official_urls：[]

## CR-019

- relation_id：CR-019
- from_number：臺教學(三)字第1070029022號
- to_number：臺教學(三)字第1070026350號
- relation_type：related_topic_only
- scope：調查小組組成、性平會及調查的專業分工；不推定取代
- effective_on：None
- effective_date_basis：未自發文日推定法定施行日；適用時點另核
- notes：此筆僅為本次編輯的主題參照，沒有法規效力變更；全文仍須各別閱讀。
- review_basis：editorial_topic_association_not_explicit_legal_effect
- scope_review：來源文字可支持的關係；不是所有後續法規及函令的完整效力審查
- from_record_id：C2018-003
- announced_on：2018-03-23
- to_record_ids：["C2018-002"]
- target_presence：indexed_primary_entry
- evidence：{"record_id": "C2018-003", "source_path": "sources/circulars/uploaded/2018(1).md", "line_start": 41, "line_end": 41, "exact_text": "- 主旨：所詢有關性別平等教育法（以下簡稱性平法）第30條第3項 規定適用疑義案，復如說明，請查照。", "content_kind": "user_uploaded_transcription"}
- official_urls：[]

## CR-020

- relation_id：CR-020
- from_number：臺教學(三)字第1132800332號
- from_record_id：C2024-001
- to_number：臺教學(三)字第1100131246號
- relation_type：modifies_part
- scope：第二、三章違反事件之收件及職權調查、引用條次
- effective_on：None
- effective_date_basis：不自發文日推定施行日期；按所述變更範圍及適用時點審查
- notes：
- review_basis：user_uploaded_transcription
- scope_review：對照來源文字所支持的關係，不代表歷年函示效力全面查核
- announced_on：2024-01-25
- to_record_ids：[]
- target_presence：reference_only_no_primary_text
- evidence：{"record_id": "C2024-001", "source_path": "sources/circulars/uploaded/2024(1).md", "line_start": 11, "line_end": 17, "exact_text": "第2章「學習環境 及資源」及\n第3章「課程、教材及教學」之調查處理案， 請查照。\n說明： 一、依據本部110年9月28日臺教學(三)字第1100131246、訂.. 1100131246A號函(諒達)續辦。 二、查性平法業經112年8月16日總統華總一義字第11200069321 號令修正公布，爰本部110年9月28日臺教學(三)字第 1100131246、1100131246A號函(諒達)修正如下： (一)原說明二、「(四)暢通申訴管道並落實依法作為」修正線.. 如下： １、學校或機關應提供校園性別事件收件單位之相關資訊 讓學生知悉，如收件單位之地點、電話、電子信箱.. 0.. 等，亦應提供學校或教師違反性平法\n第2章及\n第3章所 規範事件之收件單位。 ２、若發現學校或教師有違反性平法\n第2章及\n第3章情事， 得向學校所屬主管機關或教師所屬學校陳情或舉發， 國立嘉義大學.第 1 頁，共 2 頁1130001245　113/01/25", "content_kind": "user_uploaded_transcription"}
- official_urls：[]

## CR-021

- relation_id：CR-021
- from_number：臺教學(三)字第1132800332號
- from_record_id：C2024-001
- to_number：臺教學(三)字第1100131246A號
- relation_type：modifies_part
- scope：第二、三章違反事件之收件及職權調查、引用條次
- effective_on：None
- effective_date_basis：不自發文日推定施行日期；按所述變更範圍及適用時點審查
- notes：
- review_basis：user_uploaded_transcription
- scope_review：對照來源文字所支持的關係，不代表歷年函示效力全面查核
- announced_on：2024-01-25
- to_record_ids：[]
- target_presence：reference_only_no_primary_text
- evidence：{"record_id": "C2024-001", "source_path": "sources/circulars/uploaded/2024(1).md", "line_start": 11, "line_end": 17, "exact_text": "第2章「學習環境 及資源」及\n第3章「課程、教材及教學」之調查處理案， 請查照。\n說明： 一、依據本部110年9月28日臺教學(三)字第1100131246、訂.. 1100131246A號函(諒達)續辦。 二、查性平法業經112年8月16日總統華總一義字第11200069321 號令修正公布，爰本部110年9月28日臺教學(三)字第 1100131246、1100131246A號函(諒達)修正如下： (一)原說明二、「(四)暢通申訴管道並落實依法作為」修正線.. 如下： １、學校或機關應提供校園性別事件收件單位之相關資訊 讓學生知悉，如收件單位之地點、電話、電子信箱.. 0.. 等，亦應提供學校或教師違反性平法\n第2章及\n第3章所 規範事件之收件單位。 ２、若發現學校或教師有違反性平法\n第2章及\n第3章情事， 得向學校所屬主管機關或教師所屬學校陳情或舉發， 國立嘉義大學.第 1 頁，共 2 頁1130001245　113/01/25", "content_kind": "user_uploaded_transcription"}
- official_urls：[]

## CR-022

- relation_id：CR-022
- from_number：臺教學(三)字第1132803568號
- from_record_id：C2024-006
- to_number：臺教學(三)字第1080088013號
- relation_type：modifies_part
- scope：調查費用與行政實務支應規定，不排除本文大專校院自籌收入另定支用之條件
- effective_on：None
- effective_date_basis：不自發文日推定施行日期；按所述變更範圍及適用時點審查
- notes：
- review_basis：user_uploaded_transcription
- scope_review：對照來源文字所支持的關係，不代表歷年函示效力全面查核
- announced_on：2024-07-30
- to_record_ids：["C2019-005"]
- target_presence：indexed_primary_entry
- evidence：{"record_id": "C2024-006", "source_path": "sources/circulars/uploaded/2024(1).md", "line_start": 121, "line_end": 121, "exact_text": "調整本部108 年6 月21 日以臺教學(三)字第1080088013 號函所列支應規定如下：（一） 調查小組調查費之支給：1. 外聘之專家學者：以調查會議支給出席費，每次會議以新臺幣2,500 元為上限。會議依調查對象不同以場次計，每場次2-3 小時為原則。", "content_kind": "user_uploaded_transcription"}
- official_urls：[]

## CR-023

- relation_id：CR-023
- from_number：臺教學(三)字第1132804741B號
- from_record_id：C2024-008
- to_number：臺教學(三)字第1132804741A號
- relation_type：forwards
- scope：同日解釋令函送及學生救濟例示；A號目錄摘要與B號全文分開
- effective_on：None
- effective_date_basis：不自發文日推定施行日期；按所述變更範圍及適用時點審查
- notes：
- review_basis：user_uploaded_transcription
- scope_review：對照來源文字所支持的關係，不代表歷年函示效力全面查核
- announced_on：2024-10-29
- to_record_ids：["OC2024-04", "C2024-007"]
- target_presence：indexed_primary_entry
- evidence：{"record_id": "C2024-008", "source_path": "sources/circulars/uploaded/2024(1).md", "line_start": 180, "line_end": 182, "exact_text": "- 發文日期：2024-10-29\n- 發文字號：臺教學(三)字第1132804741B號\n- 主旨：檢送「校園性別事件防治準則」（以下簡稱防治準則）第32條 第3項規定解釋令1份，請查照。", "content_kind": "user_uploaded_transcription"}
- official_urls：[]

## CR-024

- relation_id：CR-024
- from_number：臺教學(三)字第1132804741B號
- from_record_id：C2024-008
- to_number：臺訓(三)字第1010245259號
- relation_type：ceases_entire_letter
- scope：前函全函停止適用
- effective_on：2024-10-29
- effective_date_basis：來源明示自即日停止適用
- notes：
- review_basis：user_uploaded_transcription
- scope_review：對照來源文字所支持的關係，不代表歷年函示效力全面查核
- announced_on：2024-10-29
- to_record_ids：["C2012-043"]
- target_presence：indexed_primary_entry
- evidence：{"record_id": "C2024-008", "source_path": "sources/circulars/uploaded/2024(1).md", "line_start": 201, "line_end": 201, "exact_text": "四、另本部101年12月26日臺訓(三)字第1010245259號函及102年8月20日臺教學(三)字第1020114961號函，自即日起停止適用。", "content_kind": "user_uploaded_transcription"}
- official_urls：[]

## CR-025

- relation_id：CR-025
- from_number：臺教學(三)字第1132804741B號
- from_record_id：C2024-008
- to_number：臺教學(三)字第1020114961號
- relation_type：ceases_entire_letter
- scope：前函全函停止適用
- effective_on：2024-10-29
- effective_date_basis：來源明示自即日停止適用
- notes：
- review_basis：user_uploaded_transcription
- scope_review：對照來源文字所支持的關係，不代表歷年函示效力全面查核
- announced_on：2024-10-29
- to_record_ids：["C2013-009"]
- target_presence：indexed_primary_entry
- evidence：{"record_id": "C2024-008", "source_path": "sources/circulars/uploaded/2024(1).md", "line_start": 201, "line_end": 201, "exact_text": "四、另本部101年12月26日臺訓(三)字第1010245259號函及102年8月20日臺教學(三)字第1020114961號函，自即日起停止適用。", "content_kind": "user_uploaded_transcription"}
- official_urls：[]

## CR-026

- relation_id：CR-026
- from_number：臺教學(三)字第1132804859號
- from_record_id：C2024-009
- to_number：臺教學(三)字第1100031108號
- relation_type：modifies_part
- scope：僅說明二所附軍訓教官事件處置流程圖廢止參考適用；不是全文停止
- effective_on：None
- effective_date_basis：不自發文日推定施行日期；按所述變更範圍及適用時點審查
- notes：
- review_basis：user_uploaded_transcription
- scope_review：對照來源文字所支持的關係，不代表歷年函示效力全面查核
- announced_on：2024-11-04
- to_record_ids：["C2021-002"]
- target_presence：indexed_primary_entry
- evidence：{"record_id": "C2024-009", "source_path": "sources/circulars/uploaded/2024(1).md", "line_start": 258, "line_end": 258, "exact_text": "（三）字第1100031108號函（諒達）說明二所附「教育部所屬高級中等以上學校軍訓教官涉及校園性侵害、性騷擾或性霸凌事件屬實處置程序」流程圖予以廢止參考適用。", "content_kind": "user_uploaded_transcription"}
- official_urls：[]

## CR-027

- relation_id：CR-027
- from_number：臺教學(三)字第1132805502號
- from_record_id：C2024-011
- to_number：臺教學(三)字第1132801903號
- relation_type：modifies_part
- scope：申復有理由交回學校及40日流程；原稿疑有缺頁，不反向補為原文
- effective_on：None
- effective_date_basis：不自發文日推定施行日期；按所述變更範圍及適用時點審查
- notes：
- review_basis：user_uploaded_transcription
- scope_review：對照來源文字所支持的關係，不代表歷年函示效力全面查核
- announced_on：2024-12-04
- to_record_ids：["C2024-002"]
- target_presence：indexed_primary_entry
- evidence：{"record_id": "C2024-011", "source_path": "sources/circulars/uploaded/2024(1).md", "line_start": 285, "line_end": 286, "exact_text": "說明：一丶旨揭流程圖原係本部因應性平法第37條第1項但書規定，擬訂申復審議及審議結果處置流程，提供各地方政府及各級學校參考運用。後續審酌原列交回學校依法處理（重啟調查、重為決定）段恐未能符應性平法第37條第3項後段所定限學校於40 日內完成調查之規定，爰予修正經主管機關申復審議為有理由者，逕交回學校依法處理（如流程圖左下所列）。\n二、另針對校園性別事件雙方當事人提出申復之時點有落差時（例如接獲處理結果第1日、第30日方分別提出）之申復審議時程疑義，請依下列說明辨理：（一）雙方當事人（教職員工生／生）僅向學校提出申復，但提出申復時點落差過大，難以於30日之申復審議時程併案審議時，請學校分別審議。另審酌係對渠等所涉同一校園性別事件之處理結果提出申復，為避免對同一事件產生歧異之審議結果，爰建議由同一組申復審議小紐成員審議並分別回應申復人所提事由。", "content_kind": "user_uploaded_transcription"}
- official_urls：[]

## CR-028

- relation_id：CR-028
- from_number：臺教學(三)字第1130122346號
- from_record_id：C2025-001
- to_number：臺教學(三)字第1020165630號
- relation_type：ceases_entire_letter
- scope：三法申訴處理舊函全函停止適用
- effective_on：2025-01-09
- effective_date_basis：原稿說明三記載「自即日超均停止適用」（原轉錄字樣保留），指本函發文日
- notes：不將後函所引其他文號一併列為停止適用
- review_basis：user_uploaded_transcription
- scope_review：以說明三所列三函為限
- announced_on：2025-01-09
- to_record_ids：["C2013-013"]
- target_presence：indexed_primary_entry
- evidence：{"record_id": "C2025-001", "source_path": "sources/circulars/uploaded/2025(1).md", "line_start": 19, "line_end": 21, "exact_text": "三、本部102 年12 月24 日臺教學（三）字第1020165630號函及所載100年10 月31 日臺訓（三）字第1000170857B號、同年12 月6 日臺訓\n\n（三）字第1000203271 號函自即日超均停止適用。", "content_kind": "user_uploaded_transcription"}
- official_urls：[]

## CR-029

- relation_id：CR-029
- from_number：臺教學(三)字第1130122346號
- from_record_id：C2025-001
- to_number：臺訓(三)字第1000170857B號
- relation_type：ceases_entire_letter
- scope：三法申訴處理舊函全函停止適用
- effective_on：2025-01-09
- effective_date_basis：原稿說明三記載「自即日超均停止適用」（原轉錄字樣保留），指本函發文日
- notes：不將後函所引其他文號一併列為停止適用
- review_basis：user_uploaded_transcription
- scope_review：以說明三所列三函為限
- announced_on：2025-01-09
- to_record_ids：["C2011-018"]
- target_presence：indexed_primary_entry
- evidence：{"record_id": "C2025-001", "source_path": "sources/circulars/uploaded/2025(1).md", "line_start": 19, "line_end": 21, "exact_text": "三、本部102 年12 月24 日臺教學（三）字第1020165630號函及所載100年10 月31 日臺訓（三）字第1000170857B號、同年12 月6 日臺訓\n\n（三）字第1000203271 號函自即日超均停止適用。", "content_kind": "user_uploaded_transcription"}
- official_urls：[]

## CR-030

- relation_id：CR-030
- from_number：臺教學(三)字第1130122346號
- from_record_id：C2025-001
- to_number：臺訓(三)字第1000203271號
- relation_type：ceases_entire_letter
- scope：三法申訴處理舊函全函停止適用
- effective_on：2025-01-09
- effective_date_basis：原稿說明三記載「自即日超均停止適用」（原轉錄字樣保留），指本函發文日
- notes：不將後函所引其他文號一併列為停止適用
- review_basis：user_uploaded_transcription
- scope_review：以說明三所列三函為限
- announced_on：2025-01-09
- to_record_ids：[]
- target_presence：reference_only_no_primary_text
- evidence：{"record_id": "C2025-001", "source_path": "sources/circulars/uploaded/2025(1).md", "line_start": 19, "line_end": 21, "exact_text": "三、本部102 年12 月24 日臺教學（三）字第1020165630號函及所載100年10 月31 日臺訓（三）字第1000170857B號、同年12 月6 日臺訓\n\n（三）字第1000203271 號函自即日超均停止適用。", "content_kind": "user_uploaded_transcription"}
- official_urls：[]

## CR-031

- relation_id：CR-031
- from_number：臺教學(三)字第1140017674號
- from_record_id：C2025-003
- to_number：臺教學(三)字第1132804741A號
- relation_type：supplements
- scope：跨校調查與議處之通知救濟、回報資料銜接
- effective_on：None
- effective_date_basis：不自發文日推定施行日期；按所述變更範圍及適用時點審查
- notes：
- review_basis：user_uploaded_transcription
- scope_review：對照來源文字所支持的關係，不代表歷年函示效力全面查核
- announced_on：2025-03-04
- to_record_ids：["OC2024-04", "C2024-007"]
- target_presence：indexed_primary_entry
- evidence：{"record_id": "C2025-003", "source_path": "sources/circulars/uploaded/2025(1).md", "line_start": 269, "line_end": 271, "exact_text": "- 發文日期：2025-03-04\n- 發文字號：臺教學(三)字第1140017674號\n- 主旨：有關本部113 年10 月29 日臺教學（三）字第1132804741A號令核釋 「校園性別事件防治準則（以下簡稱防治準則）第32條第3 項 規定」及本部「校園性別事件回復填報及統計管理系統」陳報 作業事項，請依說明辦理，請查照。", "content_kind": "user_uploaded_transcription"}
- official_urls：[]

## CR-032

- relation_id：CR-032
- from_number：臺教學(三)字第1140028039號
- from_record_id：C2025-005
- to_number：臺教學(三)字第1040065754號
- relation_type：supplements
- scope：實習指導人員性騷擾之共同調查與三條申訴入口
- effective_on：None
- effective_date_basis：不自發文日推定施行日期；按所述變更範圍及適用時點審查
- notes：
- review_basis：user_uploaded_transcription
- scope_review：對照來源文字所支持的關係，不代表歷年函示效力全面查核
- announced_on：2025-03-14
- to_record_ids：["C2015-009"]
- target_presence：indexed_primary_entry
- evidence：{"record_id": "C2025-005", "source_path": "sources/circulars/uploaded/2025(1).md", "line_start": 327, "line_end": 328, "exact_text": "說明：\n一、依勞動部114 年3 月11 日勞動條5 字第1140147685 號函（如附件）及本部104 年5 月22 日臺教學（三）字第1040065754 號函（諒達）辦理。", "content_kind": "user_uploaded_transcription"}
- official_urls：[]

## CR-033

- relation_id：CR-033
- from_number：臺教學(三)字第1142801109號
- from_record_id：C2025-007
- to_number：臺教學(三)字第1090151773號
- relation_type：supplements
- scope：行政調查證據認定與全數專業人員之建議；不等同法定比例變更
- effective_on：None
- effective_date_basis：不自發文日推定施行日期；按所述變更範圍及適用時點審查
- notes：
- review_basis：user_uploaded_transcription
- scope_review：對照來源文字所支持的關係，不代表歷年函示效力全面查核
- announced_on：2025-04-08
- to_record_ids：["C2020-009"]
- target_presence：indexed_primary_entry
- evidence：{"record_id": "C2025-007", "source_path": "sources/circulars/uploaded/2025(1).md", "line_start": 413, "line_end": 413, "exact_text": "四、本部109年12月4日臺教學(三)字第1090151773號函（諒達）為落實校園性別事件調查「客觀、公正、專業之原則」及維護調查專業品質，已建議「調查校園性侵害事件、或教職員工涉及性騷擾或性霸凌學生事件時，宜全數為具性侵害、性騷擾或性霸凌事件調查專業素養之專家學者」在案。為落實說明三事項，各級學校性平會調查校園性侵害事件、校長或教職員工對學生之性騷擾、性霸凌及違反與性或性別有關之專業倫理事件時，建議調查小組成員應全數延聘具校園性別事件調查專業素養之專家學者或熟稔性平法之法律專業背景人員。", "content_kind": "user_uploaded_transcription"}
- official_urls：[]

## CR-034

- relation_id：CR-034
- from_number：臺教學(三)字第1140134739號
- from_record_id：C2026-001
- to_number：臺教學(三)字第1130037236號
- relation_type：supplements
- scope：調查小組組成恆定及議處權責異動、畢業升學例外
- effective_on：None
- effective_date_basis：不自發文日推定施行日期；按所述變更範圍及適用時點審查
- notes：
- review_basis：user_uploaded_transcription
- scope_review：對照來源文字所支持的關係，不代表歷年函示效力全面查核
- announced_on：2026-01-22
- to_record_ids：["OC2024-01", "C2024-003"]
- target_presence：indexed_primary_entry
- evidence：{"record_id": "C2026-001", "source_path": "sources/circulars/uploaded/2026(1).md", "line_start": 14, "line_end": 14, "exact_text": "二、查本部113年5月21日臺教學(三)字第1130037236號函（諒達）釋示「校園性別事件防治準則（以下簡稱防治準則）第12條第1項規定校園性別事件案之行為人現所屬學校派代表參與調查定義」在案；次查本部113 年10 月29 日臺教學( 三) 字第1132804741A號令（以下簡稱本部113年10月29日令）核釋防治準則第32條第3項規定，如有防治準則第12條第2項規定情形，由事件管轄學校完成調查屬實者，應將調查報告及處理建議移送行為人現所屬學校（即議處權責學校）作成終局處理結果時，應由議處權責學校（或機關）以書面通知申請人、被害人、檢舉人及行為人，向議處權責學校（或機關）提起申復及救濟。", "content_kind": "user_uploaded_transcription"}
- official_urls：[]

## CR-035

- relation_id：CR-035
- from_number：臺教學(三)字第1140134739號
- from_record_id：C2026-001
- to_number：臺教學(三)字第1132804741A號
- relation_type：supplements
- scope：調查小組組成恆定及議處權責異動、畢業升學例外
- effective_on：None
- effective_date_basis：不自發文日推定施行日期；按所述變更範圍及適用時點審查
- notes：
- review_basis：user_uploaded_transcription
- scope_review：對照來源文字所支持的關係，不代表歷年函示效力全面查核
- announced_on：2026-01-22
- to_record_ids：["OC2024-04", "C2024-007"]
- target_presence：indexed_primary_entry
- evidence：{"record_id": "C2026-001", "source_path": "sources/circulars/uploaded/2026(1).md", "line_start": 14, "line_end": 14, "exact_text": "二、查本部113年5月21日臺教學(三)字第1130037236號函（諒達）釋示「校園性別事件防治準則（以下簡稱防治準則）第12條第1項規定校園性別事件案之行為人現所屬學校派代表參與調查定義」在案；次查本部113 年10 月29 日臺教學( 三) 字第1132804741A號令（以下簡稱本部113年10月29日令）核釋防治準則第32條第3項規定，如有防治準則第12條第2項規定情形，由事件管轄學校完成調查屬實者，應將調查報告及處理建議移送行為人現所屬學校（即議處權責學校）作成終局處理結果時，應由議處權責學校（或機關）以書面通知申請人、被害人、檢舉人及行為人，向議處權責學校（或機關）提起申復及救濟。", "content_kind": "user_uploaded_transcription"}
- official_urls：[]

## CR-036

- relation_id：CR-036
- from_number：臺教學(三)字第1140134739號
- from_record_id：C2026-001
- to_number：臺教學(三)字第1132804741B號
- relation_type：supplements
- scope：調查小組組成恆定及議處權責異動、畢業升學例外
- effective_on：None
- effective_date_basis：不自發文日推定施行日期；按所述變更範圍及適用時點審查
- notes：
- review_basis：user_uploaded_transcription
- scope_review：對照來源文字所支持的關係，不代表歷年函示效力全面查核
- announced_on：2026-01-22
- to_record_ids：["C2024-008"]
- target_presence：indexed_primary_entry
- evidence：{"record_id": "C2026-001", "source_path": "sources/circulars/uploaded/2026(1).md", "line_start": 24, "line_end": 24, "exact_text": "３、併重申畢業學生應依本部113年10月29日臺教學(三)字第1132804741B號函（諒達）附「校園性別事件學生當", "content_kind": "user_uploaded_transcription"}
- official_urls：[]

## CR-037

- relation_id：CR-037
- from_number：臺教學(三)字第1150034731號
- from_record_id：C2026-004
- to_number：臺教學(三)字第1120057724號
- relation_type：related_topic_only
- scope：重為決定與再次救濟之主題關聯；本函並未明示修改1120057724
- effective_on：None
- effective_date_basis：不自發文日推定施行日期；按所述變更範圍及適用時點審查
- notes：本邊為編者主題導引，不能解讀為後函引用或停止前函。
- review_basis：user_uploaded_transcription
- scope_review：對照來源文字所支持的關係，不代表歷年函示效力全面查核
- announced_on：2026-04-17
- to_record_ids：["C2023-002"]
- target_presence：indexed_primary_entry
- evidence：{"record_id": "C2026-004", "source_path": "sources/circulars/uploaded/2026(1).md", "line_start": 192, "line_end": 194, "exact_text": "- 發文日期：2026-04-17\n- 發文字號：臺教學(三)字第1150034731號\n- 主旨：有關校園性別事件經申復審議決定「申復有理由」，倘學校性別平等教育委員會（以下簡稱性平會）「重為決定」時，有違背申復審議決定意旨而予以變更（或維持）處分之情事，請各主管機關依說明辦理並轉知所屬，請查照。", "content_kind": "user_uploaded_transcription"}
- official_urls：[]

## CR-038

- relation_id：CR-038
- from_number：臺教學(三)字第1150050033號
- from_record_id：C2026-005
- to_number：臺教學(三)字第1020080238號
- relation_type：modifies_part
- scope：原函受理檢舉後主動徵詢被害人是否一併申請調查之段落，改為書面受理通知；保留結果通知
- effective_on：None
- effective_date_basis：不自發文日推定施行日期；按所述變更範圍及適用時點審查
- notes：
- review_basis：user_uploaded_transcription
- scope_review：對照來源文字所支持的關係，不代表歷年函示效力全面查核
- announced_on：2026-06-15
- to_record_ids：["C2013-007"]
- target_presence：indexed_primary_entry
- evidence：{"record_id": "C2026-005", "source_path": "sources/circulars/uploaded/2026(1).md", "line_start": 218, "line_end": 225, "exact_text": "請，通知其參加為當事人。」俾被害人參與調查程序；但疑似被害人不詳時，得免予通知。且該被害人得依性平法第32條第4項規定略以，於接獲不受理通知之次日起20日內，以書面具明理由，向學校或主管機關申復。\n四、次查校園性別事件防治準則第18條第3項規定：「學校或主管機關知悉疑似校園性別事件有下列情形，應由所設性平會評估該事件對學生受教權及校園安全之影響，經會議決議以檢舉案形式啟動調查程序，以釐清事實，採取必要之措施維護學生之權益與校園安全：\n一、二人以上被害人。\n二、二人以上行為人。\n三、行為人為校長或教職員工。\n四、涉及校園安全議題。\n五、其他經性平會認有以檢舉案形式啟動調查之必要者。」該等經性平會會議決議而檢舉者，亦應依性平法第32條第1項規定，以書面通知事件疑似被害人是否受理。\n五、併修正本部102年7月16日臺教學(三)字第1020080238號函略以：「有關學校因受理檢舉而調查之校園性別事件……就調查處理程序中，除事件管轄學校於案件受理後，得主動徵詢被害人或其法定代理人是否一併申請調查」1節，應依性平法第32條第1項規定，以書面通知事件疑似被害人是否受理，無須另行徵詢被害人或其法定代理人之申請調查意願；至該函「調查處理完成後」，應依性平法第36條第3項規定，將處理之結果，以書面載明事實及理由通知被害人。", "content_kind": "user_uploaded_transcription"}
- official_urls：[]

## CR-039

- relation_id：CR-039
- from_number：臺教學(三)字第1152801934號
- from_record_id：C2026-006
- to_number：臺教學(三)字第1122803970A號
- relation_type：supplements
- scope：同一教職員工多案之併案議處條件、理由與限縮報告提供
- effective_on：None
- effective_date_basis：不自發文日推定施行日期；按所述變更範圍及適用時點審查
- notes：
- review_basis：user_uploaded_transcription
- scope_review：對照來源文字所支持的關係，不代表歷年函示效力全面查核
- announced_on：2026-06-23
- to_record_ids：["C2023-003"]
- target_presence：indexed_primary_entry
- evidence：{"record_id": "C2026-006", "source_path": "sources/circulars/uploaded/2026(1).md", "line_start": 237, "line_end": 241, "exact_text": "說明：\n一、依115年2月9日本部第12屆性別平等教育委員會（以下簡稱性平會）校園性別事件防治組第1次會議決議辦理。\n二、性別平等教育法（以下簡稱性平法）第34條第4項規定：「調查發現同一行為人對不同被害人有發生類似校園性別事件時，得併案調查。」經併案調查時，得就事情情節綜合評價判斷予以議處，俾落實本部112年9月26日臺教學（三）字第1122803970A號函（諒達）示教職員工之性別事件情節輕重判斷基準。\n三、查校園性別事件防治準則（以下簡稱防治準則）第11條規定略以，校園性別事件之被害人、其法定代理人或實際照顧者（以下簡稱申請人）、檢舉人，向行為人於行為發生時所屬之學校（事件管轄學校）申請調查或檢舉，容有不同校園性別事件由不同事件管轄學校調查處理之情形，未得依性平法第34條第4項規定併案調查；次查本部113年10月29日臺教學（三）字第1132804741A號令（諒達）核釋防治準則第32條第3項規定，如有防治準則第12條第2項規定情形，由行為人現所屬學校予以終局議處。\n四、旨揭行為人所涉不同校園性別事件，應併案審議議處之程序如下：", "content_kind": "user_uploaded_transcription"}
- official_urls：[]

## CR-040

- relation_id：CR-040
- from_number：臺教學(三)字第1152801934號
- from_record_id：C2026-006
- to_number：臺教學(三)字第1132804741A號
- relation_type：supplements
- scope：同一教職員工多案之併案議處條件、理由與限縮報告提供
- effective_on：None
- effective_date_basis：不自發文日推定施行日期；按所述變更範圍及適用時點審查
- notes：
- review_basis：user_uploaded_transcription
- scope_review：對照來源文字所支持的關係，不代表歷年函示效力全面查核
- announced_on：2026-06-23
- to_record_ids：["OC2024-04", "C2024-007"]
- target_presence：indexed_primary_entry
- evidence：{"record_id": "C2026-006", "source_path": "sources/circulars/uploaded/2026(1).md", "line_start": 237, "line_end": 241, "exact_text": "說明：\n一、依115年2月9日本部第12屆性別平等教育委員會（以下簡稱性平會）校園性別事件防治組第1次會議決議辦理。\n二、性別平等教育法（以下簡稱性平法）第34條第4項規定：「調查發現同一行為人對不同被害人有發生類似校園性別事件時，得併案調查。」經併案調查時，得就事情情節綜合評價判斷予以議處，俾落實本部112年9月26日臺教學（三）字第1122803970A號函（諒達）示教職員工之性別事件情節輕重判斷基準。\n三、查校園性別事件防治準則（以下簡稱防治準則）第11條規定略以，校園性別事件之被害人、其法定代理人或實際照顧者（以下簡稱申請人）、檢舉人，向行為人於行為發生時所屬之學校（事件管轄學校）申請調查或檢舉，容有不同校園性別事件由不同事件管轄學校調查處理之情形，未得依性平法第34條第4項規定併案調查；次查本部113年10月29日臺教學（三）字第1132804741A號令（諒達）核釋防治準則第32條第3項規定，如有防治準則第12條第2項規定情形，由行為人現所屬學校予以終局議處。\n四、旨揭行為人所涉不同校園性別事件，應併案審議議處之程序如下：", "content_kind": "user_uploaded_transcription"}
- official_urls：[]

## CR-041

- relation_id：CR-041
- from_number：臺教學(三)字第1152801934號
- from_record_id：C2026-006
- to_number：臺教學(三)字第1132805149號
- relation_type：supplements
- scope：同一教職員工多案之併案議處條件、理由與限縮報告提供
- effective_on：None
- effective_date_basis：不自發文日推定施行日期；按所述變更範圍及適用時點審查
- notes：
- review_basis：user_uploaded_transcription
- scope_review：對照來源文字所支持的關係，不代表歷年函示效力全面查核
- announced_on：2026-06-23
- to_record_ids：["C2024-012"]
- target_presence：indexed_primary_entry
- evidence：{"record_id": "C2026-006", "source_path": "sources/circulars/uploaded/2026(1).md", "line_start": 243, "line_end": 246, "exact_text": "如下：(一)校園性別事件經依防治準則第30條第2項前段規定「性平會召開會議審議調查報告認定校園性別事件屬實」及依性平法第36條第2項規定，性平會將調查報告及處理建議，以書面向其所屬學校（即事件管轄學校）提出報告；事件管轄學校依性平法第36條第3項規定，移送議處權責學校議處。\n(二)因議處權責學校業依防治準則第12條第1項規定，已派員參與調查，爰得掌握調查進度。倘有同一行為人所涉不同校園性別事件之調查報告經移送議處權責學校，且處理建議未達終身不得聘任、任用、進用或運用必要時，議處權責學校可得確認其他事件管轄學校於2個月內將完成他案調查報告，並認定校園性別事件屬實予以移送議處者（參照性平法第36條第3項前段規定略以「學校應於接獲前項調查報告後2個月內，自行或移送相關權責機關依本法或相關法律或法規規定議處」），議處權責學校性平會得併案審議，綜合各調查結果作成終局議處之處理建議，包括性平法第26條第2項規定之處置措施（心理諮商與輔導之處置時數應依本部113年12月19日臺教學(三)字第1132805149號函諒達辦理）。\n(三)承上，議處權責學校以書面通知校園性別事件處理之結果，應載明原事件事實及併案加重處分理由，通知申請人、被害人、檢舉人及行為人；依防治準則第32條第1項規定所一併提供之調查報告，為符保密規定，應僅為各當事人原事件之調查報告。\n(四)倘非屬上開議處權責學校性平會於2個月內併案審議議處情形（含未適用防治準則第12條第1項規定者），各該事件之調查報告及處理建議，依性平法第26條第1項規定，應由議處權責學校分別依相關法律或法規規定議處；另依", "content_kind": "user_uploaded_transcription"}
- official_urls：[]

## CR-042

- relation_id：CR-042
- from_number：臺教學(三)字第1152803124號
- from_record_id：OC2026-01
- to_number：台訓(三)字第0990120627號
- relation_type：supplements
- scope：簡化調查處理程序與2010年不成立調查小組之歷史銜接
- effective_on：None
- effective_date_basis：不自發文日推定施行日期；按所述變更範圍及適用時點審查
- notes：
- review_basis：external_official_reading_note
- scope_review：對照來源文字所支持的關係，不代表歷年函示效力全面查核
- announced_on：2026-07-31
- to_record_ids：["C2010-010"]
- target_presence：indexed_primary_entry
- evidence：{"record_id": "OC2026-01", "source_path": "sources/circulars/official-notes/OC2026-01.md", "line_start": 15, "line_end": 15, "exact_text": "函文援引99年8月12日台訓(三)第0990120627號函的不成立小組處理方式；此為歷史銜接，不是宣告該舊函全文停止適用。主要程序為受理分流、雙方書面或言詞陳述答辯、性平會審議並提出報告；可委任人才庫資格人員一名撰寫初稿。議處、結果通知及救濟仍依性平法辦理；救濟後重新調查之指定情形應成立調查小組。", "content_kind": "external_official_reading_note"}
- official_urls：["https://gender.usc.edu.tw/p/405-1057-37212,c972.php?Lang=zh-tw"]

## CR-043

- relation_id：CR-043
- from_number：臺教學(三)字第1152803608號
- from_record_id：OC2026-02
- to_number：臺教學(三)字第1132804859號
- relation_type：reaffirms
- scope：教師解聘停聘報核時通知與雙方均未申復時最終通知再教示
- effective_on：None
- effective_date_basis：不自發文日推定施行日期；按所述變更範圍及適用時點審查
- notes：
- review_basis：external_official_reading_note
- scope_review：對照來源文字所支持的關係，不代表歷年函示效力全面查核
- announced_on：2026-08-24
- to_record_ids：["C2024-009"]
- target_presence：indexed_primary_entry
- evidence：{"record_id": "OC2026-02", "source_path": "sources/circulars/official-notes/OC2026-02.md", "line_start": 13, "line_end": 13, "exact_text": "本函重申113年11月4日臺教學（三）字第1132804859號函之救濟管轄與處理。教師解聘、停聘決議報請主管教育行政機關核准時，人事單位應同步以附理由書面通知當事人，教示通知次日起三十日內申復；申請人及被害人的通知得由性平會秘書單位另行辦理。", "content_kind": "external_official_reading_note"}
- official_urls：["https://gender.usc.edu.tw/p/405-1057-37682,c972.php?Lang=zh-tw"]

## 原始關係定義

- relations：[{"relation_id": "CR-001", "from_number": "台訓(三)字第0960001718號", "to_number": "台訓(三)字第0950132320號", "relation_type": "modifies_part", "scope": "適用說明一覽表第11項之調查費項目及標準", "effective_on": null, "effective_date_basis": "未自發文日推定法定施行日；適用時點另核", "evidence_anchor": "二、因屢接獲學校詢問前揭一覽表第11項所列調查費用支給之相關疑義，復修正旨揭事件調查費用之相關支用項目及標準（如附件），請據以支用相關經費。", "notes": "", "review_basis": "user_uploaded_transcription", "scope_review": "來源文字可支持的關係；不是所有後續法規及函令的完整效力審查", "from_record_id": "C2007-006"}, {"relation_id": "CR-002", "from_number": "臺訓(三)字第1010039771號", "to_number": "台訓(三)字第0960057668B號", "relation_type": "modifies_part", "scope": "申復提起時點；不把後函引用的其他函文一併視為停止適用", "effective_on": null, "effective_date_basis": "未自發文日推定法定施行日；適用時點另核", "evidence_anchor": "四、該聯席會議既如上述將學校教評會依法定組織及法定程序決議通過予以解聘、停聘或不續聘，並由該公立學校依法定程序通知當事人者，認定已屬「行政處分」，並認「公立學校教師得對法定生效要件尚未成就之不利益行政處分提起申訴、再申訴以資救濟，乃上開法律所為特別規定。」，又考量私立學校宜為一致處理，爰修正本部96年5月7日臺訓(三)字第0960057668B號函所訂申復之提起時點：「學校教師因具有教師法第14條第1項各款事由之一，經該校教評會依法定組織（教師法第29條第2項參照）及法定程序決議通過予以解聘、停聘或不續聘，並由該公立學校依法定程序通知當事人者」，應屬性別平等教育法第31條第3項所定「處理結果」，得就之提起申復（即學校依據教師法第14條之1規定，於作成教師解聘、停聘或不續聘之決議後，報請主管教育行政機關核准，並同時以書面附理由通知當事人時，當事人即得提起申復）。", "notes": "本函引述當時教師法及裁判見解；現行教師人事程序與救濟仍需另核。", "review_basis": "user_uploaded_transcription", "scope_review": "來源文字可支持的關係；不是所有後續法規及函令的完整效力審查", "from_record_id": "C2012-013"}, {"relation_id": "CR-003", "from_number": "臺教學(三)字第1020114975號", "to_number": "臺訓(三)字第0990227673號", "relation_type": "modifies_part", "scope": "說明三（二）第3點：另案由原調查小組續查前先審查檢舉委員迴避", "effective_on": null, "effective_date_basis": "未自發文日推定法定施行日；適用時點另核", "evidence_anchor": "(三)爰修正本部前揭函示說明三（二）第3點為「、、、由原調查小組成員依性平法第28條第3項規定向學校提出檢舉，受理後，由學校性平會決定調查方式，如決議交由同一調查小組併案續為調查時，學校性平會應先行審查該擔任檢舉人之調查小組成員有無應行迴避之事由後，再行決定是否另組新調查小組調查本檢舉案」。", "notes": "不是禁止一切併案，也不是認定凡檢舉者均無須迴避。", "review_basis": "user_uploaded_transcription", "scope_review": "來源文字可支持的關係；不是所有後續法規及函令的完整效力審查", "from_record_id": "C2013-008"}, {"relation_id": "CR-004", "from_number": "臺教學(三)字第1060065118號", "to_number": "臺教學（三）字第1050169132號", "relation_type": "modifies_part", "scope": "說明二（二）：學校議處與將報告移送社政審議之銜接", "effective_on": null, "effective_date_basis": "未自發文日推定法定施行日；適用時點另核", "evidence_anchor": "二、旨揭函文說明二（二）原函釋意見為「如為性騷擾或性霸凌屬實非屬情節重大，或認定教師違反專業倫理之情形，倘認有違反兒權法疑義，建議先將調查報告初稿轉請地方社政主管機關釐清確認有違反兒權法之事實，再錄為調查報告援引之違法依據，並由性平會對學校提出依教師法第線 14條第1項第13款之懲處建議。」，為避免影響學校依性別平等教育法第31條第3項執行議處程序之時程，修正為「教師涉及對未滿18歲學生性騷擾或性霸凌事件，經學校調查屬實者，除依性別平等教育法第31條第3項規定，自行或移權責單位審議懲處外，倘調查結果認該教師對未滿18歲學生之性騷擾或性霸凌行為恐有違反兒童及少年福利與權益保障法第49條各款情形之虞，宜請學校依法將調查報告轉請地方社政主管機關審議裁處。」。", "notes": "前函未列為本批獨立主文；後函引述舊段落不等於收錄前函全文。", "review_basis": "user_uploaded_transcription", "scope_review": "來源文字可支持的關係；不是所有後續法規及函令的完整效力審查", "from_record_id": "C2017-003"}, {"relation_id": "CR-005", "from_number": "臺教學(三)字第1100031108號", "to_number": "臺教學（三）字第1090108790號", "relation_type": "ceases_entire_letter", "scope": "本函主旨明示前函自即日起停止適用", "effective_on": "2021-03-09", "effective_date_basis": "函令明示，含後函確認的較早日期", "evidence_anchor": "- 主旨：本部109年8月13日臺教學（三）字第1090108790號函，自即日起停止適用，請查照。", "notes": "", "review_basis": "user_uploaded_transcription", "scope_review": "來源文字可支持的關係；不是所有後續法規及函令的完整效力審查", "from_record_id": "C2021-002"}, {"relation_id": "CR-006", "from_number": "臺教學(三)字第1100031108號", "to_number": "臺教學(三)字第1040042214A號", "relation_type": "reaffirms_cessation", "scope": "說明三確認該三函仍自109年6月30日停止適用", "effective_on": "2020-06-30", "effective_date_basis": "函令明示，含後函確認的較早日期", "evidence_anchor": "三、另旨揭函釋所列本部104年4月21日臺教學（三）字第1040042214A號、104年5月19日臺教學（三）字第1040065660號及105年6月28日臺教學（三）字第1050056734號函，仍自109年6月30日停止適用。", "notes": "停止1090108790函，不使這三份先前已停用函恢復適用；關係宣布日與停止適用日分開。", "review_basis": "user_uploaded_transcription", "scope_review": "來源文字可支持的關係；不是所有後續法規及函令的完整效力審查", "from_record_id": "C2021-002"}, {"relation_id": "CR-007", "from_number": "臺教學(三)字第1100031108號", "to_number": "臺教學(三)字第1040065660號", "relation_type": "reaffirms_cessation", "scope": "說明三確認該三函仍自109年6月30日停止適用", "effective_on": "2020-06-30", "effective_date_basis": "函令明示，含後函確認的較早日期", "evidence_anchor": "三、另旨揭函釋所列本部104年4月21日臺教學（三）字第1040042214A號、104年5月19日臺教學（三）字第1040065660號及105年6月28日臺教學（三）字第1050056734號函，仍自109年6月30日停止適用。", "notes": "停止1090108790函，不使這三份先前已停用函恢復適用；關係宣布日與停止適用日分開。", "review_basis": "user_uploaded_transcription", "scope_review": "來源文字可支持的關係；不是所有後續法規及函令的完整效力審查", "from_record_id": "C2021-002"}, {"relation_id": "CR-008", "from_number": "臺教學(三)字第1100031108號", "to_number": "臺教學(三)字第1050056734號", "relation_type": "reaffirms_cessation", "scope": "說明三確認該三函仍自109年6月30日停止適用", "effective_on": "2020-06-30", "effective_date_basis": "函令明示，含後函確認的較早日期", "evidence_anchor": "三、另旨揭函釋所列本部104年4月21日臺教學（三）字第1040042214A號、104年5月19日臺教學（三）字第1040065660號及105年6月28日臺教學（三）字第1050056734號函，仍自109年6月30日停止適用。", "notes": "停止1090108790函，不使這三份先前已停用函恢復適用；關係宣布日與停止適用日分開。", "review_basis": "user_uploaded_transcription", "scope_review": "來源文字可支持的關係；不是所有後續法規及函令的完整效力審查", "from_record_id": "C2021-002"}, {"relation_id": "CR-009", "from_number": "臺教學(三)字第1100007134號", "to_number": "臺教學（三）字第1020082802A號", "relation_type": "modifies_part", "scope": "所附調查及處理參考手冊Q&A第63題「何謂新事實新證據」", "effective_on": null, "effective_date_basis": "未自發文日推定法定施行日；適用時點另核", "evidence_anchor": "二、爰修正本部102年5月30日臺教學（三）字第1020082802A號函發布「校園性侵害性騷擾或性霸凌調查及處理參考手冊Q ＆A」題63「何謂新事實新證據？」內容，公布於本部性別線平等教育全球資訊網（https://www.gender.edu.tw/）。", "notes": "原Q&A未作為獨立主文收錄，不從片段補出全本。", "review_basis": "user_uploaded_transcription", "scope_review": "來源文字可支持的關係；不是所有後續法規及函令的完整效力審查", "from_record_id": "C2021-003"}, {"relation_id": "CR-010", "from_number": "臺教學(三)字第1100007134號", "to_number": "臺教學(三)字第1090164156號", "relation_type": "modifies_part", "scope": "說明二：疑似被害人未受訪案件依職權調查，及嗣後新事證", "effective_on": null, "effective_date_basis": "未自發文日推定法定施行日；適用時點另核", "evidence_anchor": "三、併修正本部109年12月25日臺教學（三）字第1090164156號函說明二（諒達）：依行政程序法第36條規定，行政機關應依職權調查證據，不受當事人主張之拘束，對當事人有利及不利事項一律注意，所詢案內以檢舉進行調查且疑似被害人拒絕受訪情形，為保障雙方當事人權益，學校性別平等教育委員會（下稱性平會）及調查小組應以依職權調", "notes": "", "review_basis": "user_uploaded_transcription", "scope_review": "來源文字可支持的關係；不是所有後續法規及函令的完整效力審查", "from_record_id": "C2021-003"}, {"relation_id": "CR-011", "from_number": "臺教學(三)字第1110029777號", "to_number": "臺教學(三)字第1070000950號", "relation_type": "supplements", "scope": "將防治教育執行者知情範圍的說明，銜接至心理輔導執行者", "effective_on": null, "effective_date_basis": "未自發文日推定法定施行日；適用時點另核", "evidence_anchor": "三、參照本部107年1月22日臺教學(三)字第1070000950號書函（諒達）略以：「學校應將執行課程之相關決議以密件通知該執行者，以利其執行防治教育課程。若課程執行者認有必要，亦得向學校提出申請提供與該事件有關之資訊（role/行為人於事件中之行為態樣及事件情境脈絡⋯等），以利其規劃符合該行為人之防治教育課程內涵，有效協助行為人釐清其行為問題與爭議。上開必要資訊之申請提供應經學校性別平等教育委員會（以下簡稱性平會）審酌評估提供之範圍內容（有助於防治教育之執行部分），並請該執行者簽署", "notes": "屬知情及保密處理的參照，不是將原函全文停止適用，也不把8小時課程改成一律必須。", "review_basis": "user_uploaded_transcription", "scope_review": "來源文字可支持的關係；不是所有後續法規及函令的完整效力審查", "from_record_id": "C2022-002"}, {"relation_id": "CR-012", "from_number": "臺教學(三)字第1122803970A號", "to_number": "臺教學(三)字第1060092113號", "relation_type": "modifies_part", "scope": "教職員工事件嚴重性及終身或1至4年不得聘任必要性之判斷基準", "effective_on": null, "effective_date_basis": "未自發文日推定法定施行日；適用時點另核", "evidence_anchor": "- 主旨：修正本部106年7月26日函示教師涉性別事件是否情節重大之判 斷基準，請依說明辦理並轉知所屬，請查照。", "notes": "後函另述113年3月8日前後事件範圍；不可將2024年第四類事件構成要件任意回溯。", "review_basis": "user_uploaded_transcription", "scope_review": "來源文字可支持的關係；不是所有後續法規及函令的完整效力審查", "from_record_id": "C2023-003"}, {"relation_id": "CR-013", "from_number": "臺教學(三)字第1132803568號", "to_number": "臺教學(三)字第1080088013號", "relation_type": "modifies_part", "scope": "校園性別事件調查處理經費支應規定；1130723版附件", "effective_on": null, "effective_date_basis": "未自發文日推定法定施行日；適用時點另核", "evidence_anchor": "函文檢送2024年7月23日版經費及行政實務說明；附件第一點調整2019年6月21日臺教學(三)字第1080088013號函的支應規定。外聘專家調查會議出席費當時上限為每次2,500元；稿費記載每千字1,100至1,600元，並註明日後主計總處修正時依其規定。", "notes": "本套件僅收官方查閱摘要及原件網址，使用時核對附件各財源適用差異。", "review_basis": "external_official_text_read; local_note_only", "scope_review": "來源文字可支持的關係；不是所有後續法規及函令的完整效力審查", "from_record_id": "OC2024-03"}, {"relation_id": "CR-014", "from_number": "臺教學（三）字第1132804741A號令", "to_number": "臺訓(三)字第1010245259號", "relation_type": "ceases_entire_letter", "scope": "解釋令第二點明示該兩函自即日起停止適用", "effective_on": "2024-10-29", "effective_date_basis": "函令明示，含後函確認的較早日期", "evidence_anchor": "第二點載明本令自即日生效，並使2012年12月26日臺訓（三）字第1010245259號函及2013年8月20日臺教學（三）字第1020114961號函自即日起停止適用。", "notes": "已於教育部主管法規共用系統核對解釋令全文。", "review_basis": "external_official_text_read; local_note_only", "scope_review": "來源文字可支持的關係；不是所有後續法規及函令的完整效力審查", "from_record_id": "OC2024-04"}, {"relation_id": "CR-015", "from_number": "臺教學（三）字第1132804741A號令", "to_number": "臺教學(三)字第1020114961號", "relation_type": "ceases_entire_letter", "scope": "解釋令第二點明示該兩函自即日起停止適用", "effective_on": "2024-10-29", "effective_date_basis": "函令明示，含後函確認的較早日期", "evidence_anchor": "第二點載明本令自即日生效，並使2012年12月26日臺訓（三）字第1010245259號函及2013年8月20日臺教學（三）字第1020114961號函自即日起停止適用。", "notes": "已於教育部主管法規共用系統核對解釋令全文。", "review_basis": "external_official_text_read; local_note_only", "scope_review": "來源文字可支持的關係；不是所有後續法規及函令的完整效力審查", "from_record_id": "OC2024-04"}, {"relation_id": "CR-016", "from_number": "臺教學(三)字第1132805502號", "to_number": "臺教學（三）字第1130801903號", "relation_type": "modifies_part", "scope": "向主管機關申復審議流程圖；1131118修版", "effective_on": null, "effective_date_basis": "未自發文日推定法定施行日；適用時點另核", "evidence_anchor": "本函修正2024年4月18日臺教學（三）字第1130801903號函所附主管機關申復流程圖。原函全文未收入本套件；只建立本函明示的修正關係，不反向重建原圖。", "notes": "前函及原版流程圖未收錄；不能宣稱已逐格比對新舊圖。", "review_basis": "external_official_text_read; local_note_only", "scope_review": "來源文字可支持的關係；不是所有後續法規及函令的完整效力審查", "from_record_id": "OC2024-05"}, {"relation_id": "CR-017", "from_number": "臺教學(三)字第1050056133號", "to_number": "法檢字第10504500190號", "relation_type": "forwards", "scope": "學校向羈押收容機關請求公務接見之函轉", "effective_on": null, "effective_date_basis": "未自發文日推定法定施行日；適用時點另核", "evidence_anchor": "- 主旨：有關學校教師因涉性侵害案件遭地方法院檢察署（下稱地檢署）聲請羈押獲准，得否同意學校調查小組請求至羈押處所進行訪談乙事，請依法務部105年4月21日法檢字第10504500190號函釋（如附件）辦理並轉知所屬，請查照。", "notes": "教育部轉函與法務部原函分開計算；現行收容機關接見作業另核。", "review_basis": "user_uploaded_transcription", "scope_review": "來源文字可支持的關係；不是所有後續法規及函令的完整效力審查", "from_record_id": "C2016-004"}, {"relation_id": "CR-018", "from_number": "台訓(三)字第0980053278號", "to_number": "童保字第0980053069號", "relation_type": "forwards", "scope": "兒少性騷擾事件通報之函轉與補充", "effective_on": null, "effective_date_basis": "未自發文日推定法定施行日；適用時點另核", "evidence_anchor": "- 主旨：函轉內政部兒童局函示(如附件影本)有關校園兒童及少年性騷擾事件，係違反兒童及少年福利法(以下簡稱兒少法)第30條相關規定，仍屬同法第34條第1項應於24小時通報之行為範疇，請 查照並轉知所屬照辦。", "notes": "", "review_basis": "user_uploaded_transcription", "scope_review": "來源文字可支持的關係；不是所有後續法規及函令的完整效力審查", "from_record_id": "C2009-006"}, {"relation_id": "CR-019", "from_number": "臺教學(三)字第1070029022號", "to_number": "臺教學(三)字第1070026350號", "relation_type": "related_topic_only", "scope": "調查小組組成、性平會及調查的專業分工；不推定取代", "effective_on": null, "effective_date_basis": "未自發文日推定法定施行日；適用時點另核", "evidence_anchor": "- 主旨：所詢有關性別平等教育法（以下簡稱性平法）第30條第3項 規定適用疑義案，復如說明，請查照。", "notes": "此筆僅為本次編輯的主題參照，沒有法規效力變更；全文仍須各別閱讀。", "review_basis": "editorial_topic_association_not_explicit_legal_effect", "scope_review": "來源文字可支持的關係；不是所有後續法規及函令的完整效力審查", "from_record_id": "C2018-003"}, {"relation_id": "CR-020", "from_number": "臺教學(三)字第1132800332號", "from_record_id": "C2024-001", "to_number": "臺教學(三)字第1100131246號", "relation_type": "modifies_part", "scope": "第二、三章違反事件之收件及職權調查、引用條次", "effective_on": null, "effective_date_basis": "不自發文日推定施行日期；按所述變更範圍及適用時點審查", "evidence_anchor": "第2章「學習環境 及資源」及\n第3章「課程、教材及教學」之調查處理案， 請查照。\n說明： 一、依據本部110年9月28日臺教學(三)字第1100131246、訂.. 1100131246A號函(諒達)續辦。 二、查性平法業經112年8月16日總統華總一義字第11200069321 號令修正公布，爰本部110年9月28日臺教學(三)字第 1100131246、1100131246A號函(諒達)修正如下： (一)原說明二、「(四)暢通申訴管道並落實依法作為」修正線.. 如下： １、學校或機關應提供校園性別事件收件單位之相關資訊 讓學生知悉，如收件單位之地點、電話、電子信箱.. 0.. 等，亦應提供學校或教師違反性平法\n第2章及\n第3章所 規範事件之收件單位。 ２、若發現學校或教師有違反性平法\n第2章及\n第3章情事， 得向學校所屬主管機關或教師所屬學校陳情或舉發， 國立嘉義大學.第 1 頁，共 2 頁1130001245　113/01/25", "notes": "", "review_basis": "user_uploaded_transcription", "scope_review": "對照來源文字所支持的關係，不代表歷年函示效力全面查核"}, {"relation_id": "CR-021", "from_number": "臺教學(三)字第1132800332號", "from_record_id": "C2024-001", "to_number": "臺教學(三)字第1100131246A號", "relation_type": "modifies_part", "scope": "第二、三章違反事件之收件及職權調查、引用條次", "effective_on": null, "effective_date_basis": "不自發文日推定施行日期；按所述變更範圍及適用時點審查", "evidence_anchor": "第2章「學習環境 及資源」及\n第3章「課程、教材及教學」之調查處理案， 請查照。\n說明： 一、依據本部110年9月28日臺教學(三)字第1100131246、訂.. 1100131246A號函(諒達)續辦。 二、查性平法業經112年8月16日總統華總一義字第11200069321 號令修正公布，爰本部110年9月28日臺教學(三)字第 1100131246、1100131246A號函(諒達)修正如下： (一)原說明二、「(四)暢通申訴管道並落實依法作為」修正線.. 如下： １、學校或機關應提供校園性別事件收件單位之相關資訊 讓學生知悉，如收件單位之地點、電話、電子信箱.. 0.. 等，亦應提供學校或教師違反性平法\n第2章及\n第3章所 規範事件之收件單位。 ２、若發現學校或教師有違反性平法\n第2章及\n第3章情事， 得向學校所屬主管機關或教師所屬學校陳情或舉發， 國立嘉義大學.第 1 頁，共 2 頁1130001245　113/01/25", "notes": "", "review_basis": "user_uploaded_transcription", "scope_review": "對照來源文字所支持的關係，不代表歷年函示效力全面查核"}, {"relation_id": "CR-022", "from_number": "臺教學(三)字第1132803568號", "from_record_id": "C2024-006", "to_number": "臺教學(三)字第1080088013號", "relation_type": "modifies_part", "scope": "調查費用與行政實務支應規定，不排除本文大專校院自籌收入另定支用之條件", "effective_on": null, "effective_date_basis": "不自發文日推定施行日期；按所述變更範圍及適用時點審查", "evidence_anchor": "調整本部108 年6 月21 日以臺教學(三)字第1080088013 號函所列支應規定如下：（一） 調查小組調查費之支給：1. 外聘之專家學者：以調查會議支給出席費，每次會議以新臺幣2,500 元為上限。會議依調查對象不同以場次計，每場次2-3 小時為原則。", "notes": "", "review_basis": "user_uploaded_transcription", "scope_review": "對照來源文字所支持的關係，不代表歷年函示效力全面查核"}, {"relation_id": "CR-023", "from_number": "臺教學(三)字第1132804741B號", "from_record_id": "C2024-008", "to_number": "臺教學(三)字第1132804741A號", "relation_type": "forwards", "scope": "同日解釋令函送及學生救濟例示；A號目錄摘要與B號全文分開", "effective_on": null, "effective_date_basis": "不自發文日推定施行日期；按所述變更範圍及適用時點審查", "evidence_anchor": "- 發文日期：2024-10-29\n- 發文字號：臺教學(三)字第1132804741B號\n- 主旨：檢送「校園性別事件防治準則」（以下簡稱防治準則）第32條 第3項規定解釋令1份，請查照。", "notes": "", "review_basis": "user_uploaded_transcription", "scope_review": "對照來源文字所支持的關係，不代表歷年函示效力全面查核"}, {"relation_id": "CR-024", "from_number": "臺教學(三)字第1132804741B號", "from_record_id": "C2024-008", "to_number": "臺訓(三)字第1010245259號", "relation_type": "ceases_entire_letter", "scope": "前函全函停止適用", "effective_on": "2024-10-29", "effective_date_basis": "來源明示自即日停止適用", "evidence_anchor": "四、另本部101年12月26日臺訓(三)字第1010245259號函及102年8月20日臺教學(三)字第1020114961號函，自即日起停止適用。", "notes": "", "review_basis": "user_uploaded_transcription", "scope_review": "對照來源文字所支持的關係，不代表歷年函示效力全面查核"}, {"relation_id": "CR-025", "from_number": "臺教學(三)字第1132804741B號", "from_record_id": "C2024-008", "to_number": "臺教學(三)字第1020114961號", "relation_type": "ceases_entire_letter", "scope": "前函全函停止適用", "effective_on": "2024-10-29", "effective_date_basis": "來源明示自即日停止適用", "evidence_anchor": "四、另本部101年12月26日臺訓(三)字第1010245259號函及102年8月20日臺教學(三)字第1020114961號函，自即日起停止適用。", "notes": "", "review_basis": "user_uploaded_transcription", "scope_review": "對照來源文字所支持的關係，不代表歷年函示效力全面查核"}, {"relation_id": "CR-026", "from_number": "臺教學(三)字第1132804859號", "from_record_id": "C2024-009", "to_number": "臺教學(三)字第1100031108號", "relation_type": "modifies_part", "scope": "僅說明二所附軍訓教官事件處置流程圖廢止參考適用；不是全文停止", "effective_on": null, "effective_date_basis": "不自發文日推定施行日期；按所述變更範圍及適用時點審查", "evidence_anchor": "（三）字第1100031108號函（諒達）說明二所附「教育部所屬高級中等以上學校軍訓教官涉及校園性侵害、性騷擾或性霸凌事件屬實處置程序」流程圖予以廢止參考適用。", "notes": "", "review_basis": "user_uploaded_transcription", "scope_review": "對照來源文字所支持的關係，不代表歷年函示效力全面查核"}, {"relation_id": "CR-027", "from_number": "臺教學(三)字第1132805502號", "from_record_id": "C2024-011", "to_number": "臺教學(三)字第1132801903號", "relation_type": "modifies_part", "scope": "申復有理由交回學校及40日流程；原稿疑有缺頁，不反向補為原文", "effective_on": null, "effective_date_basis": "不自發文日推定施行日期；按所述變更範圍及適用時點審查", "evidence_anchor": "說明：一丶旨揭流程圖原係本部因應性平法第37條第1項但書規定，擬訂申復審議及審議結果處置流程，提供各地方政府及各級學校參考運用。後續審酌原列交回學校依法處理（重啟調查、重為決定）段恐未能符應性平法第37條第3項後段所定限學校於40 日內完成調查之規定，爰予修正經主管機關申復審議為有理由者，逕交回學校依法處理（如流程圖左下所列）。\n二、另針對校園性別事件雙方當事人提出申復之時點有落差時（例如接獲處理結果第1日、第30日方分別提出）之申復審議時程疑義，請依下列說明辨理：（一）雙方當事人（教職員工生／生）僅向學校提出申復，但提出申復時點落差過大，難以於30日之申復審議時程併案審議時，請學校分別審議。另審酌係對渠等所涉同一校園性別事件之處理結果提出申復，為避免對同一事件產生歧異之審議結果，爰建議由同一組申復審議小紐成員審議並分別回應申復人所提事由。", "notes": "", "review_basis": "user_uploaded_transcription", "scope_review": "對照來源文字所支持的關係，不代表歷年函示效力全面查核"}, {"relation_id": "CR-028", "from_number": "臺教學(三)字第1130122346號", "from_record_id": "C2025-001", "to_number": "臺教學(三)字第1020165630號", "relation_type": "ceases_entire_letter", "scope": "三法申訴處理舊函全函停止適用", "effective_on": "2025-01-09", "effective_date_basis": "原稿說明三記載「自即日超均停止適用」（原轉錄字樣保留），指本函發文日", "evidence_anchor": "三、本部102 年12 月24 日臺教學（三）字第1020165630號函及所載100年10 月31 日臺訓（三）字第1000170857B號、同年12 月6 日臺訓\n\n（三）字第1000203271 號函自即日超均停止適用。", "notes": "不將後函所引其他文號一併列為停止適用", "review_basis": "user_uploaded_transcription", "scope_review": "以說明三所列三函為限"}, {"relation_id": "CR-029", "from_number": "臺教學(三)字第1130122346號", "from_record_id": "C2025-001", "to_number": "臺訓(三)字第1000170857B號", "relation_type": "ceases_entire_letter", "scope": "三法申訴處理舊函全函停止適用", "effective_on": "2025-01-09", "effective_date_basis": "原稿說明三記載「自即日超均停止適用」（原轉錄字樣保留），指本函發文日", "evidence_anchor": "三、本部102 年12 月24 日臺教學（三）字第1020165630號函及所載100年10 月31 日臺訓（三）字第1000170857B號、同年12 月6 日臺訓\n\n（三）字第1000203271 號函自即日超均停止適用。", "notes": "不將後函所引其他文號一併列為停止適用", "review_basis": "user_uploaded_transcription", "scope_review": "以說明三所列三函為限"}, {"relation_id": "CR-030", "from_number": "臺教學(三)字第1130122346號", "from_record_id": "C2025-001", "to_number": "臺訓(三)字第1000203271號", "relation_type": "ceases_entire_letter", "scope": "三法申訴處理舊函全函停止適用", "effective_on": "2025-01-09", "effective_date_basis": "原稿說明三記載「自即日超均停止適用」（原轉錄字樣保留），指本函發文日", "evidence_anchor": "三、本部102 年12 月24 日臺教學（三）字第1020165630號函及所載100年10 月31 日臺訓（三）字第1000170857B號、同年12 月6 日臺訓\n\n（三）字第1000203271 號函自即日超均停止適用。", "notes": "不將後函所引其他文號一併列為停止適用", "review_basis": "user_uploaded_transcription", "scope_review": "以說明三所列三函為限"}, {"relation_id": "CR-031", "from_number": "臺教學(三)字第1140017674號", "from_record_id": "C2025-003", "to_number": "臺教學(三)字第1132804741A號", "relation_type": "supplements", "scope": "跨校調查與議處之通知救濟、回報資料銜接", "effective_on": null, "effective_date_basis": "不自發文日推定施行日期；按所述變更範圍及適用時點審查", "evidence_anchor": "- 發文日期：2025-03-04\n- 發文字號：臺教學(三)字第1140017674號\n- 主旨：有關本部113 年10 月29 日臺教學（三）字第1132804741A號令核釋 「校園性別事件防治準則（以下簡稱防治準則）第32條第3 項 規定」及本部「校園性別事件回復填報及統計管理系統」陳報 作業事項，請依說明辦理，請查照。", "notes": "", "review_basis": "user_uploaded_transcription", "scope_review": "對照來源文字所支持的關係，不代表歷年函示效力全面查核"}, {"relation_id": "CR-032", "from_number": "臺教學(三)字第1140028039號", "from_record_id": "C2025-005", "to_number": "臺教學(三)字第1040065754號", "relation_type": "supplements", "scope": "實習指導人員性騷擾之共同調查與三條申訴入口", "effective_on": null, "effective_date_basis": "不自發文日推定施行日期；按所述變更範圍及適用時點審查", "evidence_anchor": "說明：\n一、依勞動部114 年3 月11 日勞動條5 字第1140147685 號函（如附件）及本部104 年5 月22 日臺教學（三）字第1040065754 號函（諒達）辦理。", "notes": "", "review_basis": "user_uploaded_transcription", "scope_review": "對照來源文字所支持的關係，不代表歷年函示效力全面查核"}, {"relation_id": "CR-033", "from_number": "臺教學(三)字第1142801109號", "from_record_id": "C2025-007", "to_number": "臺教學(三)字第1090151773號", "relation_type": "supplements", "scope": "行政調查證據認定與全數專業人員之建議；不等同法定比例變更", "effective_on": null, "effective_date_basis": "不自發文日推定施行日期；按所述變更範圍及適用時點審查", "evidence_anchor": "四、本部109年12月4日臺教學(三)字第1090151773號函（諒達）為落實校園性別事件調查「客觀、公正、專業之原則」及維護調查專業品質，已建議「調查校園性侵害事件、或教職員工涉及性騷擾或性霸凌學生事件時，宜全數為具性侵害、性騷擾或性霸凌事件調查專業素養之專家學者」在案。為落實說明三事項，各級學校性平會調查校園性侵害事件、校長或教職員工對學生之性騷擾、性霸凌及違反與性或性別有關之專業倫理事件時，建議調查小組成員應全數延聘具校園性別事件調查專業素養之專家學者或熟稔性平法之法律專業背景人員。", "notes": "", "review_basis": "user_uploaded_transcription", "scope_review": "對照來源文字所支持的關係，不代表歷年函示效力全面查核"}, {"relation_id": "CR-034", "from_number": "臺教學(三)字第1140134739號", "from_record_id": "C2026-001", "to_number": "臺教學(三)字第1130037236號", "relation_type": "supplements", "scope": "調查小組組成恆定及議處權責異動、畢業升學例外", "effective_on": null, "effective_date_basis": "不自發文日推定施行日期；按所述變更範圍及適用時點審查", "evidence_anchor": "二、查本部113年5月21日臺教學(三)字第1130037236號函（諒達）釋示「校園性別事件防治準則（以下簡稱防治準則）第12條第1項規定校園性別事件案之行為人現所屬學校派代表參與調查定義」在案；次查本部113 年10 月29 日臺教學( 三) 字第1132804741A號令（以下簡稱本部113年10月29日令）核釋防治準則第32條第3項規定，如有防治準則第12條第2項規定情形，由事件管轄學校完成調查屬實者，應將調查報告及處理建議移送行為人現所屬學校（即議處權責學校）作成終局處理結果時，應由議處權責學校（或機關）以書面通知申請人、被害人、檢舉人及行為人，向議處權責學校（或機關）提起申復及救濟。", "notes": "", "review_basis": "user_uploaded_transcription", "scope_review": "對照來源文字所支持的關係，不代表歷年函示效力全面查核"}, {"relation_id": "CR-035", "from_number": "臺教學(三)字第1140134739號", "from_record_id": "C2026-001", "to_number": "臺教學(三)字第1132804741A號", "relation_type": "supplements", "scope": "調查小組組成恆定及議處權責異動、畢業升學例外", "effective_on": null, "effective_date_basis": "不自發文日推定施行日期；按所述變更範圍及適用時點審查", "evidence_anchor": "二、查本部113年5月21日臺教學(三)字第1130037236號函（諒達）釋示「校園性別事件防治準則（以下簡稱防治準則）第12條第1項規定校園性別事件案之行為人現所屬學校派代表參與調查定義」在案；次查本部113 年10 月29 日臺教學( 三) 字第1132804741A號令（以下簡稱本部113年10月29日令）核釋防治準則第32條第3項規定，如有防治準則第12條第2項規定情形，由事件管轄學校完成調查屬實者，應將調查報告及處理建議移送行為人現所屬學校（即議處權責學校）作成終局處理結果時，應由議處權責學校（或機關）以書面通知申請人、被害人、檢舉人及行為人，向議處權責學校（或機關）提起申復及救濟。", "notes": "", "review_basis": "user_uploaded_transcription", "scope_review": "對照來源文字所支持的關係，不代表歷年函示效力全面查核"}, {"relation_id": "CR-036", "from_number": "臺教學(三)字第1140134739號", "from_record_id": "C2026-001", "to_number": "臺教學(三)字第1132804741B號", "relation_type": "supplements", "scope": "調查小組組成恆定及議處權責異動、畢業升學例外", "effective_on": null, "effective_date_basis": "不自發文日推定施行日期；按所述變更範圍及適用時點審查", "evidence_anchor": "３、併重申畢業學生應依本部113年10月29日臺教學(三)字第1132804741B號函（諒達）附「校園性別事件學生當", "notes": "", "review_basis": "user_uploaded_transcription", "scope_review": "對照來源文字所支持的關係，不代表歷年函示效力全面查核"}, {"relation_id": "CR-037", "from_number": "臺教學(三)字第1150034731號", "from_record_id": "C2026-004", "to_number": "臺教學(三)字第1120057724號", "relation_type": "related_topic_only", "scope": "重為決定與再次救濟之主題關聯；本函並未明示修改1120057724", "effective_on": null, "effective_date_basis": "不自發文日推定施行日期；按所述變更範圍及適用時點審查", "evidence_anchor": "- 發文日期：2026-04-17\n- 發文字號：臺教學(三)字第1150034731號\n- 主旨：有關校園性別事件經申復審議決定「申復有理由」，倘學校性別平等教育委員會（以下簡稱性平會）「重為決定」時，有違背申復審議決定意旨而予以變更（或維持）處分之情事，請各主管機關依說明辦理並轉知所屬，請查照。", "notes": "本邊為編者主題導引，不能解讀為後函引用或停止前函。", "review_basis": "user_uploaded_transcription", "scope_review": "對照來源文字所支持的關係，不代表歷年函示效力全面查核"}, {"relation_id": "CR-038", "from_number": "臺教學(三)字第1150050033號", "from_record_id": "C2026-005", "to_number": "臺教學(三)字第1020080238號", "relation_type": "modifies_part", "scope": "原函受理檢舉後主動徵詢被害人是否一併申請調查之段落，改為書面受理通知；保留結果通知", "effective_on": null, "effective_date_basis": "不自發文日推定施行日期；按所述變更範圍及適用時點審查", "evidence_anchor": "請，通知其參加為當事人。」俾被害人參與調查程序；但疑似被害人不詳時，得免予通知。且該被害人得依性平法第32條第4項規定略以，於接獲不受理通知之次日起20日內，以書面具明理由，向學校或主管機關申復。\n四、次查校園性別事件防治準則第18條第3項規定：「學校或主管機關知悉疑似校園性別事件有下列情形，應由所設性平會評估該事件對學生受教權及校園安全之影響，經會議決議以檢舉案形式啟動調查程序，以釐清事實，採取必要之措施維護學生之權益與校園安全：\n一、二人以上被害人。\n二、二人以上行為人。\n三、行為人為校長或教職員工。\n四、涉及校園安全議題。\n五、其他經性平會認有以檢舉案形式啟動調查之必要者。」該等經性平會會議決議而檢舉者，亦應依性平法第32條第1項規定，以書面通知事件疑似被害人是否受理。\n五、併修正本部102年7月16日臺教學(三)字第1020080238號函略以：「有關學校因受理檢舉而調查之校園性別事件……就調查處理程序中，除事件管轄學校於案件受理後，得主動徵詢被害人或其法定代理人是否一併申請調查」1節，應依性平法第32條第1項規定，以書面通知事件疑似被害人是否受理，無須另行徵詢被害人或其法定代理人之申請調查意願；至該函「調查處理完成後」，應依性平法第36條第3項規定，將處理之結果，以書面載明事實及理由通知被害人。", "notes": "", "review_basis": "user_uploaded_transcription", "scope_review": "對照來源文字所支持的關係，不代表歷年函示效力全面查核"}, {"relation_id": "CR-039", "from_number": "臺教學(三)字第1152801934號", "from_record_id": "C2026-006", "to_number": "臺教學(三)字第1122803970A號", "relation_type": "supplements", "scope": "同一教職員工多案之併案議處條件、理由與限縮報告提供", "effective_on": null, "effective_date_basis": "不自發文日推定施行日期；按所述變更範圍及適用時點審查", "evidence_anchor": "說明：\n一、依115年2月9日本部第12屆性別平等教育委員會（以下簡稱性平會）校園性別事件防治組第1次會議決議辦理。\n二、性別平等教育法（以下簡稱性平法）第34條第4項規定：「調查發現同一行為人對不同被害人有發生類似校園性別事件時，得併案調查。」經併案調查時，得就事情情節綜合評價判斷予以議處，俾落實本部112年9月26日臺教學（三）字第1122803970A號函（諒達）示教職員工之性別事件情節輕重判斷基準。\n三、查校園性別事件防治準則（以下簡稱防治準則）第11條規定略以，校園性別事件之被害人、其法定代理人或實際照顧者（以下簡稱申請人）、檢舉人，向行為人於行為發生時所屬之學校（事件管轄學校）申請調查或檢舉，容有不同校園性別事件由不同事件管轄學校調查處理之情形，未得依性平法第34條第4項規定併案調查；次查本部113年10月29日臺教學（三）字第1132804741A號令（諒達）核釋防治準則第32條第3項規定，如有防治準則第12條第2項規定情形，由行為人現所屬學校予以終局議處。\n四、旨揭行為人所涉不同校園性別事件，應併案審議議處之程序如下：", "notes": "", "review_basis": "user_uploaded_transcription", "scope_review": "對照來源文字所支持的關係，不代表歷年函示效力全面查核"}, {"relation_id": "CR-040", "from_number": "臺教學(三)字第1152801934號", "from_record_id": "C2026-006", "to_number": "臺教學(三)字第1132804741A號", "relation_type": "supplements", "scope": "同一教職員工多案之併案議處條件、理由與限縮報告提供", "effective_on": null, "effective_date_basis": "不自發文日推定施行日期；按所述變更範圍及適用時點審查", "evidence_anchor": "說明：\n一、依115年2月9日本部第12屆性別平等教育委員會（以下簡稱性平會）校園性別事件防治組第1次會議決議辦理。\n二、性別平等教育法（以下簡稱性平法）第34條第4項規定：「調查發現同一行為人對不同被害人有發生類似校園性別事件時，得併案調查。」經併案調查時，得就事情情節綜合評價判斷予以議處，俾落實本部112年9月26日臺教學（三）字第1122803970A號函（諒達）示教職員工之性別事件情節輕重判斷基準。\n三、查校園性別事件防治準則（以下簡稱防治準則）第11條規定略以，校園性別事件之被害人、其法定代理人或實際照顧者（以下簡稱申請人）、檢舉人，向行為人於行為發生時所屬之學校（事件管轄學校）申請調查或檢舉，容有不同校園性別事件由不同事件管轄學校調查處理之情形，未得依性平法第34條第4項規定併案調查；次查本部113年10月29日臺教學（三）字第1132804741A號令（諒達）核釋防治準則第32條第3項規定，如有防治準則第12條第2項規定情形，由行為人現所屬學校予以終局議處。\n四、旨揭行為人所涉不同校園性別事件，應併案審議議處之程序如下：", "notes": "", "review_basis": "user_uploaded_transcription", "scope_review": "對照來源文字所支持的關係，不代表歷年函示效力全面查核"}, {"relation_id": "CR-041", "from_number": "臺教學(三)字第1152801934號", "from_record_id": "C2026-006", "to_number": "臺教學(三)字第1132805149號", "relation_type": "supplements", "scope": "同一教職員工多案之併案議處條件、理由與限縮報告提供", "effective_on": null, "effective_date_basis": "不自發文日推定施行日期；按所述變更範圍及適用時點審查", "evidence_anchor": "如下：(一)校園性別事件經依防治準則第30條第2項前段規定「性平會召開會議審議調查報告認定校園性別事件屬實」及依性平法第36條第2項規定，性平會將調查報告及處理建議，以書面向其所屬學校（即事件管轄學校）提出報告；事件管轄學校依性平法第36條第3項規定，移送議處權責學校議處。\n(二)因議處權責學校業依防治準則第12條第1項規定，已派員參與調查，爰得掌握調查進度。倘有同一行為人所涉不同校園性別事件之調查報告經移送議處權責學校，且處理建議未達終身不得聘任、任用、進用或運用必要時，議處權責學校可得確認其他事件管轄學校於2個月內將完成他案調查報告，並認定校園性別事件屬實予以移送議處者（參照性平法第36條第3項前段規定略以「學校應於接獲前項調查報告後2個月內，自行或移送相關權責機關依本法或相關法律或法規規定議處」），議處權責學校性平會得併案審議，綜合各調查結果作成終局議處之處理建議，包括性平法第26條第2項規定之處置措施（心理諮商與輔導之處置時數應依本部113年12月19日臺教學(三)字第1132805149號函諒達辦理）。\n(三)承上，議處權責學校以書面通知校園性別事件處理之結果，應載明原事件事實及併案加重處分理由，通知申請人、被害人、檢舉人及行為人；依防治準則第32條第1項規定所一併提供之調查報告，為符保密規定，應僅為各當事人原事件之調查報告。\n(四)倘非屬上開議處權責學校性平會於2個月內併案審議議處情形（含未適用防治準則第12條第1項規定者），各該事件之調查報告及處理建議，依性平法第26條第1項規定，應由議處權責學校分別依相關法律或法規規定議處；另依", "notes": "", "review_basis": "user_uploaded_transcription", "scope_review": "對照來源文字所支持的關係，不代表歷年函示效力全面查核"}, {"relation_id": "CR-042", "from_number": "臺教學(三)字第1152803124號", "from_record_id": "OC2026-01", "to_number": "台訓(三)字第0990120627號", "relation_type": "supplements", "scope": "簡化調查處理程序與2010年不成立調查小組之歷史銜接", "effective_on": null, "effective_date_basis": "不自發文日推定施行日期；按所述變更範圍及適用時點審查", "evidence_anchor": "函文援引99年8月12日台訓(三)第0990120627號函的不成立小組處理方式；此為歷史銜接，不是宣告該舊函全文停止適用。主要程序為受理分流、雙方書面或言詞陳述答辯、性平會審議並提出報告；可委任人才庫資格人員一名撰寫初稿。議處、結果通知及救濟仍依性平法辦理；救濟後重新調查之指定情形應成立調查小組。", "notes": "", "review_basis": "external_official_reading_note", "scope_review": "對照來源文字所支持的關係，不代表歷年函示效力全面查核"}, {"relation_id": "CR-043", "from_number": "臺教學(三)字第1152803608號", "from_record_id": "OC2026-02", "to_number": "臺教學(三)字第1132804859號", "relation_type": "reaffirms", "scope": "教師解聘停聘報核時通知與雙方均未申復時最終通知再教示", "effective_on": null, "effective_date_basis": "不自發文日推定施行日期；按所述變更範圍及適用時點審查", "evidence_anchor": "本函重申113年11月4日臺教學（三）字第1132804859號函之救濟管轄與處理。教師解聘、停聘決議報請主管教育行政機關核准時，人事單位應同步以附理由書面通知當事人，教示通知次日起三十日內申復；申請人及被害人的通知得由性平會秘書單位另行辦理。", "notes": "", "review_basis": "external_official_reading_note", "scope_review": "對照來源文字所支持的關係，不代表歷年函示效力全面查核"}]
- interpretation_rule：關係類型具有不同意義；related_topic_only及forwards絕不當成廢止。