# 大專校院性平承辦人 Skill

版本1.4.0｜臺灣繁體中文｜2026年9月12日

累積完整版本，以使用者上傳的1.3.0 ZIP為基礎。保留三種措施分流、不同參與者的權限審查、已提出疑義仍被要求照辦的陳核規則，以及原有案件、人事、會務與年度業務。沒有安裝到任何特定平台、登入校務系統、發文或處理真實個案。

## 本次修正

版本驗證改讀安全解析後的YAML值，不因引號樣式誤判；發布完整性仍逐檔比對大小與SHA-256，兩者分開。入口增加具體適用情境，24個參考模組都有直接連結，外部技能改為確實具備時才選用；不宣稱已證明模型選用率提高。

新增115年8月7日1152803267號教育處置函摘要OC2026-03與部分修正關係CR-044，同步更新規則、範本、FW06及紀錄檢核。115年8月24日通知救濟函原已收錄為OC2026-02，本次沿用，不重複新增。

簡化程序工具增加實際階段，受理前不再要求提前確認陳述答辯後事實。共同工作紀錄分開各項任務、對象、送達、期限與完成證明；補充救濟後續、研究生與助理銜接、特殊身分、資料誤寄及例行資源提報，未將skill改成完整案件管理系統。

詳細範圍、未採用項目及升級方式見[UPGRADE-v1.4.0.md](UPGRADE-v1.4.0.md)。

## 使用與目錄

保留整個`campus-gender-equity-officer`資料夾，以`SKILL.md`為入口。不要只取主檔而漏掉相對路徑的模組與資料；平台是否支援技能自動選用及命令執行，依實際環境確認。`agents/openai.yaml`保留既有平台介面設定，不是跨平台可用性認證。

| 位置 | 用途 |
|---|---|
| SKILL.md、references/ | 依問題按需讀取的主指令及24個模組 |
| templates/ | 17個範本；15為研究生／助理銜接，16為逐對象通知送達，17為非四類事件及人力資源提報 |
| sources/uploaded/ | 18份使用者原始法規／指引JSON，保持原檔 |
| sources/circulars/ | 23份年度原稿、8筆外部查閱摘要、函示索引及關係證據 |
| sources/procedures/ | 使用者原簡化程序PDF、既有逐頁文字及來源紀錄 |
| sources/fieldwork-review/、revision-review/ | 前版六筆及本版六筆有限查閱摘要，各附範圍、網址、日期及摘要雜湊 |
| assets/ | 本校設定、工作紀錄、簡化條件、23項期限規則、規則影響表 |
| scripts/、tests/ | 檢索、條件與完整性工具，程式回歸測試與執行紀錄 |
| evals/ | 112個尚未執行的模型驗收情境；15題×3條件之優先對照準備工具 |

本校資料、任用身分、實際授權及案件未知事實保持空值；只問足以改變本題判斷的必要資料。使用共同格式時先讀[工作紀錄說明](assets/CASE-RECORD-GUIDE.md)，不要把完整卷宗、性影像或諮商內容放入範例或外部AI。

## 離線工具與依賴

純Markdown閱讀不需Python。`lookup_law.py`、`lookup_circular.py`、`check_simplified.py`及`package_integrity.py`可用Python 3.10以上與標準函式庫；完整驗證及新工作紀錄檢核另需下列選用依賴，使用者自行決定是否安裝：

```bash
python -m pip install -r requirements-validation.txt
python scripts/lookup_law.py --law 性平法 --article 25
python scripts/lookup_circular.py --number 1132805149 --full
python scripts/lookup_circular.py --id OC2026-03 --full
python scripts/check_simplified.py assets/simplified-case.example.json
python scripts/check_case_record.py assets/case-record.example.json
```

空白簡化例示應回覆`needs_verified_information`，不核准程序。空白工作紀錄通過只代表格式正確，沒有任何工作因此變成完成。工具不計算法律截止日，也不發送通知；每筆實際日期由明確起算、法定單位、計算紀錄與覆核銜接。

## 驗證與發布

```bash
python scripts/validate_package.py
python -m unittest discover -s tests -v
python scripts/package_integrity.py verify
```

本版161項程式／結構測試通過，含60項新增回歸測試；不是161項模型問答驗收。套件內`tests/last-run.txt`與`tests/structure-validation.json`為打包前紀錄，`VALIDATION.json`載明範圍；實際交付ZIP另於乾淨解壓後執行完整清冊驗證與同組測試，收據隨交付檔另提供。

`--structure-only`只在修訂過程跳過發布清冊，輸出`release_manifest_verified: false`，不代表可以交付。驗證失敗不自動修清冊。完成內容及測試紀錄後，維護者明確執行`python scripts/package_integrity.py build`再封存；之後任何修改都須重驗、重建、重新打包。清冊自身不能自我雜湊，外部收據另記ZIP與清冊SHA-256；這不是數位簽章。

實際模型作答0次；112題仍為`not_run`。優先套組只準備45筆對照工作表，詳見[評測執行說明](evals/PRIORITY-RUNBOOK.md)。不得把程式測試通過或人工法源核對寫成已證明Claude／ChatGPT自動選用與回答品質改善。

## 來源界線

原始18份JSON、23份年度Markdown及1份PDF共42檔，逐檔與使用者原ZIP比對保留。年度原稿仍有347個條目、346個不同主文號；加8筆摘要共355筆索引，並非355份完整公文。44條已整理關係、148筆純文號提及與27項品質／重號提示分開。四筆發文日期未知、三筆原有目錄摘要不補造；2026年度原稿最晚至6月23日，不宣稱全年或歷年全集。

本次查閱的法律條文及判決範圍逐筆記在revision-review；沒有把18部法規全標為2026年9月12日重新查核。OC2026-03原函三頁已閱覽，但原PDF沒有下載保存隨包提供，只有明確標示的摘要及官方網址；摘要雜湊不代表官方原檔雜湊。

`tests/v1.3.0-as-uploaded-*`保留上傳包原有發布紀錄以供比對，其中「全通過」等記載不是本次重現結果。本版不改原始法規、舊函原稿、未知日期或歷史決議來配合現行解讀。
