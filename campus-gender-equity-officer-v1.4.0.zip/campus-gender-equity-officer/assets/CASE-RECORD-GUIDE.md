# 工作紀錄與舊版欄位銜接

這是選用的去識別工作紀錄格式，不要求將完整個案上傳AI，也不是校務系統或自動法律決定。`case-record.example.json`與YAML例示同一空白結構；schema規範工作、通知、期限與處置欄位。原始證據、諮商全文及性影像應留在本校核准環境，只記必要代碼及受控位置。

一項工作一個work_item，以kind區分通報、支持、保護、教育等並行工作，不用案件單一「結案」取代各項完成。由負責者填stage、owner、decision_authority、legal_basis、deadline_ids、evidence_ids及next_step。completed必須能連到完成證明；支持服務declined不等於行為人不履行教育處置。

一名收件人、一個程序階段、一份核定版本各建立notice。寄出不代表合法送達；delivered須有送達日期、證明、依據及覆核者。deadlines另記起算事實、證明、期間單位與計算紀錄，沒有覆核不標verified；本工具不計算日期、不判斷實際法律效果。工作日、日曆日、月數不可換算成同一固定日數。

每一行為人各自建立education類work_item；同一人該次處置work_item的心理諮商與八小時課程分列assignment；已核定的兩項執行者不得相同。原輔導人員的優先續接須另外確認兩項條件。執行者索取額外案情以restricted_information_requests記性平會審酌、保密文件、核准範圍及提供證明；不能因專業資格而略過。

舊版欄位搬移前保留原紀錄與版本；本包只保留舊空白例示於legacy，沒有搬移或處理任何真實個案。

| 舊欄位 | 新欄位 |
|---|---|
| workstreams各分線 | work_items，各筆kind／stage／status／owner／evidence_ids |
| facts.outcome_service_records、outcome_notification、each_party_original_report_version | notices，依對象及文件階段分開 |
| deadlines | deadlines，增加notice_id及覆核紀錄 |
| new_procedure_records之簡化分流／轉軌 | investigation類work_item及decision_reference；條件另使用simplified-case格式，不重複存事實 |
| fieldwork_records之支持轉介、保護、教育執行 | 對應kind的work_items；教育執行者另education_assignments |
| fieldwork_records之會議出席與異議／陳核 | meeting_records、authority_objections，保留原始決議與版本 |
| interschool_followup、移轉、報核 | handoff或personnel類work_item，記接收確認及下一期限 |

`check_case_record.py`只檢查格式、代碼交互引用與少數狀態矛盾；沒有錯誤不代表資料真實、權限正確、期限合法或已符合全部法規。首次改用格式須人工核對，未知保持null或unknown。
