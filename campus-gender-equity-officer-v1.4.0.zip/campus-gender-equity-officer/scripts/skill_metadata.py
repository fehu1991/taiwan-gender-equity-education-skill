"""安全解析技能 YAML 前置資料；只供驗證工具使用，依賴 PyYAML。"""
from __future__ import annotations
import re
from pathlib import Path
from typing import Any

def parse_frontmatter(text: str) -> dict[str, Any]:
    try:
        import yaml
    except ImportError as exc:
        raise ValueError('完整驗證需 PyYAML；請安裝 requirements-validation.txt。') from exc
    match = re.match(r'\A---\r?\n(.*?)\r?\n---(?:\r?\n|\Z)', text, re.S)
    if not match:
        raise ValueError('SKILL.md 缺少完整 YAML 前置資料。')
    class UniqueSafeLoader(yaml.SafeLoader):
        pass
    def mapping(loader, node, deep=False):
        loader.flatten_mapping(node)
        result = {}
        for key_node, value_node in node.value:
            key = loader.construct_object(key_node, deep=deep)
            if not isinstance(key, str):
                raise ValueError('YAML 欄位名稱必須是字串。')
            if key in result:
                raise ValueError('YAML 重複欄位：'+key)
            result[key] = loader.construct_object(value_node, deep=deep)
        return result
    UniqueSafeLoader.add_constructor(yaml.resolver.BaseResolver.DEFAULT_MAPPING_TAG, mapping)
    try:
        data = yaml.load(match.group(1), Loader=UniqueSafeLoader)
    except yaml.YAMLError as exc:
        raise ValueError('YAML 前置資料無法安全解析：'+str(exc)) from exc
    if not isinstance(data, dict):
        raise ValueError('YAML 前置資料必須是對應表。')
    return data

def validate_metadata(text: str, version: str, folder_name: str) -> list[str]:
    data = parse_frontmatter(text)
    errors = []
    name = data.get('name')
    if not isinstance(name,str) or not re.fullmatch(r'[a-z0-9]+(?:-[a-z0-9]+)*',name) or len(name)>64 or name!=folder_name:
        errors.append('名稱格式或資料夾名稱不符。')
    description = data.get('description')
    if not isinstance(description,str) or not description.strip() or len(description)>1024:
        errors.append('description 必須是非空字串且不超過1024字元。')
    compatibility = data.get('compatibility')
    if not isinstance(compatibility,str) or not compatibility.strip() or len(compatibility)>500:
        errors.append('compatibility 應置於頂層，為非空字串且不超過500字元。')
    metadata = data.get('metadata')
    if not isinstance(metadata,dict):
        errors.append('metadata 必須是對應表。')
    else:
        if metadata.get('version') != version:
            errors.append('入口版本與 VERSION 不同；比對解析值，不比對引號樣式。')
        if 'compatibility' in metadata:
            errors.append('compatibility 不應重複放入 metadata。')
    return errors
