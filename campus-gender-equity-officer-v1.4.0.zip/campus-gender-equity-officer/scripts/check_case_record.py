#!/usr/bin/env python3
"""選用的去識別工作紀錄檢核；不判斷事實、送達效力或計算期限。"""
from __future__ import annotations
import argparse,json
from pathlib import Path
from typing import Any
ROOT=Path(__file__).resolve().parents[1]

def check(data: Any,root:Path=ROOT)->dict[str,Any]:
    errors=[];warnings=[]
    try:
        from jsonschema import Draft202012Validator, FormatChecker
    except ImportError as exc:
        raise ValueError('工作紀錄驗證需 jsonschema；請安裝 requirements-validation.txt。') from exc
    schema=json.loads((root/'assets/case-record.schema.json').read_text(encoding='utf-8'))
    for error in Draft202012Validator(schema, format_checker=FormatChecker()).iter_errors(data):
        errors.append('/'.join(str(x) for x in error.absolute_path)+': '+error.message)
    if errors:return {'passed':False,'errors':errors,'warnings':warnings,'legal_determination':False}
    groups=['source_documents','work_items','notices','deadlines','education_assignments','restricted_information_requests']
    maps={}
    for group in groups:
        maps[group]={}
        for item in data[group]:
            key=item['id']
            if key in maps[group]:errors.append(group+' 代碼重複：'+key)
            maps[group][key]=item
    def ref(group,key,where):
        if key is not None and key not in maps[group]:errors.append(where+' 引用不存在的 '+group+'：'+key)
    for w in data['work_items']:
        for key in w['deadline_ids']:ref('deadlines',key,w['id'])
        for key in w['evidence_ids']:ref('source_documents',key,w['id'])
        if w['status']=='completed' and not w['evidence_ids']:errors.append(w['id']+' 已完成卻沒有證明代碼。')
        if w['status']=='declined' and w['kind'] not in ('victim_support','other_party_support'):
            warnings.append(w['id']+' 拒絕狀態須人工辨認原因，不自動認定教育處置不履行。')
    for n in data['notices']:
        ref('deadlines',n['deadline_id'],n['id'])
        for key in n['attachment_ids']:ref('source_documents',key,n['id'])
        ref('source_documents',n['delivery_evidence_id'],n['id'])
        if n['status'] in ('approved','sent','delivered'):
            if not n['approval_reference']:errors.append(n['id']+' 缺核定出處。')
            if not n['document_version']:errors.append(n['id']+' 缺核定文件版本。')
        if n['status'] in ('sent','delivered') and not n['sent_at']:errors.append(n['id']+' 缺實際寄送時間。')
        if n['status']=='delivered':
            for key in ('delivery_date','delivery_evidence_id','delivery_legal_basis','delivery_verified_by'):
                if not n[key]:errors.append(n['id']+' 送達狀態缺少 '+key)
        if n['deadline_id'] is not None and n['deadline_id'] in maps['deadlines']:
            if maps['deadlines'][n['deadline_id']]['notice_id']!=n['id']:errors.append(n['id']+' 與期限紀錄的 notice_id 不一致。')
    for d in data['deadlines']:
        ref('notices',d['notice_id'],d['id']);ref('source_documents',d['trigger_evidence_id'],d['id'])
        if d['status'] in ('verified','expired','completed'):
            for key in ('trigger','trigger_evidence_id','legal_basis','unit','period_value','due_at','calculation_record','verified_by'):
                if not d[key]:errors.append(d['id']+' 已覆核期限缺少 '+key)
    by_work={}
    for a in data['education_assignments']:
        ref('work_items',a['work_item_id'],a['id'])
        work=maps['work_items'].get(a['work_item_id'])
        if work and work['kind']!='education':errors.append(a['id']+' 必須引用 education 工作。')
        if a['status'] in ('approved','active','completed'):
            if not a['executor_id'] or not a['decision_reference']:errors.append(a['id']+' 已核定執行缺人員或決議。')
            if a['measure'] in ('counseling','gender_course') and a['required_hours'] is None:errors.append(a['id']+' 缺具體時數。')
            if a['measure']=='gender_course' and a['required_hours']!=8:errors.append(a['id']+' gender_course 指法定八小時課程，其他教育措施須另分類與核對法源。')
            by_work.setdefault(a['work_item_id'],[]).append(a)
        if a['prior_counselor_priority'] is True and (a['measure']!='counseling' or a['acknowledged_conduct'] is not True or a['prior_gender_related_counseling'] is not True):
            errors.append(a['id']+' 原輔導人員優先續接的兩項條件未確認。')
    for wid,aa in by_work.items():
        counseling={a['executor_id'] for a in aa if a['measure']=='counseling' and a['executor_id']}
        course={a['executor_id'] for a in aa if a['measure']=='gender_course' and a['executor_id']}
        if counseling & course:errors.append(wid+' 諮商與八小時課程不可由同一人執行（OC2026-03）。')
    for i in data['restricted_information_requests']:
        for key in i['requested_document_ids']:ref('source_documents',key,i['id'])
        ref('source_documents',i['provided_evidence_id'],i['id'])
        if i['status'] in ('approved','provided'):
            for key in ('committee_review_reference','confidentiality_reference','approved_scope'):
                if not i[key]:errors.append(i['id']+' 額外事件資訊缺少 '+key)
        if i['status']=='provided' and not i['provided_evidence_id']:errors.append(i['id']+' 缺實際提供證明。')
    return {'passed':not errors,'errors':errors,'warnings':warnings,'legal_determination':False,
            'scope_note':'只核對結構、交互引用及特定紀錄矛盾；不是核准、案情認定、送達效力或完整法遵保證。'}

def main()->int:
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('input',type=Path);parser.add_argument('--root',type=Path,default=ROOT)
    args=parser.parse_args()
    try:
        if args.input.stat().st_size>1_000_000:raise ValueError('限1MB內的去識別工作條件，非卷證。')
        result=check(json.loads(args.input.read_text(encoding='utf-8')),args.root.resolve())
        print(json.dumps(result,ensure_ascii=False,indent=2));return 0 if result['passed'] else 1
    except (ValueError,OSError,KeyError,TypeError) as exc:
        print(json.dumps({'passed':False,'errors':[str(exc)]},ensure_ascii=False));return 2
if __name__=='__main__':raise SystemExit(main())
