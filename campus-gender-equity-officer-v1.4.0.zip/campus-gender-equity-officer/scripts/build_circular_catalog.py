#!/usr/bin/env python3
"""從有雜湊紀錄的來源重建函示索引；不更動原文、不自動判定函示現行效力。

Python 3.10+，僅使用標準函式庫。工作目錄可任意；預設以本腳本所在套件為根。
"""
from __future__ import annotations

import argparse
import hashlib
import json
import re
import unicodedata
from collections import Counter, defaultdict
from datetime import date
from pathlib import Path
from urllib.parse import quote
from typing import Any

ROOT = Path(__file__).resolve().parents[1]
REL = Path('sources/circulars')
TOPICS: dict[str, tuple[str, ...]] = {
    '簡化調查處理程序': ('簡化調查', '簡易程序', '不成立調查小組'),
    '普查與潛在被害人': ('普查', '潛在被害人', '問卷', '施測'),
    '職場與性騷法分流': ('職場', '性工法', '申調會', '性騷法', '共同調查'),
    '法規沿革與適用': ('停止適用', '修正', '施行前', '溯及', '實體從舊', '施行日期'),
    '身分與管轄': ('管轄', '所屬學校', '跨校', '外包', '實習生', '兼任', '學籍'),
    '通報與保護': ('通報', '保護令', '知悉', '社政', '法定責任'),
    '收件與受理': ('受理', '檢舉', '申請調查', '撤回', '程序審查', '切結'),
    '調查與證據': ('調查小組', '證據', '訪談', '事實認定', '錄音', '錄影', '新事證'),
    '會務與迴避': ('外聘', '委員會組成', '性別比例', '迴避', '派代表', '共識決'),
    '閱卷與保密': ('閱卷', '調閱', '保密', '知情範圍', '提供資料', '資訊公開'),
    '人事與議處': ('解聘', '停聘', '不續聘', '懲處', '議處', '退休', '軍訓教官', '情節重大'),
    '申復與救濟': ('申復', '申訴', '訴願', '救濟', '重為決定'),
    '教育處置與輔導': ('8小時', '八小時', '心理輔導', '心理諮商', '防治教育', '追蹤輔導'),
    '經費與行政支援': ('經費', '出席費', '稿費', '加班費', '公差', '涉訟', '聽打'),
    '年度業務與受教權': ('年度', '預算', '宣導', '懷孕', '生產', '課程', '聘約', '學則', '空間安全'),
}


def normalize(value: str) -> str:
    """僅建立搜尋鍵；不改寫原文、不校正錯字、不移除文號字尾。"""
    return re.sub(r'\s+', '', unicodedata.normalize('NFKC', value)).replace('台', '臺').upper()


def number_key(value: str) -> str:
    return re.sub(r'號(?:函|書函|令)?$', '號', normalize(value))


def serial(value: str) -> str | None:
    m = re.search(r'第([0-9]+[A-Z]?)號', number_key(value))
    return m.group(1) if m else None


def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def read_json(path: Path) -> Any:
    return json.loads(path.read_text(encoding='utf-8'))


def safe_path(root: Path, relative: str) -> Path:
    path = (root / relative).resolve()
    if not path.is_relative_to((root / REL).resolve()):
        raise ValueError(f'函示來源路徑越界：{relative}')
    return path


def source_text(root: Path, src: dict[str, Any]) -> str:
    path = safe_path(root, src['path'])
    data = path.read_bytes()
    if digest(data) != src['sha256']:
        raise ValueError(f'來源SHA-256不符：{src["source_id"]}；先核對來源及更新紀錄，勿略過檢查。')
    return data.decode('utf-8')


def metadata(block: str, label: str) -> str | None:
    m = re.search(r'^-\s*' + re.escape(label) + r'[：:]\s*(.*?)\s*$', block, re.M)
    return m.group(1) if m else None


def classify(block: str, subject: str) -> list[dict[str, Any]]:
    # 對來源中實際出現的字詞加標籤，不宣稱人工逐件法律分類。
    b, s = normalize(block), normalize(subject)
    found = []
    for topic, terms in TOPICS.items():
        hits = [word for word in terms if normalize(word) in b]
        if hits:
            title_hits = [word for word in hits if normalize(word) in s]
            found.append({'topic': topic, 'matched_terms': hits,
                          'subject_matched_terms': title_hits,
                          'method': 'keyword_routing_not_legal_assessment'})
    return sorted(found, key=lambda d: (-len(d['subject_matched_terms']), d['topic']))


def parse_source(src: dict[str, Any], text: str) -> list[dict[str, Any]]:
    lines = text.splitlines(keepends=True)
    if src['origin'] == 'user_uploaded_transcription':
        starts = [i for i, line in enumerate(lines) if re.match(r'^##\s+[^\n]*字第[0-9]+[A-Z]?號\s*$', line)]
    else:
        starts = [0]  # 外部查閱摘要的二級標題不是新的函件。
    records = []
    for pos, start in enumerate(starts):
        end = starts[pos + 1] if pos + 1 < len(starts) else len(lines)
        block = ''.join(lines[start:end])
        num = metadata(block, '發文字號') or src.get('document_number')
        issued = metadata(block, '發文日期') or src.get('date')
        subject = metadata(block, '主旨') or ''
        if not num or not issued:
            raise ValueError(f'{src["source_id"]}:{start + 1} 缺少文號或日期。')
        issued_raw = issued
        try:
            date.fromisoformat(issued)
        except ValueError:
            issued = None  # 日期未擷取或格式不明：保留原欄位，不從年度／文號推造。
        record_id = (f'C{src["year"]}-{pos+1:03d}'
                     if src['origin'] == 'user_uploaded_transcription' else src['source_id'])
        records.append({
            'record_id': record_id, 'source_id': src['source_id'], 'source_path': src['path'],
            'source_year': src['year'], 'publication_date': issued, 'publication_date_raw': issued_raw,
            'document_number': num, 'number_key': number_key(num), 'serial': serial(num),
            'subject_raw': subject, 'source_line_start': start + 1, 'source_line_end': end,
            'text_sha256': digest(block.encode('utf-8')),
            'content_kind': src['origin'],
            'representation': src.get('record_overrides', {}).get(serial(num),
                'external_reading_summary' if src['origin'] != 'user_uploaded_transcription' else 'source_transcription_not_authenticated_full_original'),
            'same_document_record_ids': [],
            'issuer': src.get('issuer'),
            'issuer_note': ('外部查閱已核對發文機關。' if src.get('issuer') else
                           '未另核對；不得將正文引述機關或文號前綴當成已驗證發文機關。'),
            'raw_text': block,
            'topics': classify(block, subject),
            'current_effect_review': 'not_exhaustively_verified',
            'current_effect_note': '收錄、查無停止適用紀錄及檢索排名，均不等於現行有效；須併讀已整理關係及適用時法。',
            'known_relation_ids': [], 'quality_issue_ids': [],
            'official_urls': src.get('urls', []),
            'effective_date': None,
            'effective_date_note': '發文日期不自動充作施行或停止適用日期；另見逐項關係紀錄。',
        })
    if len(records) != src['entry_count']:
        raise ValueError(f'{src["source_id"]} 條目數與manifest不符。')
    return records


def evidence_location(record: dict[str, Any], anchor: str) -> dict[str, Any]:
    block = record['raw_text']
    offset = block.find(anchor)
    if offset < 0:
        raise ValueError(f'證據錨點不存在：{record["record_id"]} / {anchor[:60]}')
    start = record['source_line_start'] + block[:offset].count('\n')
    return {'record_id': record['record_id'], 'source_path': record['source_path'],
            'line_start': start, 'line_end': start + anchor.count('\n'), 'exact_text': anchor,
            'content_kind': record['content_kind']}


def build(root: Path = ROOT, write: bool = True) -> dict[str, Any]:
    manifest = read_json(root / REL / 'manifest.json')
    sources = manifest['sources']
    records = [r for src in sources for r in parse_source(src, source_text(root, src))]
    lookup: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for record in records:
        lookup[record['number_key']].append(record)
    by_id = {r['record_id']: r for r in records}
    if len(by_id) != len(records):
        raise ValueError('條目代碼重複。')
    definitions = read_json(root / REL / 'relation-definitions.json')
    relations = []
    for row in definitions['relations']:
        row = dict(row)
        origin_records = lookup.get(number_key(row['from_number']), [])
        if row.get('from_record_id'):
            origin_records = [r for r in origin_records if r['record_id'] == row['from_record_id']]
        if len(origin_records) != 1:
            raise ValueError(f'關係來源不存在或不唯一：{row["from_number"]}')
        origin = origin_records[0]
        row['from_record_id'] = origin['record_id']
        row['announced_on'] = origin['publication_date']
        targets = lookup.get(number_key(row['to_number']), [])
        row['to_record_ids'] = [t['record_id'] for t in targets]
        row['target_presence'] = 'indexed_primary_entry' if targets else 'reference_only_no_primary_text'
        row['evidence'] = evidence_location(origin, row.pop('evidence_anchor'))
        row['official_urls'] = origin['official_urls']
        if row.get('effective_on'):
            date.fromisoformat(row['effective_on'])
        relations.append(row)
        for representation in lookup[origin['number_key']]:
            representation['known_relation_ids'].append(row['relation_id'])
        for target in targets:
            target['known_relation_ids'].append(row['relation_id'])

    quality_defs = read_json(root / REL / 'quality-definitions.json')
    issues = []
    for spec in quality_defs['issues']:
        issue = dict(spec)
        matched = lookup.get(number_key(issue.pop('document_number')), [])
        if issue.get('record_id'):
            selected_id = issue.pop('record_id')
            matched = [r for r in matched if r['record_id'] == selected_id]
        if not matched:
            raise ValueError(f'品質項目找不到主文號：{issue["issue_id"]}')
        issue['record_ids'] = [r['record_id'] for r in matched]
        issue['evidence'] = [evidence_location(r, issue['evidence_anchor']) for r in matched]
        issue.pop('evidence_anchor')
        issues.append(issue)
        for r in matched:
            r['quality_issue_ids'].append(issue['issue_id'])
    for record in records:
        record['same_document_record_ids'] = [r['record_id'] for r in lookup[record['number_key']] if r['record_id'] != record['record_id']]
    duplicates = {k: [r['record_id'] for r in rr] for k, rr in lookup.items() if len(rr) > 1}
    for i, (key, rr) in enumerate(sorted(duplicates.items()), 1):
        # 比較去除空白的區塊；原始區塊雜湊與來源位置仍個別保存。
        equivalent = len({normalize(by_id[r]['raw_text']) for r in rr}) == 1
        iid = f'QDUP-{i:03d}'
        issue = {'issue_id': iid, 'kind': ('duplicate_primary_document_number' if all(by_id[r]['content_kind']=='user_uploaded_transcription' for r in rr) else 'multiple_representations_of_same_document'),
                 'record_ids': rr, 'same_normalized_text': equivalent,
                 'finding': '同一主文號有多個來源位置；保留全部，不能算成不同函件。',
                 'handling': '精確文號檢索回傳全部條目；正式引用選定來源位置。'}
        issues.append(issue)
        for r in rr:
            by_id[r]['quality_issue_ids'].append(iid)

    # 單純引用只能產生候選連結，絕不自動判斷取代、停止適用或相互矛盾。
    candidates = []
    for record in records:
        norm_text = normalize(record['raw_text'])
        for key, targets in lookup.items():
            if key != record['number_key'] and key in norm_text:
                candidates.append({'from_record_id': record['record_id'],
                                   'to_record_ids': [t['record_id'] for t in targets],
                                   'relation': 'text_mentions_only',
                                   'legal_effect': 'not_inferred'})
    upload_records = [r for r in records if r['content_kind'] == 'user_uploaded_transcription']
    stats = {
        'uploaded_annual_file_count': sum(s['origin'] == 'user_uploaded_transcription' for s in sources),
        'uploaded_primary_entry_count': len(upload_records),
        'catalog_summary_only_count': sum(r['representation']=='catalog_summary_only' for r in upload_records),
        'uploaded_unique_main_number_count': len({r['number_key'] for r in upload_records}),
        'external_official_reading_note_count': len(records) - len(upload_records),
        'total_indexed_records': len(records), 'unknown_publication_date_count': sum(r['publication_date'] is None for r in records), 'curated_relation_count': len(relations),
        'candidate_text_link_count': len(candidates), 'curated_or_duplicate_quality_issue_count': len(issues),
        'year_counts': dict(sorted(Counter(str(r['source_year']) for r in records).items())),
        'missing_uploaded_years': manifest['missing_uploaded_years'],
        'complete_official_collection': False,
    }
    catalog = {'schema_version': '1.1.0', 'package_version': manifest['package_version'],
               'manifest_sha256': digest((root / REL / 'manifest.json').read_bytes()),
               'relations_source_sha256': digest((root / REL / 'relation-definitions.json').read_bytes()),
               'quality_source_sha256': digest((root / REL / 'quality-definitions.json').read_bytes()),
               'coverage_note': manifest['coverage_note'], 'statistics': stats,
               'topic_labels_are_heuristic': True, 'records': records}
    products = {'catalog.json': catalog,
                'relations.json': {'relations': relations, 'text_reference_candidates': candidates,
                                   'note': '已整理關係與純文字引用分開；未標註者不代表現行有效。'},
                'quality-issues.json': {'issues': issues,
                                       'note': '已發現的問題，不是所有轉錄錯誤之完整清單。'}}
    if write:
        for filename, data in products.items():
            (root / REL / filename).write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
        md = ['# 函示索引', '', manifest['coverage_note'], '',
              '主文號按原稿保留；主旨為原稿欄位，可能含排版或轉錄瑕疵。主題標籤只供導引。', '',
              '| 條目 | 發文日期 | 主文號 | 主旨／摘要標籤 | 來源位置 |',
              '|---|---|---|---|---|']
        for r in records:
            relative = r['source_path'].removeprefix(str(REL) + '/')
            label = r['subject_raw'].replace('|', '／').replace('\n', ' ')
            md.append(f'| {r["record_id"]} | {r["publication_date"] or r["publication_date_raw"]} | {r["document_number"]} | {label} | '
                      f'[{r["source_id"]}]({quote(relative, safe="/")}) 第{r["source_line_start"]}–{r["source_line_end"]}行 |')
        (root / REL / 'catalog.md').write_text('\n'.join(md) + '\n', encoding='utf-8')
    return products


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, default=ROOT)
    args = parser.parse_args()
    try:
        products = build(args.root.resolve())
    except (ValueError, OSError, KeyError, TypeError) as exc:
        parser.exit(2, f'索引建立失敗：{exc}\n')
    print(json.dumps(products['catalog.json']['statistics'], ensure_ascii=False, indent=2))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
