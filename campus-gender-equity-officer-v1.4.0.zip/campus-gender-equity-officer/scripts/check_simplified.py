#!/usr/bin/env python3
"""簡化程序行政條件檢核：不認定案件、不代替性平會、不自動起算期限。"""
from __future__ import annotations
import argparse
import hashlib
import json
import re
import sys
from datetime import date
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[1]
POLICY_START = date(2026, 8, 1)
BOOL_FIELDS = ('is_campus_event', 'actor_is_student', 'actor_has_mandatory_staff_role',
               'existing_evidence_sufficient', 'no_interview_needed', 'defense_information_adequate', 'actor_knows_or_can_know_source_identity_and_reason',
               'applicant_or_victim_requests_group', 'facts_unresolved_after_statements',
               'reinvestigation_after_remedy', 'respondent_requests_group',
               'committee_decision_to_simplify', 'statement_opportunity_given', 'statement_materials_ready')
STAGES = ('intake', 'notice_and_statements', 'after_statements')
ALLOWED = set(BOOL_FIELDS) | {'reported_on', 'committee_resolution_reference', 'stage'}


def verify_sources(root: Path = ROOT) -> None:
    """核對PDF與函發查閱摘要；來源內容正確性與適用時法仍由使用者審核。"""
    m = json.loads((root/'sources/procedures/manifest.json').read_text(encoding='utf-8'))
    path = (root/m['path']).resolve()
    if not path.is_relative_to((root/'sources/procedures').resolve()):
        raise ValueError('程序來源路徑越界。')
    if hashlib.sha256(path.read_bytes()).hexdigest() != m['sha256']:
        raise ValueError('原PDF完整性不符，不繼續檢核。')
    from build_circular_catalog import source_text
    cm = json.loads((root/'sources/circulars/manifest.json').read_text(encoding='utf-8'))
    source = next((s for s in cm['sources'] if s['source_id']=='OC2026-01'), None)
    if source is None:
        raise ValueError('缺少通報日期適用範圍之查閱來源。')
    source_text(root, source)


def check(data: dict[str, Any]) -> dict[str, Any]:
    """只依已輸入條件分流。未知不當成否；不接收自由案情供機器推斷。"""
    if not isinstance(data, dict):
        raise ValueError('輸入必須是JSON物件。')
    unknown = set(data) - ALLOWED
    if unknown:
        raise ValueError('未知欄位：'+', '.join(sorted(unknown)))
    for field in BOOL_FIELDS:
        if data.get(field) is not None and type(data[field]) is not bool:
            raise ValueError(field+'必須是true、false或null，不能以文字或數字替代。')
    stage = data.get('stage')
    if stage is not None and (not isinstance(stage,str) or stage not in STAGES):
        raise ValueError('stage 須為 intake、notice_and_statements、after_statements 或 null。')
    if stage in ('intake','notice_and_statements') and data.get('facts_unresolved_after_statements') is not None:
        raise ValueError('尚未完成雙方陳述答辯，facts_unresolved_after_statements 應保留 null，不能預填結果。')
    if stage=='intake' and (data.get('committee_decision_to_simplify') is True or data.get('statement_opportunity_given') is True or data.get('statement_materials_ready') is True):
        raise ValueError('intake 與已決議／已完成陳述的紀錄不一致；請依實際進度更正階段。')
    report_date = data.get('reported_on')
    if report_date is not None:
        if not isinstance(report_date, str) or not re.fullmatch(r'\d{4}-\d{2}-\d{2}', report_date):
            raise ValueError('reported_on須為YYYY-MM-DD或null。')
        report_date = date.fromisoformat(report_date)
    resolution = data.get('committee_resolution_reference')
    if resolution is not None and (not isinstance(resolution, str) or not resolution.strip() or len(resolution)>300):
        raise ValueError('決議出處應為非空字串（不超過300字）或null。')
    if data.get('committee_decision_to_simplify') is True and not resolution:
        raise ValueError('標記已有簡化決議時須附正式決議出處，不得推定已核准。')
    basis = ['SP2026-01第3–5頁、附錄1', 'OC2026-01（1152803124號函主旨）']
    result: dict[str, Any] = {'tool_version':'1.4.0', 'stage':stage, 'status':None, 'reason':None,
        'source_basis':basis, 'unknown_fields':[], 'not_yet_applicable_fields':(['facts_unresolved_after_statements'] if stage in ('intake','notice_and_statements') else []), 'determines_facts':False,
        'automatic_approval':False, 'calculates_legal_deadline':False, 'external_action_taken':False,
        'scope_note':'只檢核提供的行政條件；不核定資格、認定屬實或取代性平會。重複通報等特殊時點須另核。'}
    def finish(status: str, reason: str) -> dict[str, Any]:
        result.update(status=status, reason=reason); return result
    if data.get('is_campus_event') is False:
        return finish('other_legal_route','不是性平法校園事件，不直接套用本簡化程序。')
    if data.get('actor_has_mandatory_staff_role') is True:
        return finish('mandatory_investigation_group','已確認本案行為人具依法須成立調查小組之教職員工等身分；依第33條第2項但書辦理，不能只取學生學籍。')
    if data.get('actor_is_student') is False:
        return finish('outside_student_policy','本新制以學生行為人為範圍；另查適用身分程序。')
    if report_date is not None and report_date < POLICY_START:
        return finish('historical_route_review','通報早於2026-08-01，不逕依1152803124號函採新制；不等於歷史不成立小組程序一律違法。')
    for field, reason in [
        ('applicant_or_victim_requests_group','申請人或被害人已主張成立調查小組，依附件參二應成立。'),
        ('facts_unresolved_after_statements','雙方陳述答辯後仍無法認定事實情節，依附件參二應成立調查小組。'),
        ('reinvestigation_after_remedy','已確認符合附件參五的救濟後重新調查情形，應成立調查小組。')]:
        if data.get(field) is True:
            return finish('investigation_group_required', reason)
    if data.get('existing_evidence_sufficient') is False or data.get('no_interview_needed') is False:
        return finish('ordinary_investigation_route','既有事證或無須訪談條件不具備，不以簡化程序代替所需調查。')
    needed=['is_campus_event','actor_is_student','actor_has_mandatory_staff_role','existing_evidence_sufficient',
            'no_interview_needed','defense_information_adequate', 'actor_knows_or_can_know_source_identity_and_reason','applicant_or_victim_requests_group',
            'reinvestigation_after_remedy','respondent_requests_group','stage']
    if stage=='after_statements':
        needed.append('facts_unresolved_after_statements')
    result['unknown_fields']=[f for f in needed if data.get(f) is None]
    if report_date is None: result['unknown_fields'].insert(0,'reported_on')
    if result['unknown_fields']:
        return finish('needs_verified_information','關鍵條件尚未確認，列明缺口；不把未知當作否或自行認定案情。')
    if data['defense_information_adequate'] is False or data['actor_knows_or_can_know_source_identity_and_reason'] is False:
        return finish('needs_procedural_correction','尚不符合疑似行為人知悉或可得知悉提出方身分及調查事由、充分答辯之條件；先處理程序缺口，必要時由性平會改採小組調查。')
    if data['respondent_requests_group'] is True:
        return finish('committee_review_of_respondent_objection','記錄行為人之程序與事證疑義交性平會審酌；原文件未賦予同等自動否決權，也不得忽略其意見。')
    if stage=='intake':
        return finish('submit_to_committee_for_triage','已記錄入口條件，仍須性平會受理及分流決定；本結果不是採簡化之核准。')
    if data.get('committee_decision_to_simplify') is not True:
        result['unknown_fields']=['committee_decision_to_simplify']
        return finish('needs_verified_information','後續階段須核對正式分流決議，不以階段名稱推定已核准。')
    if stage=='notice_and_statements':
        return finish('await_statement_procedure','依正式決議完成雙方通知、陳述答辯及材料整理；完成後才改為 after_statements，不預先判斷事實。')
    if data.get('statement_opportunity_given') is not True or data.get('statement_materials_ready') is not True:
        return finish('await_statement_procedure','已提供決議出處，仍須完成雙方通知與陳述答辯程序、材料備齊；期限不由本工具創設。')
    return finish('submit_report_for_committee_review','材料可提性平會審議並提出調查報告；未認定事件屬實或議處，後續通知救濟不能省略。')


def main() -> int:
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('input',type=Path,help='僅含條件欄位之JSON，格式見assets/simplified-case.example.json')
    parser.add_argument('--root',type=Path,default=ROOT)
    args=parser.parse_args()
    try:
        verify_sources(args.root.resolve())
        if args.input.stat().st_size>100_000: raise ValueError('輸入超過100KB；此工具不接收原始案情或卷證。')
        data=json.loads(args.input.read_text(encoding='utf-8'))
        print(json.dumps(check(data),ensure_ascii=False,indent=2))
        return 0
    except (ValueError, OSError, KeyError, TypeError) as exc:
        print('檢核失敗：'+str(exc),file=sys.stderr);return 2

if __name__=='__main__':
    raise SystemExit(main())
