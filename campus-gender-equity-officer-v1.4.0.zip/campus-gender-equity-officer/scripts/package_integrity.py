#!/usr/bin/env python3
"""明確建立或唯讀驗證發布清冊；驗證絕不自動回填雜湊。"""
from __future__ import annotations
import argparse
import hashlib
import json
from pathlib import Path, PurePosixPath
from typing import Any
ROOT = Path(__file__).resolve().parents[1]
MANIFEST = 'PACKAGE-FILES.json'
IGNORED_DIRS = {'__pycache__','.pytest_cache','.mypy_cache','.ruff_cache','.git'}

def paths(root: Path) -> dict[str,Path]:
    result = {}
    for p in root.rglob('*'):
        rel = p.relative_to(root)
        if any(part in IGNORED_DIRS for part in rel.parts) or p.suffix in {'.pyc','.pyo'}:
            continue
        if p.is_symlink():
            raise ValueError('發布包不接受符號連結：'+rel.as_posix())
        if p.is_file() and rel.as_posix()!=MANIFEST:
            result[rel.as_posix()]=p
    return result

def safe_path(root:Path,rel:Any) -> Path:
    if not isinstance(rel,str) or not rel or '\\' in rel or ':' in rel:
        raise ValueError('清冊路徑格式錯誤。')
    pp=PurePosixPath(rel)
    if pp.is_absolute() or '..' in pp.parts or str(pp)!=rel or rel==MANIFEST:
        raise ValueError('清冊路徑不可越界、重複分隔或包含清冊本身：'+rel)
    p=root.joinpath(*pp.parts)
    if not p.resolve().is_relative_to(root.resolve()):
        raise ValueError('清冊路徑越界：'+rel)
    return p

def build_manifest(root:Path=ROOT) -> dict[str,Any]:
    root=root.resolve()
    version=(root/'VERSION').read_text(encoding='utf-8').strip()
    records=[]
    for rel,p in sorted(paths(root).items()):
        data=p.read_bytes()
        records.append({'path':rel,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
    return {'version':version,'scope':'All distributable files except this manifest itself; excludes documented runtime caches. Not a digital signature.','files':records}

def verify_manifest(root:Path=ROOT) -> dict[str,Any]:
    root=root.resolve(); errors=[]; checked=0
    try:
        obj=json.loads((root/MANIFEST).read_text(encoding='utf-8'))
        if obj.get('version')!=(root/'VERSION').read_text(encoding='utf-8').strip():
            errors.append('清冊版本與 VERSION 不符。')
        actual=paths(root); seen=set()
        if not isinstance(obj.get('files'),list):raise ValueError('清冊 files 必須是陣列。')
        for rec in obj['files']:
            if not isinstance(rec,dict):raise ValueError('清冊項目必須是物件。')
            rel=rec.get('path');p=safe_path(root,rel)
            if rel in seen:
                errors.append('清冊重複路徑：'+rel);continue
            seen.add(rel)
            if rel not in actual:
                errors.append('檔案缺漏或列入排除項目：'+rel);continue
            data=p.read_bytes();checked+=1
            if type(rec.get('bytes')) is not int or rec['bytes']!=len(data):errors.append('檔案大小不符：'+rel)
            if rec.get('sha256')!=hashlib.sha256(data).hexdigest():errors.append('SHA-256 不符：'+rel)
        for rel in sorted(set(actual)-seen):errors.append('未列入清冊的檔案：'+rel)
    except (OSError,ValueError,KeyError,TypeError) as exc:
        errors.append(str(exc))
    return {'passed':not errors,'checked_file_count':checked,'errors':errors,
            'scope_note':'檔案完整性與版本一致性；不是數位簽章、法律適用判斷或模型驗收。'}

def main()->int:
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action',choices=['verify','build'])
    parser.add_argument('--root',type=Path,default=ROOT)
    args=parser.parse_args()
    try:
        if args.action=='build':
            result=build_manifest(args.root)
            (args.root/MANIFEST).write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
            print(json.dumps({'manifest_written':str(args.root/MANIFEST),'file_count':len(result['files'])},ensure_ascii=False));return 0
        result=verify_manifest(args.root);print(json.dumps(result,ensure_ascii=False,indent=2));return 0 if result['passed'] else 1
    except (OSError,ValueError,TypeError) as exc:
        print(json.dumps({'passed':False,'errors':[str(exc)]},ensure_ascii=False));return 2
if __name__=='__main__':raise SystemExit(main())
