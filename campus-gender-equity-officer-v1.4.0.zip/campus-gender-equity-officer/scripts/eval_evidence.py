#!/usr/bin/env python3
"""產生對照評測工作表或檢查回填證據；不連接模型，也不自動評斷答案正確。"""
from __future__ import annotations
import argparse,hashlib,json
from pathlib import Path
from typing import Any
ROOT=Path(__file__).resolve().parents[1]
FILES=('scenarios.json','circular-scenarios.json','latest-and-simplified-scenarios.json','fieldwork-scenarios.json')

def specs(root:Path=ROOT)->dict[str,dict]:
    cases={}
    for name in FILES:
        for c in json.loads((root/'evals'/name).read_text(encoding='utf-8'))['scenarios']:
            if c['id'] in cases:raise ValueError('重複情境：'+c['id'])
            cases[c['id']]=c
    return cases

def rubric(c:dict)->list[dict]:
    rows=[]
    for kind in ('expected','must_not'):
        entries=c[kind] if isinstance(c[kind],list) else [c[kind]]
        for n,item in enumerate(entries,1):
            rows.append({'criterion_id':f'{kind}-{n}','kind':kind,'criterion':item,'satisfied':None,'evidence_excerpt':None,'review_note':None})
    return rows

def prepare(root:Path=ROOT)->dict[str,Any]:
    suite=json.loads((root/'evals/priority-suite.json').read_text(encoding='utf-8'));cases=specs(root);runs=[]
    for sid in suite['scenario_ids']:
        c=cases[sid]
        for arm in suite['arms']:
            runs.append({'scenario_id':sid,'arm':arm,'run_status':'not_run','platform':None,'model':None,'model_settings':{},'started_at':None,'finished_at':None,'input':c['input'],'complete_output':None,'skill_selected':None,'read_trace':None,'trace_observability':'unknown','trace_limitation':None,'reviewer':None,'rubric':rubric(c),'fatal_errors_found':[],'synthetic_output':False,'review_verdict':None})
    return {'suite_id':suite['suite_id'],'package_version':(root/'VERSION').read_text().strip(),'skill_sha256':hashlib.sha256((root/'SKILL.md').read_bytes()).hexdigest(),'specification_sha256':spec_hash(root),'package_content_sha256':content_hash(root),'tool_did_not_call_model':True,'runs':runs}

def content_hash(root:Path)->str:
    from package_integrity import build_manifest
    data=json.dumps(build_manifest(root),ensure_ascii=False,sort_keys=True,separators=(',',':')).encode('utf-8')
    return hashlib.sha256(data).hexdigest()

def spec_hash(root:Path)->str:
    b=b''.join((root/'evals'/name).read_bytes() for name in FILES)
    return hashlib.sha256(b).hexdigest()

def validate_evidence(obj:Any,root:Path=ROOT)->dict[str,Any]:
    errors=[];completed=0;passed=0;cases=specs(root)
    if not isinstance(obj,dict):return {'passed':False,'errors':['輸入必須是物件。']}
    if obj.get('package_version')!=(root/'VERSION').read_text().strip():errors.append('套件版本不符。')
    if obj.get('skill_sha256')!=hashlib.sha256((root/'SKILL.md').read_bytes()).hexdigest():errors.append('入口檔雜湊不符。')
    if obj.get('specification_sha256')!=spec_hash(root):errors.append('情境規格雜湊不符。')
    if obj.get('package_content_sha256')!=content_hash(root):errors.append('套件檔案集合或內容改變，不能視為同一受控版本。')
    if not isinstance(obj.get('runs'),list):return {'passed':False,'errors':errors+['runs 必須是陣列。']}
    suite=json.loads((root/'evals/priority-suite.json').read_text(encoding='utf-8'))
    expected_keys={(sid,arm) for sid in suite['scenario_ids'] for arm in suite['arms']};seen=set()
    for r in obj['runs']:
        if not isinstance(r,dict):errors.append('run 必須是物件。');continue
        sid=r.get('scenario_id');arm=r.get('arm');key=(sid,arm);tag=f'{sid}/{arm}'
        if key in seen:errors.append(tag+' 重複紀錄。')
        seen.add(key)
        if key not in expected_keys:errors.append(tag+' 不屬本優先對照組。');continue
        if r.get('input')!=cases[sid]['input']:errors.append(tag+' 輸入與受控規格不同。')
        if r.get('run_status')=='not_run':
            if r.get('complete_output') or r.get('review_verdict'):errors.append(tag+' 未執行狀態不可宣稱已有答案或評分。')
            continue
        if r.get('run_status')!='completed':errors.append(tag+' 未知執行狀態。');continue
        completed+=1
        if r.get('synthetic_output') is not False:errors.append(tag+' 合成／模擬答案不能當成實際模型執行。')
        for k in ('platform','model','started_at','finished_at','complete_output','reviewer'):
            if not isinstance(r.get(k),str) or not r[k].strip():errors.append(tag+' 缺少 '+k)
        if not isinstance(r.get('model_settings'),dict) or not r['model_settings']:errors.append(tag+' 缺模型設定；預設也須明示。')
        if r.get('trace_observability')=='available':
            if not isinstance(r.get('read_trace'),list) or not r['read_trace']:errors.append(tag+' 缺可取得的讀取／選用軌跡。')
        elif r.get('trace_observability')=='unavailable':
            if not r.get('trace_limitation'):errors.append(tag+' 須說明無法觀測之範圍。')
        else:errors.append(tag+' 須標示軌跡是否可觀測。')
        if arm=='forced_skill' and r.get('skill_selected') is not True:errors.append(tag+' 指定條件未確認載入。')
        if arm=='baseline_no_skill' and r.get('skill_selected') is not False:errors.append(tag+' 基準條件須確認未使用本技能。')
        actual=r.get('rubric');desired=rubric(cases[sid])
        if not isinstance(actual,list) or len(actual)!=len(desired):errors.append(tag+' 評分項目數不符。');continue
        all_satisfied=True
        for a,d in zip(actual,desired):
            if not isinstance(a,dict):errors.append(tag+' 評分項目不是物件。');all_satisfied=False;continue
            for k in ('criterion_id','kind','criterion'):
                if a.get(k)!=d[k]:errors.append(tag+' 擅改驗收條件。')
            if type(a.get('satisfied')) is not bool:errors.append(tag+' 缺逐條評分。')
            if a.get('satisfied') is not True:all_satisfied=False
            if not (a.get('evidence_excerpt') or a.get('review_note')):errors.append(tag+' 缺逐條證據或評閱說明。')
        fatal=r.get('fatal_errors_found')
        if not isinstance(fatal,list):errors.append(tag+' 缺重大錯誤欄位。')
        verdict=r.get('review_verdict')
        if verdict not in ('pass','fail'):errors.append(tag+' 缺人工評閱結論。')
        if verdict=='pass':
            if not all_satisfied or fatal:errors.append(tag+' 有未通過條件或重大錯誤，不得標示通過。')
            else:passed+=1
    if seen!=expected_keys:errors.append('未保留完整15題×3條件；未跑條件應保留 not_run，不能刪除。')
    return {'passed':not errors,'completed_model_runs_recorded':completed,'human_pass_verdicts_recorded':passed,'pending_model_runs':len(expected_keys)-completed,'errors':errors,'scope_note':'僅核對證據欄位與結論一致性；不驗證輸出真實性、不代替法律評閱、不證明自動選用有效。'}

def main()->int:
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('action',choices=['prepare','validate']);p.add_argument('file',type=Path);p.add_argument('--root',type=Path,default=ROOT)
    a=p.parse_args()
    try:
        if a.action=='prepare':
            # Never overwrite a result or write to the sealed package by default.
            with a.file.open('x',encoding='utf-8') as f:json.dump(prepare(a.root),f,ensure_ascii=False,indent=2);f.write('\n')
            print('已建立45筆未執行工作表；未呼叫模型。');return 0
        if a.file.stat().st_size>10_000_000:raise ValueError('評測紀錄上限10MB。')
        r=validate_evidence(json.loads(a.file.read_text(encoding='utf-8')),a.root);print(json.dumps(r,ensure_ascii=False,indent=2));return 0 if r['passed'] else 1
    except (OSError,ValueError,TypeError,KeyError) as exc:print(json.dumps({'passed':False,'errors':[str(exc)]},ensure_ascii=False));return 2
if __name__=='__main__':raise SystemExit(main())
