"""資料／分流函式測試，情境為合成資料；不評測模型或判斷法律事實。"""
from __future__ import annotations
import json
import hashlib
import shutil
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'scripts'))
from lookup_circular import CircularCatalog
from build_circular_catalog import build, parse_source
from check_simplified import check, verify_sources, BOOL_FIELDS


def fixture():
    d={k:False for k in BOOL_FIELDS}
    d.update(stage='intake',facts_unresolved_after_statements=None,reported_on='2026-08-01',is_campus_event=True,actor_is_student=True,
             existing_evidence_sufficient=True,no_interview_needed=True,defense_information_adequate=True,
             actor_knows_or_can_know_source_identity_and_reason=True,committee_resolution_reference=None)
    return d

class LatestSourcesTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):cls.db=CircularCatalog(ROOT)
    def test_new_annual_counts(self):
        for y,n in [(2024,14),(2025,10),(2026,6)]:
            rr=[r for r in self.db.records if r['source_year']==y and r['content_kind']=='user_uploaded_transcription']
            self.assertEqual(len(rr),n)
    def test_nested_summary_headings_not_split(self):
        for rid in ['C2024-007','C2025-002','C2025-008']:
            r=self.db.query(record_id=rid)['records'][0]
            self.assertIn('## 來源摘錄整理',r['raw_text'])
            self.assertEqual(r['representation'],'catalog_summary_only')
        self.assertTrue(all(r['document_number']!='來源摘錄整理' for r in self.db.records))
    def test_all_unknown_dates_remain_null(self):
        nums={'1100082461B','1132802191','1132803074','1142803509'}
        self.assertEqual({r['serial'] for r in self.db.records if r['publication_date'] is None},nums)
    def test_cutoff_counts_only_query_undated(self):
        q=self.db.query(year=2024,as_of='2026-09-06')
        self.assertEqual(q['undated_records_excluded'],2)
        self.assertEqual(set(q['undated_record_ids_excluded']),{'C2024-013','C2024-014'})
    def test_full_suffix_identity_maintained(self):
        self.assertEqual(self.db.query(number='1142803509')['records'][0]['record_id'],'C2025-010')
        self.assertEqual(self.db.query(number='1142803509A')['records'][0]['record_id'],'C2025-008')
    def test_old_notes_not_replaced(self):
        q=self.db.query(number='1130037236')
        self.assertEqual({r['record_id'] for r in q['records']},{'OC2024-01','C2024-003'})
        for r in q['records']:self.assertEqual(len(r['same_document_record_ids']),1)
    def test_relation_propagates_between_representations(self):
        q=self.db.query(number='1130037236')
        for r in q['records']:
            self.assertTrue(any(l['from_record_id']=='C2026-001' for l in r['known_relations']))
    def test_new_letter_ceases_three_old_letters(self):
        for n in ['1020165630','1000170857B','1000203271']:
            q=self.db.query(number=n)
            links=q['records'][0]['known_relations'] if q['records'] else q['reference_only']
            self.assertTrue(any(l['from_record_id']=='C2025-001' and l['effective_on']=='2025-01-09' and l['relation_type']=='ceases_entire_letter' for l in links))
    def test_old_notice_only_partly_modified(self):
        r=self.db.query(number='1020080238')['records'][0]
        self.assertEqual(r['retrieval_use_status'],'has_partial_change_evidence')
        self.assertTrue(any(l['from_record_id']=='C2026-005' for l in r['known_relations']))
    def test_military_attachment_not_whole_cessation(self):
        rr=self.db.query(number='1100031108')['records'][0]
        self.assertEqual(rr['retrieval_use_status'],'has_partial_change_evidence')
    def test_2026_external_notes_separate(self):
        rr=self.db.query(year=2026)['records']
        self.assertEqual(sum(r['content_kind']=='external_official_reading_note' for r in rr),3)
        self.assertTrue(all(r['publication_date']<='2026-06-23' for r in rr if r['content_kind']=='user_uploaded_transcription'))
    def test_pdf_manifest_and_page_text_integrity(self):
        verify_sources(ROOT)
        m=json.loads((ROOT/'sources/procedures/manifest.json').read_text())
        self.assertEqual(m['pages'],8)
        self.assertEqual(len(m['extracted_pages']),8)
        for p in m['extracted_pages']:
            self.assertEqual(hashlib.sha256((ROOT/p['path']).read_bytes()).hexdigest(),p['sha256'])
    def test_source_gap_marks_minor_role(self):
        r=self.db.query(number='1152800098')['records'][0]
        self.assertTrue(any(i['kind']=='minor_role_scope_requires_source_confirmation' for i in r['quality_issues']))
    def test_specific_disposition_wording_not_silently_changed(self):
        r=self.db.query(number='1152801934')['records'][0]
        self.assertIn('須逐案分別令行為人接受心理諮商與輔導時數及接受8小時',r['raw_text'])
        self.assertTrue(any(i['kind']=='specific_disposition_direction_not_universal_rule' for i in r['quality_issues']))
    def test_unknown_date_relation_does_not_break_cutoff(self):
        # Dates unknown in records may be excluded; no inferred latest date is generated.
        for r in self.db.records:self.db.view(r,as_of='2026-09-06')
    def test_new_eval_spec_unexecuted(self):
        o=json.loads((ROOT/'evals/latest-and-simplified-scenarios.json').read_text())
        self.assertEqual(len(o['scenarios']),30)
        self.assertEqual(o['execution_status'],'not_run')
        self.assertTrue(all(c['model_run_status']=='not_run' and c['expected'] and c['must_not'] for c in o['scenarios']))

class SimplifiedGateTests(unittest.TestCase):
    def assert_status(self,d,status):self.assertEqual(check(d)['status'],status)
    def test_complete_intake_still_requires_committee(self):self.assert_status(fixture(),'submit_to_committee_for_triage')
    def test_unknown_not_false(self):
        self.assert_status({},'needs_verified_information')
        self.assertIn('reported_on',check({})['unknown_fields'])
    def test_boundary_before(self):
        d=fixture();d['reported_on']='2026-07-31';self.assert_status(d,'historical_route_review')
    def test_boundary_on(self):self.assert_status(fixture(),'submit_to_committee_for_triage')
    def test_wrong_date_field_rejected(self):
        d=fixture();d['occurred_on']='2026-08-10'
        with self.assertRaises(ValueError):check(d)
    def test_staff_role_priority_over_student(self):
        d=fixture();d['actor_has_mandatory_staff_role']=True;self.assert_status(d,'mandatory_investigation_group')
    def test_unknown_staff_role_does_not_pass(self):
        d=fixture();d['actor_has_mandatory_staff_role']=None;self.assert_status(d,'needs_verified_information')
    def test_not_student(self):
        d=fixture();d['actor_is_student']=False;self.assert_status(d,'outside_student_policy')
    def test_other_law(self):
        d=fixture();d['is_campus_event']=False;self.assert_status(d,'other_legal_route')
    def test_victim_request(self):
        d=fixture();d['applicant_or_victim_requests_group']=True;self.assert_status(d,'investigation_group_required')
    def test_unresolved_after_statements(self):
        d=fixture();d.update(stage='after_statements',facts_unresolved_after_statements=True);self.assert_status(d,'investigation_group_required')
    def test_remedy_reinvestigation(self):
        d=fixture();d['reinvestigation_after_remedy']=True;self.assert_status(d,'investigation_group_required')
    def test_respondent_objection_neither_veto_nor_ignored(self):
        d=fixture();d['respondent_requests_group']=True;self.assert_status(d,'committee_review_of_respondent_objection')
    def test_evidence_insufficient(self):
        d=fixture();d['existing_evidence_sufficient']=False;self.assert_status(d,'ordinary_investigation_route')
    def test_interview_needed(self):
        d=fixture();d['no_interview_needed']=False;self.assert_status(d,'ordinary_investigation_route')
    def test_inadequate_defense(self):
        d=fixture();d['defense_information_adequate']=False;self.assert_status(d,'needs_procedural_correction')
    def test_source_identity_condition_explicit(self):
        d=fixture();d['actor_knows_or_can_know_source_identity_and_reason']=False;self.assert_status(d,'needs_procedural_correction')
    def test_resolution_reference_required(self):
        d=fixture();d['committee_decision_to_simplify']=True
        with self.assertRaises(ValueError):check(d)
    def test_resolution_does_not_imply_notice_complete(self):
        d=fixture();d.update(stage='notice_and_statements',committee_decision_to_simplify=True,committee_resolution_reference='合成測試決議編號')
        self.assert_status(d,'await_statement_procedure')
    def test_report_ready_not_finding(self):
        d=fixture();d.update(stage='after_statements',facts_unresolved_after_statements=False,committee_decision_to_simplify=True,committee_resolution_reference='合成測試決議編號',statement_opportunity_given=True,statement_materials_ready=True)
        result=check(d);self.assertEqual(result['status'],'submit_report_for_committee_review')
        for key in ['determines_facts','automatic_approval','calculates_legal_deadline','external_action_taken']:self.assertFalse(result[key])
    def test_bool_strings_rejected(self):
        for v in ['true','否',0,1,[],{}]:
            d=fixture();d['actor_is_student']=v
            with self.assertRaises(ValueError):check(d)
    def test_invalid_dates_rejected(self):
        for v in ['2026-02-30','115-08-01','20260801',123,'2026-8-1']:
            d=fixture();d['reported_on']=v
            with self.assertRaises(ValueError):check(d)
    def test_empty_reference_rejected(self):
        d=fixture();d['committee_resolution_reference']=' '
        with self.assertRaises(ValueError):check(d)
    def test_extra_consent_or_severity_fields_rejected(self):
        for k in ['both_parties_agree','minor_incident','confession','not_sexual_assault']:
            d=fixture();d[k]=True
            with self.assertRaises(ValueError):check(d)
    def test_nonobject_rejected(self):
        for d in [None,[],True,'a']:
            with self.assertRaises(ValueError):check(d)
    def test_tampered_pdf_rejected(self):
        with tempfile.TemporaryDirectory() as p:
            root=Path(p);shutil.copytree(ROOT/'sources/procedures',root/'sources/procedures')
            m=json.loads((root/'sources/procedures/manifest.json').read_text())
            f=root/m['path'];f.write_bytes(f.read_bytes()+b'changed')
            with self.assertRaises(ValueError):verify_sources(root)
    def test_cli_from_other_directory(self):
        out=subprocess.run([sys.executable,str(ROOT/'scripts/check_simplified.py'),str(ROOT/'assets/simplified-case.example.json')],cwd='/tmp',capture_output=True,text=True,timeout=20)
        self.assertEqual(out.returncode,0,out.stderr);self.assertEqual(json.loads(out.stdout)['status'],'needs_verified_information')

if __name__=='__main__':unittest.main()
