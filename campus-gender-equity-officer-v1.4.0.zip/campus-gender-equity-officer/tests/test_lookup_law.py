from __future__ import annotations

import importlib.util
import json
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location('lookup_law', ROOT / 'scripts/lookup_law.py')
assert SPEC and SPEC.loader
MODULE = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(MODULE)


class LookupTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.entries = MODULE.load_manifest(ROOT)

    def test_eighteen_sources(self):
        self.assertEqual(len(self.entries), 18)

    def test_exact_alias_resolves_statute_not_rules(self):
        result = MODULE.select_sources(self.entries, '性平法', None, ROOT)
        self.assertEqual([e['source_id'] for e in result], ['U02'])

    def test_article_22_source_and_pointer(self):
        selected = MODULE.select_sources(self.entries, None, 'U02', ROOT)
        row = MODULE.lookup(selected, ['第 22 條'], root=ROOT)[0]
        self.assertIn('二十四小時', row['text'])
        self.assertIn('不得另設調查機制', row['text'])
        self.assertTrue(row['json_pointer'].endswith('/plainText'))
        self.assertFalse(row['authoritative_current_full_text'])

    def test_multi_article_selection(self):
        selected = MODULE.select_sources(self.entries, None, 'U09', ROOT)
        rows = MODULE.lookup(selected, ['16', '22'], root=ROOT)
        self.assertEqual([r['article_number'] for r in rows], ['16', '22'])
        self.assertIn('應迴避', rows[1]['text'])

    def test_outdated_teacher_version_warning(self):
        selected = MODULE.select_sources(self.entries, None, 'U13', ROOT)
        row = MODULE.lookup(selected, ['25'], root=ROOT)[0]
        self.assertEqual(row['review_status'], 'superseded_version')
        self.assertTrue(any('2026-05-13' in s for s in row['review_notes']))
        self.assertEqual(row['source_version']['promulgationDate'], '2019-06-05')

    def test_guideline_retains_section_name(self):
        selected = MODULE.select_sources(self.entries, None, 'U12', ROOT)
        row = MODULE.lookup(selected, ['1'], root=ROOT)[0]
        self.assertEqual(row['display_number'], '壹、法規與政策')
        self.assertEqual(row['review_status'], 'undated_administrative_guideline')

    def test_unknown_source_rejected(self):
        with self.assertRaises(ValueError):
            MODULE.select_sources(self.entries, None, 'U99', ROOT)

    def test_unknown_article_not_fabricated(self):
        selected = MODULE.select_sources(self.entries, None, 'U02', ROOT)
        self.assertEqual(MODULE.lookup(selected, ['999'], root=ROOT), [])

    def test_ambiguous_law_rejected(self):
        with self.assertRaisesRegex(ValueError, '不唯一'):
            MODULE.select_sources(self.entries, '性侵害', None, ROOT)

    def test_invalid_article_rejected(self):
        for value in ['二十二', '../22', '22或33', '']:
            with self.subTest(value=value), self.assertRaises(ValueError):
                MODULE.normalize_article(value)

    def test_keyword_terms_must_all_match(self):
        selected = MODULE.select_sources(self.entries, None, 'U09', ROOT)
        rows = MODULE.lookup(selected, query='承辦人員 迴避', root=ROOT)
        self.assertTrue(rows)
        self.assertTrue(all('承辦人員' in r['text'] and '迴避' in r['text'] for r in rows))

    def test_hash_mismatch_rejected(self):
        selected = MODULE.select_sources(self.entries, None, 'U02', ROOT)[0]
        changed = dict(selected, sha256='0' * 64)
        with self.assertRaisesRegex(ValueError, '雜湊不符'):
            MODULE.load_source(changed, ROOT)

    def test_path_escape_rejected(self):
        changed = dict(self.entries[0], path='../outside.json')
        with self.assertRaisesRegex(ValueError, '路徑超出'):
            MODULE.load_source(changed, ROOT)

    def test_cli_json_output(self):
        proc = subprocess.run([sys.executable, str(ROOT / 'scripts/lookup_law.py'),
                               '--source', 'U02', '--article', '22', '--format', 'json'],
                              capture_output=True, text=True, encoding='utf-8', check=False)
        self.assertEqual(proc.returncode, 0, proc.stderr)
        data = json.loads(proc.stdout)
        self.assertEqual(data['results'][0]['source_id'], 'U02')
        self.assertEqual(data['returned'], 1)

    def test_cli_unknown_article_nonzero(self):
        proc = subprocess.run([sys.executable, str(ROOT / 'scripts/lookup_law.py'),
                               '--source', 'U02', '--article', '999'],
                              capture_output=True, text=True, encoding='utf-8', check=False)
        self.assertEqual(proc.returncode, 2)
        self.assertIn('查無', proc.stderr)


if __name__ == '__main__':
    unittest.main()
