"""可重現的資料與檢索測試，不執行LLM作答，也不宣稱法律效力全數驗證。"""
from __future__ import annotations

import hashlib
import json
import shutil
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'scripts'))
from build_circular_catalog import build, normalize, number_key, safe_path, serial, source_text
from lookup_circular import CircularCatalog


class CircularTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.db = CircularCatalog(ROOT)
        cls.sources = json.loads((ROOT / 'sources/circulars/manifest.json').read_text())['sources']

    def test_statistics(self):
        s = self.db.catalog['statistics']
        self.assertEqual((s['uploaded_annual_file_count'], s['uploaded_primary_entry_count'],
                          s['uploaded_unique_main_number_count'], s['external_official_reading_note_count'],
                          s['total_indexed_records']), (23, 347, 346, 8, 355))
        self.assertEqual(s['curated_relation_count'], 44)
        self.assertFalse(s['complete_official_collection'])

    def test_all_source_hashes(self):
        for src in self.sources:
            self.assertEqual(hashlib.sha256((ROOT / src['path']).read_bytes()).hexdigest(), src['sha256'])

    def test_all_source_ranges_roundtrip(self):
        for r in self.db.records:
            lines = (ROOT / r['source_path']).read_text(encoding='utf-8').splitlines(keepends=True)
            self.assertEqual(''.join(lines[r['source_line_start']-1:r['source_line_end']]), r['raw_text'])

    def test_search_key_does_not_change_raw(self):
        q = self.db.query(number='台教學（三）字第１１３２８０４７４１Ａ號')
        self.assertEqual(q['match_count'], 2)
        self.assertIn('臺教學（三）字第1132804741A號令', [r['document_number'] for r in q['records']])

    def test_suffix_preserved(self):
        self.assertNotEqual(number_key('臺教學(三)字第1132804741A號'), number_key('臺教學(三)字第1132804741號'))
        self.assertEqual(self.db.query(number='1132804741')['match_count'], 0)
        self.assertEqual(serial('臺教學(三)字第1132804741A號令'), '1132804741A')

    def test_duplicate_records_retained(self):
        q = self.db.query(number='1080108133')
        self.assertEqual(q['match_count'], 2)
        self.assertNotEqual(q['records'][0]['record_id'], q['records'][1]['record_id'])
        self.assertNotEqual(q['records'][0]['source_line_start'], q['records'][1]['source_line_start'])
        self.assertEqual(normalize(q['records'][0]['raw_text']), normalize(q['records'][1]['raw_text']))
        self.assertTrue(all(any(i['kind']=='duplicate_primary_document_number' for i in r['quality_issues']) for r in q['records']))

    def test_keyword_and(self):
        q = self.db.query(query='受理 程序審查')
        self.assertGreater(q['match_count'], 0)
        self.assertTrue(all('受理' in r['raw_text'] and '程序審查' in r['raw_text'] for r in q['records']))

    def test_topic_year(self):
        q = self.db.query(topic='申復與救濟', year=2023)
        self.assertIn('1120057724', [r['serial'] for r in q['records']])
        self.assertTrue(all(r['source_year']==2023 for r in q['records']))

    def test_2024_records_preserve_source_layers(self):
        q = self.db.query(year=2024)
        self.assertEqual(q['match_count'], 19)
        notes = [r for r in q['records'] if r['content_kind']=='external_official_reading_note']
        self.assertEqual(len(notes), 5)
        self.assertTrue(all('非官方函令全文' in r['raw_text'] and r['official_urls'] for r in notes))
        self.assertEqual(len([r for r in q['records'] if r['representation']=='catalog_summary_only']), 1)

    def test_current_cessation(self):
        q = self.db.query(number='1010245259')
        self.assertEqual(q['records'][0]['retrieval_use_status'], 'has_explicit_cessation_evidence')
        self.assertTrue(any(l['effective_on']=='2024-10-29' for l in q['records'][0]['known_relations']))

    def test_historical_cutoff_does_not_use_later_order(self):
        r = self.db.query(number='1010245259', as_of='2023-12-31')['records'][0]
        self.assertNotEqual(r['retrieval_use_status'], 'has_explicit_cessation_evidence')
        self.assertNotEqual(r['retrieval_use_status'], 'effective')
        self.assertTrue(r['later_relation_ids_not_applied'])

    def test_cutoff_excludes_future_entries(self):
        q = self.db.query(year=2024, as_of='2024-07-01')
        self.assertEqual(q['match_count'], 6)

    def test_partial_modification_not_whole_cessation(self):
        r = self.db.query(number='0990227673')['records'][0]
        self.assertEqual(r['retrieval_use_status'], 'has_partial_change_evidence')
        self.assertTrue(any('第3點' in l['scope'] for l in r['known_relations']))

    def test_stopped_old_military_letters_do_not_revive(self):
        r = self.db.query(number='1040042214A')['records'][0]
        self.assertEqual(r['retrieval_use_status'], 'has_explicit_cessation_evidence')
        link = next(l for l in r['known_relations'] if l['relation_type']=='reaffirms_cessation')
        self.assertEqual((link['announced_on'], link['effective_on']), ('2021-03-09', '2020-06-30'))

    def test_reference_only_no_full_original(self):
        q = self.db.query(number='1090108790')
        self.assertEqual(q['match_count'], 0)
        self.assertTrue(q['reference_only'])
        self.assertTrue(all(not l['to_record_ids'] for l in q['reference_only']))

    def test_document_number_typo_not_silently_fixed(self):
        r = self.db.query(number='1110055944')['records'][0]
        self.assertIn('第1110007134號', r['raw_text'])
        self.assertTrue(any(i['kind']=='reference_number_inconsistency' for i in r['quality_issues']))
        self.assertEqual(self.db.query(number='1110007134')['match_count'], 0)
        self.assertEqual(self.db.query(number='1100007134')['match_count'], 1)

    def test_unknown_date_preserved(self):
        r = self.db.query(number='1100082461B')['records'][0]
        self.assertIsNone(r['publication_date'])
        self.assertEqual(r['publication_date_raw'], '未擷取')

    def test_unknown_date_excluded_from_cutoff_with_notice(self):
        q = self.db.query(year=2021, as_of='2024-12-31')
        self.assertEqual(q['undated_records_excluded'], 1)
        self.assertNotIn('1100082461B', [r['serial'] for r in q['records']])

    def test_all_relation_evidence_ranges(self):
        for link in self.db.relations:
            ev = link['evidence']
            lines = (ROOT / ev['source_path']).read_text().splitlines()
            block = '\n'.join(lines[ev['line_start']-1:ev['line_end']])
            self.assertIn(ev['exact_text'], block)

    def test_text_mentions_never_imply_effect(self):
        obj = json.loads((ROOT/'sources/circulars/relations.json').read_text())
        self.assertEqual(len(obj['text_reference_candidates']), 148)
        self.assertTrue(all(c['legal_effect']=='not_inferred' for c in obj['text_reference_candidates']))

    def test_forwarding_not_cessation(self):
        r = self.db.query(number='10504500190')['records'][0]
        self.assertEqual(r['retrieval_use_status'], 'current_applicability_unverified')
        self.assertTrue(any(l['relation_type']=='forwards' for l in r['known_relations']))

    def test_default_is_not_verified_effective(self):
        self.assertTrue(all(r['current_effect_review']=='not_exhaustively_verified' for r in self.db.records))

    def test_invalid_cutoff_fails(self):
        with self.assertRaises(ValueError):
            self.db.query(year=2024, as_of='2024-02-30')

    def test_empty_query_and_unknown_topic_fail(self):
        with self.assertRaises(ValueError): self.db.query()
        with self.assertRaises(ValueError): self.db.query(query='   ')
        with self.assertRaises(ValueError): self.db.query(topic='未知類別')

    def test_nonexistent_exact_number_no_invention(self):
        q = self.db.query(number='9999999999A')
        self.assertEqual(q['match_count'], 0)
        self.assertEqual(q['reference_only'], [])

    def test_path_traversal_rejected(self):
        with self.assertRaises(ValueError): safe_path(ROOT, '../other.md')
        with self.assertRaises(ValueError): safe_path(ROOT, '/etc/passwd')

    def test_tampered_source_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            src = self.sources[0]
            target = root / src['path']
            target.parent.mkdir(parents=True)
            target.write_bytes((ROOT/src['path']).read_bytes()+b'\nchanged')
            with self.assertRaises(ValueError): source_text(root, src)

    def test_tampered_derived_index_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp)
            shutil.copytree(ROOT/'sources/circulars', root/'sources/circulars')
            path=root/'sources/circulars/catalog.json'
            doc=json.loads(path.read_text()); doc['records'][0]['subject_raw']='tampered'
            path.write_text(json.dumps(doc))
            with self.assertRaises(ValueError): CircularCatalog(root)

    def test_rebuild_idempotent(self):
        rebuilt=build(ROOT, write=False)
        self.assertEqual(rebuilt['catalog.json'], self.db.catalog)

    def test_cli_runs_from_other_directory(self):
        result=subprocess.run([sys.executable, str(ROOT/'scripts/lookup_circular.py'), '--number', '1010245259', '--json'],
                              cwd='/tmp', capture_output=True, text=True, timeout=20)
        self.assertEqual(result.returncode, 0, result.stderr)
        doc=json.loads(result.stdout)
        self.assertEqual(doc['match_count'], 1)

    def test_cli_exact_duplicate_not_truncated(self):
        result=subprocess.run([sys.executable, str(ROOT/'scripts/lookup_circular.py'), '--number', '1080108133', '--limit','1'],
                              capture_output=True, text=True, timeout=20)
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertIn('C2019-009', result.stdout) # 原稿第176行的重複主文號
        self.assertIn('C2019-010', result.stdout) # 原稿第197行的重複主文號


if __name__ == '__main__':
    unittest.main()
