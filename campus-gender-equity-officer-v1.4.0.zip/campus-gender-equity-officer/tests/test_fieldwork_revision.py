"""v1.3.0文件、引用及實務測試規格的靜態檢核；不呼叫模型。"""
import hashlib
import json
import re
import unittest
import sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]

def txt(rel):return (ROOT/rel).read_text(encoding='utf-8')

class FieldworkRevisionTests(unittest.TestCase):
    def test_main_version(self):
        sys.path.insert(0,str(ROOT/'scripts'))
        from skill_metadata import parse_frontmatter
        self.assertEqual(parse_frontmatter(txt('SKILL.md'))['metadata']['version'],txt('VERSION').strip())
    def test_main_has_three_distinct_care_topics(self):
        t=txt('SKILL.md')
        for s in ['**當事人保護。**','**被害人支持服務。**','**行為人教育處置。**']:self.assertIn(s,t)
    def test_fieldwork_before_conditional_branch(self):
        t=txt('SKILL.md');self.assertLess(t.index('references/20-'),t.index('references/16-'))
        self.assertLess(t.index('references/22-'),t.index('references/16-'))
    def test_no_special_launch_date_in_main(self):
        self.assertNotRegex(txt('SKILL.md'),r'2026-08-01|115\s*年\s*8\s*月\s*1\s*日')
    def test_booking_and_substantive_inquiry_distinguished(self):
        t=txt('references/22-authority-errors-and-escalation.md')
        for s in ['排時間','實質調查','人才庫資格','仍被要求']:self.assertIn(s,t)
    def test_order_rules_are_scoped(self):
        t=txt('references/22-authority-errors-and-escalation.md')
        for s in ['第17條','第3條','刑事法律','監督範圍','長官拒絕','私校','不是']:self.assertIn(s,t)
    def test_meeting_templates_keep_dissent_and_vote(self):
        t=txt('templates/03-meeting-package.md')
        for s in ['代理','迴避','棄權','程序意見','主席','真實','原稿']:self.assertIn(s,t)
    def test_support_is_not_disposition_form(self):
        t=txt('templates/06-protection-and-coordination.md')
        for s in ['支持服務','是否接通','拒絕','templates/14','性平會決議後執行']:self.assertIn(s,t)
    def test_disposition_retains_consent_and_continuity(self):
        t=txt('templates/14-education-disposition.md')
        for s in ['同意','終身','具體時數','同','折抵','諮商全文']:self.assertIn(s,t)
    def test_field_sources_are_hashed_summaries(self):
        m=json.loads(txt('sources/fieldwork-review/manifest.json'));self.assertEqual(len(m['sources']),6)
        for s in m['sources']:
            self.assertEqual(s['representation'],'assistant_summary_of_official_web_reading')
            self.assertFalse(s['full_official_text_included'])
            self.assertEqual(hashlib.sha256((ROOT/s['path']).read_bytes()).hexdigest(),s['sha256'])
    def test_32_scenarios_not_run(self):
        m=json.loads(txt('evals/fieldwork-scenarios.json'));self.assertEqual(len(m['scenarios']),32)
        self.assertEqual(m['execution_status'],'not_run')
        for c in m['scenarios']:
            self.assertEqual(c['model_run_status'],'not_run');self.assertTrue(c['expected']);self.assertTrue(c['must_not'])
    def test_workflow_cross_reference_and_priority(self):
        t=txt('references/03-case-workflow.md')
        self.assertIn('性平法第41條',t)
        self.assertGreater(t.index('## 條件式分支'),t.index('## 8.'))

if __name__=='__main__':unittest.main()
