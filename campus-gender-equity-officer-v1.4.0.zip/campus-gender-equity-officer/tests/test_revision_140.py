"""v1.4.0回歸測試；全為程式／結構／合成資料測試，絕不呼叫模型。"""
from __future__ import annotations
import copy,hashlib,json,re,sys,tempfile,unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'scripts'))
from skill_metadata import parse_frontmatter,validate_metadata
from package_integrity import build_manifest,verify_manifest,safe_path
from check_simplified import check as gate
from check_case_record import check as case_check
from eval_evidence import prepare,validate_evidence
from test_latest_and_simplified import fixture
from lookup_circular import CircularCatalog

def blank():return json.loads((ROOT/'assets/case-record.example.json').read_text())
def work():return {'id':'ED1','kind':'education','stage':'assignment','status':'pending','owner':None,'decision_authority':None,'legal_basis':['OC2026-03'],'decision_reference':None,'deadline_ids':[],'evidence_ids':[],'next_step':None}
def assignment(n,measure,person):return {'id':n,'work_item_id':'ED1','measure':measure,'executor_id':person,'decision_reference':'合成決議','required_hours':8,'prior_counselor_priority':None,'acknowledged_conduct':None,'prior_gender_related_counseling':None,'status':'approved'}
def education():
    d=blank();d['work_items']=[work()];d['education_assignments']=[assignment('A1','counseling','P1'),assignment('A2','gender_course','P2')];return d

def notice():return {'id':'N1','recipient_id':'S1','phase':'outcome','document_version':'v1','attachment_ids':[],'status':'draft','approval_reference':None,'sent_at':None,'delivery_date':None,'delivery_evidence_id':None,'delivery_legal_basis':None,'delivery_verified_by':None,'remedy_type':None,'remedy_authority':None,'deadline_id':None}
def deadline():return {'id':'D1','notice_id':'N1','trigger':None,'trigger_evidence_id':None,'legal_basis':[],'unit':None,'period_value':None,'due_at':None,'calculation_record':None,'verified_by':None,'status':'unknown'}

class MetadataTests(unittest.TestCase):
    def text(self,version='"1.4.0"'):
        return '---\nname: campus-gender-equity-officer\ndescription: >-\n  性平承辦\n  權限與文書\ncompatibility: Python optional\nmetadata:\n  version: '+version+'\n---\n# Title\n'
    def test_versions_compared_by_value(self):
        for value in ('1.4.0','"1.4.0"',"'1.4.0'"):
            self.assertEqual(validate_metadata(self.text(value),'1.4.0',ROOT.name),[])
    def test_folded_description(self):self.assertIn('權限與文書',parse_frontmatter(self.text())['description'])
    def test_crlf_header(self):self.assertEqual(validate_metadata(self.text().replace('\n','\r\n'),'1.4.0',ROOT.name),[])
    def test_wrong_version_rejected(self):self.assertTrue(validate_metadata(self.text(),'1.3.0',ROOT.name))
    def test_duplicate_key_rejected(self):
        with self.assertRaises(ValueError):parse_frontmatter(self.text().replace('description: >-','name: duplicate\ndescription: >-'))
    def test_executable_yaml_tag_rejected(self):
        with self.assertRaises(ValueError):parse_frontmatter('---\nx: !!python/object/apply:os.system [echo]\n---\n')
    def test_nested_compatibility_rejected(self):
        t=self.text().replace('compatibility: Python optional\n','').replace('metadata:\n','metadata:\n  compatibility: misplaced\n')
        self.assertTrue(validate_metadata(t,'1.4.0',ROOT.name))
    def test_overlong_description(self):
        t=self.text().replace('  性平承辦\n  權限與文書','  '+'甲'*1025)
        self.assertTrue(validate_metadata(t,'1.4.0',ROOT.name))
    def test_no_header(self):
        with self.assertRaises(ValueError):parse_frontmatter('# title')
    def test_all_reference_files_directly_linked(self):
        main=(ROOT/'SKILL.md').read_text()
        for p in (ROOT/'references').glob('*.md'):self.assertIn('('+p.relative_to(ROOT).as_posix()+')',main)

class ManifestTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.root=Path(self.temp.name)
        (self.root/'VERSION').write_text('1.4.0\n');(self.root/'SKILL.md').write_text('version: 1.4.0\n')
        self.write(build_manifest(self.root))
    def tearDown(self):self.temp.cleanup()
    def write(self,m):(self.root/'PACKAGE-FILES.json').write_text(json.dumps(m))
    def test_clean_passes(self):self.assertTrue(verify_manifest(self.root)['passed'])
    def test_semantic_equivalent_edit_still_fails_integrity(self):
        (self.root/'SKILL.md').write_text('version: "1.4.0"\n');self.assertFalse(verify_manifest(self.root)['passed'])
    def test_missing_file(self):
        (self.root/'SKILL.md').unlink();self.assertFalse(verify_manifest(self.root)['passed'])
    def test_unlisted_file(self):
        (self.root/'extra.md').write_text('new');self.assertFalse(verify_manifest(self.root)['passed'])
    def test_duplicate_entry(self):
        m=build_manifest(self.root);m['files'].append(m['files'][0]);self.write(m);self.assertFalse(verify_manifest(self.root)['passed'])
    def test_tampered_byte_count(self):
        m=build_manifest(self.root);m['files'][0]['bytes']+=1;self.write(m);self.assertFalse(verify_manifest(self.root)['passed'])
    def test_tampered_manifest_version(self):
        m=build_manifest(self.root);m['version']='1.3.0';self.write(m);self.assertFalse(verify_manifest(self.root)['passed'])
    def test_traversal_rejected(self):
        for rel in ('../x','/etc/passwd','a\\b','a//b','PACKAGE-FILES.json','C:/x'):
            with self.assertRaises(ValueError):safe_path(self.root,rel)
    def test_symlink_rejected(self):
        (self.root/'link').symlink_to(self.root/'VERSION');self.assertFalse(verify_manifest(self.root)['passed'])
    def test_caches_documented_exclusion(self):
        p=self.root/'__pycache__';p.mkdir();(p/'x.pyc').write_bytes(b'a');self.assertTrue(verify_manifest(self.root)['passed'])
    def test_verify_never_rewrites_manifest(self):
        before=(self.root/'PACKAGE-FILES.json').read_bytes();(self.root/'SKILL.md').write_text('changed');verify_manifest(self.root)
        self.assertEqual(before,(self.root/'PACKAGE-FILES.json').read_bytes())

class StageRegressionTests(unittest.TestCase):
    def test_intake_unknown_future_fact_not_blocker(self):
        r=gate(fixture());self.assertEqual(r['status'],'submit_to_committee_for_triage');self.assertIn('facts_unresolved_after_statements',r['not_yet_applicable_fields']);self.assertNotIn('facts_unresolved_after_statements',r['unknown_fields'])
    def test_intake_prefilled_future_fact_rejected(self):
        for value in (True,False):
            d=fixture();d['facts_unresolved_after_statements']=value
            with self.assertRaises(ValueError):gate(d)
    def test_missing_stage_not_inferred(self):
        d=fixture();d.pop('stage');r=gate(d);self.assertEqual(r['status'],'needs_verified_information');self.assertIn('stage',r['unknown_fields'])
    def test_invalid_stage_rejected(self):
        for value in ('report_drafted',1,True,[]):
            d=fixture();d['stage']=value
            with self.assertRaises(ValueError):gate(d)
    def test_intake_cannot_already_have_decision(self):
        d=fixture();d.update(committee_decision_to_simplify=True,committee_resolution_reference='合成')
        with self.assertRaises(ValueError):gate(d)
    def test_later_stage_does_not_imply_decision(self):
        d=fixture();d['stage']='notice_and_statements';self.assertEqual(gate(d)['status'],'needs_verified_information')
    def test_post_statements_unknown_is_now_material(self):
        d=fixture();d.update(stage='after_statements',committee_decision_to_simplify=True,committee_resolution_reference='合成',statement_opportunity_given=True,statement_materials_ready=True)
        r=gate(d);self.assertEqual(r['status'],'needs_verified_information');self.assertIn('facts_unresolved_after_statements',r['unknown_fields'])
    def test_stage_does_not_reset_deadlines(self):
        for stage in ('intake','notice_and_statements','after_statements'):
            d=fixture();d['stage']=stage;self.assertFalse(gate(d)['calculates_legal_deadline'])

class RecordRegressionTests(unittest.TestCase):
    def test_blank_is_structurally_valid_not_completion(self):
        r=case_check(blank());self.assertTrue(r['passed']);self.assertFalse(r['legal_determination'])
    def test_distinct_executors(self):self.assertTrue(case_check(education())['passed'])
    def test_same_executor_rejected(self):
        d=education();d['education_assignments'][1]['executor_id']='P1';self.assertFalse(case_check(d)['passed'])
    def test_continuity_requires_both_conditions(self):
        for v in (None,False):
            d=education();a=d['education_assignments'][0];a.update(prior_counselor_priority=True,acknowledged_conduct=True,prior_gender_related_counseling=v)
            self.assertFalse(case_check(d)['passed'])
    def test_continuity_with_two_conditions(self):
        d=education();d['education_assignments'][0].update(prior_counselor_priority=True,acknowledged_conduct=True,prior_gender_related_counseling=True);self.assertTrue(case_check(d)['passed'])
    def test_course_does_not_accept_counselor_priority(self):
        d=education();d['education_assignments'][1].update(prior_counselor_priority=True,acknowledged_conduct=True,prior_gender_related_counseling=True);self.assertFalse(case_check(d)['passed'])
    def test_course_not_universal_twelve_hours(self):
        d=education();d['education_assignments'][1]['required_hours']=12;self.assertFalse(case_check(d)['passed'])
    def test_counseling_specific_hours_not_fixed_eight(self):
        d=education();d['education_assignments'][0]['required_hours']=5;self.assertTrue(case_check(d)['passed'])
    def test_missing_work_reference(self):
        d=education();d['education_assignments'][0]['work_item_id']='missing';self.assertFalse(case_check(d)['passed'])
    def test_completed_work_requires_evidence(self):
        d=blank();w=work();w['status']='completed';d['work_items']=[w];self.assertFalse(case_check(d)['passed'])
    def test_support_refusal_not_education_noncompliance(self):
        d=blank();w=work();w.update(kind='victim_support',status='declined');d['work_items']=[w];r=case_check(d);self.assertTrue(r['passed']);self.assertEqual(r['warnings'],[])
    def test_duplicate_record_ids(self):
        d=education();d['work_items'].append(work());self.assertFalse(case_check(d)['passed'])
    def test_draft_notice_can_be_incomplete(self):
        d=blank();d['notices']=[notice()];self.assertTrue(case_check(d)['passed'])
    def test_sent_not_automatically_delivered(self):
        d=blank();n=notice();n.update(status='sent',approval_reference='核定',sent_at='2026-09-12T08:00:00+08:00');d['notices']=[n];self.assertTrue(case_check(d)['passed']);self.assertIsNone(n['delivery_date'])
    def test_delivery_requires_proof_and_review(self):
        d=blank();n=notice();n.update(status='delivered',approval_reference='核定',sent_at='2026-09-12T08:00:00+08:00');d['notices']=[n];self.assertFalse(case_check(d)['passed'])
    def test_invalid_delivery_date_rejected(self):
        d=blank();n=notice();n['delivery_date']='2026-02-30';d['notices']=[n];self.assertFalse(case_check(d)['passed'])
    def test_notice_deadline_link_must_match(self):
        d=blank();n=notice();n['deadline_id']='D1';dl=deadline();dl['notice_id']=None;d['notices']=[n];d['deadlines']=[dl];self.assertFalse(case_check(d)['passed'])
    def test_verified_deadline_requires_calculation_record(self):
        d=blank();n=notice();dl=deadline();dl['status']='verified';d['notices']=[n];d['deadlines']=[dl];self.assertFalse(case_check(d)['passed'])
    def test_extra_case_information_not_automatic_access(self):
        d=blank();d['restricted_information_requests']=[{'id':'I1','requester_id':'P1','requested_document_ids':[],'status':'provided','committee_review_reference':None,'confidentiality_reference':None,'approved_scope':None,'provided_evidence_id':None}];self.assertFalse(case_check(d)['passed'])
    def test_schema_rejects_unknown_top_level(self):
        d=blank();d['new_procedure_records']={};self.assertFalse(case_check(d)['passed'])

class UpdateAndEvalTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):cls.db=CircularCatalog(ROOT)
    def test_new_circular_has_partial_relation(self):
        r=self.db.query(number='1132805149')['records'][0]
        self.assertTrue(any(x['relation_id']=='CR-044' and x['relation_type']=='modifies_part' and x['effective_on'] is None for x in r['known_relations']))
    def test_new_circular_is_summary_not_original(self):
        r=self.db.query(record_id='OC2026-03')['records'][0];self.assertEqual(r['representation'],'external_reading_summary');self.assertIn('未隨包收錄',r['raw_text'])
    def test_older_cutoff_excludes_new_relation(self):
        r=self.db.query(number='1132805149',as_of='2026-08-06')['records'][0]
        self.assertNotIn('CR-044',[x['relation_id'] for x in r['known_relations']])
    def test_fw06_updated_not_claimed_run(self):
        c=next(x for x in json.loads((ROOT/'evals/fieldwork-scenarios.json').read_text())['scenarios'] if x['id']=='FW06')
        self.assertEqual(c['model_run_status'],'not_run');self.assertIn('1152803267',json.dumps(c,ensure_ascii=False))
    def test_prepares_45_pending_runs(self):
        d=prepare();r=validate_evidence(d);self.assertTrue(r['passed'],r['errors']);self.assertEqual(r['completed_model_runs_recorded'],0);self.assertEqual(r['pending_model_runs'],45)
    def test_not_run_cannot_claim_pass(self):
        d=prepare();d['runs'][0]['review_verdict']='pass';self.assertFalse(validate_evidence(d)['passed'])
    def test_missing_evidence_cannot_claim_completed(self):
        d=prepare();d['runs'][0]['run_status']='completed';self.assertFalse(validate_evidence(d)['passed'])
    def test_missing_control_arm_rejected(self):
        d=prepare();d['runs'].pop();self.assertFalse(validate_evidence(d)['passed'])
    def test_duplicate_arm_rejected(self):
        d=prepare();d['runs'][-1]=copy.deepcopy(d['runs'][0]);self.assertFalse(validate_evidence(d)['passed'])
    def test_input_modification_breaks_comparison(self):
        d=prepare();d['runs'][0]['input']='changed';self.assertFalse(validate_evidence(d)['passed'])
    def test_stale_version_or_spec_rejected(self):
        d=prepare();d['specification_sha256']='0'*64;self.assertFalse(validate_evidence(d)['passed'])

if __name__=='__main__':unittest.main()
