#!/usr/bin/env python3
"""結構、來源與可重建性檢核；不執行模型評測或全面法律效力驗證。"""
from __future__ import annotations
import hashlib
import json
import re
from pathlib import Path
from urllib.parse import unquote
from typing import Any
ROOT=Path(__file__).resolve().parents[1]

def validate(root: Path = ROOT) -> dict[str, Any]:
    errors=[];checks=[]
    def load(rel):return json.loads((root/rel).read_text(encoding='utf-8'))
    def need(ok,message):
        if not ok:errors.append(message)
    try:
        text=(root/'SKILL.md').read_text(encoding='utf-8')
        m=re.match(r'\A---\n(.*?)\n---\n',text,re.S)
        need(m is not None,'SKILL.md缺少前置資料')
        if m:
            front=m.group(1);n=re.search(r'^name:\s*(.+)$',front,re.M);d=re.search(r'^description:\s*(.+)$',front,re.M)
            name=n.group(1).strip() if n else ''
            need(bool(re.fullmatch(r'[a-z0-9]+(?:-[a-z0-9]+)*',name)) and len(name)<=64 and name==root.name,'名稱格式或資料夾名稱不符')
            need(bool(d) and len(d.group(1))<=1024,'description缺漏或過長')
            need('version: "1.3.0"' in front,'入口版本不是1.3.0')
        checks.append('SKILL.md前置資料、名稱與版本')
        original=load('sources/manifest.json')['sources'];need(len(original)==18,'法規原稿數不符18')
        for s in original:
            p=(root/s['path']).resolve()
            need(p.is_relative_to((root/'sources/uploaded').resolve()),s['source_id']+'路徑越界')
            if not p.is_relative_to((root/'sources/uploaded').resolve()):continue
            need(hashlib.sha256(p.read_bytes()).hexdigest()==s['sha256'],s['source_id']+'原檔SHA不符')
            need(len(json.loads(p.read_text())['regulation']['articles'])==s['article_count'],s['source_id']+'條目數不符')
        checks.append('18份法規原稿路徑、SHA-256、JSON及條目數')
        from lookup_circular import CircularCatalog
        db=CircularCatalog(root);st=db.catalog['statistics']
        expected={'uploaded_annual_file_count':23,'uploaded_primary_entry_count':347,'uploaded_unique_main_number_count':346,
                  'external_official_reading_note_count':7,'total_indexed_records':354,'unknown_publication_date_count':4,
                  'catalog_summary_only_count':3,'curated_relation_count':43,'candidate_text_link_count':148,
                  'curated_or_duplicate_quality_issue_count':27,'missing_uploaded_years':[],'complete_official_collection':False}
        for k,v in expected.items():need(st[k]==v,f'函示統計{k}不符：{st[k]} != {v}')
        checks.append('23年度原稿與7摘要之SHA、354條目重建、來源行號與43條關係證據')
        ids={r['record_id'] for r in db.records}
        for folder in ['references','templates']:
            for p in (root/folder).glob('*.md'):
                for rid in set(re.findall(r'\b(?:C20\d{2}-\d{3}|OC20\d{2}-\d{2})\b',p.read_text())):
                    need(rid in ids,p.name+'未知來源代碼'+rid)
        lawids={s['source_id'] for s in original}|{s['source_id'] for s in load('sources/official-research.json')['sources']}
        for p in list((root/'references').glob('*.md'))+[root/'SKILL.md']:
            for rid in set(re.findall(r'\b[UW]\d{2}\b',p.read_text())):need(rid in lawids,p.name+'未知法源代碼'+rid)
        checks.append('法規及函示來源代碼')
        from check_simplified import verify_sources, check, BOOL_FIELDS
        verify_sources(root)
        pdf=load('sources/procedures/manifest.json');need(pdf['pages']==8,'PDF頁數錯誤')
        for item in pdf['extracted_pages']:
            need(hashlib.sha256((root/item['path']).read_bytes()).hexdigest()==item['sha256'],'PDF文字抽取SHA不符')
        need(hashlib.sha256((root/pdf['compiled_text_path']).read_bytes()).hexdigest()==pdf['compiled_text_sha256'],'PDF彙整抽取SHA不符')
        example=load('assets/simplified-case.example.json');schema=load('assets/simplified-case.schema.json')
        need(set(example)==set(schema['properties']),'簡化範例與schema欄位不同')
        need(check(example)['status']=='needs_verified_information','空白簡化範例不應自動核准')
        checks.append('原PDF、八頁與彙整抽取完整性；簡化例示與schema保持未知、不核准')
        deadlines=load('assets/deadline-catalog.json')
        need(deadlines['automatic_due_date_calculation'] is False,'不得自動推定截止日')
        rr=deadlines['rules'];need(len(rr)==23 and len({r['id'] for r in rr})==23,'期限代碼／數量不符')
        need(all(r.get('legal_basis') and r.get('trigger') for r in rr),'期限缺少依據或起算')
        checks.append('23項期限／期間條件，有依據與起算，不自動計算截止日')
        total=0;seen=set()
        for file,count in [('evals/scenarios.json',30),('evals/circular-scenarios.json',20),('evals/latest-and-simplified-scenarios.json',30),('evals/fieldwork-scenarios.json',32)]:
            o=load(file);cases=o['scenarios'];need(len(cases)==count,file+'題數不符')
            for c in cases:
                need(c['id'] not in seen,'重複情境代碼'+c['id']);seen.add(c['id'])
                need(bool(c.get('expected')) and bool(c.get('must_not')),c['id']+'缺少驗收內容')
                need(c.get('model_run_status')=='not_run',c['id']+'模型狀態非未執行')
            total+=len(cases)
        need(total==112,'模型驗收規格總數不符')
        checks.append('112個情境規格存在且均未執行模型作答')
        need(len(list((root/'references').glob('*.md')))==24,'參考模組數非24')
        need(len(list((root/'templates').glob('*.md')))==14,'模板數非14')
        for file in ['references/16-simplified-procedure.md','templates/10-simplified-intake-notices.md',
                     'templates/11-simplified-meeting-report.md','templates/12-latest-circular-handoffs.md',
                     'README.md','UPGRADE-v1.2.0.md','scripts/check_simplified.py','tests/test_latest_and_simplified.py']:
            need((root/file).is_file(),'必要檔案缺漏'+file)
        field=load('sources/fieldwork-review/manifest.json')
        need(len(field['sources'])==6,'本次法源查閱摘要數量不符')
        fids={s['source_id'] for s in field['sources']}
        for s in field['sources']:
            need(s['representation']=='assistant_summary_of_official_web_reading','不得將查閱摘要冒充原件')
            need(s['full_official_text_included'] is False,'不得稱已收官方全文')
            need(hashlib.sha256((root/s['path']).read_bytes()).hexdigest()==s['sha256'],s['source_id']+'摘要SHA不符')
        for p in [root/'SKILL.md']+list((root/'references').glob('*.md'))+list((root/'templates').glob('*.md')):
            for sid in set(re.findall(r'\bF13\d{2}\b',p.read_text())):
                need(sid in fids,p.name+'未知本次法源代碼'+sid)
        need('2026-08-01' not in text and '115年8月1日' not in text and '115 年 8 月 1 日' not in text,'主檔不應以特殊程序日期為常態提示')
        for rel in ['references/20-protection-support-education.md','references/21-committee-operations.md',
                    'references/22-authority-errors-and-escalation.md','references/23-fieldwork-source-notes.md',
                    'templates/13-objection-and-escalation.md','templates/14-education-disposition.md',
                    'tests/test_fieldwork_revision.py','UPGRADE-v1.3.0.md']:
            need((root/rel).is_file(),'本次實務檔案缺漏'+rel)
        checks.append('六筆有限官方查閱摘要、來源代碼、雜湊與新實務模組路徑；不等於模型行為測試')
        # Only explicit relative Markdown links are checked; general textual section references are not paths.
        for p in root.rglob('*.md'):
            if any(x in p.parts for x in ('uploaded','official-notes')):continue
            for link in re.findall(r'\]\(([^)]+)\)',p.read_text()):
                if '://' in link or link.startswith('#'):continue
                dest=unquote(link.split('#')[0])
                if dest:need((p.parent/dest).exists(),str(p.relative_to(root))+'相對連結缺漏：'+dest)
        checks.append('24參考模組、14模板、必要腳本及相對連結')
    except (OSError, ValueError, KeyError, TypeError, ImportError) as exc:
        errors.append(str(exc))
    return {'package_version':'1.3.0','passed':not errors,'checks':checks,'errors':errors,
            'limitations':'結構、來源完整性與規則檢核，不是法律效力全數查核，未執行模型作答評測。'}

if __name__=='__main__':
    result=validate();print(json.dumps(result,ensure_ascii=False,indent=2));raise SystemExit(0 if result['passed'] else 1)
