"""Offline packaging and deferred-loading contracts, NOT an actual web-model test.
No function here accepts a user conversation or intercepts runtime input.
"""
from __future__ import annotations
import hashlib
import json
import re
import sys
import tempfile
import unittest
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'scripts'))
from validate_package import router_errors

def text(rel):return (ROOT/rel).read_text(encoding='utf-8')
def load(rel):return json.loads(text(rel))

def fixture(root: Path):
    for rel in ('SKILL.md','WORKFLOW.md'):
        (root/rel).write_text(text(rel),encoding='utf-8')

class WebRouterTests(unittest.TestCase):
    def test_router_structurally_valid(self):
        self.assertEqual(router_errors(ROOT),[])

    def test_entry_is_actually_compact(self):
        s=text('SKILL.md')
        self.assertLessEqual(len(s.splitlines()),60)
        self.assertLessEqual(len(s.encode('utf-8')),5000)
        old=load('tests/v1.7.3-preservation.json')['entry_before']
        self.assertLess(len(s.encode('utf-8')),old['utf8_bytes'])

    def test_root_has_only_one_conditional_link(self):
        s=text('SKILL.md')
        self.assertEqual(re.findall(r'\]\(([^)]+)\)',s),['WORKFLOW.md'])
        self.assertLess(s.index('startup-warning:end'),s.index('](WORKFLOW.md)'))
        self.assertIn('僅在 B 分支',s)

    def test_business_not_embedded_in_root(self):
        for section in ['## 回覆順序：','## 按問題讀取','## 法規核心唯讀 Wiki','## 與其他技能分工']:
            self.assertNotIn(section,text('SKILL.md'))
            self.assertIn(section,text('WORKFLOW.md'))

    def test_no_commands_or_deep_paths_in_root(self):
        for phrase in ['```','scripts/','references/','templates/','sources/','wiki/','lookup_legal.py']:
            self.assertNotIn(phrase,text('SKILL.md'))

    def test_description_discourages_batch_loading(self):
        import yaml
        meta=yaml.safe_load(text('SKILL.md').split('---',2)[1])
        self.assertIn('啟用先只讀SKILL.md',meta['description'])
        self.assertIn('不併讀業務檔案',meta['description'])

    def test_existing_warning_bytes_preserved(self):
        baseline=load('tests/v1.7.3-preservation.json')
        self.assertEqual(hashlib.sha256((ROOT/'assets/startup-warning.txt').read_bytes()).hexdigest(),baseline['original_warning_sha256'])
        s=text('SKILL.md')
        self.assertEqual(re.findall(r'<!-- startup-warning:start -->\n(.*?)\n<!-- startup-warning:end -->',s,re.S),[text('assets/startup-warning.txt').strip()])

    def test_business_tail_is_verbatim_not_a_summary(self):
        b=load('tests/v1.7.3-preservation.json')['moved_business']
        s=text('WORKFLOW.md');tail=s[s.index(b['starts_with']):]
        self.assertEqual(hashlib.sha256(tail.encode('utf-8')).hexdigest(),b['sha256'])
        self.assertEqual(len(tail.encode('utf-8')),b['utf8_bytes'])

    def test_all_prior_sources_preserved(self):
        p=load('tests/v1.7.3-preservation.json')
        self.assertEqual(p['source_count'],102)
        self.assertEqual(len(p['sources']),102)
        for item in p['sources']:
            self.assertTrue(item['bytewise_identical'])
            self.assertEqual(hashlib.sha256((ROOT/item['path']).read_bytes()).hexdigest(),item['sha256'],item['path'])

    def test_single_skill_not_split_into_competing_skills(self):
        self.assertEqual([p.relative_to(ROOT).as_posix() for p in ROOT.rglob('SKILL.md')],['SKILL.md'])
        self.assertFalse(text('WORKFLOW.md').startswith('---'))
        self.assertIn('不是另一個可獨立選用的 Skill',text('WORKFLOW.md'))

    def test_modules_and_templates_still_directly_reachable(self):
        for folder in ('references','templates'):
            for p in (ROOT/folder).glob('*.md'):
                self.assertIn(']('+p.relative_to(ROOT).as_posix()+')',text('WORKFLOW.md'),p.name)

    def test_first_branch_independent_of_case_type(self):
        s=text('SKILL.md')
        for clause in ['不分析初始輸入以決定是否警告','不查閱案情或其他檔案','不做案件分流','不必逐項辨識或辯論']:
            self.assertIn(clause,s)

    def test_first_branch_explicitly_avoids_prefetch(self):
        for s in [text('SKILL.md'),text('deployment/TOP_LEVEL_INSTRUCTIONS.md')]:
            self.assertIn('不與業務檔案批次或平行載入',s)
            self.assertIn('不為取得警告再開檔',s)

    def test_later_loading_and_reuse_do_not_add_consent(self):
        s=text('SKILL.md')
        self.assertIn('已在本次脈絡中完整讀取時不必重讀',s)
        self.assertIn('下一則直接處理問題',s)
        self.assertIn('無須同意詞、獨立確認或資料審查',s)
        self.assertIn('不在後續回合增加內容掃描或攔截',s)

    def test_web_deployment_does_not_require_api(self):
        self.assertIn('不需API、外掛或程式介接',text('README.md'))
        self.assertIn('沒有另外設定首層指令者不必新增部署步驟',text('deployment/README.md'))
        self.assertFalse((ROOT/'scripts/startup_gate.py').exists())

    def test_report_separates_web_category_from_unknown_product(self):
        d=load('tests/v1.7.3-user-report.json')
        self.assertEqual(d['platform_category'],'web')
        self.assertIsNone(d['actual_product']);self.assertIsNone(d['actual_model'])
        self.assertFalse(d['complete_tool_trace_available'])
        self.assertEqual(d['evidence_type'],'user_report_not_independently_reproduced')

    def test_web_cases_are_16_unrun_specifications(self):
        d=load('evals/web-router-scenarios.json')
        self.assertEqual(len(d['scenarios']),16)
        self.assertFalse(d['runtime_use']);self.assertFalse(d['contains_real_case_data'])
        for case in d['scenarios']:
            self.assertEqual(case['model_run_status'],'not_run')
            self.assertIsNone(case['model_result']);self.assertIsNone(case['tool_trace_result'])
            self.assertTrue(case['expected']);self.assertTrue(case['must_not'])

    def test_trace_absence_is_not_pass(self):
        d=load('evals/web-router-scenarios.json')
        self.assertIn('unobservable',d['unobservable_trace_policy'])
        self.assertIn('不可因最後有警告而填pass',d['unobservable_trace_policy'])
        self.assertIn('不宣稱被本版阻止',d['preactivation_boundary'])

    def test_two_turn_transition_is_specified(self):
        d=load('evals/web-router-scenarios.json')
        case=next(c for c in d['scenarios'] if c['id']=='WEB-ROUTER-15')
        self.assertEqual(case['session_profile'],'new')
        self.assertTrue(case['continuation']['expected'])
        self.assertTrue(case['continuation']['must_not'])

    def test_no_case_memory_or_consent_profiles(self):
        d=load('evals/session-profiles.json')
        self.assertEqual(set(d['profiles']),{'new','after_warning'})
        self.assertFalse(d['cross_case_memory'])
        self.assertIn('web-router-scenarios.json',d['additional_suites'])

    def test_validator_rejects_extra_entry_link(self):
        with tempfile.TemporaryDirectory() as td:
            p=Path(td);fixture(p)
            (p/'SKILL.md').write_text(text('SKILL.md')+'\n[預讀](references/01-law-map.md)\n')
            self.assertTrue(any('一個' in e for e in router_errors(p)))

    def test_validator_rejects_missing_workflow(self):
        with tempfile.TemporaryDirectory() as td:
            p=Path(td);fixture(p);(p/'WORKFLOW.md').unlink()
            self.assertTrue(any('無法檢查' in e for e in router_errors(p)))

    def test_validator_rejects_business_in_first_file(self):
        with tempfile.TemporaryDirectory() as td:
            p=Path(td);fixture(p)
            (p/'SKILL.md').write_text(text('SKILL.md')+'\n## 按問題讀取\n執行scripts/lookup_legal.py\n')
            self.assertTrue(any('業務正文' in e for e in router_errors(p)))

    def test_validator_rejects_oversized_router(self):
        with tempfile.TemporaryDirectory() as td:
            p=Path(td);fixture(p)
            (p/'SKILL.md').write_text(text('SKILL.md')+'\n'*70)
            self.assertTrue(any('60行' in e for e in router_errors(p)))

if __name__=='__main__':unittest.main()
