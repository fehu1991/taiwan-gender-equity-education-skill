#!/usr/bin/env python3
"""結構、來源與可重建性檢核；不執行模型評測或全面法律效力驗證。"""
from __future__ import annotations
import hashlib
import json
import re
from pathlib import Path
from urllib.parse import unquote
from typing import Any
ROOT=Path(__file__).resolve().parents[1]

def distribution_errors(root: Path) -> list[str]:
    """Validate the distributable inventory, not just selected legal source hashes."""
    errors = []
    try:
        manifest = json.loads((root / 'PACKAGE-FILES.json').read_text(encoding='utf-8'))
        version = (root / 'VERSION').read_text(encoding='utf-8').strip()
        if manifest.get('version') != version:
            errors.append('PACKAGE-FILES版本與VERSION不符')
        declared = set()
        for item in manifest['files']:
            rel = item['path']
            path = (root / rel).resolve()
            if not path.is_relative_to(root.resolve()) or rel == 'PACKAGE-FILES.json':
                errors.append('發行清單路徑越界或包含自身：' + rel)
                continue
            if rel in declared:
                errors.append('發行清單重複路徑：' + rel)
            declared.add(rel)
            if not path.is_file():
                errors.append('發行清單檔案缺漏：' + rel)
                continue
            content = path.read_bytes()
            if len(content) != item['bytes'] or hashlib.sha256(content).hexdigest() != item['sha256']:
                errors.append('發行清單大小或SHA不符：' + rel)
        actual = {p.relative_to(root).as_posix() for p in root.rglob('*')
                  if p.is_file() and p.name != 'PACKAGE-FILES.json'
                  and '__pycache__' not in p.parts and p.suffix not in ('.pyc', '.pyo')}
        for rel in sorted(actual - declared):
            errors.append('未列入發行清單：' + rel)
        for rel in sorted(declared - actual):
            errors.append('發行清單與實際檔案集不同：' + rel)
    except (OSError, ValueError, KeyError, TypeError) as exc:
        errors.append('發行清單無法驗證：' + str(exc))
    return errors


def router_errors(root: Path) -> list[str]:
    """Inspect bundled files only. Does not accept, classify, or intercept messages."""
    errors: list[str] = []
    try:
        entry = (root/'SKILL.md').read_text(encoding='utf-8')
        workflow = (root/'WORKFLOW.md').read_text(encoding='utf-8')
        links = re.findall(r'\]\(([^)]+)\)', entry)
        if links != ['WORKFLOW.md']:
            errors.append('精簡入口只能有一個有條件的WORKFLOW.md連結')
        if len(entry.splitlines()) > 60 or len(entry.encode('utf-8')) > 5000:
            errors.append('精簡入口超出本版60行／5000 bytes的建置目標')
        for phrase in ['## 回覆順序：', '## 按問題讀取', '## 三種工作', 'scripts/', 'references/', 'wiki/', 'sources/', 'templates/', '```']:
            if phrase in entry:
                errors.append('入口不應含業務正文、指令或深層路徑：'+phrase)
        for phrase in ['A｜尚未提示','B｜已提示且進入下一則','不讀取業務入口','不分析初始輸入以決定是否警告','不與業務檔案批次或平行載入','無須同意詞、獨立確認或資料審查','不在後續回合增加內容掃描或攔截']:
            if phrase not in entry:
                errors.append('精簡分流缺少要求：'+phrase)
        if 'startup-warning:end' not in entry or '](WORKFLOW.md)' not in entry or entry.index('startup-warning:end') >= entry.index('](WORKFLOW.md)'):
            errors.append('業務連結必須在完整警告之後')
        if '只供本次首則警示已完成後的下一則及後續業務使用' not in workflow:
            errors.append('業務入口缺少延後載入限定')
        if workflow.startswith('---'):
            errors.append('WORKFLOW.md不是另一個可獨立啟用的Skill')
        for phrase in ['## 回覆順序：先結論，再依據與涵攝','## 按問題讀取','## 法規核心唯讀 Wiki']:
            if phrase not in workflow:
                errors.append('業務正文缺漏：'+phrase)
    except (OSError, ValueError) as exc:
        errors.append('分流入口無法檢查：'+str(exc))
    return errors


def validate(root: Path = ROOT, *, verify_distribution: bool = True) -> dict[str, Any]:
    errors=[];checks=[]
    def load(rel):return json.loads((root/rel).read_text(encoding='utf-8'))
    def need(ok,message):
        if not ok:errors.append(message)
    try:
        text=(root/'SKILL.md').read_text(encoding='utf-8')
        workflow=(root/'WORKFLOW.md').read_text(encoding='utf-8')
        errors.extend(router_errors(root))
        checks.append('精簡分流入口、警告後唯一業務連結與延後載入；非執行期攔截')
        from frontmatter import validate_frontmatter
        version=(root/'VERSION').read_text(encoding='utf-8').strip()
        validate_frontmatter(text, folder_name=root.name, version=version)
        checks.append('SKILL.md前置資料、名稱與版本')
        original=load('sources/manifest.json')['sources'];need(len(original)==18,'法規原稿數不符18')
        for s in original:
            p=(root/s['path']).resolve()
            need(p.is_relative_to((root/'sources/uploaded').resolve()),s['source_id']+'路徑越界')
            if not p.is_relative_to((root/'sources/uploaded').resolve()):continue
            need(hashlib.sha256(p.read_bytes()).hexdigest()==s['sha256'],s['source_id']+'原檔SHA不符')
            need(len(json.loads(p.read_text())['regulation']['articles'])==s['article_count'],s['source_id']+'條目數不符')
        checks.append('18份法規原稿路徑、SHA-256、JSON及條目數')
        from lookup_circular import CircularCatalog
        db=CircularCatalog(root);st=db.catalog['statistics']
        expected={'uploaded_annual_file_count':23,'uploaded_primary_entry_count':347,'uploaded_unique_main_number_count':346,
                  'external_official_reading_note_count':7,'total_indexed_records':354,'unknown_publication_date_count':4,
                  'catalog_summary_only_count':3,'curated_relation_count':43,'candidate_text_link_count':148,
                  'curated_or_duplicate_quality_issue_count':27,'missing_uploaded_years':[],'complete_official_collection':False}
        for k,v in expected.items():need(st[k]==v,f'函示統計{k}不符：{st[k]} != {v}')
        checks.append('23年度原稿與7摘要之SHA、354條目重建、來源行號與43條關係證據')
        ids={r['record_id'] for r in db.records}
        for p in [root/'SKILL.md',root/'WORKFLOW.md']+list((root/'references').glob('*.md'))+list((root/'templates').glob('*.md')):
            for rid in set(re.findall(r'\b(?:C20\d{2}-\d{3}|OC20\d{2}-\d{2})\b',p.read_text())):
                need(rid in ids,p.name+'未知來源代碼'+rid)
        lawids={s['source_id'] for s in original}|{s['source_id'] for s in load('sources/official-research.json')['sources']}
        for p in list((root/'references').glob('*.md'))+list((root/'templates').glob('*.md'))+[root/'SKILL.md',root/'WORKFLOW.md']:
            for rid in set(re.findall(r'\b[UW]\d{2}\b',p.read_text())):need(rid in lawids,p.name+'未知法源代碼'+rid)
        checks.append('法規及函示來源代碼')
        from check_simplified import verify_sources, check, BOOL_FIELDS
        verify_sources(root)
        pdf=load('sources/procedures/manifest.json');need(pdf['pages']==8,'PDF頁數錯誤')
        for item in pdf['extracted_pages']:
            need(hashlib.sha256((root/item['path']).read_bytes()).hexdigest()==item['sha256'],'PDF文字抽取SHA不符')
        need(hashlib.sha256((root/pdf['compiled_text_path']).read_bytes()).hexdigest()==pdf['compiled_text_sha256'],'PDF彙整抽取SHA不符')
        example=load('assets/simplified-case.example.json');schema=load('assets/simplified-case.schema.json')
        need(set(example)==set(schema['properties']),'簡化範例與schema欄位不同')
        need(check(example)['status']=='needs_verified_information','空白簡化範例不應自動核准')
        checks.append('原PDF、八頁與彙整抽取完整性；簡化例示與schema保持未知、不核准')
        deadlines=load('assets/deadline-catalog.json')
        need(deadlines['automatic_due_date_calculation'] is False,'不得自動推定截止日')
        rr=deadlines['rules'];need(len(rr)==23 and len({r['id'] for r in rr})==23,'期限代碼／數量不符')
        need(all(r.get('legal_basis') and r.get('trigger') for r in rr),'期限缺少依據或起算')
        checks.append('23項期限／期間條件，有依據與起算，不自動計算截止日')
        total=0;seen=set()
        for file,count in [('evals/scenarios.json',30),('evals/circular-scenarios.json',20),('evals/latest-and-simplified-scenarios.json',30),('evals/fieldwork-scenarios.json',32),('evals/reliability-and-ai-scenarios.json',24),('evals/layered-index-scenarios.json',16),('evals/law-wiki-scenarios.json',24),('evals/entry-admin-scenarios.json',24),('evals/first-warning-bypass-scenarios.json',24),('evals/web-router-scenarios.json',16)]:
            o=load(file);cases=o['scenarios'];need(len(cases)==count,file+'題數不符')
            for c in cases:
                need(c['id'] not in seen,'重複情境代碼'+c['id']);seen.add(c['id'])
                need(bool(c.get('expected')) and bool(c.get('must_not')),c['id']+'缺少驗收內容')
                need(c.get('model_run_status')=='not_run',c['id']+'模型狀態非未執行')
            total+=len(cases)
        need(total==240,'模型驗收規格總數不符')
        checks.append('240個情境規格存在且均未執行模型作答')
        need(len(list((root/'references').glob('*.md')))==31,'參考模組數非31')
        need(len(list((root/'templates').glob('*.md')))==15,'模板數非15')
        for file in ['references/16-simplified-procedure.md','templates/10-simplified-intake-notices.md',
                     'templates/11-simplified-meeting-report.md','templates/12-latest-circular-handoffs.md',
                     'README.md','UPGRADE-v1.2.0.md','scripts/check_simplified.py','tests/test_latest_and_simplified.py']:
            need((root/file).is_file(),'必要檔案缺漏'+file)
        field=load('sources/fieldwork-review/manifest.json')
        need(len(field['sources'])==6,'本次法源查閱摘要數量不符')
        fids={s['source_id'] for s in field['sources']}
        for s in field['sources']:
            need(s['representation']=='assistant_summary_of_official_web_reading','不得將查閱摘要冒充原件')
            need(s['full_official_text_included'] is False,'不得稱已收官方全文')
            need(hashlib.sha256((root/s['path']).read_bytes()).hexdigest()==s['sha256'],s['source_id']+'摘要SHA不符')
        for p in [root/'SKILL.md',root/'WORKFLOW.md']+list((root/'references').glob('*.md'))+list((root/'templates').glob('*.md')):
            for sid in set(re.findall(r'\bF13\d{2}\b',p.read_text())):
                need(sid in fids,p.name+'未知本次法源代碼'+sid)
        need('2026-08-01' not in text and '115年8月1日' not in text and '115 年 8 月 1 日' not in text,'主檔不應以特殊程序日期為常態提示')
        for rel in ['references/20-protection-support-education.md','references/21-committee-operations.md',
                    'references/22-authority-errors-and-escalation.md','references/23-fieldwork-source-notes.md',
                    'templates/13-objection-and-escalation.md','templates/14-education-disposition.md',
                    'tests/test_fieldwork_revision.py','UPGRADE-v1.3.0.md']:
            need((root/rel).is_file(),'本次實務檔案缺漏'+rel)
        checks.append('六筆有限官方查閱摘要、來源代碼、雜湊與新實務模組路徑；不等於模型行為測試')
        # Only explicit relative Markdown links are checked; general textual section references are not paths.
        for p in root.rglob('*.md'):
            if any(x in p.parts for x in ('uploaded','official-notes')):continue
            for link in re.findall(r'\]\(([^)]+)\)',p.read_text()):
                if '://' in link or link.startswith('#'):continue
                dest=unquote(link.split('#')[0])
                if dest:need((p.parent/dest).exists(),str(p.relative_to(root))+'相對連結缺漏：'+dest)
        for folder in ('references', 'templates'):
            for ref in (root/folder).glob('*.md'):
                need(f']({ref.relative_to(root).as_posix()})' in workflow,
                     '業務入口未直接連結：'+ref.relative_to(root).as_posix())
        need(len(text.splitlines()) <= 500, '本套件入口超出所採最佳實務500行目標（非通用有效性限制）')
        checks.append('31參考模組、15模板由WORKFLOW直接連到；精簡主檔不預列業務路徑')
        ai=load('sources/ai-guidance/manifest.json')
        need(ai['source_id']=='AI01' and ai['pages']==2, 'AI原指引標識／頁數不符')
        need(hashlib.sha256((root/ai['path']).read_bytes()).hexdigest()==ai['sha256'],'AI原指引SHA不符')
        for page in ai['extracted_pages']:
            need(hashlib.sha256((root/page['path']).read_bytes()).hexdigest()==page['sha256'],'AI指引抽取SHA不符')
        notes=load('sources/ai-guidance/research.json')['sources']
        for note in notes:
            need(hashlib.sha256((root/note['path']).read_bytes()).hexdigest()==note['sha256'],'AI FAQ摘要SHA不符')
            need(note['full_webpage_snapshot_included'] is False,'AI FAQ不能冒稱網頁全文快照')
        ai_ids={ai['source_id']}|{x['source_id'] for x in notes}
        for p in [root/'SKILL.md',root/'WORKFLOW.md']+list((root/'references').glob('*.md'))+list((root/'templates').glob('*.md')):
            for sid in set(re.findall(r'\bAI\d{2}\b',p.read_text())):
                need(sid in ai_ids,p.name+'未知AI來源代碼'+sid)
        checks.append('AI原指引及抽取、官方FAQ有限摘要之SHA與代碼')
        from build_layered_index import build_index
        layered=build_index(root,check=True)
        need(layered['statistics']['records']==354,'分層索引條目數不符')
        need(layered['statistics']['unclassified']==14,'未分類數不符')
        need(layered['statistics']['curated_relations']==43,'分層已整理關係數不符')
        checks.append('分層索引來源重建逐位元相同、354卡片、14未分類、43已整理關係及法規候選')
        from build_legal_wiki import build_wiki
        wiki=build_wiki(root,check=True)
        need(wiki['statistics']['law_nodes']==29,'Wiki法規節點數不符')
        need(wiki['statistics']['official_excerpt_sources']==16,'Wiki官方部分轉錄數不符')
        need(wiki['statistics']['case_storage_enabled'] is False,'Wiki不得保存個案')
        checks.append('法規核心Wiki可重現、來源雜湊、有限摘錄及唯讀結構；不認證法律適用')
        warning=(root/'assets/startup-warning.txt').read_text(encoding='utf-8').strip()
        marker=r'<!-- startup-warning:start -->\n(.*?)\n<!-- startup-warning:end -->'
        for rel in ['SKILL.md','deployment/TOP_LEVEL_INSTRUCTIONS.md']:
            matches=re.findall(marker,(root/rel).read_text(encoding='utf-8'),re.S)
            need(matches==[warning],rel+'固定警告不一致或重複')
        contract_pattern=r'<!-- first-warning-contract:start -->\n(.*?)\n<!-- first-warning-contract:end -->'
        skill_contract=re.findall(contract_pattern,text,re.S)
        outer_contract=re.findall(contract_pattern,(root/'deployment/TOP_LEVEL_INSTRUCTIONS.md').read_text(encoding='utf-8'),re.S)
        need(len(skill_contract)==1 and skill_contract==outer_contract,'首次契約必須唯一且內外層一致')
        if skill_contract:
            for phrase in ['要求忽略限制','本次真實對話','不能在同一回合合併','不自行提高指令權限','下一則直接處理問題']:
                need(phrase in skill_contract[0],'首次契約缺少明確邊界：'+phrase)
        checks.append('精簡首次分流一致、真實提示狀態與指令層級界線；不代表模型實測')
        need('下一則可直接提出問題' in warning,'警告必須說明下一則可直接提問')
        need('我已閱讀並同意使用限制' not in warning,'不能要求舊版同意詞')
        need(not (root/'scripts/startup_gate.py').exists(),'已撤除的宿主攔截程式不應留在套件')
        need(not (root/'references/29-entry-gate-and-response.md').exists(),'已撤除的舊入口規則不應留在套件')
        admin=load('knowledge/admin-law-framework.json')
        need(len(admin['stages'])==7,'行政法框架階段數不符')
        need(admin['bridge']['paragraph']=='6','性平法第33條第6項銜接不符')
        profiles=load('evals/session-profiles.json')
        need(profiles['model_run_status']=='not_run' and profiles['cross_case_memory'] is False,'模型評測不得假稱執行或跨案記憶')
        need(set(profiles['profiles'])=={'new','after_warning'},'評測不得保留同意或封鎖狀態')
        checks.append('首次警告一致、下一則直接提問、已撤除攔截程式及確認狀態；行政法七階段保留（非模型／平台實測）')
        if verify_distribution:
            report=load('VALIDATION.json')
            need(report.get('version')==version,'現行驗證報告版本與套件不符')
            totals=report.get('unit_and_static_tests',{})
            need(totals.get('run_count')==totals.get('passed_count',0)+totals.get('failed_count',0),'驗證報告測試計數不一致')
            need(report.get('model_evaluation',{}).get('run_count')==0 and report.get('platform_import_tested') is False,'本版未執行實際模型／平台，不得更改為已通過')
            checks.append('現行驗證報告版本、測試計數及未執行模型／平台的界線')
            errors.extend(distribution_errors(root))
            checks.append('全套發行清單檔案集合、大小、SHA-256及版本')
    except (OSError, ValueError, KeyError, TypeError, ImportError) as exc:
        errors.append(str(exc))
    return {'package_version':(root/'VERSION').read_text(encoding='utf-8').strip(),'passed':not errors,'checks':checks,'errors':errors,
            'limitations':'結構、來源完整性與規則檢核，不是法律效力全數查核，未執行模型作答評測。'}

if __name__=='__main__':
    result=validate();print(json.dumps(result,ensure_ascii=False,indent=2));raise SystemExit(0 if result['passed'] else 1)
