# 網頁使用與首層文字 v1.7.3

本資料夾只有[首層指令文字](TOP_LEVEL_INSTRUCTIONS.md)與使用說明，沒有對話攔截或資料分類程式。首次警示一次，下一則直接工作，無須同意詞、獨立確認、資料審查或額外程式。

## 網頁使用

用完整新版 Skill 取代網頁中舊版本，不要同時啟用兩版。日常使用只從 SKILL.md 進入；不要把整包內容、WORKFLOW.md 或全部參考模組另貼進常駐的入口指令或單一對話，否則這些內容可能已在首次分流前被提供。

沒有另外設定首層指令者不必新增部署步驟。原本已配置舊首層文字者，才同步換成本版；它只設定同一套首次分流，不新增第二次警告。

若網頁提供助手或專案指令欄位，可選用本資料夾的首層文字；名稱不等於實際指令層級，是否具有較高優先性由平台決定。放在ZIP、知識附件或普通訊息，不會自動取得該優先性。本次未操作網頁設定、未實際匯入，也未取得使用者的網頁產品或模型型號。

## 為何要拆開入口

Agent Skills 說明主檔在啟用後整份載入，其他資料按需取得。[R1–R3] 本版因此使 SKILL.md 只保留A／B分流、固定警告及一個有條件的業務連結。行政法分析、案件流程、搜尋指令與模組選擇移到 WORKFLOW.md；首次不讀它。

這是檔案分離與閱讀指令，不是平台硬性鎖定。網頁仍可能先處理輸入以選擇技能，也可能不依預期順序讀檔。只能用可見工具軌跡檢查是否提早載入業務內容，不能憑最後顯示警告就宣稱零解析、零推論或沒有收到資料。

## 檢查本版行為

首次：啟用及讀取 SKILL.md 後，只有完整警告；沒有再讀 WORKFLOW.md、references、Wiki、sources、templates，沒有搜尋或其他業務操作。主檔之前的技能探索另記錄，不能宣稱已阻止。

下一則：直接讀業務入口並工作；不需確認、不再警告，不對輸入另作分類或攔截。無工具軌跡的網頁只能檢查輸出，無法確認載入順序；應將該項記為不可觀察，而非通過。

## 官方依據（2026-09-20查閱）

R1. Agent Skills Specification，Body content／Progressive disclosure： https://agentskills.io/specification

R2. Claude Agent Skills，Level 1–3／How Claude accesses Skill content： https://platform.claude.com/docs/en/agents-and-tools/agent-skills/overview

R3. Claude Help Center，What are skills?： https://support.claude.com/en/articles/12512176-what-are-skills

以上支持拆分與按需載入的設計，不是本版已通過網頁模型測試的證據。
