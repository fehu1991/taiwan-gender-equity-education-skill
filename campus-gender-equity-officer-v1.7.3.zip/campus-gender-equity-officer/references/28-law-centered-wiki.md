# 法規核心唯讀 LLM Wiki

## 使用位置

後續處理問題時，先依[行政法核心](30-administrative-law-framework.md)及[結構化入口](../wiki/admin-framework.md)定性；再定位法規、適用時點及條項款，取得相關函示、條件與原文。每次啟動都是新的個案分析，不讀取、保存或累積先前個案，不將本次答案寫回 Wiki。法規頁只是預先編製的通用知識，不能作為另一項法源。

本模組與第00、24、25、26、27號模組併用：來源、法解釋與AI資料界線優先；不是新增一套必經流程。精確查文號直接取得函示即可，無須依序閱讀全部Wiki。原第17、20號模組保留承辦流程，不複製成第二份權威摘要。

## 統一查詢入口

[法規目錄](../wiki/README.md)列出全部29個法規／指引節點；[收錄範圍](../wiki/coverage.md)列出已知缺口。直接使用[查詢工具](../scripts/lookup_legal.py)，不需模型讀完整搜尋索引。

```bash
python scripts/lookup_legal.py --list --json
python scripts/lookup_legal.py --law 性平法 --article 26 --paragraph 2 --json
python scripts/lookup_legal.py --source O1612 --article 25 --full --json
python scripts/lookup_legal.py --query "心理諮商 時數" --json
python scripts/lookup_legal.py --query "性平法 第26條 心理諮商 時數" --json
python scripts/lookup_legal.py --number 1132805149 --json
python scripts/lookup_legal.py --relation CR-041 --full --json
```

`--law`接受精確全名、已登記別名、法規ID或來源代碼。`--source`限定特定來源表示；`--law U13`只選教師法節點，仍回傳可用的不同來源，不能把兩者混淆。多個條號重複使用`--article`。法條條文／指引章節依原名稱呈現，不把章節索引1稱成法定第1條。

`--paragraph`、`--item`只篩選函示中的明示條項款，不擅自將法條切成未驗證的小段；`--full`回傳所收整條／章節，保留但書及上下文。`--cross-laws`展開已選條文範圍的文字援引關係及可查來源；目標來源存在不等於已確認其為當時所據版本。

無Python時，直接讀所需法規頁、該頁連結的原資料及函示年度稿，並以全文搜尋補查；不需要讀`_index/search.json`或整個Wiki。

## 分頁、缺漏與搜尋

回傳的`articles`、`circulars`、`reading_notes`各有自己的`page`。分別以`--offset`、`--circular-offset`、`--note-offset`續頁，`--all`才取本次條件全部命中。文號精確查詢沿用既有同號多來源及純提及契約，主件不因預設10筆被切斷；精確文號模式的純提及結果以`--circular-offset`續頁，與主件頁次分開；這是本工具的參數，舊函示工具仍用`--mention-offset`。

`missing_requested_articles`表示選定來源範圍未收該條號；`requested_articles_filtered_out`表示條文存在但被關鍵字條件排除；每個`source_coverage`另列該來源缺哪些指定條號。CLI部分收錄回傳exit 3並保留可用結果，參數或完整性錯誤exit 2。兩者不可當成「不存在這條法規」。

一般關鍵字以空白分詞，組間AND，使用單字／雙字反向索引後再核對完整詞；不是語意搜尋。`--expand`才啟用明示的候選詞組擴張，組內OR，並在`search_logic`列出實際詞組；「併案」「合併議處」只是檢索詞組，不主張所有情況法律同義。無法唯一辨識法規時要求全名或代碼，不默默選一部。

法規條號查詢只涵蓋已解析的文字援引候選；沒有法規名稱、未分類、範圍、省略或遠距指代仍可能漏連。依本題需要以全域關鍵字補查，不把`other_law_related_candidates_count`或既有連結當作全集保證。

## 版本、效力與證據

法規身分共用，但來源表示與版本分開。舊附件、官方有限轉錄、函示原稿、官方摘要、編製者閱讀提示各有自己的性質。新增官方資料位於[sources/wiki-official](../sources/wiki-official/manifest.json)及[行政法補充](../sources/admin-framework/manifest.json)，是網頁選定條文人工轉錄，不是raw HTML、完整現行法或正本認證。

教師法官方查閱版本2026-05-13較U13附件新，但O1612僅收第3、25、53條；不能以舊版其他條文補成未標示的現行全文。個資法官方頁面標示部分未施行，O1603第1-1條標示尚未施行；公布日與施行日分開。附件自身`status:effective`只是原資料欄位，不由Wiki保證全條文已施行。

函示關聯的`cited_version`保持未知，歷史法名只作搜尋別名；法規頁的新版本不會自動成為舊函的適用版本。`--as-of`只提供前後函時間檢視脈絡，不能代替行為時、程序時或過渡規定的法律判斷，更不自動選取適用法版本。

`known_relation_closure`保留本頁命中在既有43條已整理關係中的連結鏈，不受關鍵字或主題篩選排除。預設只讀關係性質、範圍、日期及來源位置；關聯卡保留品質問題的發現與處理界線，但不重複原段；需來源完整欄位與文字時使用卡片的`evidence_command`。法規文字連結預設保留條項、可查版本及原段位置，完整擷取欄位以同一查詢加`--full`取得。要核對關係原段用`--relation CR-041 --full`。後函補充、部分修正、停止適用與重申不混為全面取代。已知圖完整不代表所有官方後函已收錄。

重要結論要讀支持段落及例外；已提供充分原文與上下文可重用，不機械重讀整份年度稿。`reading_notes`為編製者依據來源的閱讀提示，非官方解釋，亦沒有不存在的人工法制核准。單憑文號、連結、雜湊或機器測試成功，不能認定法律結論正確。

當次分析需要的規定未收、版本不足、存在分階段施行或相關新函時，查官方有效條文及必要歷史資料，清楚區分本次外部查核與固定套件內容。新查資料只供本案，不寫入 Skill。無網路時明示缺口對具體結論的影響，不補造來源或施行日期。

## 發布與模型適配

Wiki在製作新版時由[建置工具](../scripts/build_legal_wiki.py)產生，原來源不變、派生頁面可重建。來源、閱讀提示、建置或查詢程式、上游索引改變時，原Wiki拒絕使用，須核對後重建及驗證。一次實例使用同一核驗快照；長期實例不可跨來源更新沿用。未登記新來源不得聲稱已納入，歷史來源manifest版本不擅改成新版本。

Astra採最小必要路徑，保留證據與權限的硬限制，不要求每題讀完所有頁面；Claude按需載入，首次由SKILL.md只顯示警告，下一則才載入WORKFLOW.md；本模組與Wiki入口由該業務檔直接連到，首次不預讀。知識間關係可多層，模型不需要逐層翻資料夾找限制。普通查詢不重建、匯入或寫回案件。

本版測試驗證的是來源、索引、引用定位及工具行為；沒有執行Astra或Claude新案件作答評測，也沒有跨案件記憶功能。

## 行政法檢索

`python scripts/lookup_legal.py --law 行政程序法 --json`同時提供原有限來源與本版補充，指定單一來源可用`--source O1701`。`--query "行政法核心"`取得按法規歸屬的閱讀提示；`--source O1702 --article 33 --full --cross-laws --json`取得性平法明文銜接。

[行政法核心](../wiki/admin-framework.md)由knowledge/admin-law-framework.json發布時生成，條文引用及銜接原句均經位置存在性核對。這不等於法律涵攝獲得認證；不將所有函示一律掛上行政程序法適用結論。
