# 行政法核心檢核入口

以行政法為總體分析框架，性別平等教育法及其授權子法為特別行政法依據。行政程序法不是性平法的形式上母法，也不是可以一律優先適用的上位法。

本次問題的公私法與行為性質 → 特別規定及適用／準用 → 必要行政法審查 → 結論優先輸出。首層警示僅在首次啟用顯示，不附帶後續內容攔截。

本頁是Skill分析架構，不是官方解釋。只在本題相關處展開；首層警示不附帶後續內容攔截。
[完整使用界線](../references/30-administrative-law-framework.md)；[行政程序法](laws/tw-administrative-procedure-act.md)；[性平法](laws/tw-gender-equity-education-act.md)。

## 特別法銜接

行政程序法有關管轄、移送、迴避、送達、補正等相關規定，於本法適用或準用之。

依據：性平法第33條第6項；明文列舉及等相關規定須依具體事項確認；不推為全法直接適用。

## 公私法與行政行為性質

現在要判斷的是哪一個決定、措施或程序？誰作成，是否對外直接發生法律效果？

分辨行政處分、程序行為、事實行為、行政指導及私法行為；不能只依校名、公私立、職稱、文件名稱或由性平會作成，就判定法律性質。行政法核心不排除另有民事、勞動、刑事規範。

依據定位：
- [O1701:2 行政程序法第2條](../sources/admin-framework/O1701.json)；`/articles/0`。
- [O1701:92 行政程序法第92條](../sources/admin-framework/O1701.json)；`/articles/5`。
- [O1601:3 行政程序法第3條](../sources/wiki-official/O1601.json)；`/articles/0`。
- [O1702:33 性別平等教育法第33條](../sources/admin-framework/O1702.json)；`/articles/0`。

## 法源位階、法律依據與版本

對本措施有無法律依據、授權或特別規定？函示究竟解釋哪一條、作用於何種範圍？

法律優位、法律保留、特別法優先與法定授權分開；比例或公益不是獨立創設強制權限的法源。函釋、指引、校規、工作建議不混同，特別法優先也不代表可無視上位規範。

依據定位：
- [O1601:4 行政程序法第4條](../sources/wiki-official/O1601.json)；`/articles/1`。
- [O1701:150 行政程序法第150條](../sources/admin-framework/O1701.json)；`/articles/13`。
- [O1701:158 行政程序法第158條](../sources/admin-framework/O1701.json)；`/articles/14`。
- [O1601:159 行政程序法第159條](../sources/wiki-official/O1601.json)；`/articles/10`。
- [O1601:161 行政程序法第161條](../sources/wiki-official/O1601.json)；`/articles/12`。
- [O1607:11 中央法規標準法第11條](../sources/wiki-official/O1607.json)；`/articles/0`。
- [O1607:16 中央法規標準法第16條](../sources/wiki-official/O1607.json)；`/articles/4`。

## 組織、管轄與決定權限

性平會、調查小組、主席、學校、主管機關、教評或人事單位各負責什麼？

受理、調查認定、議處、核定、通知與執行分開；會議共識、主管口頭同意或承辦專業，不能取代法定權限。管轄細節仍核性平特別規定及行政程序法相關條文。

依據定位：
- [U02:6 性別平等教育法第 6 條](../sources/uploaded/%E6%80%A7%E5%88%A5%E5%B9%B3%E7%AD%89%E6%95%99%E8%82%B2%E6%B3%95.json)；`/regulation/articles/5`。
- [U02:31 性別平等教育法第 31 條](../sources/uploaded/%E6%80%A7%E5%88%A5%E5%B9%B3%E7%AD%89%E6%95%99%E8%82%B2%E6%B3%95.json)；`/regulation/articles/30`。
- [O1702:33 性別平等教育法第33條](../sources/admin-framework/O1702.json)；`/articles/0`。
- [O1702:36 性別平等教育法第36條](../sources/admin-framework/O1702.json)；`/articles/2`。
- [O1702:40 性別平等教育法第40條](../sources/admin-framework/O1702.json)；`/articles/5`。
- [O1604:4 各級學校性別平等教育委員會設置準則第4條](../sources/wiki-official/O1604.json)；`/articles/2`。
- [O1604:5 各級學校性別平等教育委員會設置準則第5條](../sources/wiki-official/O1604.json)；`/articles/3`。

## 程序合法性與參與保障

組成、迴避、通知、陳述、證據、閱卷與保密、期間及送達是否依正確規範辦理？

第3條教育內部程序／人事例外須辨識具體行為；不得略過性平法第33條第6項等特別銜接。不能把所有程序權利一律排除，也不能把行政程序法全部機械套用；陳述意見與保密均有適用條件。 性平法第23條的說明答辯保障及第26條第5項的身分變更書面陳述規定優先逐一確認，不因行政程序法第3條例外而遺漏。

依據定位：
- [O1601:3 行政程序法第3條](../sources/wiki-official/O1601.json)；`/articles/0`。
- [O1601:32 行政程序法第32條](../sources/wiki-official/O1601.json)；`/articles/7`。
- [O1601:33 行政程序法第33條](../sources/wiki-official/O1601.json)；`/articles/8`。
- [O1601:48 行政程序法第48條](../sources/wiki-official/O1601.json)；`/articles/9`。
- [O1702:33 性別平等教育法第33條](../sources/admin-framework/O1702.json)；`/articles/0`。
- [O1702:36 性別平等教育法第36條](../sources/admin-framework/O1702.json)；`/articles/2`。
- [O1701:46 行政程序法第46條](../sources/admin-framework/O1701.json)；`/articles/4`。
- [O1701:102 行政程序法第102條](../sources/admin-framework/O1701.json)；`/articles/8`。
- [O1701:103 行政程序法第103條](../sources/admin-framework/O1701.json)；`/articles/9`。
- [U02:23 性別平等教育法第 23 條](../sources/uploaded/%E6%80%A7%E5%88%A5%E5%B9%B3%E7%AD%89%E6%95%99%E8%82%B2%E6%B3%95.json)；`/regulation/articles/22`。
- [O1613:26 性別平等教育法第26條](../sources/wiki-official/O1613.json)；`/articles/2`。

## 實體要件、事實與裁量控制

法定要件有何證據支持？有利與不利資料是否兼顧？目的、明確性、平等、比例與裁量有無問題？

調查與司法程序分開；不因刑事未定罪就自動排除校園程序，也不自行生成特定證明程度。處置是否屬行政罰須另判斷；不將教育處置、懲處、預防措施及任用資格限制全部等同行政罰。

依據定位：
- [O1601:4 行政程序法第4條](../sources/wiki-official/O1601.json)；`/articles/1`。
- [O1601:5 行政程序法第5條](../sources/wiki-official/O1601.json)；`/articles/2`。
- [O1601:6 行政程序法第6條](../sources/wiki-official/O1601.json)；`/articles/3`。
- [O1701:7 行政程序法第7條](../sources/admin-framework/O1701.json)；`/articles/1`。
- [O1601:8 行政程序法第8條](../sources/wiki-official/O1601.json)；`/articles/4`。
- [O1601:9 行政程序法第9條](../sources/wiki-official/O1601.json)；`/articles/5`。
- [O1601:10 行政程序法第10條](../sources/wiki-official/O1601.json)；`/articles/6`。
- [O1701:36 行政程序法第36條](../sources/admin-framework/O1701.json)；`/articles/2`。
- [O1701:43 行政程序法第43條](../sources/admin-framework/O1701.json)；`/articles/3`。
- [O1702:34 性別平等教育法第34條](../sources/admin-framework/O1702.json)；`/articles/1`。

## 法律效果、瑕疵與補正

是否已作成及對外生效？瑕疵是無效、得撤銷或可依法補正，還是僅屬內部程序問題？

不能一見違法即宣告自始無效；不能以事後簽名或會議紀錄偽造補正，也不把第114條誤當一律可先做再追認的授權。補正、撤銷與停止執行的要件、權限、期間須另核。

依據定位：
- [O1701:96 行政程序法第96條](../sources/admin-framework/O1701.json)；`/articles/6`。
- [O1701:97 行政程序法第97條](../sources/admin-framework/O1701.json)；`/articles/7`。
- [O1701:110 行政程序法第110條](../sources/admin-framework/O1701.json)；`/articles/10`。
- [O1701:111 行政程序法第111條](../sources/admin-framework/O1701.json)；`/articles/11`。
- [O1701:114 行政程序法第114條](../sources/admin-framework/O1701.json)；`/articles/12`。
- [O1702:36 性別平等教育法第36條](../sources/admin-framework/O1702.json)；`/articles/2`。
- [O1702:37 性別平等教育法第37條](../sources/admin-framework/O1702.json)；`/articles/3`。
- [O1702:40 性別平等教育法第40條](../sources/admin-framework/O1702.json)；`/articles/5`。

## 申復、申訴、訴願與司法救濟

哪個人針對哪個結果不服？身分、行為性質、送達與特別救濟程序為何？

申復不等於申訴或訴願；不要把所有案件導向行政訴訟。依具體身分與爭議標的確認特別途徑，涉及行政罰法、行政訴訟法、勞動或民事規定而未收時另查官方資料。

依據定位：
- [O1702:37 性別平等教育法第37條](../sources/admin-framework/O1702.json)；`/articles/3`。
- [O1702:39 性別平等教育法第39條](../sources/admin-framework/O1702.json)；`/articles/4`。
- [O1702:40 性別平等教育法第40條](../sources/admin-framework/O1702.json)；`/articles/5`。
- [O1608:1 訴願法第1條](../sources/wiki-official/O1608.json)；`/articles/0`。
- [O1608:14 訴願法第14條](../sources/wiki-official/O1608.json)；`/articles/1`。
- [O1608:17 訴願法第17條](../sources/wiki-official/O1608.json)；`/articles/2`。

## 輸出

只在本題有影響的面向展開；首段先結論與必要條件，再給法源、可檢查的涵攝與理由，不輸出隱藏思考鏈。

未收法源依當次問題查官方資料，不向Skill寫回案件。
