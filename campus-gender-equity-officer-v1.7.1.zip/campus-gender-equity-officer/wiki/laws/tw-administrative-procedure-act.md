# 行政程序法

本頁是法規核心導覽及有依據的閱讀提示，不是新的法源或個案認定。
函示連結所據版本仍待確認；優先選定適用版本，再核對原文與例外。

## 版本與收錄範圍

| 來源 | 修正／觀察日期 | 收錄 | 原資料 |
|---|---|---|---|
| O1601 | 2021-01-20 | 官方頁面部分條文轉錄（17條／章節） | [來源](../../sources/wiki-official/O1601.json) |

| O1701 | 2021-01-20 | 官方頁面部分條文轉錄（15條／章節） | [來源](../../sources/admin-framework/O1701.json) |


**O1601**：第3條、第4條、第5條、第6條、第8條、第9條、第10條、第32條、第33條、第48條、第159條、第160條、第161條、第162條、第165條、第166條、第167條。

適用程序前先檢查第3條與特別法；本次未收全法，未核對之條文須回官方全文。

[官方網頁](https://mojlaw.moj.gov.tw/LawContent.aspx?LSID=FL000632)；查閱：2026-09-19。

**O1701**：第2條、第7條、第36條、第43條、第46條、第92條、第96條、第97條、第102條、第103條、第110條、第111條、第114條、第150條、第158條。

只收本檔明列條文；其他條號未收錄不表示不存在。

行政程序法程序規定先核第3條與特別法適用／準用，不能機械套用。

[官方網頁](https://law.moj.gov.tw/LawClass/LawAll.aspx?pcode=A0030055)；查閱：2026-09-19。

## 函示的效力及程序適用

第159至162條區分行政規則的性質、下達、發布、拘束及廢止；第165至167條處理行政指導。先看文件內容、對象、依據及發布方式，不只依「函」「令」標題判斷效力。涉及學校程序時另核對第3條及特別法。

適用界線：不是每份函都屬行政規則，也不是每份函都直接對人民產生義務；本文不是對全庫函示逐份完成效力分類。

依據：O1601:3、O1601:159、O1601:160、O1601:161、O1601:162、O1601:165、O1601:166、O1601:167。這是編製者閱讀提示，未取得人工法制審核，不代替來源。

- [O1601:3 第3條](../../sources/wiki-official/O1601.json)；JSON位置 `/articles/0`。

- [O1601:159 第159條](../../sources/wiki-official/O1601.json)；JSON位置 `/articles/10`。

- [O1601:160 第160條](../../sources/wiki-official/O1601.json)；JSON位置 `/articles/11`。

- [O1601:161 第161條](../../sources/wiki-official/O1601.json)；JSON位置 `/articles/12`。

- [O1601:162 第162條](../../sources/wiki-official/O1601.json)；JSON位置 `/articles/13`。

- [O1601:165 第165條](../../sources/wiki-official/O1601.json)；JSON位置 `/articles/14`。

- [O1601:166 第166條](../../sources/wiki-official/O1601.json)；JSON位置 `/articles/15`。

- [O1601:167 第167條](../../sources/wiki-official/O1601.json)；JSON位置 `/articles/16`。

## 行政法核心：公私法與行政行為性質

現在要判斷的是哪一個決定、措施或程序？誰作成，是否對外直接發生法律效果？ 分辨行政處分、程序行為、事實行為、行政指導及私法行為；不能只依校名、公私立、職稱、文件名稱或由性平會作成，就判定法律性質。行政法核心不排除另有民事、勞動、刑事規範。

適用界線：本Skill的行政法分析提示；只在本題相關時使用。先辨特別規定、行政程序法第3條及性平法第33條第6項，不推定全法適用或完成個案認定。

依據：O1701:2、O1701:92、O1601:3、O1702:33。這是編製者閱讀提示，未取得人工法制審核，不代替來源。

- [O1701:2 第2條](../../sources/admin-framework/O1701.json)；JSON位置 `/articles/0`。

- [O1701:92 第92條](../../sources/admin-framework/O1701.json)；JSON位置 `/articles/5`。

- [O1601:3 第3條](../../sources/wiki-official/O1601.json)；JSON位置 `/articles/0`。

- [O1702:33 第33條](../../sources/admin-framework/O1702.json)；JSON位置 `/articles/0`。

## 行政法核心：法源位階、法律依據與版本

對本措施有無法律依據、授權或特別規定？函示究竟解釋哪一條、作用於何種範圍？ 法律優位、法律保留、特別法優先與法定授權分開；比例或公益不是獨立創設強制權限的法源。函釋、指引、校規、工作建議不混同，特別法優先也不代表可無視上位規範。

適用界線：本Skill的行政法分析提示；只在本題相關時使用。先辨特別規定、行政程序法第3條及性平法第33條第6項，不推定全法適用或完成個案認定。

依據：O1601:4、O1701:150、O1701:158、O1601:159、O1601:161、O1607:11、O1607:16。這是編製者閱讀提示，未取得人工法制審核，不代替來源。

- [O1601:4 第4條](../../sources/wiki-official/O1601.json)；JSON位置 `/articles/1`。

- [O1701:150 第150條](../../sources/admin-framework/O1701.json)；JSON位置 `/articles/13`。

- [O1701:158 第158條](../../sources/admin-framework/O1701.json)；JSON位置 `/articles/14`。

- [O1601:159 第159條](../../sources/wiki-official/O1601.json)；JSON位置 `/articles/10`。

- [O1601:161 第161條](../../sources/wiki-official/O1601.json)；JSON位置 `/articles/12`。

- [O1607:11 第11條](../../sources/wiki-official/O1607.json)；JSON位置 `/articles/0`。

- [O1607:16 第16條](../../sources/wiki-official/O1607.json)；JSON位置 `/articles/4`。

## 行政法核心：組織、管轄與決定權限

性平會、調查小組、主席、學校、主管機關、教評或人事單位各負責什麼？ 受理、調查認定、議處、核定、通知與執行分開；會議共識、主管口頭同意或承辦專業，不能取代法定權限。管轄細節仍核性平特別規定及行政程序法相關條文。

適用界線：本Skill的行政法分析提示；只在本題相關時使用。先辨特別規定、行政程序法第3條及性平法第33條第6項，不推定全法適用或完成個案認定。

依據：U02:6、U02:31、O1702:33、O1702:36、O1702:40、O1604:4、O1604:5。這是編製者閱讀提示，未取得人工法制審核，不代替來源。

- [U02:6 第 6 條](../../sources/uploaded/%E6%80%A7%E5%88%A5%E5%B9%B3%E7%AD%89%E6%95%99%E8%82%B2%E6%B3%95.json)；JSON位置 `/regulation/articles/5`。

- [U02:31 第 31 條](../../sources/uploaded/%E6%80%A7%E5%88%A5%E5%B9%B3%E7%AD%89%E6%95%99%E8%82%B2%E6%B3%95.json)；JSON位置 `/regulation/articles/30`。

- [O1702:33 第33條](../../sources/admin-framework/O1702.json)；JSON位置 `/articles/0`。

- [O1702:36 第36條](../../sources/admin-framework/O1702.json)；JSON位置 `/articles/2`。

- [O1702:40 第40條](../../sources/admin-framework/O1702.json)；JSON位置 `/articles/5`。

- [O1604:4 第4條](../../sources/wiki-official/O1604.json)；JSON位置 `/articles/2`。

- [O1604:5 第5條](../../sources/wiki-official/O1604.json)；JSON位置 `/articles/3`。

## 行政法核心：程序合法性與參與保障

組成、迴避、通知、陳述、證據、閱卷與保密、期間及送達是否依正確規範辦理？ 第3條教育內部程序／人事例外須辨識具體行為；不得略過性平法第33條第6項等特別銜接。不能把所有程序權利一律排除，也不能把行政程序法全部機械套用；陳述意見與保密均有適用條件。

適用界線：本Skill的行政法分析提示；只在本題相關時使用。先辨特別規定、行政程序法第3條及性平法第33條第6項，不推定全法適用或完成個案認定。

依據：O1601:3、O1601:32、O1601:33、O1601:48、O1702:33、O1702:36、O1701:46、O1701:102、O1701:103。這是編製者閱讀提示，未取得人工法制審核，不代替來源。

- [O1601:3 第3條](../../sources/wiki-official/O1601.json)；JSON位置 `/articles/0`。

- [O1601:32 第32條](../../sources/wiki-official/O1601.json)；JSON位置 `/articles/7`。

- [O1601:33 第33條](../../sources/wiki-official/O1601.json)；JSON位置 `/articles/8`。

- [O1601:48 第48條](../../sources/wiki-official/O1601.json)；JSON位置 `/articles/9`。

- [O1702:33 第33條](../../sources/admin-framework/O1702.json)；JSON位置 `/articles/0`。

- [O1702:36 第36條](../../sources/admin-framework/O1702.json)；JSON位置 `/articles/2`。

- [O1701:46 第46條](../../sources/admin-framework/O1701.json)；JSON位置 `/articles/4`。

- [O1701:102 第102條](../../sources/admin-framework/O1701.json)；JSON位置 `/articles/8`。

- [O1701:103 第103條](../../sources/admin-framework/O1701.json)；JSON位置 `/articles/9`。

## 行政法核心：實體要件、事實與裁量控制

法定要件有何證據支持？有利與不利資料是否兼顧？目的、明確性、平等、比例與裁量有無問題？ 調查與司法程序分開；不因刑事未定罪就自動排除校園程序，也不自行生成特定證明程度。處置是否屬行政罰須另判斷；不將教育處置、懲處、預防措施及任用資格限制全部等同行政罰。

適用界線：本Skill的行政法分析提示；只在本題相關時使用。先辨特別規定、行政程序法第3條及性平法第33條第6項，不推定全法適用或完成個案認定。

依據：O1601:4、O1601:5、O1601:6、O1701:7、O1601:8、O1601:9、O1601:10、O1701:36、O1701:43、O1702:34。這是編製者閱讀提示，未取得人工法制審核，不代替來源。

- [O1601:4 第4條](../../sources/wiki-official/O1601.json)；JSON位置 `/articles/1`。

- [O1601:5 第5條](../../sources/wiki-official/O1601.json)；JSON位置 `/articles/2`。

- [O1601:6 第6條](../../sources/wiki-official/O1601.json)；JSON位置 `/articles/3`。

- [O1701:7 第7條](../../sources/admin-framework/O1701.json)；JSON位置 `/articles/1`。

- [O1601:8 第8條](../../sources/wiki-official/O1601.json)；JSON位置 `/articles/4`。

- [O1601:9 第9條](../../sources/wiki-official/O1601.json)；JSON位置 `/articles/5`。

- [O1601:10 第10條](../../sources/wiki-official/O1601.json)；JSON位置 `/articles/6`。

- [O1701:36 第36條](../../sources/admin-framework/O1701.json)；JSON位置 `/articles/2`。

- [O1701:43 第43條](../../sources/admin-framework/O1701.json)；JSON位置 `/articles/3`。

- [O1702:34 第34條](../../sources/admin-framework/O1702.json)；JSON位置 `/articles/1`。

## 行政法核心：法律效果、瑕疵與補正

是否已作成及對外生效？瑕疵是無效、得撤銷或可依法補正，還是僅屬內部程序問題？ 不能一見違法即宣告自始無效；不能以事後簽名或會議紀錄偽造補正，也不把第114條誤當一律可先做再追認的授權。補正、撤銷與停止執行的要件、權限、期間須另核。

適用界線：本Skill的行政法分析提示；只在本題相關時使用。先辨特別規定、行政程序法第3條及性平法第33條第6項，不推定全法適用或完成個案認定。

依據：O1701:96、O1701:97、O1701:110、O1701:111、O1701:114、O1702:36、O1702:37、O1702:40。這是編製者閱讀提示，未取得人工法制審核，不代替來源。

- [O1701:96 第96條](../../sources/admin-framework/O1701.json)；JSON位置 `/articles/6`。

- [O1701:97 第97條](../../sources/admin-framework/O1701.json)；JSON位置 `/articles/7`。

- [O1701:110 第110條](../../sources/admin-framework/O1701.json)；JSON位置 `/articles/10`。

- [O1701:111 第111條](../../sources/admin-framework/O1701.json)；JSON位置 `/articles/11`。

- [O1701:114 第114條](../../sources/admin-framework/O1701.json)；JSON位置 `/articles/12`。

- [O1702:36 第36條](../../sources/admin-framework/O1702.json)；JSON位置 `/articles/2`。

- [O1702:37 第37條](../../sources/admin-framework/O1702.json)；JSON位置 `/articles/3`。

- [O1702:40 第40條](../../sources/admin-framework/O1702.json)；JSON位置 `/articles/5`。

## 行政法核心：申復、申訴、訴願與司法救濟

哪個人針對哪個結果不服？身分、行為性質、送達與特別救濟程序為何？ 申復不等於申訴或訴願；不要把所有案件導向行政訴訟。依具體身分與爭議標的確認特別途徑，涉及行政罰法、行政訴訟法、勞動或民事規定而未收時另查官方資料。

適用界線：本Skill的行政法分析提示；只在本題相關時使用。先辨特別規定、行政程序法第3條及性平法第33條第6項，不推定全法適用或完成個案認定。

依據：O1702:37、O1702:39、O1702:40、O1608:1、O1608:14、O1608:17。這是編製者閱讀提示，未取得人工法制審核，不代替來源。

- [O1702:37 第37條](../../sources/admin-framework/O1702.json)；JSON位置 `/articles/3`。

- [O1702:39 第39條](../../sources/admin-framework/O1702.json)；JSON位置 `/articles/4`。

- [O1702:40 第40條](../../sources/admin-framework/O1702.json)；JSON位置 `/articles/5`。

- [O1608:1 第1條](../../sources/wiki-official/O1608.json)；JSON位置 `/articles/0`。

- [O1608:14 第14條](../../sources/wiki-official/O1608.json)；JSON位置 `/articles/1`。

- [O1608:17 第17條](../../sources/wiki-official/O1608.json)；JSON位置 `/articles/2`。

## 函示與跨法規查找

本法規名稱／明確條項款候選涵蓋 36 筆函示；候選不是法律解釋認證。
`python scripts/lookup_legal.py --law O1601 --json`

[函示關聯目錄](../circulars/tw-administrative-procedure-act.md)。查特定條文另加 `--article`；法條與函示各自分頁。
需要跨法規連結加 `--cross-laws`；需要特定原文加 `--full`。
未分類、未解析及僅提及資料另以全域關鍵字補查，不把本頁連結當成法源全集。
