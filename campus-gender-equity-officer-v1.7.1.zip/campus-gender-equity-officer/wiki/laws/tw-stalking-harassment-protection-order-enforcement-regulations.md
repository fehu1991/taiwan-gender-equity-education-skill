# 跟蹤騷擾案件保護令執行辦法

本頁是法規核心導覽及有依據的閱讀提示，不是新的法源或個案認定。
函示連結所據版本仍待確認；優先選定適用版本，再核對原文與例外。

## 版本與收錄範圍

| 來源 | 修正／觀察日期 | 收錄 | 原資料 |
|---|---|---|---|
| U17 | 2022-03-18 | 附件條目集；非現行認證（8條／章節） | [來源](../../sources/uploaded/%E8%B7%9F%E8%B9%A4%E9%A8%B7%E6%93%BE%E6%A1%88%E4%BB%B6%E4%BF%9D%E8%AD%B7%E4%BB%A4%E5%9F%B7%E8%A1%8C%E8%BE%A6%E6%B3%95.json) |

**U17**：第 1 條、第 2 條、第 3 條、第 4 條、第 5 條、第 6 條、第 7 條、第 8 條。

來源 PDF未載明主管機關，authority 依規範填「未提供」。

來源 PDF未印出官方法規代碼，code 依規範填「UNKNOWN」。

## 函示與跨法規查找

本法規名稱／明確條項款候選涵蓋 0 筆函示；候選不是法律解釋認證。
`python scripts/lookup_legal.py --law U17 --json`

[函示關聯目錄](../circulars/tw-stalking-harassment-protection-order-enforcement-regulations.md)。查特定條文另加 `--article`；法條與函示各自分頁。
需要跨法規連結加 `--cross-laws`；需要特定原文加 `--full`。
未分類、未解析及僅提及資料另以全域關鍵字補查，不把本頁連結當成法源全集。
