# 中央法規標準法

本頁是法規核心導覽及有依據的閱讀提示，不是新的法源或個案認定。
函示連結所據版本仍待確認；優先選定適用版本，再核對原文與例外。

## 版本與收錄範圍

| 來源 | 修正／觀察日期 | 收錄 | 原資料 |
|---|---|---|---|
| O1607 | 2004-05-19 | 官方頁面部分條文轉錄（7條／章節） | [來源](../../sources/wiki-official/O1607.json) |


**O1607**：第11條、第12條、第13條、第14條、第16條、第17條、第18條。

第18條有聲請許可案件等前提，不能概括作為所有性平案件新舊法規則。

[官方網頁](https://law.moj.gov.tw/LawClass/LawAll.aspx?pcode=A0030133)；查閱：2026-09-19。

## 法規位階與施行不能只依日期排序

第11條規範位階、第12至14條處理施行，第16條處理特別規定。第18條以受理人民聲請許可等情境為前提，不是所有法律問題一律從新從優的公式。

適用界線：本案是否存在特別規定與新舊法問題仍須涵攝；不推定較新函示可以改變較高位階法規。

依據：O1607:11、O1607:12、O1607:13、O1607:14、O1607:16、O1607:18。這是編製者閱讀提示，未取得人工法制審核，不代替來源。

- [O1607:11 第11條](../../sources/wiki-official/O1607.json)；JSON位置 `/articles/0`。

- [O1607:12 第12條](../../sources/wiki-official/O1607.json)；JSON位置 `/articles/1`。

- [O1607:13 第13條](../../sources/wiki-official/O1607.json)；JSON位置 `/articles/2`。

- [O1607:14 第14條](../../sources/wiki-official/O1607.json)；JSON位置 `/articles/3`。

- [O1607:16 第16條](../../sources/wiki-official/O1607.json)；JSON位置 `/articles/4`。

- [O1607:18 第18條](../../sources/wiki-official/O1607.json)；JSON位置 `/articles/6`。

## 函示與跨法規查找

本法規名稱／明確條項款候選涵蓋 1 筆函示；候選不是法律解釋認證。
`python scripts/lookup_legal.py --law O1607 --json`

[函示關聯目錄](../circulars/tw-central-regulation-standard-act.md)。查特定條文另加 `--article`；法條與函示各自分頁。
需要跨法規連結加 `--cross-laws`；需要特定原文加 `--full`。
未分類、未解析及僅提及資料另以全域關鍵字補查，不把本頁連結當成法源全集。
