# 不適任教育人員之通報資訊蒐集及查詢處理利用辦法

本頁是法規核心導覽及有依據的閱讀提示，不是新的法源或個案認定。
函示連結所據版本仍待確認；優先選定適用版本，再核對原文與例外。

## 版本與收錄範圍

| 來源 | 修正／觀察日期 | 收錄 | 原資料 |
|---|---|---|---|
| O1610 | 2026-06-05 | 官方頁面部分條文轉錄（4條／章節） | [來源](../../sources/wiki-official/O1610.json) |


**O1610**：第1條、第3條、第4條、第5條。

本次補收2026-06-05版本部分條文；與另一不適任學校人員辦法的對象及依據不同，不能混用。

[官方網頁](https://edu.law.moe.gov.tw/LawContent.aspx?id=GL001062)；查閱：2026-09-19。

## 兩種不適任通報辦法分開

本辦法第1條以教育人員任用條例及教師法為依據；另一不適任學校人員辦法依性平法第30條訂定。應按人員身分、適用法源及程序查找，不只因名稱相似就合併。

適用界線：收錄範圍不同且皆非全文，通報期限、資格及解除登載條件須讀各自來源。

依據：O1610:1、O1610:3、O1610:4、O1610:5、O1611:1、O1611:2。這是編製者閱讀提示，未取得人工法制審核，不代替來源。

- [O1610:1 第1條](../../sources/wiki-official/O1610.json)；JSON位置 `/articles/0`。

- [O1610:3 第3條](../../sources/wiki-official/O1610.json)；JSON位置 `/articles/1`。

- [O1610:4 第4條](../../sources/wiki-official/O1610.json)；JSON位置 `/articles/2`。

- [O1610:5 第5條](../../sources/wiki-official/O1610.json)；JSON位置 `/articles/3`。

- [O1611:1 第1條](../../sources/wiki-official/O1611.json)；JSON位置 `/articles/0`。

- [O1611:2 第2條](../../sources/wiki-official/O1611.json)；JSON位置 `/articles/1`。

## 函示與跨法規查找

本法規名稱／明確條項款候選涵蓋 0 筆函示；候選不是法律解釋認證。
`python scripts/lookup_legal.py --law O1610 --json`

[函示關聯目錄](../circulars/tw-unfit-educational-personnel-reporting-regulations.md)。查特定條文另加 `--article`；法條與函示各自分頁。
需要跨法規連結加 `--cross-laws`；需要特定原文加 `--full`。
未分類、未解析及僅提及資料另以全域關鍵字補查，不把本頁連結當成法源全集。
