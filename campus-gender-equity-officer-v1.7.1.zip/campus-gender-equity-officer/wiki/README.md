# 法規核心唯讀 LLM Wiki

從適用法規與版本定位條文，再連結函示、解釋條件與必要前後函。每次啟動分析新案件，不保存或累積案件。
本目錄與全部頁面由來源及 `knowledge/law-wiki-notes.json` 在發布階段產生，執行時不得改寫。
只閱讀本題需要的頁面。已知文號仍可直接用函示工具，不必逐層走訪Wiki。

[使用規則](../references/28-law-centered-wiki.md)；[涵蓋範圍與缺口](coverage.md)；[行政法核心](admin-framework.md)。

法規定位以行政法為分析框架，先辨行為性質、特別規定及適用／準用；行政程序法不是性平法的形式上母法。

| 法規／指引 | 來源 | 法規頁 |
|---|---|---|
| 行政程序法 | O1601,O1701 | [法規頁](laws/tw-administrative-procedure-act.md) |
| 性別平等工作法 | O1602 | [法規頁](laws/tw-gender-equality-employment-act.md) |
| 個人資料保護法 | O1603 | [法規頁](laws/tw-personal-data-protection-act.md) |
| 各級學校性別平等教育委員會設置準則 | O1604 | [法規頁](laws/tw-school-gender-equity-committee-standards.md) |
| 公務人員保障法 | O1605 | [法規頁](laws/tw-civil-service-protection-act.md) |
| 公務員服務法 | O1606 | [法規頁](laws/tw-civil-servants-service-act.md) |
| 中央法規標準法 | O1607 | [法規頁](laws/tw-central-regulation-standard-act.md) |
| 訴願法 | O1608 | [法規頁](laws/tw-petitions-and-appeals-act.md) |
| 兒童及少年福利與權益保障法 | O1609 | [法規頁](laws/tw-child-youth-welfare-rights-protection-act.md) |
| 不適任教育人員之通報資訊蒐集及查詢處理利用辦法 | O1610 | [法規頁](laws/tw-unfit-educational-personnel-reporting-regulations.md) |
| 涉性別事件之學校不適任人員通報資訊蒐集及查詢處理利用辦法 | O1611 | [法規頁](laws/tw-unfit-school-personnel-gender-reporting-regulations.md) |
| 兒童及少年性剝削防制條例 | U01 | [法規頁](laws/tw-child-youth-sexual-exploitation-prevention-act.md) |
| 性別平等教育法 | U02,O1613,O1702 | [法規頁](laws/tw-gender-equity-education-act.md) |
| 性別平等教育法施行細則 | U03 | [法規頁](laws/tw-gender-equity-education-act-enforcement-rules.md) |
| 性侵害犯罪防治法 | U04 | [法規頁](laws/tw-sexual-assault-crime-prevention-act.md) |
| 性侵害犯罪防治法施行細則 | U05 | [法規頁](laws/tw-sexual-assault-crime-prevention-act-enforcement-rules.md) |
| 性騷擾防治法 | U06 | [法規頁](laws/tw-sexual-harassment-prevention-act.md) |
| 性騷擾防治法施行細則 | U07 | [法規頁](laws/tw-sexual-harassment-prevention-act-enforcement-rules.md) |
| 性騷擾防治準則 | U08 | [法規頁](laws/tw-sexual-harassment-prevention-standards.md) |
| 校園性別事件防治準則 | U09,O1614 | [法規頁](laws/tw-campus-gender-incident-prevention-standards.md) |
| 專科以上學校兼任教師聘任辦法 | U10 | [法規頁](laws/tw-part-time-teacher-appointment-regulations.md) |
| 教育人員任用條例 | U11 | [法規頁](laws/tw-educational-personnel-employment-act.md) |
| 教育部「學校校長及教職員工違反與性或性別有關之專業倫理防治指引」 | U12 | [法規頁](laws/edu-professional-ethics-prevention-guidelines.md) |
| 教師法 | U13,O1612 | [法規頁](laws/tw-teachers-act.md) |
| 教師法施行細則 | U14 | [法規頁](laws/tw-teachers-act-enforcement-rules.md) |
| 跟蹤騷擾防制法 | U15 | [法規頁](laws/tw-stalking-harassment-prevention-act.md) |
| 跟蹤騷擾防制法施行細則 | U16 | [法規頁](laws/tw-stalking-harassment-prevention-act-enforcement-rules.md) |
| 跟蹤騷擾案件保護令執行辦法 | U17 | [法規頁](laws/tw-stalking-harassment-protection-order-enforcement-regulations.md) |
| 大學法 | U18 | [法規頁](laws/tw-university-act.md) |

精確查詢：`python scripts/lookup_legal.py --law 性平法 --article 26 --json`。
跨來源搜尋：`python scripts/lookup_legal.py --query "心理諮商 時數" --json`。
只要詞組可能不同，可明示 `--expand`，顯示的替代詞只作檢索，不主張法律概念相等。
所有重要法律結論仍回讀條文及函示支持段落；版本未知、原件未收、部分尚未施行均不能被頁面摘要消除。
