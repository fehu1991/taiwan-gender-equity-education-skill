"""Parse and validate the Skill frontmatter; release-time only, not a retrieval dependency."""
from __future__ import annotations
import re
from typing import Any
import yaml

class UniqueKeyLoader(yaml.SafeLoader):
    pass

def _mapping(loader: UniqueKeyLoader, node: yaml.MappingNode, deep: bool = False) -> dict[str, Any]:
    result = {}
    for key_node, value_node in node.value:
        key = loader.construct_object(key_node, deep=deep)
        if not isinstance(key, str):
            raise ValueError('YAML欄位名稱必須為字串。')
        if key in result:
            raise ValueError('YAML欄位重複：' + key)
        result[key] = loader.construct_object(value_node, deep=deep)
    return result

UniqueKeyLoader.add_constructor(yaml.resolver.BaseResolver.DEFAULT_MAPPING_TAG, _mapping)

def parse_frontmatter(text: str) -> dict[str, Any]:
    match = re.match(r'\A---\r?\n(.*?)\r?\n---(?:\r?\n|$)', text, re.S)
    if not match:
        raise ValueError('SKILL.md缺少完整YAML前置資料。')
    try:
        obj = yaml.load(match.group(1), Loader=UniqueKeyLoader)
    except yaml.YAMLError as exc:
        raise ValueError('YAML解析失敗：' + str(exc)) from exc
    if not isinstance(obj, dict):
        raise ValueError('前置資料必須為對應表。')
    return obj

def validate_frontmatter(text: str, *, folder_name: str, version: str) -> dict[str, Any]:
    data = parse_frontmatter(text)
    allowed = {'name', 'description', 'license', 'compatibility', 'metadata', 'allowed-tools'}
    if set(data) - allowed:
        raise ValueError('非本套件採用之可攜式欄位：' + ', '.join(sorted(set(data) - allowed)))
    name, description = data.get('name'), data.get('description')
    if not isinstance(name, str) or len(name) > 64 or not re.fullmatch(r'[a-z0-9]+(?:-[a-z0-9]+)*', name) or name != folder_name:
        raise ValueError('name格式、長度或資料夾名稱不符。')
    if not isinstance(description, str) or not description.strip() or len(description) > 1024 or re.search(r'<[^>]*>', description):
        raise ValueError('description須為1至1024字元且不含XML標籤。')
    compatibility = data.get('compatibility')
    if compatibility is not None and (not isinstance(compatibility, str) or not compatibility.strip() or len(compatibility) > 500):
        raise ValueError('compatibility須為1至500字元字串。')
    metadata = data.get('metadata', {})
    if not isinstance(metadata, dict) or any(not isinstance(k, str) or not isinstance(v, str) for k, v in metadata.items()):
        raise ValueError('metadata須為字串鍵值對。')
    if metadata.get('version') != version:
        raise ValueError('metadata.version與VERSION不符。')
    if not re.fullmatch(r'\d+\.\d+\.\d+(?:[-+][A-Za-z0-9.-]+)?', version):
        raise ValueError('VERSION不是有效的本套件版本格式。')
    return data
