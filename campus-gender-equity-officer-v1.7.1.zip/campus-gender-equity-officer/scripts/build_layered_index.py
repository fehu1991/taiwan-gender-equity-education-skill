#!/usr/bin/env python3
"""建立可重現的函示分層索引。原件唯讀；文字援引不是法律解釋或效力認證。"""
from __future__ import annotations

import argparse
import hashlib
import json
import re
import shutil
import sys
import tempfile
import unicodedata
from collections import defaultdict
from pathlib import Path
from typing import Any
from urllib.parse import quote

from build_circular_catalog import ROOT, REL, build, digest, normalize, read_json

INDEX = Path('indexes/circulars')
SCHEMA = '1.0.0'
CARD_FIELDS = ('record_id', 'source_id', 'source_path', 'source_year', 'publication_date',
               'publication_date_raw', 'document_number', 'number_key', 'serial', 'subject_raw',
               'source_line_start', 'source_line_end', 'text_sha256', 'content_kind',
               'representation', 'same_document_record_ids', 'issuer', 'known_relation_ids',
               'quality_issue_ids', 'official_urls')
NUM = r'[0-9〇零一二三四五六七八九十百千兩]+'
PROVISION = re.compile(r'第(?P<article>'+NUM+r'(?:-'+NUM+r')?)條(?:之(?P<sub>'+NUM+r'))?'
                       r'(?:第(?P<paragraph>'+NUM+r')項)?(?:第(?P<item>'+NUM+r')款)?')
FOLLOW = re.compile(r'第(?P<number>'+NUM+r')(?P<unit>項|款)')
JOIN = re.compile(r'(?:、|及|與|或|暨|,|以及)')


def encode(data: Any) -> bytes:
    return (json.dumps(data, ensure_ascii=False, sort_keys=True, separators=(',', ':'))+'\n').encode('utf-8')


def contained(root: Path, rel: str, *, prefix: Path | None = None) -> Path:
    path = (root / rel).resolve()
    if Path(rel).is_absolute() or not path.is_relative_to((root / (prefix or Path('.'))).resolve()):
        raise ValueError('路徑越界：'+rel)
    return path


def number(value: str | None) -> str | None:
    """解析明確的阿拉伯／一般中文整數。不猜混合寫法。"""
    if value is None:
        return None
    if '-' in value:
        return '-'.join(number(x) or '' for x in value.split('-'))
    if value.isascii() and value.isdigit():
        return str(int(value))
    digits = dict(zip('零〇一二三四五六七八九兩', [0,0,1,2,3,4,5,6,7,8,9,2]))
    units = {'十':10,'百':100,'千':1000}
    if all(c in digits for c in value):
        return str(int(''.join(str(digits[c]) for c in value)))
    total = 0; current = 0; previous_unit = 10000
    for c in value:
        if c in digits:
            current = digits[c]
        elif c in units and units[c] < previous_unit:
            unit = units[c]; total += (current or 1)*unit; current = 0; previous_unit = unit
        else:
            raise ValueError('不支援的數字：'+value)
    return str(total+current)


def normalized_offsets(raw: str) -> tuple[str, list[int]]:
    chars: list[str] = []; offsets: list[int] = []
    for i,c in enumerate(raw):
        for part in unicodedata.normalize('NFKC',c).replace('台','臺').upper():
            if not part.isspace():
                chars.append(part); offsets.append(i)
    return ''.join(chars), offsets


def citation_units(text: str, start: int) -> tuple[list[dict[str, Any]], int, bool]:
    """僅解析緊接已識別法規名稱的明確條項款；範圍及模糊指代不展開。"""
    units: list[dict[str, Any]] = []; pos = start; last = None; ambiguous = False
    while True:
        match = PROVISION.match(text, pos)
        if match:
            data = match.groupdict()
            article = number(data['article'])
            if data['sub']:
                article += '-'+str(number(data['sub']))
            last = {'article':article, 'paragraph':number(data['paragraph']), 'item':number(data['item'])}
            units.append(dict(last)); pos = match.end()
        else:
            match = FOLLOW.match(text,pos) if last else None
            if not match:
                break
            # 遇「第2項第3款」要先讀完同一目標，不能漏掉後接款。
            last = dict(last)
            if match['unit']=='項':
                last.update(paragraph=number(match['number']),item=None)
            else:
                last['item']=number(match['number'])
            pos=match.end()
            if match['unit']=='項':
                tail=FOLLOW.match(text,pos)
                if tail and tail['unit']=='款':
                    last['item']=number(tail['number']);pos=tail.end()
            units.append(dict(last))
        if text[pos:pos+1] in ('至','到','~','～','-'):
            ambiguous = True  # 不展開範圍，候選另需全文搜尋。
            break
        sep = JOIN.match(text,pos)
        if not sep:
            break
        if not (PROVISION.match(text,sep.end()) or FOLLOW.match(text,sep.end())):
            break
        pos=sep.end()
    return units,pos,ambiguous


def law_registry(root: Path) -> tuple[dict[str,Any], list[str]]:
    source_manifest=read_json(root/'sources/manifest.json')
    laws:dict[str,Any]={};inputs=['sources/manifest.json']
    for s in source_manifest['sources']:
        path=contained(root,s['path'],prefix=Path('sources/uploaded'))
        b=path.read_bytes()
        if digest(b)!=s['sha256']:
            raise ValueError('法規來源SHA不符：'+s['source_id'])
        r=json.loads(b)['regulation'];inputs.append(s['path'])
        aliases=sorted({x for x in [r['name'],r.get('shortName'),*r.get('aliases',[])] if x})
        laws[s['source_id']]={'source_id':s['source_id'],'regulation_id':s['regulation_id'],
                              'name':r['name'],'aliases_from_uploaded_metadata':aliases,
                              'available_source_version':r.get('version'),'source_path':s['path'],
                              'source_sha256':s['sha256'],
                              'note':'別名僅作文字搜尋，包含歷史名稱；不認定名稱間版本或條號等同。'}
    return laws,inputs


def law_occurrences(record:dict[str,Any], laws:dict[str,Any]) -> list[dict[str,Any]]:
    raw=record['raw_text'];text,offsets=normalized_offsets(raw)
    alias_map:dict[str,set[str]]=defaultdict(set)
    for sid,law in laws.items():
        for name in law['aliases_from_uploaded_metadata']:
            alias_map[normalize(name)].add(sid)
    # 最長優先，避免將「性平法施行細則」的全名誤當母法。
    pattern=re.compile('|'.join(re.escape(a) for a in sorted(alias_map,key=lambda a:(-len(a),a))))
    found=[]
    for m in pattern.finditer(text):
        sids=sorted(alias_map[m.group()]);cursor=m.end()
        if cursor<len(text) and text[cursor] in '」》〉':cursor+=1
        intro=re.match(r'\((?:以下)?(?:簡稱|下稱)[^)]{1,30}\)',text[cursor:])
        if intro:cursor+=intro.end()
        units,end,ambiguous=citation_units(text,cursor)
        for sid in sids:
            raw_start=offsets[m.start()];raw_end=offsets[max(m.end(),end)-1]+1
            line_start=record['source_line_start']+raw[:raw_start].count('\n')
            line_end=record['source_line_start']+raw[:raw_end].count('\n')
            found.append({'source_id':sid,'record_id':record['record_id'],
                          'matched_alias':m.group(),'provisions':units,
                          'relation_type':'explicit_text_citation_candidate' if units else 'law_name_mention_only',
                          'legal_effect':'not_inferred','cited_version':None,
                          'version_status':'unverified_do_not_map_to_available_version',
                          'review_status':'machine_extracted_not_legal_review',
                          'ambiguous_range_not_expanded':ambiguous,
                          'alias_ambiguous':len(sids)>1,
                          'evidence':{'source_path':record['source_path'],
                                      'line_start':line_start,'line_end':line_end,
                                      'exact_text':raw[raw_start:raw_end]}})
    return found


def products(root:Path=ROOT) -> tuple[dict[str,bytes],list[str],dict[str,Any]]:
    original=build(root,write=False)
    for name,expected in original.items():
        if read_json(root/REL/name)!=expected:
            raise ValueError('既有目錄與來源不符，先核對後重建：'+name)
    records=original['catalog.json']['records'];laws,law_inputs=law_registry(root)
    src=read_json(root/REL/'manifest.json')['sources'];source_hashes={s['path']:s['sha256'] for s in src}
    routes={'by_document_number':defaultdict(list),'by_serial':defaultdict(list),
            'by_topic':defaultdict(list),'by_year':defaultdict(list),
            'record_locations':{},'unclassified_ids':[]}
    shards:dict[str,dict[str,Any]]=defaultdict(dict)
    grams:dict[str,list[int]]=defaultdict(list)
    law_refs:dict[str,list[dict[str,Any]]]=defaultdict(list)
    all_ids=[]
    for i,r in enumerate(records):
        rid=r['record_id'];all_ids.append(rid);year=str(r['source_year'])
        card={k:r[k] for k in CARD_FIELDS}
        card['source_sha256']=source_hashes[r['source_path']]
        card['topics']=[x['topic'] for x in r['topics']]
        shard='cards/'+year+'.json';routes['record_locations'][rid]=shard;shards[shard][rid]=card
        routes['by_document_number'][r['number_key']].append(rid)
        if r['serial']:routes['by_serial'][r['serial']].append(rid)
        routes['by_year'][year].append(rid)
        if not r['topics']:routes['unclassified_ids'].append(rid)
        for topic in r['topics']:routes['by_topic'][topic['topic']].append(rid)
        text=normalize(r['raw_text'])
        for gram in set(text)|{text[j:j+2] for j in range(len(text)-1)}:
            grams[gram].append(i)
        for occurrence in law_occurrences(r,laws):
            law_refs[occurrence['source_id']].append(occurrence)
    law_routes={}
    for sid,law in laws.items():
        rows=law_refs[sid];by_article:dict[str,list[str]]=defaultdict(list)
        for o in rows:
            for p in o['provisions']:
                if o['record_id'] not in by_article[p['article']]:by_article[p['article']].append(o['record_id'])
        law_routes[sid]={'law':law,'record_ids':sorted({x['record_id'] for x in rows}),
                         'by_article':dict(by_article),'occurrences_file':'laws/'+sid+'.json',
                         'occurrence_count':len(rows)}
    out={'routes.json':encode(routes),'terms.json':encode({'record_ids':all_ids,'postings':grams}),
         'law-routes.json':encode(law_routes),
         'relations.json':encode(original['relations.json']),
         'quality-issues.json':encode(original['quality-issues.json'])}
    unresolved={
        'unclassified_ids':routes['unclassified_ids'],
        'unknown_publication_date_ids':[r['record_id'] for r in records if r['publication_date'] is None],
        'catalog_summary_only_ids':[r['record_id'] for r in records if r['representation']=='catalog_summary_only'],
        'no_recognized_law_name_ids':sorted(set(all_ids)-{o['record_id'] for rows in law_refs.values() for o in rows}),
        'unexpanded_range_ids':sorted({o['record_id'] for rows in law_refs.values() for o in rows if o['ambiguous_range_not_expanded']}),
        'generic_reference_ids':sorted({r['record_id'] for r in records if re.search(r'本法|本準則',r['raw_text'])}),
        'note':'未連結不等於不相關；模糊指代可能與明確援引同時存在。全域關鍵字搜尋涵蓋全部原文區塊。',
    }
    out['unresolved.json']=encode(unresolved)
    out.update({k:encode(v) for k,v in shards.items()})
    for shard,cards in shards.items():
        lines=['# '+Path(shard).stem+'年度索引卡','',
               '只供來源定位；非官方全集。原文、資料性質與法律效力仍須核對。','',
               '| 代碼 | 發文日期 | 完整文號 | 資料性質 | 原稿主旨 | 來源 |',
               '|---|---|---|---|---|---|']
        for rid,c in sorted(cards.items()):
            subject=c['subject_raw'].replace('|','／').replace('\n',' ')
            url=quote('../../../'+c['source_path'],safe='/')
            lines.append(f'| {rid} | {c["publication_date"] or c["publication_date_raw"]} | {c["document_number"]} | {c["representation"]} | {subject} | [原稿]({url}) 第{c["source_line_start"]}–{c["source_line_end"]}行 |')
        out[str(Path(shard).with_suffix('.md'))]=('\n'.join(lines)+'\n').encode('utf-8')
    out.update({'laws/'+sid+'.json':encode({'occurrences':law_refs[sid]}) for sid in laws})
    counts={'records':len(records),'card_shards':len(shards),'topics':len(routes['by_topic']),
            'unclassified':len(routes['unclassified_ids']),'curated_relations':len(original['relations.json']['relations']),
            'law_source_families':len(laws),'law_name_occurrences':sum(map(len,law_refs.values())),
            'explicit_provision_occurrences':sum(bool(o['provisions']) for rows in law_refs.values() for o in rows),
            'gram_keys':len(grams),'complete_official_collection':False,
            'legal_relationships_verified_by_this_build':False}
    coverage=original['catalog.json']['coverage_note']
    overview=['# 函示分層索引入口','',coverage,'',
              '只在需要时讀取本頁；已知文號可直接查詢，不必依序讀完整索引。'.replace('时','時'),'',
              '入口：`python scripts/lookup_circular.py --number 1132805149 --json`。',
              '預設只回傳索引卡；`--id C2024-012 --full --json`才讀原文區塊。',
              '`--query 執行秘書 --topic 會務與迴避`先排序該主題，但仍保留其他符合關鍵字的來源。',
              '`--law 性平法 --article 26 --json`只查明確文字援引候選；不是現行條文適用或完整函釋清單。',
              '未分類、未辨識法條及僅有轉引仍可全域關鍵字檢索；`--all`是本次條件全部命中，不是法源全集。','',
              '| 主題 | 索引筆數 |','|---|---:|']
    overview += [f'| {t} | {len(ids)} |' for t,ids in sorted(routes['by_topic'].items())]
    overview += ['',f'未分類：{counts["unclassified"]}筆。全部：{counts["records"]}筆。',
                 '主題、法規名稱及條文候選只供查找；已知前後函與資料問題會隨卡片提供，不因原查詢主題不同隱藏。',
                 '沒有Python時：按需要讀相應年份的cards檔及卡片所指原文；可用文字搜尋補查全庫，不須打開terms.json。','']
    overview += ['## 年度索引卡', '', '| 年度 | 筆數 | 索引 |', '|---|---:|---|']
    overview += [f'| {year} | {len(ids)} | [年度卡片](cards/{year}.md) |' for year,ids in sorted(routes['by_year'].items())]
    overview += ['', '法規名稱／條項款候選、純提及及未解項目不是現行效力認證。', '']
    out['README.md']='\n'.join(overview).encode()
    inputs=['VERSION','scripts/build_circular_catalog.py','scripts/build_layered_index.py',
            str(REL/'manifest.json'),str(REL/'relation-definitions.json'),str(REL/'quality-definitions.json')]
    inputs += [str(REL/name) for name in original]+[s['path'] for s in src]+law_inputs
    return out,sorted(set(inputs)),{'statistics':counts,'coverage_note':coverage}


def build_index(root:Path=ROOT, *, check:bool=False) -> dict[str,Any]:
    root=root.resolve();out,inputs,info=products(root)
    manifest={'schema_version':SCHEMA,'package_version':(root/'VERSION').read_text().strip(),
              **info,'inputs':[{'path':p,'sha256':digest(contained(root,p).read_bytes())} for p in inputs],
              'products':[{'path':p,'bytes':len(b),'sha256':digest(b)} for p,b in sorted(out.items())],
              'integrity_note':'每次建立檢索實例核對輸入與索引雜湊但不重建；長期實例使用該次核驗快照。雜湊不是來源真實性、數位簽章或法律效力認證。',
              'legal_version_note':'法規附件版本與函示援引版本分開；本索引不指定任何函示所用版本。'}
    out['manifest.json']=encode(manifest)
    dest=root/INDEX
    if check:
        actual={p.relative_to(dest).as_posix() for p in dest.rglob('*') if p.is_file()}
        if actual!=set(out):raise ValueError('分層索引檔案集合不一致。')
        for rel,b in out.items():
            if contained(root,str(INDEX/rel),prefix=INDEX).read_bytes()!=b:
                raise ValueError('分層索引不可重現或已過期：'+rel)
    else:
        # 在同一磁碟先建立完整暫存目錄。失敗時不留下半套索引；查詢絕不隱式重建。
        dest.parent.mkdir(parents=True,exist_ok=True)
        stage=Path(tempfile.mkdtemp(prefix='.circulars-build-',dir=dest.parent))
        backup=dest.with_name('.circulars-backup')
        try:
            for rel,b in out.items():
                p=stage/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
            if backup.exists():raise ValueError('發現未處理的索引備份，請先確認：'+str(backup))
            if dest.exists():dest.rename(backup)
            try:stage.rename(dest)
            except OSError:
                if backup.exists():backup.rename(dest)
                raise
            if backup.exists():shutil.rmtree(backup)
        finally:
            if stage.exists():shutil.rmtree(stage)
    return manifest


def main() -> int:
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--root',type=Path,default=ROOT);p.add_argument('--check',action='store_true')
    a=p.parse_args()
    try:
        m=build_index(a.root,check=a.check)
        print(json.dumps({'package_version':m['package_version'],'check_only':a.check,
                          'statistics':m['statistics']},ensure_ascii=False,indent=2));return 0
    except (ValueError,OSError,KeyError,TypeError) as exc:
        print('分層索引建立／驗證失敗：'+str(exc),file=sys.stderr);return 2

if __name__=='__main__':raise SystemExit(main())
