#!/usr/bin/env python3
"""唯讀查找歷年函示；保留重號、已知修正與停止適用關係及來源性質。"""
from __future__ import annotations

import argparse
import hashlib
import json
import re
import sys
from datetime import date
from pathlib import Path
from typing import Any

from build_circular_catalog import ROOT, REL, TOPICS, build, normalize, number_key, read_json, serial


class CircularCatalog:
    def __init__(self, root: Path = ROOT) -> None:
        self.root = root.resolve()
        # 來源僅約數MB；每次以已登記雜湊重建比對，避免過時或被修改的派生索引。
        expected = build(self.root, write=False)
        for name, value in expected.items():
            actual = read_json(self.root / REL / name)
            if actual != value:
                raise ValueError(f'{name} 與來源或審核紀錄不符；請執行 build_circular_catalog.py 重建。')
        self.catalog = expected['catalog.json']
        self.records = self.catalog['records']
        self.relations = expected['relations.json']['relations']
        self.issues = expected['quality-issues.json']['issues']
        self.relations_by_id = {r['relation_id']: r for r in self.relations}
        self.issues_by_id = {r['issue_id']: r for r in self.issues}

    def query(self, *, number: str | None = None, query: str | None = None,
              topic: str | None = None, year: int | None = None,
              as_of: str | None = None, record_id: str | None = None) -> dict[str, Any]:
        if as_of:
            date.fromisoformat(as_of)
        if topic and topic not in TOPICS:
            raise ValueError(f'未知主題：{topic}；請使用 --topics 查看。')
        if not any([number, query, topic, year, record_id]):
            raise ValueError('至少指定文號、關鍵詞、主題、年份或條目代碼。')
        if query is not None and not query.strip():
            raise ValueError('查詢字串不能空白。')
        terms = [normalize(t) for t in re.split(r'\s+', query.strip())] if query else []
        key = number_key(number) if number else None
        only_serial = bool(key and re.fullmatch(r'\d+[A-Z]?', key))
        found = []
        excluded_undated = []
        for r in self.records:
            if key and ((r['serial'] != key) if only_serial else (r['number_key'] != key)):
                continue
            if year is not None and r['source_year'] != year:
                continue
            if record_id and r['record_id'] != record_id:
                continue
            if topic and topic not in [t['topic'] for t in r['topics']]:
                continue
            text, title = normalize(r['raw_text']), normalize(r['subject_raw'])
            if terms and not all(t in text for t in terms):
                continue
            if as_of and r['publication_date'] is None:
                excluded_undated.append(r['record_id']); continue
            if as_of and r['publication_date'] > as_of:
                continue
            score = sum((5 if t in title else 0) + text.count(t) for t in terms)
            found.append((score, r))
        found.sort(key=lambda sr: (-sr[0], sr[1]['publication_date'] or '9999-12-31', sr[1]['record_id']))
        views = [self.view(r, as_of) for _, r in found]
        # 精確主文號不存在，但可能是只在後函中被引述的前函；不能因此生成前函全文。
        reference_only = []
        if key and not views:
            for link in self.relations:
                target = serial(link['to_number']) if only_serial else number_key(link['to_number'])
                if target == key and not link['to_record_ids']:
                    if not as_of or (link['announced_on'] is not None and link['announced_on'] <= as_of):
                        reference_only.append(link)
        mentions_only = self.find_mentions(key, only_serial, terms, topic, year, as_of, record_id) if key else []
        # A hit in another document is not a separately collected original or an effectiveness decision.
        return {'query': {'number': number, 'keywords': query, 'topic': topic, 'source_year': year,
                          'publication_cutoff': as_of, 'record_id': record_id},
                'match_count': len(views), 'records': views, 'reference_only': reference_only,
                'mentions_only': mentions_only, 'mention_count': len(mentions_only),
                'coverage_note': self.catalog['coverage_note'],
                'undated_records_excluded': len(excluded_undated),
                'undated_record_ids_excluded': excluded_undated,
                'as_of_note': ('僅篩選截至該日已發布之條目與已發布之關係；未知發文日期條目另行排除，不是行為時法或施行效力判定。'
                               if as_of else '未完成全部函示之現行有效性查核；不得將未標記停止適用視為有效。')}

    def find_mentions(self, key: str, only_serial: bool, terms: list[str],
                      topic: str | None, year: int | None, as_of: str | None,
                      record_id: str | None) -> list[dict[str, Any]]:
        """Search cited document numbers without manufacturing independent source records."""
        out: list[dict[str, Any]] = []
        for r in self.records:
            if (r['serial'] == key if only_serial else r['number_key'] == key):
                continue  # Already handled as a primary-document hit, including duplicate records.
            if year is not None and r['source_year'] != year:
                continue
            if record_id and r['record_id'] != record_id:
                continue
            if topic and topic not in [t['topic'] for t in r['topics']]:
                continue
            if terms and not all(t in normalize(r['raw_text']) for t in terms):
                continue
            if as_of and (r['publication_date'] is None or r['publication_date'] > as_of):
                continue
            target = '第' + key + '號' if only_serial else key
            # Match the complete serial with its suffix; never conflate 123A with 123.
            if target not in normalize(r['raw_text']):
                continue
            source_path = (self.root / r['source_path']).resolve()
            if not source_path.is_relative_to((self.root / 'sources').resolve()):
                raise ValueError('提及來源路徑越界。')
            source_bytes = source_path.read_bytes()
            source_lines = source_bytes.decode('utf-8').splitlines()
            start, end = r['source_line_start'], r['source_line_end']
            excerpts = [{'line': i + 1, 'text': source_lines[i]}
                        for i in range(start - 1, min(end, len(source_lines)))
                        if target in normalize(source_lines[i])]
            out.append({
                'mentioned_number_search_key': key, 'mentioned_in_record_id': r['record_id'],
                'citing_document_number': r['document_number'],
                'citing_record_representation': r['representation'],
                'citing_record_content_kind': r['content_kind'],
                'citing_document_publication_date': r['publication_date'],
                'source_path': r['source_path'], 'source_line_start': start, 'source_line_end': end,
                'source_sha256': hashlib.sha256(source_bytes).hexdigest(),
                'excerpts': excerpts, 'representation': 'mention_only',
                'independent_original_included': False,
                'note': '僅證明來源區塊提及該文號；日期屬引用它的文件，非被引文件。未認證被引文件全文、內容或效力。',
            })
        return out

    def view(self, record: dict[str, Any], as_of: str | None = None) -> dict[str, Any]:
        r = dict(record)
        links = [self.relations_by_id[rid] for rid in record['known_relation_ids']]
        eligible = [l for l in links if not as_of or (l['announced_on'] is not None and l['announced_on'] <= as_of)]
        r['known_relations'] = eligible
        r['later_relation_ids_not_applied'] = [l['relation_id'] for l in links if l not in eligible]
        r['quality_issues'] = [self.issues_by_id[iid] for iid in record['quality_issue_ids']]
        ceased = [l for l in eligible if l['relation_type'] in ('ceases_entire_letter', 'reaffirms_cessation')
                  and record['record_id'] in l['to_record_ids']
                  and l.get('effective_on') and (not as_of or l['effective_on'] <= as_of)]
        partial = [l for l in eligible if l['relation_type'] in ('modifies_part', 'ceases_conflicting_parts')
                   and record['record_id'] in l['to_record_ids']]
        if ceased:
            r['retrieval_use_status'] = 'has_explicit_cessation_evidence'
            r['retrieval_use_note'] = '已有明示停止適用依據；僅作歷史檢索或適用時點分析，不直接作現行作業依據。'
        elif partial:
            r['retrieval_use_status'] = 'has_partial_change_evidence'
            r['retrieval_use_note'] = '存在部分修正或停止適用關係；必須逐段確認，不能把全文一律標為失效或有效。'
        else:
            r['retrieval_use_status'] = 'current_applicability_unverified'
            r['retrieval_use_note'] = '尚未完成現行適用性審核；找到資料不等於可直接採用。'
        return r


def text_output(result: dict[str, Any], full: bool, limit: int) -> str:
    chunks = [result['coverage_note'], result['as_of_note'], f'符合條目：{result["match_count"]}']
    # 文號及ID精確查詢不能因預設limit而漏列重號。
    rows = result['records'] if result['query']['number'] or result['query']['record_id'] else result['records'][:limit]
    for r in rows:
        lines = [f'\n{r["record_id"]}｜{r["publication_date"] or r["publication_date_raw"]}｜{r["document_number"]}', r['subject_raw'],
                 f'資料性質：{r["content_kind"]}；呈現型態：{r["representation"]}',
                 f'同文號其他來源：{r["same_document_record_ids"]}',
                 f'來源：{r["source_path"]} 第{r["source_line_start"]}–{r["source_line_end"]}行',
                 r['retrieval_use_note']]
        for link in r['known_relations']:
            lines.append(f'關係 {link["relation_id"]}：{link["from_number"]} → {link["to_number"]}；'
                         f'{link["relation_type"]}；範圍：{link["scope"]}；明示生效日：{link.get("effective_on") or "未確認"}')
        for issue in r['quality_issues']:
            lines.append(f'來源問題 {issue["issue_id"]}：{issue["finding"]}')
        if r['official_urls']:
            lines.extend(['原始官方來源：'] + r['official_urls'])
        if full:
            lines.extend(['--- 以下為來源區塊；外部摘要不等於函示原文 ---', r['raw_text']])
        chunks.append('\n'.join(lines))
    for link in result['reference_only']:
        chunks.append(f'\n僅有前函引述，無獨立主文全文：{link["to_number"]}；見 {link["from_number"]}，'
                      f'關係 {link["relation_id"]}。不得反向補造被引函示。')
    for hit in result.get('mentions_only', []):
        chunks.append(f'\n僅在內文提及，非獨立原件：{hit["mentioned_number_search_key"]}；'
                      f'見 {hit["mentioned_in_record_id"]}；{hit["source_path"]} '
                      f'第{hit["source_line_start"]}–{hit["source_line_end"]}行。' + hit['note'])
    if len(rows) < result['match_count']:
        chunks.append(f'僅顯示{len(rows)}筆；增加 --limit，或使用 --json 取得全部符合條目。')
    if not rows and not result['reference_only'] and not result.get('mentions_only'):
        chunks.append('本次索引查無符合條目；不代表該函不存在或該年度沒有函示。')
    return '\n'.join(chunks)


def legacy_main() -> int:
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--root', type=Path, default=ROOT)
    p.add_argument('--number', help='完整文號或完整流水號，保留A/B/C字尾')
    p.add_argument('--query', help='空白分隔關鍵詞，採全部符合；不是向量語意搜尋')
    p.add_argument('--topic', choices=sorted(TOPICS))
    p.add_argument('--year', type=int, help='原稿年度，不從文號前三碼推定發文年度')
    p.add_argument('--as-of', help='YYYY-MM-DD，只限制已發布資料，不自動判定法規效力')
    p.add_argument('--id', dest='record_id')
    p.add_argument('--full', action='store_true')
    p.add_argument('--json', action='store_true', help='回傳全部符合紀錄及來源區塊')
    p.add_argument('--limit', type=int, default=10)
    p.add_argument('--stats', action='store_true')
    p.add_argument('--topics', action='store_true')
    args = p.parse_args()
    if args.topics:
        print('\n'.join(sorted(TOPICS)))
        return 0
    if args.limit < 1:
        p.error('--limit 必須大於零。')
    try:
        db = CircularCatalog(args.root)
        if args.stats:
            print(json.dumps(db.catalog['statistics'], ensure_ascii=False, indent=2))
            return 0
        result = db.query(number=args.number, query=args.query, topic=args.topic, year=args.year,
                          as_of=args.as_of, record_id=args.record_id)
        print(json.dumps(result, ensure_ascii=False, indent=2) if args.json else text_output(result, args.full, args.limit))
        return 0 if result['match_count'] or result['reference_only'] or result['mentions_only'] else 1
    except (ValueError, OSError, KeyError, TypeError) as exc:
        print(f'檢索失敗：{exc}', file=sys.stderr)
        return 2


def main() -> int:
    # Python API保留v1嚴格重建；CLI預設使用v2分層索引。
    if '--legacy' in sys.argv:
        sys.argv.remove('--legacy')
        return legacy_main()
    from lookup_circular_index import main as layered_main
    return layered_main()


if __name__ == '__main__':
    raise SystemExit(main())
