#!/usr/bin/env python3
"""重建發行檔案清單；只記錄檔案集合與雜湊，不替代測試或來源查核。"""
from __future__ import annotations
import argparse
import hashlib
import json
import sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]


def manifest(root:Path) -> dict:
    root=root.resolve();rows=[]
    for p in sorted(root.rglob('*')):
        if not p.is_file() or '__pycache__' in p.parts or p.suffix in ('.pyc','.pyo'):continue
        rel=p.relative_to(root).as_posix()
        if rel=='PACKAGE-FILES.json':continue
        if not p.resolve().is_relative_to(root):raise ValueError('拒絕套件外部連結：'+rel)
        b=p.read_bytes();rows.append({'path':rel,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
    return {'version':(root/'VERSION').read_text().strip(),
            'scope':'All distributable files except this manifest itself; Python caches excluded. Hashes do not certify source authenticity or legal validity.',
            'files':rows}


def main() -> int:
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--root',type=Path,default=ROOT)
    p.add_argument('--check',action='store_true');a=p.parse_args()
    try:
        m=manifest(a.root);target=a.root/'PACKAGE-FILES.json'
        if a.check:
            if json.loads(target.read_text())!=m:raise ValueError('發行清單與目前檔案不一致。')
        else:
            tmp=target.with_name('.PACKAGE-FILES.tmp')
            if tmp.exists():raise ValueError('發現未處理的暫存發行清單，請先確認。')
            tmp.write_text(json.dumps(m,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');tmp.replace(target)
        print(json.dumps({'version':m['version'],'files':len(m['files']),'check_only':a.check},ensure_ascii=False));return 0
    except (ValueError,OSError,KeyError,TypeError) as exc:
        print('發行清單處理失敗：'+str(exc),file=sys.stderr);return 2

if __name__=='__main__':raise SystemExit(main())
