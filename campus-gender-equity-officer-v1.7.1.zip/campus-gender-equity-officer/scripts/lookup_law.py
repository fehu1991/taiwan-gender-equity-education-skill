#!/usr/bin/env python3
"""唯讀查詢套件內的使用者附件；不連線、不計算法律截止日。"""
from __future__ import annotations

import argparse
import hashlib
import json
import re
import sys
import unicodedata
from pathlib import Path
from typing import Any

PACKAGE_ROOT = Path(__file__).resolve().parents[1]
NOTICE = (
    '以下為使用者上傳之正規化JSON附件內容，不是即時現行法資料庫。'
    '請保留來源版本，依manifest及官方來源核對適用條文、施行日與已知差異。'
)


def read_json(path: Path) -> dict[str, Any]:
    try:
        value = json.loads(path.read_text(encoding='utf-8'))
    except (OSError, UnicodeError, json.JSONDecodeError) as exc:
        raise ValueError(f'無法讀取有效JSON：{path.name}；{exc}') from exc
    if not isinstance(value, dict):
        raise ValueError(f'JSON根節點必須是物件：{path.name}')
    return value


def load_manifest(root: Path = PACKAGE_ROOT) -> list[dict[str, Any]]:
    entries = read_json(root / 'sources' / 'manifest.json').get('sources')
    if not isinstance(entries, list):
        raise ValueError('manifest缺少sources陣列。')
    return entries


def load_source(entry: dict[str, Any], root: Path = PACKAGE_ROOT) -> dict[str, Any]:
    path = (root / entry['path']).resolve()
    if not path.is_relative_to((root / 'sources' / 'uploaded').resolve()):
        raise ValueError('來源路徑超出套件附件目錄。')
    try:
        actual = hashlib.sha256(path.read_bytes()).hexdigest()
    except OSError as exc:
        raise ValueError(f'無法開啟附件：{entry["filename"]}') from exc
    if actual != entry.get('sha256'):
        raise ValueError(f'附件雜湊不符，停止引用：{entry["filename"]}')
    doc = read_json(path)
    reg = doc.get('regulation')
    if not isinstance(reg, dict) or not isinstance(reg.get('articles'), list):
        raise ValueError(f'附件缺少regulation/articles：{entry["filename"]}')
    return reg


def normalize_article(value: str) -> str:
    # 接受22、22-1、第22條、第 22-1 條；不猜測中文數字或歷史條號。
    token = re.sub(r'\s+', '', unicodedata.normalize('NFKC', value)).removeprefix('第').removesuffix('條')
    if not re.fullmatch(r'[0-9]+(?:-[0-9]+)?', token):
        raise ValueError('條號請使用阿拉伯數字，例如22、22-1或第22條。')
    return '-'.join(str(int(part)) for part in token.split('-'))


def select_sources(
    entries: list[dict[str, Any]], law: str | None, source_id: str | None,
    root: Path = PACKAGE_ROOT,
) -> list[dict[str, Any]]:
    if source_id:
        selected = [entry for entry in entries if entry['source_id'].casefold() == source_id.casefold()]
        if not selected:
            raise ValueError(f'查無來源代碼：{source_id}')
        if law:
            raise ValueError('--law與--source請擇一使用。')
        return selected
    if not law:
        return entries
    normalized = law.strip().casefold()
    exact: list[dict[str, Any]] = []
    partial: list[dict[str, Any]] = []
    for entry in entries:
        reg = load_source(entry, root)
        names = [reg['name'], reg.get('shortName') or '', *reg.get('aliases', [])]
        if any(normalized == name.casefold() for name in names if name):
            exact.append(entry)
        elif any(normalized in name.casefold() for name in names if name):
            partial.append(entry)
    result = exact or partial
    if not result:
        raise ValueError(f'查無法規：{law}；請先使用--list確認名稱。')
    if len(result) > 1:
        names = '、'.join(f'{entry["source_id"]} {entry["name"]}' for entry in result)
        raise ValueError(f'法規名稱不唯一：{names}。請指定全名或--source。')
    return result


def lookup(
    entries: list[dict[str, Any]], articles: list[str] | None = None,
    query: str | None = None, root: Path = PACKAGE_ROOT,
) -> list[dict[str, Any]]:
    targets = {normalize_article(item) for item in (articles or [])}
    terms = [term.casefold() for term in (query or '').split() if term]
    output: list[dict[str, Any]] = []
    for entry in entries:
        reg = load_source(entry, root)
        for index, article in enumerate(reg['articles']):
            if targets and article['articleNumber'] not in targets:
                continue
            content = article.get('plainText') or ''
            haystack = (article.get('displayNumber', '') + '\n' + content).casefold()
            if terms and not all(term in haystack for term in terms):
                continue
            output.append({
                'source_id': entry['source_id'], 'law_name': reg['name'],
                'display_number': article.get('displayNumber'),
                'article_number': article['articleNumber'], 'text': content,
                'file_path': entry['path'],
                'json_pointer': f'/regulation/articles/{index}/plainText',
                'source_version': reg.get('version'),
                'source_kind': entry['source_kind'], 'sha256': entry['sha256'],
                'review_status': entry['review_status'],
                'review_notes': entry.get('review_notes', []),
                'official_source_ids': entry.get('official_source_ids', []),
                'authoritative_current_full_text': False,
            })
    return output


def build_response(
    entries: list[dict[str, Any]], articles: list[str] | None = None,
    query: str | None = None, *, limit: int = 5, offset: int = 0,
    all_results: bool = False, root: Path = PACKAGE_ROOT,
) -> dict[str, Any]:
    """Report retrieval coverage separately from whether a source legally supports a claim."""
    if not 1 <= limit <= 100 or offset < 0:
        raise ValueError('limit須為1至100，offset不得小於零。')
    if all_results and offset:
        raise ValueError('--all不可併用非零--offset。')
    requested = list(dict.fromkeys(normalize_article(a) for a in (articles or [])))
    results = lookup(entries, articles, query, root)
    missing: dict[str, list[str]] = {}
    filtered: dict[str, list[str]] = {}
    for entry in entries:
        sid = entry['source_id']
        available = {str(a['articleNumber']) for a in load_source(entry, root)['articles']}
        matched = {r['article_number'] for r in results if r['source_id'] == sid}
        absent = [a for a in requested if a not in available]
        removed = [a for a in requested if a in available and a not in matched]
        if absent:
            missing[sid] = absent
        if removed:
            filtered[sid] = removed
    total = len(results)
    if offset and offset >= total:
        raise ValueError(f'--offset超出符合結果範圍；本次共{total}筆。')
    page = results if all_results else results[offset:offset + limit]
    end = offset + len(page)
    next_offset = end if end < total else None
    return {
        'notice': NOTICE, 'scope_source_ids': [e['source_id'] for e in entries],
        'requested_articles': requested,
        'missing_requested_articles': missing,
        'requested_articles_filtered_out': filtered,
        'request_complete': not missing and not filtered,
        'total_matches': total, 'returned': len(page), 'offset': offset,
        'next_offset': next_offset,
        'truncated': offset > 0 or next_offset is not None,
        'all_matches_returned': len(page) == total,
        'results': page,
        'coverage_note': '完整性僅指本次指定附件與查詢條件，不是相關法律全集或法律效力認證。',
    }


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--list', action='store_true', help='列出附件名稱、版本及查核狀態')
    parser.add_argument('--law', help='法規全名或唯一別名，例如性平法')
    parser.add_argument('--source', help='來源代碼，例如U02')
    parser.add_argument('--article', action='append', help='阿拉伯數字條號；可重複指定')
    parser.add_argument('--query', help='文字關鍵詞；空白分隔表示每個詞均須出現，不作語意推論')
    parser.add_argument('--limit', type=int, default=5, help='顯示筆數，1至100，預設5')
    parser.add_argument('--offset', type=int, default=0, help='略過筆數；依next_offset續查')
    parser.add_argument('--all', dest='all_results', action='store_true', help='回傳本次條件全部命中，不受limit限制')
    parser.add_argument('--format', choices=('text', 'json'), default='text')
    args = parser.parse_args(argv)
    if not 1 <= args.limit <= 100:
        parser.error('--limit須為1至100。')
    if args.offset < 0 or (args.all_results and args.offset):
        parser.error('--offset不得小於零；--all不可併用非零--offset。')
    if not (args.list or args.article or (args.query and args.query.strip())):
        parser.error('請提供--list、--article或非空白--query。')
    if args.article and not (args.law or args.source):
        parser.error('指定條號時請同時指定--law或--source，避免混淆不同法規。')
    try:
        entries = select_sources(load_manifest(), args.law, args.source)
        if args.list:
            items = [{'source_id': e['source_id'], 'name': e['name'],
                      'version': e['version'], 'review_status': e['review_status'],
                      'review_notes': e.get('review_notes', [])} for e in entries]
            response = {'notice': NOTICE, 'total': len(items), 'sources': items}
        else:
            response = build_response(entries, args.article, args.query, limit=args.limit,
                                      offset=args.offset, all_results=args.all_results)
            if not response['total_matches']:
                # Keep the established exit code/stderr contract, but JSON callers also get coverage.
                if args.format == 'json':
                    print(json.dumps(response, ensure_ascii=False, indent=2))
                raise ValueError('查無符合條號或關鍵詞的附件條文；未以其他條文或推測補出結果。')
        if args.format == 'json':
            print(json.dumps(response, ensure_ascii=False, indent=2))
        else:
            print(NOTICE)
            if args.list:
                for item in response['sources']:
                    label = (item.get('version') or {}).get('label') or '版本未載明'
                    print(f'\n{item["source_id"]} {item["name"]}｜{label}｜{item["review_status"]}')
                    for note in item['review_notes']:
                        print(f'  注意：{note}')
            else:
                print(f'符合{response["total_matches"]}筆，顯示{response["returned"]}筆。')
                if response['missing_requested_articles']:
                    print('附件缺少指定條號：' + json.dumps(response['missing_requested_articles'], ensure_ascii=False))
                if response['requested_articles_filtered_out']:
                    print('條號存在但被關鍵詞條件排除：' + json.dumps(response['requested_articles_filtered_out'], ensure_ascii=False))
                if response['next_offset'] is not None:
                    print(f'尚有結果未顯示；使用 --offset {response["next_offset"]} 續查，或 --all 取得全部。')
                print(response['coverage_note'])
                for item in response['results']:
                    label = (item.get('source_version') or {}).get('label') or '版本未載明'
                    print(f'\n[{item["source_id"]}] {item["law_name"]} {item["display_number"]}｜{label}')
                    print(f'來源：{item["file_path"]}#{item["json_pointer"]}')
                    print(f'查核狀態：{item["review_status"]}')
                    for note in item['review_notes']:
                        print(f'注意：{note}')
                    print(item['text'])
        return 0 if args.list or response['request_complete'] else 1
    except (ValueError, KeyError, TypeError) as exc:
        print(f'錯誤：{exc}', file=sys.stderr)
        return 2


if __name__ == '__main__':
    raise SystemExit(main())
