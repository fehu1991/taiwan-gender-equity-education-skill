#!/usr/bin/env python3
"""離線建立法規核心、版本分離的唯讀 Wiki；不讀取或累積任何案件。"""
from __future__ import annotations
import argparse
import json
import re
import shutil
import sys
import tempfile
from collections import defaultdict
from pathlib import Path
from typing import Any
from urllib.parse import quote
from build_circular_catalog import ROOT, digest, normalize
from build_layered_index import contained, encode, normalized_offsets, citation_units, number
from lookup_circular_index import LayeredCatalog

SCHEMA='1.0.0'
DEST=Path('wiki')
CONFIG=Path('knowledge/law-wiki-notes.json')
OFFICIAL=Path('sources/wiki-official/manifest.json')
ADMIN_SOURCES=Path('sources/admin-framework/manifest.json')
ADMIN_FRAMEWORK=Path('knowledge/admin-law-framework.json')


def article_number(value:str)->str:
    """僅接受一個明確條號。不得把範圍或不明文字強制轉成條號。"""
    s=normalize(str(value))
    m=re.fullmatch(r'(?:第)?([0-9〇零一二三四五六七八九十百千兩]+)(?:條)?(?:(?:之|-)([0-9〇零一二三四五六七八九十百千兩]+))?(?:條)?',s)
    if not m:raise ValueError('無法辨識單一條號：'+str(value))
    n=number(m[1]);return str(n)+('-'+str(number(m[2])) if m[2] else '')


def document_definitions(text:str,aliases:dict[str,set[str]])->dict[str,set[str]]:
    """只從本文件明示的「全名（以下簡稱…）」建立局部別名；不猜「本法」。"""
    norm=normalize(text);out:dict[str,set[str]]=defaultdict(set)
    if not aliases:return out
    pat=re.compile('|'.join(re.escape(a) for a in sorted(aliases,key=lambda x:(-len(x),x))))
    for m in pat.finditer(norm):
        intro=re.match(r'\((?:以下)?(?:簡稱|下稱)([^)]{1,24})\)',norm[m.end():])
        if intro:
            alias=intro[1].strip('「」『』"')
            if re.fullmatch(r'[\u4e00-\u9fffA-Z0-9]+',alias):out[alias].update(aliases[m.group()])
    return dict(out)


def extract_citations(text:str,alias_map:dict[str,set[str]],*,local:dict[str,set[str]]|None=None)->list[dict]:
    """帶位置的名稱／條項款候選；局部別名衝突、範圍及省略指代不得推成確定連結。"""
    norm,offsets=normalized_offsets(text);am={a:set(ids) for a,ids in alias_map.items()}
    for alias,ids in (local or {}).items():
        # 本文件的明示別名優先；多重定義保留歧義，不選其中一個。
        am[alias]=set(ids)
    if not am:return []
    pat=re.compile('|'.join(re.escape(a) for a in sorted(am,key=lambda x:(-len(x),x))))
    found=[]
    for m in pat.finditer(norm):
        cursor=m.end()
        if norm[cursor:cursor+1] in ('」','》','〉'):cursor+=1
        intro=re.match(r'\((?:以下)?(?:簡稱|下稱)[^)]{1,30}\)',norm[cursor:])
        if intro:cursor+=intro.end()
        units,end,amb=citation_units(norm,cursor)
        st=offsets[m.start()];en=offsets[max(m.end(),end)-1]+1
        for lid in sorted(am[m.group()]):
            found.append({'target_law_id':lid,'matched_alias':m.group(),'provisions':units,
              'relation_type':'explicit_text_citation_candidate' if units else 'law_name_mention_only',
              'cited_version':None,'version_status':'unknown_not_auto_mapped',
              'review_status':'machine_extracted_not_legal_review','legal_effect':'not_inferred',
              'ambiguous_alias':len(am[m.group()])>1,'range_not_expanded':amb,
              'local_definition_used':m.group() in (local or {}),
              'char_start':st,'char_end':en,'exact_text':text[st:en]})
    return found


def grams(text:str)->set[str]:
    n=normalize(text)
    return set(n)|{n[i:i+2] for i in range(len(n)-1)}


def load_laws(root:Path)->tuple[dict,dict,dict,list[str],list[dict]]:
    """合併法規身分，不合併版本或來源全文。"""
    inputs=['sources/manifest.json',str(OFFICIAL),str(ADMIN_SOURCES)];laws={};reps={};docs={};oldlinks=[]
    source_specs=json.loads((root/'sources/manifest.json').read_bytes())['sources']
    off=json.loads((root/OFFICIAL).read_bytes())['sources']+json.loads((root/ADMIN_SOURCES).read_bytes())['sources']
    if len({s['source_id'] for s in source_specs+off})!=len(source_specs+off):raise ValueError('來源代碼重複')
    for spec in source_specs+off:
        sid=spec['source_id'];rel=spec['path'];b=contained(root,rel,prefix=Path('sources')).read_bytes()
        if digest(b)!=spec['sha256']:raise ValueError('法規来源SHA不符：'.replace('来源','來源')+sid)
        inputs.append(rel);o=json.loads(b)
        uploaded='regulation' in o
        if uploaded:
            r=o['regulation'];lid=r['id'];name=r['name'];ver=r.get('version') or {}
            date=ver.get('promulgationDate');vkey=lid+'@'+date if date else lid+'@unknown:'+sid
            aliases=[name,r.get('shortName'),*r.get('aliases',[])]
            articles=r['articles'];warnings=spec.get('review_notes',[])+spec.get('normalization_warnings',[])
            kind=spec.get('source_kind','user_uploaded_ai_normalized_json')
            for link in r.get('crossRegulationLinks',[]):oldlinks.append({'source_id':sid,**link})
            url=None
        else:
            if o['representation']!='manually_transcribed_official_web_excerpts' or o['full_official_text_included'] is not False:
                raise ValueError('官方來源必須如實標記為有限轉錄')
            lid=o['law_id'];name=o['law_name'];date=o['observed_revision_date'];vkey=lid+'@'+(date or 'undated')
            aliases=[name,*o.get('aliases',[])];articles=o['articles'];warnings=o['warnings']
            kind=o['representation'];url=o['official_url'];ver={'observed_revision_date':date,'status':'not_case_applicability_certified'}
        law=laws.setdefault(lid,{'law_id':lid,'name':name,'aliases':[],'source_ids':[],'version_keys':[],
                                'current_full_text_certified':False})
        law['aliases']=sorted(set(law['aliases'])|{a for a in aliases if a})
        law['source_ids'].append(sid)
        if vkey not in law['version_keys']:law['version_keys'].append(vkey)
        rp={'source_id':sid,'law_id':lid,'law_name':name,'version_key':vkey,'observed_revision_date':date,
          'source_path':rel,'source_sha256':digest(b),'representation':kind,
          'coverage':'uploaded_article_set_not_current_certified' if uploaded else 'selected_articles_only',
          'original_version_metadata':ver,'effective_status':'article_effectivity_check_required',
          'official_url':url,'accessed_on':o.get('accessed_on'),'warnings':warnings,
          'article_ids':[],'is_partial':not uploaded}
        reps[sid]=rp
        seen=set()
        for i,a in enumerate(articles):
            no=str(a.get('articleNumber') if uploaded else a['article_number'])
            if no in seen:raise ValueError('同來源條號重複：'+sid+':'+no)
            seen.add(no)
            text=a.get('plainText','') if uploaded else a['text']
            # 指引數字僅作章節定位，保留displayNumber，不能稱為第1條。
            display=a.get('displayNumber',no) if uploaded else a['display_number']
            unit='article' if re.search('條',display) else 'section'
            did=sid+':'+no
            row={'document_id':did,'kind':'law_article' if unit=='article' else 'guide_section',
              'law_id':lid,'law_name':name,'source_id':sid,'version_key':vkey,'observed_revision_date':date,
              'article_number':no,'unit':unit,'display_number':display,'title':a.get('title') or display,
              'text':text,'source_path':rel,'source_sha256':digest(b),
              'json_pointer':('/regulation/articles/' if uploaded else '/articles/')+str(i),
              'text_sha256':digest(text.encode()),'representation':kind,'official_url':url,
              'effective_status':a.get('effective_status','not_independently_determined'),
              'paragraph_structure_verified':False}
            docs[did]=row;rp['article_ids'].append(did)
    return laws,reps,docs,sorted(set(inputs)),oldlinks


def products(root:Path)->tuple[dict[str,bytes],list[str],dict]:
    laws,reps,docs,inputs,oldlinks=load_laws(root)
    cfg=json.loads((root/CONFIG).read_bytes());inputs += [str(CONFIG),str(ADMIN_FRAMEWORK),'VERSION','scripts/build_legal_wiki.py','scripts/lookup_legal.py','indexes/circulars/manifest.json']
    circles=LayeredCatalog(root)
    aliases:dict[str,set[str]]=defaultdict(set)
    for lid,law in laws.items():
        for a in law['aliases']:aliases[normalize(a)].add(lid)
    for lid,alist in cfg.get('extra_aliases',{}).items():
        if lid not in laws:raise ValueError('未知別名法規：'+lid)
        for a in alist:aliases[normalize(a)].add(lid);laws[lid]['aliases'].append(a)
    # 法規文件內定義只在該來源表示有效；未明示者不默認本法指誰。
    local_by_sid={sid:document_definitions('\n'.join(docs[k]['text'] for k in rep['article_ids']),aliases) for sid,rep in reps.items()}
    bylaw=defaultdict(list);cross=[];circular_refs=defaultdict(list);unresolved=[]
    for did,d in docs.items():
        local=local_by_sid[d['source_id']]
        refs=extract_citations(d['text'],aliases,local=local)
        for x in refs:
            rec={'from_document_id':did,'from_law_id':d['law_id'],'from_version_key':d['version_key'],**x,
                 'evidence':{'source_path':d['source_path'],'source_sha256':d['source_sha256'],
                             'json_pointer':d['json_pointer'],'exact_text':x['exact_text'],
                             'char_start':x['char_start'],'char_end':x['char_end']}}
            cross.append(rec)
        if '本法' in d['text'] and '本法' not in local:
            unresolved.append({'kind':'unresolved_local_reference','document_id':did,'term':'本法',
                               'note':'尚未建立明示別名；讀原文，不擅自指向性平法。'})
    for rid in sorted(circles.all_ids):
        card=circles.card(rid);text=circles.raw_text(rid);local=document_definitions(text,aliases)
        refs=extract_citations(text,aliases,local=local)
        for x in refs:
            st=x['char_start'];en=x['char_end']
            ev={'source_path':card['source_path'],'source_sha256':card['source_sha256'],
                'line_start':card['source_line_start']+text[:st].count('\n'),
                'line_end':card['source_line_start']+text[:en].count('\n'),
                'exact_text':x['exact_text'],'char_start_in_record':st,'char_end_in_record':en,
                'record_text_sha256':card['text_sha256']}
            rec={'record_id':rid,**x,'evidence':ev};bylaw[x['target_law_id']].append(rec);circular_refs[rid].append(rec)
        if not refs or ('本法' in text and '本法' not in local):
            unresolved.append({'kind':'circular_needs_global_search','record_id':rid,
                               'reason':'沒有明示法規名稱或尚有未解析的本法；不從索引排除。'})
    # 可供查閱的版本與函示所據版本分開；連結不代表適用認定。
    for relation in cross+[x for items in bylaw.values() for x in items]:
        lid=relation['target_law_id']
        relation['available_source_ids']=laws[lid]['source_ids']
        relation['provision_targets']=[{'article':u['article'],'paragraph':u['paragraph'],'item':u['item'],
           'available_document_ids':[sid+':'+u['article'] for sid in laws[lid]['source_ids'] if sid+':'+u['article'] in docs],
           'not_collected_in_sources':[sid for sid in laws[lid]['source_ids'] if sid+':'+u['article'] not in docs],
           'available_versions_are_not_cited_version':True} for u in relation['provisions']]
    # 原JSON交互連結保留為待核對輸入，不升格為法律解釋；差異單列。
    gaps=[]
    for lk in oldlinks:
        target=lk.get('targetRegulationId');names=lk.get('targetRegulationNames') or []
        resolved=target if target in laws else None
        matches=set()
        for n in names:matches.update(aliases.get(normalize(n),set()))
        if not resolved and len(matches)==1:resolved=next(iter(matches))
        gaps.append({'source_id':lk['source_id'],'original_link_id':lk.get('id'),
                     'original_target_law_id':target,'target_names':names,'resolved_law_id':resolved,
                     'target_article':lk.get('targetArticleNumber'),
                     'status':'target_node_available_not_provision_or_effect_verified' if resolved else 'target_law_not_collected',
                     'original_relation_not_promoted':True})
    notes={}
    for n in cfg['notes']:
        nid=n['note_id']
        if nid in notes:raise ValueError('重複說明代碼：'+nid)
        if n['law_id'] not in laws:raise ValueError('說明核心法規不存在：'+nid)
        if not n.get('basis'):raise ValueError('說明欠缺依據：'+nid)
        for bid in n['basis']:
            if bid not in docs:raise ValueError('說明引用條文不存在：'+bid)
        for rid in n.get('circular_ids',[]):
            if rid not in circles.all_ids:raise ValueError('說明引用函示不存在：'+rid)
        for anchor in n.get('circular_evidence',[]):
            raw=circles.raw_text(anchor['record_id']);snippet=anchor['exact_text']
            if snippet not in raw:raise ValueError('函示說明缺乏支持原文：'+nid)
            anchor['source_path']=circles.card(anchor['record_id'])['source_path']
            anchor['source_sha256']=circles.card(anchor['record_id'])['source_sha256']
            anchor['line_start']=circles.card(anchor['record_id'])['source_line_start']+raw[:raw.index(snippet)].count('\n')
        notes[nid]={**n,'kind':'source_based_reading_note_not_authoritative_interpretation',
                    'human_legal_approval':False,'case_facts_included':False}
    framework=json.loads((root/ADMIN_FRAMEWORK).read_bytes())
    if framework.get('case_storage_enabled') is not False:raise ValueError('行政法框架不可保存個案')
    stage_ids=set()
    for stage in framework['stages']:
        if stage['id'] in stage_ids:raise ValueError('行政法階段代碼重複')
        stage_ids.add(stage['id'])
        if not stage.get('basis') or not stage.get('limits'):raise ValueError('行政法階段缺依據或界線')
        for bid in stage['basis']:
            if bid not in docs:raise ValueError('行政法框架引用不存在：'+bid)
    bridge=framework['bridge']
    if bridge['exact_text'] not in docs[bridge['source_document_id']]['text']:
        raise ValueError('行政法銜接缺乏支持原文')
    if bridge['target_law_id'] not in laws:raise ValueError('行政法銜接目標不存在')
    out={};docs_by_law=defaultdict(dict)
    for did,d in docs.items():docs_by_law[d['law_id']][did]=d
    routes={'schema_version':SCHEMA,'laws':laws,'representations':reps,
            'source_to_law':{sid:r['law_id'] for sid,r in reps.items()},
            'alias_to_laws':{a:sorted(ids) for a,ids in aliases.items()},
            'doc_to_law':{did:d['law_id'] for did,d in docs.items()},
            'by_law_documents':{lid:list(rows) for lid,rows in docs_by_law.items()},
            'by_law_notes':{lid:[nid for nid,n in notes.items() if n['law_id']==lid] for lid in laws},
            'circular_ids_by_law':{lid:sorted({x['record_id'] for x in bylaw[lid]}) for lid in laws}}
    search_docs=[]
    for did,d in docs.items():search_docs.append({'key':did,'kind':d['kind'],'title':d['law_name']+' '+d['display_number'],
                                               'law_id':d['law_id'],'text':normalize(d['text'])})
    for rid in sorted(circles.all_ids):
        c=circles.card(rid);search_docs.append({'key':rid,'kind':'circular','title':c['subject_raw'],
                                             'text':normalize(circles.raw_text(rid))})
    for nid,n in notes.items():search_docs.append({'key':nid,'kind':'reading_note','law_id':n['law_id'],
                                                'title':n['title'],'text':normalize(n['text']+' '+n.get('limits',''))})
    postings=defaultdict(list)
    for i,d in enumerate(search_docs):
        for g in grams(d['title']+' '+d['text']):postings[g].append(i)
    out['_index/admin-framework.json']=encode(framework)
    af=['# 行政法核心檢核入口','',framework['position'],'',framework['priority'],'',
        '本頁是Skill分析架構，不是官方解釋。只在本題相關處展開；首層警示不附帶後續內容攔截。',
        '[完整使用界線](../references/30-administrative-law-framework.md)；[行政程序法](laws/tw-administrative-procedure-act.md)；[性平法](laws/tw-gender-equity-education-act.md)。','',
        '## 特別法銜接','',bridge['exact_text'],'',
        '依據：性平法第33條第6項；'+bridge['scope'],'']
    for stage in framework['stages']:
        af+=['## '+stage['name'],'',stage['question'],'',stage['limits'],'','依據定位：']
        for bid in stage['basis']:
            d=docs[bid]
            af.append('- ['+bid+' '+d['law_name']+d['display_number']+']('+quote('../'+d['source_path'],safe='/')+')；`'+d['json_pointer']+'`。')
        af.append('')
    af+=['## 輸出','',framework['output'],'','未收法源依當次問題查官方資料，不向Skill寫回案件。','']
    out['admin-framework.md']='\n'.join(af).encode()
    out['_index/routes.json']=encode(routes)
    out['_index/search.json']=encode({'documents':search_docs,'postings':dict(postings),
      'contract':'完整詞核對；多詞AND；明示--expand才使用人工檢索詞組，僅增補候選，不視為法律同義。'})
    out['_index/notes.json']=encode(notes)
    out['_index/cross-law.json']=encode({'relations':cross,'legacy_target_audit':gaps})
    out['_index/unresolved.json']=encode({'items':unresolved,
       'known_limits':['條號範圍不自動展開；無明示定義的本法、前法與遠距指代未全面解析。',
                       '名稱相同不代表版本一致。沒有命中不是沒有相關函釋。',
                       '原跨法規連結的目標可定位，不表示該目標條文已收錄或現行有效。']})
    out['_index/config.json']=encode({'search_expansions':cfg.get('search_expansions',[])})
    for lid in laws:
        out['_index/laws/'+lid+'.json']=encode(docs_by_law[lid])
        out['_index/links/'+lid+'.json']=encode({'circular_links':bylaw[lid],
                    'cross_law_links':[x for x in cross if x['from_law_id']==lid or x['target_law_id']==lid]})
    # 閱讀頁以法規為主體；索引資料完整保存，頁面不重複堆疊各來源全文。
    for lid,law in sorted(laws.items()):
        lines=['# '+law['name'],'','本頁是法規核心導覽及有依據的閱讀提示，不是新的法源或個案認定。',
          '函示連結所據版本仍待確認；優先選定適用版本，再核對原文與例外。','',
          '## 版本與收錄範圍','','| 來源 | 修正／觀察日期 | 收錄 | 原資料 |','|---|---|---|---|']
        for sid in law['source_ids']:
            rp=reps[sid];scope='附件條目集；非现行認證'.replace('现','現') if not rp['is_partial'] else '官方頁面部分條文轉錄'
            link='../../'+rp['source_path']
            lines.append(f'| {sid} | {rp["observed_revision_date"] or "未確認"} | {scope}（{len(rp["article_ids"])}條／章節） | [來源]({quote(link,safe="/")}) |')
            if rp['official_url']:lines.append(f'')
        for sid in law['source_ids']:
            rp=reps[sid]
            lines+=['',f'**{sid}**：'+('、'.join(docs[x]['display_number'] for x in rp['article_ids']))+'。']
            for warning in rp['warnings']:lines+=['',warning]
            if rp['official_url']:lines+=['',[f'[官方網頁]({rp["official_url"]})；查閱：{rp["accessed_on"]}。'][0]]
        for nid in routes['by_law_notes'][lid]:
            n=notes[nid];lines+=['','## '+n['title'],'',n['text'],'','適用界線：'+n['limits'],
              '','依據：'+ '、'.join(n['basis'])+'。這是編製者閱讀提示，未取得人工法制審核，不代替來源。']
            for bid in n['basis']:
                d=docs[bid];lines+=['',f'- [{bid} {d["display_number"]}]({quote("../../"+d["source_path"],safe="/")})；JSON位置 `{d["json_pointer"]}`。']
            if n.get('circular_ids'):lines+=['','相關函示：'+ '、'.join(n['circular_ids'])+'；使用工具取得原文及前後函。']
        ids=routes['circular_ids_by_law'][lid]
        lines+=['','## 函示與跨法規查找','',f'本法規名稱／明確條項款候選涵蓋 {len(ids)} 筆函示；候選不是法律解釋認證。',
          f'`python scripts/lookup_legal.py --law {law["source_ids"][0]} --json`',
          '',f'[函示關聯目錄](../circulars/{lid}.md)。查特定條文另加 `--article`；法條與函示各自分頁。',
          '需要跨法規連結加 `--cross-laws`；需要特定原文加 `--full`。',
          '未分類、未解析及僅提及資料另以全域關鍵字補查，不把本頁連結當成法源全集。','']
        out['laws/'+lid+'.md']='\n'.join(lines).encode()
        crows=['# '+law['name']+'：函示候選關聯','',
               '由原稿文字建立；不推定函示適用版本、法律效果或現行效力。完整支持片段由查詢工具回傳。','',
               '| 代碼 | 文號 | 所見條項款候選 | 來源 |','|---|---|---|---|']
        for rid in ids:
            c=circles.card(rid);units=sorted({u['article']+('項'+u['paragraph'] if u['paragraph'] else '')+('款'+u['item'] if u['item'] else '')
                       for ref in bylaw[lid] if ref['record_id']==rid for u in ref['provisions']})
            crows.append(f'| {rid} | {c["document_number"]} | '+('、'.join(units) if units else '名稱提及，未解析條號')+
                         f' | [原稿]({quote("../../"+c["source_path"],safe="/")}) 第{c["source_line_start"]}–{c["source_line_end"]}行 |')
        out['circulars/'+lid+'.md']='\n'.join(crows).encode()+b'\n'
    stats={'law_nodes':len(laws),'source_representations':len(reps),'uploaded_sources':18,
      'official_excerpt_sources':len(reps)-18,'law_article_or_section_records':len(docs),
      'new_official_article_excerpts':sum(len(r['article_ids']) for r in reps.values() if r['is_partial']),
      'circular_records':len(circles.all_ids),'circular_name_or_provision_occurrences':sum(map(len,bylaw.values())),
      'explicit_circular_provision_occurrences':sum(bool(x['provisions']) for xs in bylaw.values() for x in xs),
      'cross_law_text_occurrences':len(cross),'source_backed_reading_notes':len(notes),
      'legacy_cross_links':len(gaps),'legacy_targets_not_collected':sum(g['resolved_law_id'] is None for g in gaps),
      'unresolved_items':len(unresolved),'complete_official_collection':False,
      'case_storage_enabled':False,'model_evaluation_run':False,'administrative_framework_stages':len(framework['stages'])}
    cov=['# 收錄範圍與缺口','',
      '此報告描述已登記來源，不保證全部相關法規、歷史版本或函示已收齊。',
      '原18份法規／指引逐位元保存；新增官方網頁只有明示條文的人工轉錄，沒有冒稱整頁快照。','',
      '## 已知未收法規目標','', '| 原名稱 | 出現於來源 |','|---|---|']
    absent=defaultdict(set)
    for g in gaps:
        if g['resolved_law_id'] is None:absent['／'.join(g['target_names']) or g['original_target_law_id'] or '未知'].add(g['source_id'])
    for name,sids in sorted(absent.items()):cov.append('| '+name+' | '+','.join(sorted(sids))+' |')
    cov+=['','函示另提及的學生輔導法等尚未在本次保存完整法源；需要相關專業資格定義時應查官方原文。',
      '上述缺口不因本次補收11部法規而消失。涉及犯罪構成、訴訟、民法期間、歷史法版本等時，必須依本案需求查官方原文。',
      '新版教師法僅收選定條文，禁止以較舊的附件補成無標示的「現行全文」。個資法部分條文尚未施行，不能以公布日期取代施行判斷。',
      '全部循環、別名、範圍與文字辨識問題均不可能僅靠目錄完備性證明；全域補查仍須保留。','']
    out['coverage.md']='\n'.join(cov).encode()
    lines=['# 法規核心唯讀 LLM Wiki','',
      '從適用法規與版本定位條文，再連結函示、解釋條件與必要前後函。每次啟動分析新案件，不保存或累積案件。',
      '本目錄與全部頁面由來源及 `knowledge/law-wiki-notes.json` 在發布階段產生，執行時不得改寫。',
      '只閱讀本題需要的頁面。已知文號仍可直接用函示工具，不必逐層走訪Wiki。','',
      '[使用規則](../references/28-law-centered-wiki.md)；[涵蓋範圍與缺口](coverage.md)；[行政法核心](admin-framework.md)。','',
      '法規定位以行政法為分析框架，先辨行為性質、特別規定及適用／準用；行政程序法不是性平法的形式上母法。','',
      '| 法規／指引 | 來源 | 法規頁 |','|---|---|---|']
    for lid,l in sorted(laws.items(),key=lambda kv:kv[1]['source_ids'][0]):
        lines.append(f'| {l["name"]} | '+','.join(l['source_ids'])+f' | [法規頁](laws/{lid}.md) |')
    lines+=['','精確查詢：`python scripts/lookup_legal.py --law 性平法 --article 26 --json`。',
      '跨來源搜尋：`python scripts/lookup_legal.py --query "心理諮商 時數" --json`。',
      '只要詞組可能不同，可明示 `--expand`，顯示的替代詞只作檢索，不主張法律概念相等。',
      '所有重要法律結論仍回讀條文及函示支持段落；版本未知、原件未收、部分尚未施行均不能被頁面摘要消除。','']
    out['README.md']='\n'.join(lines).encode()
    return out,sorted(set(inputs)),stats


def build_wiki(root:Path=ROOT,*,check:bool=False)->dict:
    root=root.resolve();out,inputs,stats=products(root)
    manifest={'schema_version':SCHEMA,'package_version':(root/'VERSION').read_text().strip(),
      'statistics':stats,'inputs':[{'path':p,'sha256':digest(contained(root,p).read_bytes())} for p in inputs],
      'products':[{'path':p,'bytes':len(b),'sha256':digest(b)} for p,b in sorted(out.items())],
      'runtime':'read_only_no_case_memory','source_integrity_is_not_authenticity_or_legal_validity':True}
    out['_index/manifest.json']=encode(manifest);dest=root/DEST
    if check:
        actual={p.relative_to(dest).as_posix() for p in dest.rglob('*') if p.is_file()}
        if actual!=set(out):raise ValueError('Wiki檔案集合與發布建置不同')
        for p,b in out.items():
            if contained(root,str(DEST/p),prefix=DEST).read_bytes()!=b:raise ValueError('Wiki不可重現或已過期：'+p)
    else:
        stage=Path(tempfile.mkdtemp(prefix='.wiki-build-',dir=root));backup=root/'.wiki-backup'
        try:
            for p,b in out.items():
                f=stage/p;f.parent.mkdir(parents=True,exist_ok=True);f.write_bytes(b)
            if backup.exists():raise ValueError('發現未處理的Wiki備份；先核對')
            if dest.exists():dest.rename(backup)
            try:stage.rename(dest)
            except OSError:
                if backup.exists():backup.rename(dest)
                raise
            if backup.exists():shutil.rmtree(backup)
        finally:
            if stage.exists():shutil.rmtree(stage)
    return manifest


def main()->int:
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--root',type=Path,default=ROOT);p.add_argument('--check',action='store_true');a=p.parse_args()
    try:print(json.dumps(build_wiki(a.root,check=a.check)['statistics'],ensure_ascii=False,indent=2));return 0
    except (ValueError,OSError,KeyError,TypeError) as exc:print('Wiki建置／核對失敗：'+str(exc),file=sys.stderr);return 2
if __name__=='__main__':raise SystemExit(main())
