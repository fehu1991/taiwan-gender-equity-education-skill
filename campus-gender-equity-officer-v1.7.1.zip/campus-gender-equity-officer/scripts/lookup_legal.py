#!/usr/bin/env python3
"""法規核心唯讀查詢：版本／條文／函示／證據分離，不寫回個案。Python 3.10+。"""
from __future__ import annotations
import argparse
import json
import re
import sys
import unicodedata
from datetime import date
sys.dont_write_bytecode = True
from pathlib import Path
from typing import Any
from build_circular_catalog import ROOT, normalize, digest
from build_layered_index import contained, number
from build_legal_wiki import SCHEMA, DEST, article_number
from lookup_circular_index import LayeredCatalog


class LegalWiki:
    def __init__(self,root:Path=ROOT):
        self.root=root.resolve();mp=contained(self.root,str(DEST/'_index/manifest.json'),prefix=DEST)
        self.manifest=json.loads(mp.read_bytes());self._bytes={};self._objects={}
        if self.manifest['schema_version']!=SCHEMA:raise ValueError('不支援的Wiki結構版本')
        if self.manifest['package_version']!=(self.root/'VERSION').read_text().strip():raise ValueError('Wiki版本不符，須製作新版，不自動重建')
        seen=set()
        for s in self.manifest['inputs']:
            rel=s['path']
            if rel in seen:raise ValueError('Wiki來源重複：'+rel)
            seen.add(rel);b=contained(self.root,rel).read_bytes()
            if digest(b)!=s['sha256']:raise ValueError('Wiki依據已變動或SHA不符：'+rel)
        for s in self.manifest['products']:
            rel=s['path']
            if rel in self._bytes:raise ValueError('Wiki派生檔重複：'+rel)
            b=contained(self.root,str(DEST/rel),prefix=DEST).read_bytes()
            if digest(b)!=s['sha256'] or len(b)!=s['bytes']:raise ValueError('Wiki檔案不符：'+rel)
            self._bytes[rel]=b
        self.routes=self.load('_index/routes.json');self.notes=self.load('_index/notes.json')
        self.circles=LayeredCatalog(self.root)

    def load(self,rel:str)->Any:
        if rel not in self._bytes:raise ValueError('未登記的Wiki檔案：'+rel)
        if rel not in self._objects:self._objects[rel]=json.loads(self._bytes[rel])
        return self._objects[rel]

    def resolve_law(self,value:str)->str:
        if value in self.routes['laws']:return value
        if value in self.routes['source_to_law']:return self.routes['source_to_law'][value]
        ids=self.routes['alias_to_laws'].get(normalize(value),[])
        if len(ids)==1:return ids[0]
        if len(ids)>1:raise ValueError('法規名稱有歧義，請用來源代碼或全名：'+value)
        raise ValueError('未收錄或無精確別名的法規：'+value+'；請用--list查看，不能將未命中當成不存在。')

    def doc(self,did:str)->dict:
        lid=self.routes['doc_to_law'].get(did)
        if not lid:raise ValueError('未知條文／章節：'+did)
        return self.load('_index/laws/'+lid+'.json')[did]

    def article_view(self,did:str,full:bool=False)->dict:
        d=self.doc(did);r={k:v for k,v in d.items() if k!='text'}
        r['source_coverage']=self.routes['representations'][d['source_id']]['coverage']
        r['source_warnings']=self.routes['representations'][d['source_id']]['warnings']
        r['evidence_command']=f'python scripts/lookup_legal.py --source {d["source_id"]} --article {d["article_number"]} --full --json'
        if d['unit']=='section':r['evidence_command']+= ' # article參數在指引僅為索引章節ID，沿用原章節名'
        if full:r['text']=d['text'];r['text_scope']='whole_collected_article_or_section_not_paragraph_filtered'
        return r

    def circular_view(self,rid:str,full:bool=False,as_of:str|None=None)->dict:
        r=self.circles.view(rid,full=full,as_of=as_of)
        r.pop('known_relations',None)  # 前後函在closure集中提供，避免逐卡重複長段證據。
        return r

    def related_card_view(self,rid:str,as_of:str|None=None)->dict:
        """關聯節點先回身份、限制及定位；不重複完整品質問題證據。"""
        c=self.circular_view(rid,as_of=as_of)
        keys=['record_id','document_number','publication_date','subject_raw','content_kind',
              'representation','source_path','source_line_start','source_line_end',
              'retrieval_use_status','retrieval_use_note','later_relation_ids_not_applied','evidence_command']
        v={k:c[k] for k in keys if k in c}
        v['quality_issues']=[{k:i.get(k) for k in ['issue_id','kind','finding','handling']} for i in c.get('quality_issues',[])]
        v['detail_mode']='compact_related_card; primary card and evidence via evidence_command'
        return v

    def law_link_view(self,x:dict,full:bool=False)->dict:
        """定位卡不重複原始擷取、兩份條項與來源hash；完整欄位保留在--full。"""
        if full:return x
        v={k:x.get(k) for k in ['record_id','target_law_id','relation_type','review_status',
                                'cited_version','ambiguous_alias','range_not_expanded','provision_targets']}
        v['evidence']={k:x['evidence'].get(k) for k in ['source_path','line_start','line_end',
                                                      'char_start_in_record','char_end_in_record','exact_text']}
        v['detail_mode']='compact_link; full metadata via same query --full'
        return v

    def relation_closure(self,seeds:list[str],as_of:str|None=None,full:bool=False)->dict:
        """只展開已整理前後函；保留範圍與證據，不把關係當成取代效力。"""
        seen=set(seeds);todo=list(seeds);edges={}
        adjacency={}
        for e in self.circles.relations:
            vertices={e['from_record_id'],*e.get('to_record_ids',[])}
            for v in vertices:adjacency.setdefault(v,[]).append((e,vertices))
        while todo:
            rid=todo.pop()
            for e,vertices in adjacency.get(rid,[]):
                edges[e['relation_id']]=e
                for v in vertices-seen:
                    seen.add(v);todo.append(v)
        return {'relation_count':len(edges),'relations':[self.relation_view(edges[k],as_of,full) for k in sorted(edges)],
          'related_cards':[self.related_card_view(rid,as_of=as_of) for rid in sorted(seen-set(seeds)) if rid in self.circles.all_ids],
          'complete_for_curated_graph':True,'complete_for_all_law_or_circulars':False,
          'meaning':'完整保留本頁命中在已整理圖中的前後函鏈；不推定補充即取代、日期即施行，也不自動讀全部鄰接全文。'}

    def relation_view(self,e:dict,as_of:str|None=None,full:bool=False)->dict:
        r={k:e.get(k) for k in ['relation_id','relation_type','from_record_id','to_record_ids',
                               'from_number','to_number','scope','announced_on','effective_on',
                               'effective_date_basis','review_basis','target_presence','scope_review']}
        if not full:
            for k in ['effective_date_basis','review_basis','scope_review']:
                r.pop(k,None)
        ev=e.get('evidence',{})
        r['evidence']={k:ev.get(k) for k in ['source_path','line_start','line_end','record_id','content_kind']}
        r['evidence']['exact_text_included']=full
        if full:r['evidence']['exact_text']=ev.get('exact_text')
        r['evidence_command']='python scripts/lookup_legal.py --relation '+e['relation_id']+' --full --json'
        r['outside_requested_as_of']=bool(as_of and e.get('announced_on') and e['announced_on']>as_of)
        r['legal_effect_in_this_case']='not_determined'
        return r

    def search_matches(self,q:str,expand:bool=False)->tuple[dict,dict]:
        groups=[]
        expansions=self.load('_index/config.json')['search_expansions']
        for word in q.split():
            w=normalize(word)
            if not w:continue
            alternatives={w}
            if expand:
                for group in expansions:
                    ng={normalize(x) for x in group}
                    if w in ng:alternatives.update(ng)
            groups.append(sorted(alternatives))
        if not groups:return {},{'groups':[],'expanded':False}
        data=self.load('_index/search.json');p=data['postings'];universe=set(range(len(data['documents'])))
        def hits(term):
            keys=[term] if len(term)==1 else [term[i:i+2] for i in range(len(term)-1)]
            cand=None
            for g in keys:
                ids=set(p.get(g,[]));cand=ids if cand is None else cand&ids
                if not cand:break
            # 確認完整詞，避免相同bigram不同順序造成錯誤命中。
            return {i for i in (cand or set()) if term in normalize(data['documents'][i]['title']) or term in data['documents'][i]['text']}
        for group in groups:
            part=set()
            for term in group:part|=hits(term)
            universe &= part
        matches={data['documents'][i]['key']:data['documents'][i] for i in sorted(universe)}
        return matches,{'groups':groups,'expanded':expand,'logic':'組間AND、組內OR；完整詞核對，不是語意召回保證。'}

    def list_laws(self)->dict:
        return {'contract_version':'1.0.0','package_version':self.manifest['package_version'],
          'laws':list(self.routes['laws'].values()),'statistics':self.manifest['statistics'],
          'case_memory':False,'complete_official_collection':False}

    def query(self,*,law:str|None=None,source:str|None=None,articles:list[str]|None=None,
              paragraph:str|None=None,item:str|None=None,query:str|None=None,number_value:str|None=None,
              circular_id:str|None=None,relation_id:str|None=None,full:bool=False,limit:int=10,offset:int=0,circular_offset:int=0,
              note_offset:int=0,all_results:bool=False,expand:bool=False,cross_laws:bool=False,as_of:str|None=None)->dict:
        for label,v in [('offset',offset),('circular_offset',circular_offset),('note_offset',note_offset)]:
            if not isinstance(v,int) or isinstance(v,bool) or v<0:raise ValueError(label+'須為非負整數')
        if not isinstance(limit,int) or isinstance(limit,bool) or not 1<=limit<=100:raise ValueError('limit須為1至100；全部命中用--all')
        if as_of:
            try:date.fromisoformat(as_of)
            except ValueError:raise ValueError('as-of須為有效YYYY-MM-DD日期')
        if relation_id:
            if any([law,source,articles,paragraph,item,query,number_value,circular_id]):raise ValueError('關係代碼查詢不可混用其他條件')
            if relation_id not in self.circles.relations_by_id:raise ValueError('未知前後函關係：'+relation_id)
            return {'contract_version':'1.0.0','package_version':self.manifest['package_version'],
                    'mode':'exact_relation','relation':self.relation_view(self.circles.relations_by_id[relation_id],as_of,full),
                    'read_only':True,'case_memory':False}
        if number_value or circular_id:
            if any([law,source,articles,paragraph,item,query]):raise ValueError('文號／函示代碼精確查詢不可混用法條條件，避免默默忽略限制')
            base=self.circles.query(number_value=number_value,record_id=circular_id,full=full,all_results=all_results,
                                    limit=limit,offset=offset,mention_offset=circular_offset,as_of=as_of)
            seeds=[x['record_id'] for x in base['records']]
            for row in base['records']:row.pop('known_relations',None)
            return {'contract_version':'1.0.0','mode':'exact_circular','package_version':self.manifest['package_version'],
              'circular_result':base,'known_relation_closure':self.relation_closure(seeds,as_of=as_of),
              'law_links':[self.law_link_view(x,full) for lid in self.routes['laws'] for x in self.load('_index/links/'+lid+'.json')['circular_links'] if x['record_id'] in seeds],
              'read_only':True,'case_memory':False}
        if (paragraph or item) and not articles:raise ValueError('項款篩選須同時指定法規與條號')
        lid=self.resolve_law(law) if law else None
        if source:
            if source not in self.routes['representations']:raise ValueError('未知來源代碼：'+source)
            sl=self.routes['source_to_law'][source]
            if lid and sl!=lid:raise ValueError('法規與來源條件衝突')
            lid=sl
        req=list(dict.fromkeys(article_number(a) for a in (articles or [])))
        if req and not lid:raise ValueError('條號不是全庫唯一鍵，須指定--law或--source')
        para=number(paragraph) if paragraph else None;it=number(item) if item else None
        parsed_query=query or '';interpretation=[]
        # 只移除可唯一辨識的明示法規名稱與條號，不猜自然語言中的身分或事實。
        if parsed_query and not lid:
            detected=[]
            for a,ids in sorted(self.routes['alias_to_laws'].items(),key=lambda kv:-len(kv[0])):
                if len(a)>=3 and a in normalize(parsed_query) and len(ids)==1:
                    if not any(a in previous[0] for previous in detected):detected.append((a,ids[0]))
            unique={x[1] for x in detected}
            if len(unique)==1:
                lid=next(iter(unique));nq=unicodedata.normalize('NFKC',parsed_query).replace('台','臺').upper()
                for a,_ in detected:nq=nq.replace(a,' ')
                pm=re.search(r'第[0-9〇零一二三四五六七八九十百千兩]+條(?:之[0-9〇零一二三四五六七八九十百千兩]+)?(?:第[0-9〇零一二三四五六七八九十百千兩]+項)?',nq)
                if pm:
                    from build_layered_index import PROVISION
                    m=PROVISION.fullmatch(pm.group())
                    if m:
                        req=[number(m['article'])+('-'+number(m['sub']) if m['sub'] else '')];para=number(m['paragraph'])
                        nq=nq[:pm.start()]+' '+nq[pm.end():]
                parsed_query=nq.strip();interpretation.append('只將唯一法規全名／別名與明示條項轉為結構化條件；可用參數覆寫。')
        matches,qinfo=self.search_matches(parsed_query,expand) if parsed_query.strip() else ({},{'groups':[],'expanded':False})
        active=bool(parsed_query.strip())
        candidate_docs=[did for did,l in self.routes['doc_to_law'].items() if (not lid or l==lid) and (not source or did.startswith(source+':'))]
        requested_presence={a:[did for did in candidate_docs if self.doc(did)['article_number']==a] for a in req}
        article_ids=[did for did in candidate_docs if (not req or self.doc(did)['article_number'] in req) and (not active or did in matches)]
        article_ids.sort(key=lambda did:(self.doc(did)['law_name'],self.doc(did)['article_number'],self.doc(did)['source_id']))
        source_coverage=[]
        scope_sids=[source] if source else (self.routes['laws'][lid]['source_ids'] if lid else [])
        for sid in scope_sids:
            rp=self.routes['representations'][sid]
            source_coverage.append({**{k:v for k,v in rp.items() if k not in ['article_ids','original_version_metadata']},
              'requested_articles_not_collected':[a for a in req if sid+':'+a not in self.routes['doc_to_law']]})
        links=[]
        for l in ([lid] if lid else self.routes['laws']):links.extend(self.load('_index/links/'+l+'.json')['circular_links'])
        def provision_match(x):
            if not req:return True
            if x['ambiguous_alias']:return False
            return any(u['article'] in req and (not para or u['paragraph']==para) and (not it or u['item']==it) for u in x['provisions'])
        selected_links=[x for x in links if provision_match(x)]
        cids=sorted({x['record_id'] for x in selected_links}) if lid else sorted(self.circles.all_ids)
        if active:cids=[rid for rid in cids if rid in matches]
        # 無法規連結的函示仍可全域查到；限定法規查詢另揭露未解析候選數，絕不宣称已查全。 
        related_scope=sorted({x['record_id'] for x in links}-set(cids)) if lid else []
        nids=[nid for nid,n in self.notes.items() if (not lid or n['law_id']==lid)
              and (not req or any(self.doc(b)['law_id']==lid and self.doc(b)['article_number'] in req for b in n['basis']))
              and (not active or nid in matches)]
        def page(ids,off):
            chosen=ids if all_results else ids[off:off+limit]
            stop=len(ids) if all_results else off+len(chosen)
            return chosen,{'total_matches':len(ids),'returned':len(chosen),'offset':0 if all_results else off,
                           'next_offset':stop if stop<len(ids) else None,'truncated':not all_results and (off>0 or stop<len(ids))}
        ap,am=page(article_ids,offset);cp,cm=page(cids,circular_offset);np,nm=page(nids,note_offset)
        page_links=[x for x in selected_links if x['record_id'] in cp]
        missing=[a for a,ids in requested_presence.items() if not ids]
        filtered=[a for a,ids in requested_presence.items() if ids and not set(ids)&set(article_ids)]
        result={'contract_version':'1.0.0','package_version':self.manifest['package_version'],'mode':'law_centered',
          'status':'partial_source_coverage' if missing or any(s['requested_articles_not_collected'] for s in source_coverage) else 'retrieved_not_legal_certification',
          'resolved_law_id':lid,'as_of_context':as_of,'as_of_does_not_select_legal_version':True,'requested_articles':req,'requested_paragraph':para,'requested_item':it,
          'source_coverage':source_coverage,'missing_requested_articles':missing,'requested_articles_filtered_out':filtered,
          'query_interpretation':interpretation,'search_logic':qinfo,
          'articles':{'page':am,'records':[self.article_view(did,full) for did in ap]},
          'circulars':{'page':cm,'records':[self.circular_view(rid,full=full,as_of=as_of) for rid in cp],
                       'law_links':[self.law_link_view(x,full) for x in page_links],'other_law_related_candidates_count':len(related_scope),
                       'cited_version':'unknown_not_auto_mapped_to_selected_law_source'},
          'reading_notes':{'page':nm,'records':[self.notes[nid] for nid in np]},
          'known_relation_closure':self.relation_closure(cp,as_of=as_of),
          'warnings':['條項款只過濾明示引用候選；原法條全文仍保留，不假裝已切出指定項款。',
              '法規名稱、修正日期及關係連結不能取代適用版本、施行命令、例外及原文核對。',
              '查無資料不代表不存在；全域關鍵字、未解析資料及官方網站應依本案需要補查。',
              '資料為固定發布快照，未全庫核實現行效力；僅最新觀察日期不能證明完整。'],
          'read_only':True,'case_memory':False,'complete_official_collection':False}
        if cross_laws:
            allx=self.load('_index/cross-law.json')['relations']
            result['cross_law_links']=[x for x in allx if (not lid or x['from_law_id']==lid or x['target_law_id']==lid)
              and (not req or (x['from_law_id']==lid and self.doc(x['from_document_id'])['article_number'] in req)
                   or (x['target_law_id']==lid and any(u['article'] in req for u in x['provisions'])))]
            result['cross_law_links_note']='已選範圍完整文字關聯；目標版本未知，可能未收所援引條文，非適用認證。'
        return result


def main()->int:
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--root',type=Path,default=ROOT)
    p.add_argument('--list',action='store_true');p.add_argument('--law');p.add_argument('--source')
    p.add_argument('--article',action='append');p.add_argument('--paragraph');p.add_argument('--item');p.add_argument('--query')
    p.add_argument('--number');p.add_argument('--circular');p.add_argument('--relation');p.add_argument('--as-of')
    p.add_argument('--full',action='store_true');p.add_argument('--json',action='store_true')
    p.add_argument('--all',action='store_true');p.add_argument('--expand',action='store_true');p.add_argument('--cross-laws',action='store_true')
    p.add_argument('--limit',type=int,default=10);p.add_argument('--offset',type=int,default=0)
    p.add_argument('--circular-offset',type=int,default=0);p.add_argument('--note-offset',type=int,default=0)
    a=p.parse_args()
    try:
        db=LegalWiki(a.root)
        criteria=any([a.law,a.source,a.article,a.paragraph,a.item,a.query,a.number,a.circular,a.relation])
        if a.list and criteria:raise ValueError('--list不可混用查詢條件；避免將未執行的篩選誤認為已查核')
        if a.list or not criteria:r=db.list_laws()
        else:r=db.query(law=a.law,source=a.source,articles=a.article,paragraph=a.paragraph,item=a.item,query=a.query,
             number_value=a.number,circular_id=a.circular,relation_id=a.relation,full=a.full,limit=a.limit,offset=a.offset,circular_offset=a.circular_offset,
             note_offset=a.note_offset,all_results=a.all,expand=a.expand,cross_laws=a.cross_laws,as_of=a.as_of)
        if a.json:print(json.dumps(r,ensure_ascii=False,indent=2))
        elif 'laws' in r:
            for l in r['laws']:print(l['name']+' | '+','.join(l['source_ids'])+' | wiki/laws/'+l['law_id']+'.md')
            print('固定法規／指引資料；不是現行法全集。')
        elif r['mode']=='exact_relation':
            print(json.dumps(r,ensure_ascii=False,indent=2))
        elif r['mode']=='exact_circular':
            for c in r['circular_result']['records']:print(c['record_id']+' '+c['document_number']+'\n'+c.get('raw_text',c['subject_raw']))
            print('已知前後函鏈：'+str(r['known_relation_closure']['relation_count'])+'；細節用--json。')
        else:
            print('法規：'+str(r['resolved_law_id'])+'；'+r['status'])
            for section in ['articles','circulars','reading_notes']:
                meta=r[section]['page'];print('\n'+section+f'：{meta["returned"]}/{meta["total_matches"]}；下一頁 {meta["next_offset"]}')
                for row in r[section]['records']:
                    print(row.get('document_id',row.get('record_id',row.get('note_id','')))+' '+row.get('law_name',row.get('title',row.get('document_number',''))))
                    print(row.get('text',row.get('raw_text',row.get('subject_raw',row.get('display_number','')))))
            if r['missing_requested_articles']:print('未收指定條號：'+','.join(r['missing_requested_articles']))
            for s in r['source_coverage']:
                if s['requested_articles_not_collected']:print(s['source_id']+'未收：'+','.join(s['requested_articles_not_collected']))
            print('前後函及來源限制請讀--json；需要原文加--full。Wiki與查詢均不写回個案。'.replace('写','寫'))
        partial=r.get('status')=='partial_source_coverage'
        return 3 if partial else 0
    except (ValueError,OSError,KeyError,TypeError) as exc:
        print(json.dumps({'error':str(exc),'read_only':True},ensure_ascii=False),file=sys.stderr);return 2
if __name__=='__main__':raise SystemExit(main())
