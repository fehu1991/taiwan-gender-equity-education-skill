#!/usr/bin/env python3
"""比較同一套件舊API完整JSON與新索引卡。不是LLM token、召回率或法律正確性評測。"""
from __future__ import annotations
import argparse
import json
import statistics
import time
from pathlib import Path
from typing import Any
from build_circular_catalog import ROOT
from lookup_circular import CircularCatalog, text_output as legacy_text
from lookup_circular_index import LayeredCatalog


def size(x:Any) -> int:
    return len(json.dumps(x,ensure_ascii=False,indent=2).encode('utf-8'))+1


def run(root:Path=ROOT,repeats:int=3) -> dict[str,Any]:
    timings={}
    for name,cls in [('legacy_catalog',CircularCatalog),('layered_index',LayeredCatalog)]:
        samples=[]
        for _ in range(repeats):
            start=time.perf_counter();cls(root);samples.append(time.perf_counter()-start)
        timings[name]={'repeats':repeats,'median_initialization_seconds':statistics.median(samples),'samples_seconds':samples}
    old=CircularCatalog(root);new=LayeredCatalog(root);rows=[]
    for options in [{'query':'心理諮商'},{'topic':'通報與保護'},{'query':'執行秘書'},{'number':'1132805149'}]:
        a=old.query(**options)
        opts=dict(options)
        if 'number' in opts:opts['number_value']=opts.pop('number')
        b=new.query(**opts,all_results=True);page=new.query(**opts)
        old_ids=[r['record_id'] for r in a['records']];new_ids=[r['record_id'] for r in b['records']]
        rows.append({'query':options,'primary_matches':len(old_ids),'same_ordered_primary_ids':old_ids==new_ids,
                     'legacy_all_full_json_bytes':size(a),'new_all_cards_json_bytes':size(b),
                     'new_default_page_json_bytes':size(page),'new_default_primary_count':page['returned'],
                     'legacy_default_text_bytes':len((legacy_text(a,False,10)+'\n').encode()),
                     'note':'完整JSON與卡片保留的主件集合相同；卡片未含全文，正式引用仍需另讀原文。原預設文字本已較精簡。'})
    return {'package_version':(root/'VERSION').read_text().strip(),'measurement':'UTF-8 bytes and local initialization timing',
            'timings':timings,'cases':rows,
            'limitations':['不是token數、實際模型延遲或整题成本。'.replace('题','題'),
                          '不以本次四個查詢代表所有題型或語意召回率。',
                          '新索引增加磁碟派生檔；不等於每次載入模型的內容增加。',
                          '未比較完整的LLM工作流程及維護成本，不保證所有查詢比舊文字模式省。']}

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--root',type=Path,default=ROOT)
    p.add_argument('--repeats',type=int,default=3);a=p.parse_args()
    if not 1<=a.repeats<=10:p.error('repeats須為1–10')
    print(json.dumps(run(a.root,a.repeats),ensure_ascii=False,indent=2))
