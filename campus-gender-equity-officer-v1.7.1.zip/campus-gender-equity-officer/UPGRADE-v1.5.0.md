# v1.5.0升級說明：函示分層索引

基礎版本v1.4.0；本版為完整套件，不是只有新增檔案的修補包。保留資料、法律分析、實務模組及AI指引，不建立LLM Wiki。只有索引及其使用規則、工具、測試與發行紀錄更新。

## 需要注意的相容性變更

`lookup_circular.py --json`改用v2契約：預設索引卡、每頁10筆。要原文加`--full`，要本次條件全部命中加`--all`。`--full --all --json`才與舊CLI完整JSON接近，欄位仍有新增。舊程式若依賴raw_text或把records當全部結果，應先調整；過渡可用`--legacy --json`保持舊CLI行為。

Python程式直接匯入`CircularCatalog`者維持舊API與嚴格重建。新API為`lookup_circular_index.LayeredCatalog`，查詢精確文號參數為`number_value`，不是舊API的`number`。

主題與關鍵字／文號／代碼／法規併用時，預設改為主題優先排序並保留其他符合資料。需原本的硬篩選時加`--strict-topic`；單獨主題查詢仍採該主題範圍。年份與發文截止日期仍是篩選，未改為偏好。

精確文號主件保持全部回傳；一般主件及文號提及各有分頁欄位。exit 0不是所有資料已讀完，也不是有效性認證。完整契約見[27號模組](references/27-circular-layered-index.md)。

## 新增索引

入口層含完整文號、流水號（保留A/B/C字尾）、代碼、年份、15主題、18份法規附件名稱。索引卡按23年度分片，另有可直接閱讀的年度Markdown卡片。文字反向索引對全部354筆原文區塊建立單字／雙字候選，取得候選後核對完整詞，未分類14筆同樣可被搜尋。

法規入口從附件名稱與別名出發，擷取緊接的明確條項款並保留原文位置。多條／多項明確引用不壓成一條。這是機器可重建的文字援引候選；沒有宣稱建立完整法律關係，沒有將函示指定為適用附件所列版本。未解指代及範圍需全域補查；原139筆法規交互連結未被冒充為已校正、已核實的關係資料。

已整理43條前後函及27項品質／重號提示沿用原紀錄。命中卡片帶回必要關係；`--related`額外取得直接相關卡片，不擴至全部知識網，不自動讀關係對方全文。純提及與已整理法律關係維持分開。

## 查詢與建置分離

查詢核對來源、版本、索引檔雜湊，不重跑切分、分類及引用抽取。索引過期或雜湊失敗會停止，不悄悄使用舊結果。完整檢查另用`build_layered_index.py --check`，由來源重建比對；維護時才寫入新索引。新增資料不得覆寫歷史來源或重用代碼指向不同公文。

索引manifest與資料的雜湊是內部一致性機制，不是來源真實性或防竄改簽章。所有檔案及manifest同時被修改仍需可信發行清單、外部版本管理與權限控制；不可為加速而宣稱已獲完整資安認證。

## 保留與未完成事項

v1.4.0所有sources檔案逐位元比對；本版未新增法規或函示原件、未修正文號或法律內容、未重新核認各函現行效力。AI原指引及既有使用規則保留，個案資料不自動進入索引或知識庫。

程式測試涵蓋原始區塊一致、搜尋集合、分頁、重號、字尾、停止／部分修正關係、法規候選與來源位置、索引過期、檔案變更及路徑越界。新增模型情境保持未執行；沒有實際平台匯入或Astra／Claude作答評測，不以自動測試替代法律查核。

## 技術設計參照

2026-09-19查閱Agent Skills規格、Claude官方最佳實務及OpenAI的Astra技能建議，採主檔直接入口、按題取得資料、不強制深層逐頁閱讀。這是本版設計參照，不是模型效能認證；網頁全文未收入套件。

- Agent Skills Specification：https://agentskills.io/specification
- Claude Skill authoring best practices：https://platform.claude.com/docs/en/agents-and-tools/agent-skills/best-practices
- OpenAI, Rethinking skills and prompts for GPT-6 Astra：https://developers.openai.com/blog/rethinking-skills-and-prompts-for-gpt-6-astra
