"""v1.5.0回歸：資料與工具契約。不是Astra／Claude實際作答評測。"""
from __future__ import annotations
import hashlib
import json
import shutil
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'scripts'))
from build_layered_index import build_index, citation_units, law_occurrences, normalized_offsets, number
from lookup_circular_index import LayeredCatalog
from lookup_circular import CircularCatalog


class LayeredRetrievalTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.db=LayeredCatalog(ROOT);cls.old=CircularCatalog(ROOT)

    def test_records_preserved(self):
        self.assertEqual(len(self.db.all_ids),354)
        self.assertEqual(self.db.all_ids,{r['record_id'] for r in self.old.records})

    def test_all_record_cards_without_full_text(self):
        for rid in self.db.all_ids:
            r=self.db.view(rid)
            self.assertNotIn('raw_text',r);self.assertEqual(r['source_layer'],'metadata_card')
            self.assertIn('--full',r['evidence_command'])

    def test_all_full_blocks_equal_original(self):
        for r in self.old.records:
            self.assertEqual(self.db.raw_text(r['record_id']),r['raw_text'])

    def test_default_json_cli_is_paginated_cards(self):
        p=subprocess.run([sys.executable,str(ROOT/'scripts/lookup_circular.py'),'--query','應','--json'],capture_output=True,text=True)
        self.assertEqual(p.returncode,0,p.stderr);r=json.loads(p.stdout)
        self.assertEqual(r['contract_version'],'2.0.0');self.assertEqual(r['returned'],10)
        self.assertTrue(r['truncated']);self.assertTrue(all('raw_text' not in x for x in r['records']))

    def test_global_keyword_parity_with_legacy(self):
        for q in ['應','學校','執行秘書','心理諮商','受理 程序審查','調查小組','停止適用','09300111761','新事證','臺教學','abcdefghNO_MATCH']:
            with self.subTest(q=q):
                a=self.old.query(query=q);b=self.db.query(query=q,all_results=True)
                self.assertEqual([x['record_id'] for x in a['records']],[x['record_id'] for x in b['records']])

    def test_all_numbers_primary_parity(self):
        for n in {r['number_key'] for r in self.old.records}:
            expected={r['record_id'] for r in self.old.records if r['number_key']==n}
            self.assertEqual({r['record_id'] for r in self.db.query(number_value=n)['records']},expected)

    def test_page_roundtrip(self):
        whole=self.db.query(query='應',all_results=True);parts=[];offset=0
        while True:
            page=self.db.query(query='應',limit=37,offset=offset)
            parts.extend(page['records'])
            if page['next_offset'] is None:break
            offset=page['next_offset']
        self.assertEqual(parts,whole['records']);self.assertEqual(len(parts),313)
        self.assertEqual(len({r['record_id'] for r in parts}),313)

    def test_last_page_still_not_whole_query(self):
        r=self.db.query(query='應',limit=100,offset=300)
        self.assertEqual(r['returned'],13);self.assertIsNone(r['next_offset'])
        self.assertTrue(r['truncated']);self.assertFalse(r['response_complete_for_query'])

    def test_topic_preference_preserves_unclassified_hit(self):
        r=self.db.query(query='執行秘書',topic='會務與迴避')
        self.assertEqual(r['match_count'],7);self.assertEqual(r['outside_preferred_topic_count'],5)
        self.assertIn('C2010-016',[x['record_id'] for x in r['records']])

    def test_topic_strict_opt_in(self):
        r=self.db.query(query='執行秘書',topic='會務與迴避',strict_topic=True)
        self.assertEqual(r['match_count'],2);self.assertEqual(r['query']['topic_mode'],'strict_filter')

    def test_topic_alone_matches_old_scope(self):
        for t in self.db.routes['by_topic']:
            self.assertEqual({r['record_id'] for r in self.old.query(topic=t)['records']},
                             {r['record_id'] for r in self.db.query(topic=t,all_results=True)['records']})

    def test_unclassified_query(self):
        r=self.db.query(unclassified=True,all_results=True)
        self.assertEqual(r['match_count'],14);self.assertTrue(all(not x['topics'] for x in r['records']))

    def test_duplicate_exact_not_limited(self):
        r=self.db.query(number_value='1080108133',limit=1)
        self.assertEqual(r['returned'],2);self.assertFalse(r['truncated'])
        self.assertEqual({x['record_id'] for x in r['records']},{'C2019-009','C2019-010'})

    def test_suffixes_and_width(self):
        a=self.db.query(number_value='台教學（三）字第１１３２８０４７４１Ａ號')
        self.assertEqual(a['match_count'],2)
        self.assertEqual(self.db.query(number_value='1132804741')['match_count'],0)

    def test_mentioned_only_not_promoted(self):
        r=self.db.query(number_value='09300111761')
        self.assertEqual(r['match_count'],0);self.assertEqual(r['mention_count'],3)
        for m in r['mentions_only']:
            self.assertFalse(m['independent_original_included']);self.assertNotIn('publication_date',m)

    def test_mention_pagination(self):
        rows=[]
        for i in range(3):
            r=self.db.query(number_value='09300111761',limit=1,mention_offset=i)
            rows.extend(r['mentions_only']);self.assertTrue(r['mentions_truncated'])
        self.assertEqual(rows,self.db.query(number_value='09300111761',all_results=True)['mentions_only'])

    def test_mention_evidence_exact(self):
        for m in self.db.query(number_value='09300111761')['mentions_only']:
            b=(ROOT/m['source_path']).read_bytes()
            self.assertEqual(hashlib.sha256(b).hexdigest(),m['source_sha256'])
            for e in m['excerpts']:self.assertEqual(b.decode().splitlines()[e['line']-1],e['text'])

    def test_full_number_no_wrong_issuer(self):
        self.assertEqual(self.db.query(number_value='華總一義字第09300111761號')['mention_count'],3)
        self.assertEqual(self.db.query(number_value='不存在機關字第09300111761號')['mention_count'],0)

    def test_unknown_dates_excluded_not_filled(self):
        r=self.db.query(year=2024,as_of='2026-09-19',all_results=True)
        self.assertEqual(set(r['undated_record_ids_excluded']),{'C2024-013','C2024-014'})
        self.assertEqual(r['undated_records_excluded'],2)

    def test_known_cessation_preserved(self):
        r=self.db.query(number_value='1010245259')['records'][0]
        self.assertEqual(r['retrieval_use_status'],'has_explicit_cessation_evidence')
        self.assertTrue(r['known_relations'])

    def test_partial_change_not_whole_cessation(self):
        r=self.db.query(number_value='1020080238')['records'][0]
        self.assertEqual(r['retrieval_use_status'],'has_partial_change_evidence')

    def test_cutoff_does_not_apply_future_relation(self):
        r=self.db.query(number_value='1010245259',as_of='2023-12-31')['records'][0]
        self.assertNotEqual(r['retrieval_use_status'],'has_explicit_cessation_evidence')
        self.assertTrue(r['later_relation_ids_not_applied'])

    def test_relation_not_lost_by_topic_preference(self):
        r=self.db.query(record_id='C2024-012',topic='會務與迴避')['records'][0]
        self.assertIn('CR-041',[x['relation_id'] for x in r['known_relations']])

    def test_related_cards_do_not_read_neighbor_fulltext(self):
        r=self.db.query(record_id='C2024-012',related=True,full=True)
        self.assertTrue(r['related_records']);self.assertIn('raw_text',r['records'][0])
        self.assertTrue(all('raw_text' not in x for x in r['related_records']))

    def test_no_match_keeps_scope(self):
        r=self.db.query(query='zzxxNonexistentTERM')
        self.assertEqual(r['match_count'],0);self.assertTrue(r['coverage_note'])
        self.assertEqual(r['records'],[])

    def test_empty_and_invalid_inputs(self):
        for opts in [{},{'query':' '},{'number_value':' '},{'law':' '},{'query':'x','limit':0},
                     {'query':'x','limit':101},{'query':'應','offset':-1},{'query':'應','offset':313},
                     {'query':'應','offset':1,'all_results':True},
                     {'number_value':'1080108133','offset':1},{'query':'x','as_of':'20240101'},
                     {'query':'x','as_of':'2024-02-30'},{'query':'x','strict_topic':True},
                     {'query':'x','articles':['26']},{'law':'性平法','paragraph':'2'},
                     {'law':'性平法','number_value':'1132805149'}]:
            with self.subTest(opts=opts),self.assertRaises(ValueError):self.db.query(**opts)

    def test_cli_other_working_directory(self):
        p=subprocess.run([sys.executable,str(ROOT/'scripts/lookup_circular.py'),'--id','C2024-012','--json','--full'],cwd='/tmp',capture_output=True,text=True)
        self.assertEqual(p.returncode,0,p.stderr);self.assertIn('raw_text',json.loads(p.stdout)['records'][0])

    def test_legacy_cli_explicitly_available(self):
        p=subprocess.run([sys.executable,str(ROOT/'scripts/lookup_circular.py'),'--legacy','--number','1132805149','--json'],capture_output=True,text=True)
        self.assertEqual(p.returncode,0,p.stderr);self.assertIn('raw_text',json.loads(p.stdout)['records'][0])

    def test_index_reader_does_not_rebuild(self):
        with patch('build_circular_catalog.build',side_effect=AssertionError('must not rebuild')):
            db=LayeredCatalog(ROOT);self.assertEqual(db.query(record_id='C2024-012')['match_count'],1)

    def test_rebuild_exact_bytes(self):
        self.assertEqual(build_index(ROOT,check=True)['package_version'],(ROOT/'VERSION').read_text().strip())


class LawCandidateTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):cls.db=LayeredCatalog(ROOT)

    def test_law_article_candidate_includes_known_letter(self):
        r=self.db.query(law='性平法',articles=['26'],all_results=True)
        self.assertIn('C2024-012',[x['record_id'] for x in r['records']])
        self.assertFalse(r['law_lookup']['citation_version_verified'])

    def test_paragraph_filter(self):
        r=self.db.query(law='U02',articles=['第２６條'],paragraph='第二項')
        self.assertIn('C2024-012',[x['record_id'] for x in r['records']])
        self.assertEqual(r['law_lookup']['requested_paragraph'],'2')

    def test_multiple_requested_articles_counts(self):
        r=self.db.query(law='性平法',articles=['26','999'])
        self.assertEqual(r['law_lookup']['explicit_candidate_counts_before_other_filters']['999'],0)
        self.assertGreater(r['law_lookup']['explicit_candidate_counts_before_other_filters']['26'],0)

    def test_broad_law_retains_other_mentions(self):
        narrow=self.db.query(law='性平法',articles=['26'],all_results=True)
        broad=self.db.query(law='性平法',articles=['26'],broad_law=True,all_results=True)
        self.assertGreater(broad['match_count'],narrow['match_count'])
        self.assertTrue(any(x['law_candidate_match']=='name_only_or_other_provision_not_requested' for x in broad['records']))
        self.assertEqual([r['record_id'] for r in broad['records'][:narrow['match_count']]], [r['record_id'] for r in narrow['records']])

    def test_no_assigned_cited_version(self):
        for law in self.db.load('law-routes.json').values():
            for o in self.db.load(law['occurrences_file'])['occurrences']:
                self.assertIsNone(o['cited_version']);self.assertEqual(o['legal_effect'],'not_inferred')

    def test_each_candidate_evidence_is_in_source_lines(self):
        for law in self.db.load('law-routes.json').values():
            for o in self.db.load(law['occurrences_file'])['occurrences']:
                e=o['evidence'];lines=(ROOT/e['source_path']).read_text().splitlines(keepends=True)
                self.assertIn(e['exact_text'],''.join(lines[e['line_start']-1:e['line_end']]))

    def test_compound_articles_not_collapsed(self):
        units,end,amb=citation_units('第21條第1項及第33條第3項規定',0)
        self.assertEqual(units,[{'article':'21','paragraph':'1','item':None},{'article':'33','paragraph':'3','item':None}])
        self.assertFalse(amb)

    def test_compound_paragraph_and_item(self):
        u,_,_=citation_units('第26條第1項及第2項第3款',0)
        self.assertEqual(u[-1],{'article':'26','paragraph':'2','item':'3'})

    def test_chinese_numbers_and_subarticle(self):
        u,_,_=citation_units('第二十一條第一項及第三十三條之二第三項',0)
        self.assertEqual(u[0]['article'],'21');self.assertEqual(u[1]['article'],'33-2')
        self.assertEqual(number('一百零二'),'102')

    def test_range_not_silently_expanded(self):
        units,end,amb=citation_units('第26條至第30條',0)
        self.assertTrue(amb);self.assertEqual(len(units),1)
        self.assertEqual(units[0]['article'],'26')

    def test_longest_name_prevents_parent_law_false_assignment(self):
        laws={'A':{'aliases_from_uploaded_metadata':['教師法']},'B':{'aliases_from_uploaded_metadata':['教師法施行細則']}}
        row={'record_id':'synthetic','raw_text':'依教師法施行細則第3條','source_path':'synthetic.md','source_line_start':1}
        out=law_occurrences(row,laws)
        self.assertEqual([x['source_id'] for x in out],['B'])

    def test_bare_this_law_not_guessed(self):
        row={'record_id':'synthetic','raw_text':'依本法第25條','source_path':'synthetic.md','source_line_start':1}
        self.assertEqual(law_occurrences(row,{'A':{'aliases_from_uploaded_metadata':['性別平等教育法']}}),[])

    def test_unresolved_registry_is_searchable(self):
        d=self.db.load('unresolved.json')
        self.assertEqual(len(d['unclassified_ids']),14)
        self.assertEqual(len(d['unknown_publication_date_ids']),4)
        self.assertEqual(len(d['catalog_summary_only_ids']),3)
        self.assertIn('C2010-016',d['unclassified_ids'])

    def test_available_version_not_invented_effectivity(self):
        r=self.db.query(law='U02')
        self.assertIn('available_source_version',r['law_lookup'])
        self.assertFalse(r['law_lookup']['citation_version_verified'])


class IndexIntegrityTests(unittest.TestCase):
    def fixture(self):
        td=tempfile.TemporaryDirectory();self.addCleanup(td.cleanup)
        root=Path(td.name)/ROOT.name
        shutil.copytree(ROOT,root,ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
        return root

    def test_tampered_input_rejected(self):
        root=self.fixture();m=json.loads((root/'indexes/circulars/manifest.json').read_text())
        rel=next(x['path'] for x in m['inputs'] if '/uploaded/' in x['path'] and 'circulars' in x['path'])
        with (root/rel).open('ab') as f:f.write(b'changed')
        with self.assertRaises(ValueError):LayeredCatalog(root)

    def test_tampered_card_rejected(self):
        root=self.fixture();p=root/'indexes/circulars/cards/2024.json';p.write_bytes(p.read_bytes()+b' ')
        with self.assertRaises(ValueError):LayeredCatalog(root)

    def test_tampered_term_posting_rejected(self):
        root=self.fixture();p=root/'indexes/circulars/terms.json';p.write_text('{}')
        with self.assertRaises(ValueError):LayeredCatalog(root)

    def test_missing_index_file_rejected(self):
        root=self.fixture();(root/'indexes/circulars/laws/U02.json').unlink()
        with self.assertRaises((OSError,ValueError)):LayeredCatalog(root)

    def test_stale_version_rejected(self):
        root=self.fixture();(root/'VERSION').write_text('1.9.9\n')
        with self.assertRaises(ValueError):LayeredCatalog(root)

    def test_manifest_unsafe_path_rejected(self):
        root=self.fixture();p=root/'indexes/circulars/manifest.json';m=json.loads(p.read_text())
        m['inputs'][0]['path']='../../outside';p.write_text(json.dumps(m))
        with self.assertRaises(ValueError):LayeredCatalog(root)

    def test_rebuild_catches_semantic_tampering_even_if_hash_updated(self):
        root=self.fixture();p=root/'indexes/circulars/cards/2024.json';doc=json.loads(p.read_text());doc['C2024-012']['subject_raw']='changed'
        b=json.dumps(doc).encode();p.write_bytes(b)
        mp=root/'indexes/circulars/manifest.json';m=json.loads(mp.read_text())
        for x in m['products']:
            if x['path']=='cards/2024.json':x.update(bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
        mp.write_text(json.dumps(m))
        with self.assertRaises(ValueError):build_index(root,check=True)

    def test_query_does_not_write_files(self):
        root=self.fixture()
        def inventory():return {p.relative_to(root).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in root.rglob('*') if p.is_file() and '__pycache__' not in p.parts}
        before=inventory();db=LayeredCatalog(root);db.query(query='心理諮商',full=True)
        self.assertEqual(before,inventory())

if __name__=='__main__':unittest.main()
