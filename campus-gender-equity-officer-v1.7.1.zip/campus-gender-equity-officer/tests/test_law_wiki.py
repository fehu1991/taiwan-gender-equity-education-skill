"""v1.6.0確定性回歸：來源、版本、候選引用、唯讀查詢。不是模型法律作答評測。"""
from __future__ import annotations
import hashlib,json,os,shutil,subprocess,sys,tempfile,unittest
from pathlib import Path
from unittest.mock import patch
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'scripts'))
from build_legal_wiki import article_number,document_definitions,extract_citations,build_wiki
from lookup_legal import LegalWiki
from build_circular_catalog import normalize

class WikiTests(unittest.TestCase):
 @classmethod
 def setUpClass(cls):cls.db=LegalWiki(ROOT)
 def test_29_law_nodes(self):self.assertEqual(len(self.db.routes['laws']),29)
 def test_34_source_representations(self):self.assertEqual(len(self.db.routes['representations']),34)
 def test_661_article_or_section_representations(self):self.assertEqual(len(self.db.routes['doc_to_law']),661)
 def test_all_circulars_preserved(self):self.assertEqual(len(self.db.circles.all_ids),354)
 def test_uploaded_sources_not_labeled_official_full(self):
  for sid,r in self.db.routes['representations'].items():
   if sid.startswith('U'):self.assertEqual(r['coverage'],'uploaded_article_set_not_current_certified')
 def test_official_excerpts_honest_scope(self):
  for sid,r in self.db.routes['representations'].items():
   if sid.startswith('O'):
    o=json.loads((ROOT/r['source_path']).read_bytes());self.assertFalse(o['full_official_text_included']);self.assertFalse(o['raw_webpage_included']);self.assertEqual(o['representation'],'manually_transcribed_official_web_excerpts')
 def test_every_source_sha(self):
  for r in self.db.routes['representations'].values():self.assertEqual(hashlib.sha256((ROOT/r['source_path']).read_bytes()).hexdigest(),r['source_sha256'])
 def test_document_json_pointer_and_text(self):
  for did in self.db.routes['doc_to_law']:
   d=self.db.doc(did);o=json.loads((ROOT/d['source_path']).read_bytes())
   for part in d['json_pointer'].strip('/').split('/'):o=o[int(part)] if isinstance(o,list) else o[part]
   self.assertEqual(d['text'],o.get('plainText',o.get('text')));self.assertEqual(hashlib.sha256(d['text'].encode()).hexdigest(),d['text_sha256'])
 def test_exact_name_alias_and_source(self):
  for alias in ['性平法','性別平等教育法','U02','O1613']:self.assertEqual(self.db.resolve_law(alias),'tw-gender-equity-education-act')
 def test_new_law_alias(self):
  self.assertEqual(self.db.resolve_law('性工法'),'tw-gender-equality-employment-act')
  source=json.loads((ROOT/'sources/wiki-official/O1604.json').read_text())
  self.assertEqual(source['law_name'],'各級學校性別平等教育委員會設置準則')
  self.assertTrue(next(a['text'] for a in source['articles'] if a['article_number']=='3').startswith('學校之性別平等教育委員會，'))
  source=json.loads((ROOT/'sources/wiki-official/O1611.json').read_text())
  self.assertEqual(source['law_name'],'涉性別事件之學校不適任人員通報資訊蒐集及查詢處理利用辦法')
 def test_ambiguous_alias_not_guessed(self):
  with patch.dict(self.db.routes['alias_to_laws'],{'模糊法':['a','b']}):
   with self.assertRaises(ValueError):self.db.resolve_law('模糊法')
 def test_unknown_law_not_invented(self):
  with self.assertRaises(ValueError):self.db.resolve_law('不存在的規範999')
 def test_number_normalization(self):
  for a in ['第二十六條','26','第２６條']:self.assertEqual(article_number(a),'26')
 def test_subarticle_normalization(self):
  for a in ['第十三條之一','13-1','第13條之1']:self.assertEqual(article_number(a),'13-1')
 def test_invalid_article_range(self):
  with self.assertRaises(ValueError):article_number('第21條至33條')
 def test_source_law_mismatch(self):
  with self.assertRaises(ValueError):self.db.query(law='性平法',source='O1612')
 def test_article_needs_law(self):
  with self.assertRaises(ValueError):self.db.query(articles=['26'])
 def test_paragraph_needs_article(self):
  with self.assertRaises(ValueError):self.db.query(law='性平法',paragraph='2')
 def test_negative_offset(self):
  with self.assertRaises(ValueError):self.db.query(query='應',offset=-1)
 def test_invalid_limit(self):
  for n in [0,101,True]:
   with self.assertRaises(ValueError):self.db.query(query='應',limit=n)
 def test_invalid_as_of_even_no_hits(self):
  with self.assertRaises(ValueError):self.db.query(query='abcdefgh',as_of='2026-02-31')
 def test_teacher_versions_separate(self):
  r=self.db.query(law='教師法',articles=['25'],full=True);rows=r['articles']['records']
  self.assertEqual({x['source_id'] for x in rows},{'U13','O1612'});self.assertEqual(len({x['version_key'] for x in rows}),2)
 def test_same_observed_revision_different_representation(self):
  r=self.db.query(law='性平法',articles=['26']);rows=r['articles']['records'];self.assertEqual(len(rows),2);self.assertEqual(len({x['version_key'] for x in rows}),1)
 def test_missing_new_teacher_article_no_fallback(self):
  r=self.db.query(source='O1612',articles=['14']);self.assertEqual(r['missing_requested_articles'],['14']);self.assertEqual(r['articles']['records'],[])
 def test_mixed_source_coverage_reported(self):
  r=self.db.query(law='教師法',articles=['14']);self.assertEqual(r['status'],'partial_source_coverage');self.assertEqual({x['source_id'] for x in r['articles']['records']},{'U13'});self.assertIn('14',next(x for x in r['source_coverage'] if x['source_id']=='O1612')['requested_articles_not_collected'])
 def test_multiple_requested_missing(self):
  r=self.db.query(source='U02',articles=['26','999']);self.assertEqual(r['missing_requested_articles'],['999']);self.assertEqual(len(r['articles']['records']),1)
 def test_filtered_article_distinct_from_missing(self):
  r=self.db.query(source='U02',articles=['26'],query='無此詞ZZ');self.assertEqual(r['missing_requested_articles'],[]);self.assertEqual(r['requested_articles_filtered_out'],['26'])
 def test_guide_not_fake_article(self):
  r=self.db.query(source='U12',articles=['1']);d=r['articles']['records'][0];self.assertEqual(d['unit'],'section');self.assertNotEqual(d['display_number'],'第1條')
 def test_pending_effective_pdpa(self):
  r=self.db.query(source='O1603',articles=['1-1'],full=True);self.assertEqual(r['articles']['records'][0]['effective_status'],'official_page_marks_not_yet_effective')
 def test_default_no_full_law_text(self):
  r=self.db.query(law='性平法',articles=['26']);self.assertNotIn('text',r['articles']['records'][0])
 def test_full_law_keeps_exception(self):
  r=self.db.query(source='O1613',articles=['26'],paragraph='2',full=True);d=r['articles']['records'][0];self.assertIn('但終身不得聘任',d['text']);self.assertFalse(d['paragraph_structure_verified']);self.assertEqual(d['text_scope'],'whole_collected_article_or_section_not_paragraph_filtered')
 def test_cross_reference_two_targets(self):
  r=self.db.query(source='U09',articles=['1'],cross_laws=True)
  targets=[u for x in r['cross_law_links'] if x['from_document_id']=='U09:1' for u in x['provisions']]
  self.assertIn({'article':'21','paragraph':'1','item':None},targets);self.assertIn({'article':'33','paragraph':'3','item':None},targets)
 def test_unknown_cited_versions_not_promoted(self):
  for lid in self.db.routes['laws']:
   for x in self.db.load('_index/links/'+lid+'.json')['circular_links']:self.assertIsNone(x['cited_version']);self.assertEqual(x['legal_effect'],'not_inferred')
 def test_all_circular_reference_spans(self):
  for lid in self.db.routes['laws']:
   for x in self.db.load('_index/links/'+lid+'.json')['circular_links']:
    text=self.db.circles.raw_text(x['record_id']);self.assertEqual(text[x['char_start']:x['char_end']],x['exact_text'])
 def test_doc_local_definition(self):
  am={'性別平等教育法':{'ge'}};txt='性別平等教育法（以下簡稱本法）第21條。本法第33條第3項。'
  local=document_definitions(txt,am);r=extract_citations(txt,am,local=local);self.assertTrue(any(x['local_definition_used'] and x['provisions'] and x['provisions'][0]['article']=='33' for x in r))
 def test_undefined_benfa_not_assigned(self):self.assertEqual(extract_citations('本法第33條',{'性別平等教育法':{'ge'}}),[])
 def test_range_marked_not_expanded(self):
  r=extract_citations('性平法第21條至第33條',{'性平法':{'ge'}});self.assertTrue(r[0]['range_not_expanded']);self.assertEqual(len(r[0]['provisions']),1)
 def test_longest_law_name(self):
  r=extract_citations('性別平等教育法施行細則第1條',{'性別平等教育法':{'ge'},'性別平等教育法施行細則':{'rules'}});self.assertEqual({x['target_law_id'] for x in r},{'rules'})
 def test_ambiguous_local_definition_preserved(self):
  am={'甲法':{'a'},'乙法':{'b'}};t='甲法（以下簡稱本法）；乙法（以下簡稱本法）；本法第1條';local=document_definitions(t,am);r=extract_citations(t,am,local=local);self.assertTrue(all(x['ambiguous_alias'] for x in r if x['matched_alias']=='本法'))
 def test_missing_target_provision_not_assumed(self):
  links=self.db.load('_index/links/tw-gender-equality-employment-act.json')['circular_links'];targets=[u for x in links for u in x['provision_targets'] if u['article']=='12'];self.assertTrue(targets);self.assertTrue(all('O1602' in u['not_collected_in_sources'] for u in targets))
 def test_global_secretary_regression(self):
  r=self.db.query(query='執行秘書',all_results=True);self.assertEqual(r['circulars']['page']['total_matches'],7);self.assertIn('C2010-016',{x['record_id'] for x in r['circulars']['records']})
 def test_all_circular_keyword_parity(self):
  for q in ['應','心理諮商','執行秘書','停止適用','調查小組','09300111761','ABCDEFGzzNO']:
   a=self.db.query(query=q,all_results=True)['circulars']['records'];b=self.db.circles.query(query=q,all_results=True)['records'];self.assertEqual({x['record_id'] for x in a},{x['record_id'] for x in b})
 def test_multiterm_and(self):
  r=self.db.query(query='心理諮商 時數',all_results=True)
  for x in r['circulars']['records']:t=normalize(self.db.circles.raw_text(x['record_id']));self.assertIn('心理諮商',t);self.assertIn('時數',t)
 def test_structured_query_parsing_preserves_spaces(self):
  r=self.db.query(query='性平法 第26條 心理諮商 時數');self.assertEqual(r['resolved_law_id'],'tw-gender-equity-education-act');self.assertEqual(r['requested_articles'],['26']);self.assertEqual(len(r['search_logic']['groups']),2);self.assertIn('C2024-012',{x['record_id'] for x in r['circulars']['records']})
 def test_expansion_opt_in_superset(self):
  a=self.db.query(query='諮商輔導',all_results=True);b=self.db.query(query='諮商輔導',expand=True,all_results=True)
  self.assertFalse(a['search_logic']['expanded']);self.assertTrue(b['search_logic']['expanded']);self.assertTrue({x['record_id'] for x in a['circulars']['records']}<={x['record_id'] for x in b['circulars']['records']})
 def test_exact_word_not_bigram_only(self):
  matches,_=self.db.search_matches('學校性別ABNO');self.assertFalse(matches)
 def test_article_pagination_roundtrip(self):
  allr=self.db.query(query='應',all_results=True)['articles']['records'];acc=[];off=0
  while True:
   r=self.db.query(query='應',limit=31,offset=off)['articles'];acc+=r['records']
   if r['page']['next_offset'] is None:break
   off=r['page']['next_offset']
  self.assertEqual([d['document_id'] for d in acc],[d['document_id'] for d in allr])
 def test_circular_pagination_independent(self):
  r=self.db.query(query='應',limit=3,offset=2,circular_offset=5);self.assertEqual(r['articles']['page']['offset'],2);self.assertEqual(r['circulars']['page']['offset'],5)
 def test_exact_number_preserves_primary_set(self):
  a=self.db.query(number_value='1132805149')['circular_result'];b=self.db.circles.query(number_value='1132805149');self.assertEqual([x['record_id'] for x in a['records']],[x['record_id'] for x in b['records']])
 def test_mentions_only_still_available(self):
  r=self.db.query(number_value='09300111761')['circular_result'];self.assertEqual(r['records'],[]);self.assertTrue(r['mentions_only'])
 def test_relation_closure_reaches_later_circular(self):
  r=self.db.relation_closure(['C2024-012']);self.assertIn('CR-041',{x['relation_id'] for x in r['relations']});self.assertIn('C2026-006',{x['record_id'] for x in r['related_cards']})
 def test_relation_scope_not_replacement(self):
  r=self.db.query(relation_id='CR-041',full=True)['relation'];self.assertEqual(r['relation_type'],'supplements');self.assertIn('併案',r['scope']);self.assertTrue(r['evidence']['exact_text_included'])
 def test_relation_metadata_no_long_duplicate(self):
  r=self.db.relation_closure(['C2024-012']);self.assertTrue(all('exact_text' not in x['evidence'] for x in r['relations']));self.assertTrue(all('known_relations' not in x for x in r['related_cards']));self.assertTrue(all('detail_mode' in x for x in r['related_cards']))
  for c in r['related_cards']:
   for issue in c['quality_issues']:self.assertIn('handling',issue);self.assertNotIn('evidence',issue)
  link=self.db.query(number_value='1132805149')['law_links'][0];self.assertIsNone(link['cited_version']);self.assertTrue(link['evidence']['exact_text']);self.assertIn('provision_targets',link)
 def test_relation_cycle_terminates(self):
  edges=[{'relation_id':'a','from_record_id':'C2024-012','to_record_ids':['C2026-006'],'relation_type':'supplements','scope':'test'}, {'relation_id':'b','from_record_id':'C2026-006','to_record_ids':['C2024-012'],'relation_type':'supplements','scope':'test'}]
  with patch.object(self.db.circles,'relations',edges):r=self.db.relation_closure(['C2024-012']);self.assertEqual(r['relation_count'],2)
 def test_as_of_not_applied_as_legal_version(self):
  r=self.db.query(law='教師法',articles=['25'],as_of='2020-01-01');self.assertTrue(r['as_of_does_not_select_legal_version']);self.assertEqual(len(r['articles']['records']),2)
 def test_later_relation_labeled_for_as_of(self):
  r=self.db.query(relation_id='CR-041',as_of='2024-12-31')['relation'];self.assertTrue(r['outside_requested_as_of'])
 def test_unknown_relation(self):
  with self.assertRaises(ValueError):self.db.query(relation_id='CR-999')
 def test_relation_mixed_filters_error(self):
  with self.assertRaises(ValueError):self.db.query(relation_id='CR-041',law='性平法')
 def test_exact_circular_mixed_law_error(self):
  with self.assertRaises(ValueError):self.db.query(number_value='1132805149',law='性平法')
 def test_notes_have_real_basis_not_human_approval(self):
  self.assertEqual(len(self.db.notes),26)
  for n in self.db.notes.values():
   self.assertTrue(n['basis']);self.assertFalse(n['human_legal_approval']);self.assertFalse(n['case_facts_included'])
   for b in n['basis']:self.db.doc(b)
 def test_notes_preserve_yi_and_exception(self):
  n=self.db.notes['LN003'];self.assertIn('宜',n['text']);self.assertIn('更換',n['text']);self.assertIn('宜為同一位',n['circular_evidence'][0]['exact_text'])
 def test_no_case_memory_flag(self):
  r=self.db.query(query='心理諮商');self.assertFalse(r['case_memory']);self.assertTrue(r['read_only'])
 def test_query_does_not_call_builder(self):
  with patch('build_legal_wiki.build_wiki',side_effect=AssertionError('no runtime build')):self.db.query(query='執行秘書')
 def test_query_no_file_writes(self):
  with patch.object(Path,'write_text',side_effect=AssertionError('write')),patch.object(Path,'write_bytes',side_effect=AssertionError('write')):self.db.query(query='心理諮商')
 def test_two_new_cases_no_cross_query_state(self):
  a=self.db.query(query='CANNOT_EXIST_CASE_ALPHA');b=self.db.query(query='心理諮商');self.assertEqual(a['circulars']['page']['total_matches'],0);self.assertNotIn('CANNOT_EXIST_CASE_ALPHA',json.dumps(b))
 def test_every_law_page_present(self):
  for lid in self.db.routes['laws']:self.assertTrue((ROOT/'wiki/laws'/f'{lid}.md').is_file())
 def test_each_wiki_link_target_exists(self):
  import re;from urllib.parse import unquote
  for p in (ROOT/'wiki').rglob('*.md'):
   for link in re.findall(r'\]\(([^)]+)\)',p.read_text()):
    if '://' not in link:self.assertTrue((p.parent/unquote(link.split('#')[0])).exists(),str(p)+':'+link)
 def test_reproducible_build(self):self.assertEqual(build_wiki(ROOT,check=True)['statistics']['law_nodes'],29)
 def test_path_escape_rejected(self):
  with self.assertRaises(ValueError):self.db.load('../../sources/manifest.json')
 def test_cli_partial_exit_3(self):
  p=subprocess.run([sys.executable,str(ROOT/'scripts/lookup_legal.py'),'--source','O1612','--article','14','--json'],capture_output=True,text=True);self.assertEqual(p.returncode,3,p.stderr);self.assertEqual(json.loads(p.stdout)['missing_requested_articles'],['14'])
 def test_cli_unknown_exit_2(self):
  for args in [['--law','Fakexx'],['--paragraph','2'],['--list','--law','性平法']]:
   p=subprocess.run([sys.executable,str(ROOT/'scripts/lookup_legal.py'),*args,'--json'],capture_output=True,text=True);self.assertEqual(p.returncode,2,p.stdout);self.assertIn('error',json.loads(p.stderr))
 def test_modified_source_rejected(self):
  with tempfile.TemporaryDirectory() as d:
   r=Path(d)/ROOT.name;shutil.copytree(ROOT,r);p=r/'sources/wiki-official/O1612.json';p.write_text(p.read_text()+' ')
   with self.assertRaises(ValueError):LegalWiki(r)
 def test_modified_wiki_page_rejected(self):
  with tempfile.TemporaryDirectory() as d:
   r=Path(d)/ROOT.name;shutil.copytree(ROOT,r);p=r/'wiki/README.md';p.write_text(p.read_text()+'bad')
   with self.assertRaises(ValueError):LegalWiki(r)
 def test_modified_knowledge_rejected(self):
  with tempfile.TemporaryDirectory() as d:
   r=Path(d)/ROOT.name;shutil.copytree(ROOT,r);p=r/'knowledge/law-wiki-notes.json';p.write_text(p.read_text()+' ')
   with self.assertRaises(ValueError):LegalWiki(r)
 def test_modified_version_rejected(self):
  with tempfile.TemporaryDirectory() as d:
   r=Path(d)/ROOT.name;shutil.copytree(ROOT,r);(r/'VERSION').write_text('9.9.9\n')
   with self.assertRaises(ValueError):LegalWiki(r)

if __name__=='__main__':unittest.main()
