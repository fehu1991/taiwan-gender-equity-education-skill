"""v1.4.0 deterministic regressions; these are NOT Astra/Claude answer evaluations."""
import hashlib
import json
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'scripts'))
from frontmatter import parse_frontmatter, validate_frontmatter
from lookup_law import build_response, load_manifest, select_sources
from lookup_circular import CircularCatalog, text_output
from validate_package import distribution_errors

class LawCoverageTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.entries=load_manifest(ROOT)
        cls.u02=select_sources(cls.entries, None, 'U02', ROOT)
    def test_partial_missing_reported(self):
        r=build_response(self.u02,['22','999'],root=ROOT)
        self.assertEqual(r['missing_requested_articles'],{'U02':['999']})
        self.assertEqual(r['returned'],1);self.assertFalse(r['request_complete'])
    def test_partial_cli_nonzero_with_result(self):
        p=subprocess.run([sys.executable,str(ROOT/'scripts/lookup_law.py'),'--source','U02','--article','22','--article','999','--format','json'],capture_output=True,text=True)
        self.assertEqual(p.returncode,1);self.assertEqual(json.loads(p.stdout)['returned'],1)
    def test_all_missing_json_preserves_coverage(self):
        p=subprocess.run([sys.executable,str(ROOT/'scripts/lookup_law.py'),'--source','U02','--article','999','--format','json'],capture_output=True,text=True)
        self.assertEqual(p.returncode,2);self.assertIn('查無',p.stderr)
        self.assertEqual(json.loads(p.stdout)['missing_requested_articles'],{'U02':['999']})
    def test_filtered_is_not_missing(self):
        r=build_response(self.u02,['22'],query='zzzz_no_such_word',root=ROOT)
        self.assertEqual(r['missing_requested_articles'],{})
        self.assertEqual(r['requested_articles_filtered_out'],{'U02':['22']})
    def test_fullwidth_article(self):
        r=build_response(self.u02,['第２２條'],root=ROOT)
        self.assertEqual(r['requested_articles'],['22']);self.assertTrue(r['request_complete'])
    def test_duplicate_requested_article_deduped(self):
        r=build_response(self.u02,['22','第22條'],root=ROOT)
        self.assertEqual(r['requested_articles'],['22']);self.assertEqual(r['returned'],1)
    def test_pagination_reconstructs_all_330_without_duplicates(self):
        all_r=build_response(self.entries,query='應',all_results=True,root=ROOT)
        self.assertEqual(all_r['total_matches'],330)
        rows=[];offset=0
        while True:
            r=build_response(self.entries,query='應',limit=100,offset=offset,root=ROOT)
            rows.extend(r['results'])
            if r['next_offset'] is None:break
            offset=r['next_offset']
        self.assertEqual(rows,all_r['results'])
        self.assertEqual(len({(r['source_id'],r['article_number']) for r in rows}),330)
    def test_all_result_metadata(self):
        r=build_response(self.entries,query='應',all_results=True,root=ROOT)
        self.assertFalse(r['truncated']);self.assertTrue(r['all_matches_returned']);self.assertIsNone(r['next_offset'])
    def test_late_page_is_not_entire_result_set(self):
        r=build_response(self.entries,query='應',limit=100,offset=300,root=ROOT)
        self.assertEqual(r['returned'],30);self.assertTrue(r['truncated']);self.assertFalse(r['all_matches_returned'])
    def test_invalid_offsets(self):
        for opts in ({'offset':-1},{'offset':330},{'offset':1,'all_results':True}):
            with self.subTest(opts=opts),self.assertRaises(ValueError):
                build_response(self.entries,query='應',root=ROOT,**opts)
    def test_guideline_label_not_invented_article(self):
        entries=select_sources(self.entries,None,'U12',ROOT)
        r=build_response(entries,['1'],root=ROOT)
        self.assertEqual(r['results'][0]['display_number'],'壹、法規與政策')

class MentionTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):cls.db=CircularCatalog(ROOT)
    def test_mentioned_only_number(self):
        r=self.db.query(number='09300111761')
        self.assertEqual(r['match_count'],0);self.assertEqual(r['mention_count'],3)
        self.assertEqual({m['mentioned_in_record_id'] for m in r['mentions_only']},{'C2004-002','C2004-003','C2004-005'})
    def test_mention_location_and_sha(self):
        for m in self.db.query(number='09300111761')['mentions_only']:
            b=(ROOT/m['source_path']).read_bytes();lines=b.decode().splitlines()
            self.assertEqual(hashlib.sha256(b).hexdigest(),m['source_sha256']);self.assertTrue(m['excerpts'])
            for e in m['excerpts']:self.assertEqual(lines[e['line']-1],e['text'])
    def test_mention_does_not_promote_original(self):
        for m in self.db.query(number='09300111761')['mentions_only']:
            self.assertFalse(m['independent_original_included']);self.assertEqual(m['representation'],'mention_only')
            self.assertNotIn('publication_date',m);self.assertNotIn('effective_on',m)
    def test_full_document_number(self):
        self.assertEqual(self.db.query(number='華總一義字第09300111761號')['mention_count'],3)
        self.assertEqual(self.db.query(number='不存在機關字第09300111761號')['mention_count'],0)
    def test_suffix_is_preserved(self):
        a=self.db.query(number='0930087101A');base=self.db.query(number='0930087101')
        self.assertGreater(a['match_count'],0);self.assertEqual(base['match_count'],0)
        self.assertNotIn('C2004-002',{m['mentioned_in_record_id'] for m in base['mentions_only']})
    def test_mention_year_and_asof(self):
        self.assertEqual(self.db.query(number='09300111761',year=2005)['mention_count'],0)
        self.assertEqual(self.db.query(number='09300111761',as_of='2004-01-01')['mention_count'],0)
    def test_mention_text_is_not_no_hit(self):
        text=text_output(self.db.query(number='09300111761'),False,10)
        self.assertIn('僅在內文提及',text);self.assertNotIn('本次索引查無',text)

class MetadataAndIntegrityTests(unittest.TestCase):
    def setUp(self):self.text=(ROOT/'SKILL.md').read_text();self.version=(ROOT/'VERSION').read_text().strip()
    def test_version_quoted_and_unquoted_equal(self):
        a=validate_frontmatter(self.text,folder_name=ROOT.name,version=self.version)
        b=validate_frontmatter(self.text.replace(f'version: "{self.version}"',f'version: {self.version}'),folder_name=ROOT.name,version=self.version)
        self.assertEqual(a,b)
    def test_block_description_valid(self):
        text='---\nname: campus-gender-equity-officer\ndescription: >\n  第一行用途\n  第二行觸發\nmetadata:\n  version: "1.4.0"\n---\n正文'
        self.assertIn('第二行',validate_frontmatter(text,folder_name=ROOT.name,version='1.4.0')['description'])
    def test_duplicate_yaml_key_rejected(self):
        with self.assertRaises(ValueError):parse_frontmatter('---\nname: one\nname: two\n---\n')
    def test_wrong_version_rejected(self):
        with self.assertRaises(ValueError):validate_frontmatter(self.text,folder_name=ROOT.name,version='9.9.9')
    def test_metadata_nonstring_rejected(self):
        with self.assertRaises(ValueError):validate_frontmatter(self.text.replace('locale: zh-TW','locale: true'),folder_name=ROOT.name,version=self.version)
    def test_compatibility_top_level(self):
        data=parse_frontmatter(self.text);self.assertIn('compatibility',data);self.assertNotIn('compatibility',data['metadata'])
    def fixture(self,root):
        (root/'VERSION').write_text('1.4.0\n');(root/'SKILL.md').write_text('test')
        files=[{'path':p.name,'bytes':len(p.read_bytes()),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted(root.iterdir())]
        (root/'PACKAGE-FILES.json').write_text(json.dumps({'version':'1.4.0','files':files}))
    def test_distribution_intact_and_tampering(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td);self.fixture(root);self.assertEqual(distribution_errors(root),[])
            (root/'SKILL.md').write_text('changed');self.assertTrue(any('SHA不符' in e for e in distribution_errors(root)))
    def test_distribution_extra_missing_and_unsafe_path(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td);self.fixture(root);(root/'extra.txt').write_text('x');(root/'SKILL.md').unlink()
            errors=distribution_errors(root);self.assertTrue(any('未列入' in e for e in errors));self.assertTrue(any('缺漏' in e for e in errors))
            manifest=json.loads((root/'PACKAGE-FILES.json').read_text());manifest['files'].append({'path':'../outside','bytes':0,'sha256':''})
            (root/'PACKAGE-FILES.json').write_text(json.dumps(manifest));self.assertTrue(any('越界' in e for e in distribution_errors(root)))
    def test_all_references_and_templates_have_entry_links(self):
        for folder in ('references','templates'):
            for p in (ROOT/folder).glob('*.md'):
                self.assertIn(']('+p.relative_to(ROOT).as_posix()+')',self.text)
    def test_ai_pdf_and_extraction_are_hashed(self):
        m=json.loads((ROOT/'sources/ai-guidance/manifest.json').read_text())
        for item in [m]+m['extracted_pages']:
            self.assertEqual(hashlib.sha256((ROOT/item['path']).read_bytes()).hexdigest(),item['sha256'])
    def test_new_model_scenarios_remain_not_run(self):
        data=json.loads((ROOT/'evals/reliability-and-ai-scenarios.json').read_text())
        self.assertEqual(len(data['scenarios']),24);self.assertEqual(data['execution_status'],'not_run')
        for c in data['scenarios']:self.assertEqual(c['model_run_status'],'not_run')

if __name__=='__main__':unittest.main()
