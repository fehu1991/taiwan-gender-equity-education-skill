"""First-warning-only document regressions and retained administrative-law tests.
These tests read package files, not user conversations; no LLM/platform is called.
"""
from __future__ import annotations
import ast
import hashlib
import json
import re
import sys
import unittest
from pathlib import Path
from unittest.mock import patch
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'scripts'))
from lookup_legal import LegalWiki
from build_legal_wiki import build_wiki

def text(rel): return (ROOT / rel).read_text(encoding='utf-8')
def load(rel): return json.loads(text(rel))
STARTUP_WARNING=text('assets/startup-warning.txt').strip()

class FirstWarningOnlyTests(unittest.TestCase):
    def test_warning_is_present(self):
        self.assertTrue(STARTUP_WARNING.startswith('【使用前警告'))
    def test_warning_top_and_skill_exact(self):
        for rel in ['SKILL.md','deployment/TOP_LEVEL_INSTRUCTIONS.md']:
            self.assertEqual(re.findall(r'<!-- startup-warning:start -->\n(.*?)\n<!-- startup-warning:end -->',text(rel),re.S),[STARTUP_WARNING])
    def test_warning_precedes_tools_and_business(self):
        s=text('SKILL.md')
        self.assertLess(s.index('startup-warning:start'),s.index('## 與其他技能分工'))
        self.assertLess(s.index('startup-warning:start'),s.index('## 按問題讀取'))
    def test_first_turn_instruction_is_warning_only(self):
        s=text('SKILL.md').split('<!-- startup-warning:start -->')[0]
        for phrase in ['不先分析問題','不讀附件','不搜尋','不呼叫工具','不給計畫']:
            self.assertIn(phrase,s)
    def test_initial_warning_not_based_on_content_classification(self):
        self.assertIn('不分析初始輸入以決定是否警告',text('SKILL.md'))
    def test_warning_retains_requested_legal_notice(self):
        for phrase in ['可直接或間接','姓名改成代號仍不夠','機密文書','未經同意公開','唯一依據','不能保證刪除']:
            self.assertIn(phrase,STARTUP_WARNING)
    def test_no_consent_keyword_in_warning(self):
        self.assertNotIn('我已閱讀並同意使用限制',STARTUP_WARNING)
        self.assertIn('下一則可直接提出問題',STARTUP_WARNING)
        self.assertIn('無須回覆同意詞或另行確認',STARTUP_WARNING)
    def test_later_turns_are_direct_work(self):
        self.assertIn('下一則直接依使用者問題工作',text('SKILL.md'))
        self.assertIn('下一則直接處理問題',text('deployment/TOP_LEVEL_INSTRUCTIONS.md'))
    def test_reloading_does_not_repeat_warning(self):
        self.assertIn('不因重新讀取模組或切換議題而重複警告',text('SKILL.md'))
    def test_old_runtime_gate_deleted(self):
        self.assertFalse((ROOT/'scripts/startup_gate.py').exists())
    def test_no_gate_imports_or_handler_definitions_in_scripts(self):
        removed={'GateSession','TrustedAssessment','route_turn','decide'}
        for p in (ROOT/'scripts').glob('*.py'):
            tree=ast.parse(p.read_text())
            for n in ast.walk(tree):
                if isinstance(n,ast.ImportFrom):
                    self.assertNotEqual(n.module,'startup_gate',p.name)
                if isinstance(n,ast.Import):
                    self.assertNotIn('startup_gate',{a.name for a in n.names},p.name)
                if isinstance(n,(ast.ClassDef,ast.FunctionDef,ast.AsyncFunctionDef)):
                    self.assertNotIn(n.name,removed,p.name)
    def test_old_active_rule_deleted(self):
        self.assertFalse((ROOT/'references/29-entry-gate-and-response.md').exists())
        self.assertTrue((ROOT/'references/29-initial-warning-and-response.md').is_file())
    def test_no_residual_lock_protocol_in_operating_documents(self):
        files=[ROOT/'SKILL.md']+list((ROOT/'references').glob('*.md'))+list((ROOT/'deployment').glob('*.md'))+list((ROOT/'agents').glob('*.yaml'))+list((ROOT/'knowledge').glob('*.json'))
        removed=['BLOCKED_CONTEXT','TrustedAssessment','GateSession','NEW → WARNED → READY',
                 '我已閱讀並同意使用限制','無法確認資料安全時暫不呼叫',
                 '本回合只停止並提醒','後續放行須有可信','下一則必須僅回覆',
                 '首次警告及獨立確認完成','後續遇到可辨識或保密資料依29號模組停止',
                 '先判斷輸入與工作可否使用AI']
        for file in files:
            for phrase in removed:self.assertNotIn(phrase,file.read_text(),str(file.relative_to(ROOT)))
    def test_ai_reference_is_not_per_turn_admission_check(self):
        s=text('references/25-public-sector-ai-governance.md')
        self.assertIn('不是每回合必讀的輸入檢查清單',s)
        self.assertNotIn('## 不符條件或已收到敏感內容',s)
        self.assertNotIn('## 先判斷材料與工作',s)
    def test_ai_source_distinctions_preserved(self):
        s=text('references/25-public-sector-ai-governance.md')
        for phrase in ['第3點','第4點','得準用','第2、5點','第6點','第7點','第8點']:
            self.assertIn(phrase,s)
    def test_conclusion_first_and_uncertainty_retained(self):
        s=text('SKILL.md')
        for phrase in ['首段直接交付結論','不輸出隱藏思考鏈','不能為果斷省略重要不確定性']:
            self.assertIn(phrase,s)
    def test_deployment_is_text_only(self):
        self.assertEqual({p.name for p in (ROOT/'deployment').iterdir()},{'README.md','TOP_LEVEL_INSTRUCTIONS.md'})
        self.assertIn('沒有對話攔截或資料分類程式',text('deployment/README.md'))
        self.assertIn('不是平台硬性鎖定',text('deployment/README.md'))
    def test_upgrade_does_not_leave_deleted_file(self):
        self.assertIn('完整資料夾取代舊版',text('UPGRADE-v1.7.1.md'))
        self.assertIn('不要僅解壓覆蓋舊目錄',text('UPGRADE-v1.7.1.md'))
    def test_all_reference_links_direct(self):
        s=text('SKILL.md')
        for p in (ROOT/'references').glob('*.md'):
            self.assertIn(']('+p.relative_to(ROOT).as_posix()+')',s)
    def test_frontmatter_standard_fields_and_version(self):
        import yaml
        front=yaml.safe_load(text('SKILL.md').split('---',2)[1])
        self.assertTrue(set(front)<={'name','description','license','compatibility','metadata','allowed-tools'})
        self.assertEqual(front['metadata']['version'],text('VERSION').strip())
        self.assertLess(len(text('SKILL.md').splitlines()),500)
    def test_no_confirmation_or_block_profiles(self):
        d=load('evals/session-profiles.json')
        self.assertEqual(set(d['profiles']),{'new','after_warning'})
        self.assertEqual(d['model_run_status'],'not_run')
        self.assertFalse(d['cross_case_memory'])
    def test_new_scenarios_are_unrun_and_use_correct_profiles(self):
        d=load('evals/entry-admin-scenarios.json')
        self.assertEqual(len(d['scenarios']),24)
        for c in d['scenarios']:
            self.assertEqual(c['model_run_status'],'not_run')
            self.assertIn(c['session_profile'],{'new','after_warning'})
            self.assertFalse(c['id'].startswith('GATE-'))
    def test_admin_priority_does_not_reinstate_screening(self):
        d=load('knowledge/admin-law-framework.json')
        self.assertNotIn('資料閘門',d['priority'])
        self.assertTrue(d['priority'].startswith('本次問題的公私法與行為性質'))
    def test_query_api_has_no_admission_parameter(self):
        import inspect
        for obj in [LegalWiki,LegalWiki.query]:
            parameters=inspect.signature(obj).parameters
            self.assertTrue(set(parameters).isdisjoint({'assessment','session','consent','verdict','fingerprint'}))

class AdminFrameworkTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.db=LegalWiki(ROOT);cls.framework=load('knowledge/admin-law-framework.json')
    def test_two_additional_representations_not_fake_new_laws(self):
        self.assertEqual(self.db.resolve_law('O1701'),'tw-administrative-procedure-act');self.assertEqual(self.db.resolve_law('O1702'),'tw-gender-equity-education-act');self.assertEqual(len(self.db.routes['laws']),29)
    def test_21_selected_articles_only(self):
        m=load('sources/admin-framework/manifest.json');self.assertEqual(sum(len(s['article_numbers']) for s in m['sources']),21)
        for s in m['sources']:
            self.assertEqual(hashlib.sha256((ROOT/s['path']).read_bytes()).hexdigest(),s['sha256']);d=load(s['path']);self.assertFalse(d['full_official_text_included']);self.assertFalse(d['raw_webpage_included'])
    def test_source_is_not_apa_formal_mother(self):
        self.assertIn('不是性平法的形式上母法',self.framework['position']);self.assertEqual(self.framework['kind'],'skill_analysis_framework_not_statute')
    def test_bridge_exact_sixth_paragraph(self):
        b=self.framework['bridge'];d=self.db.doc(b['source_document_id']);self.assertEqual(b['paragraph'],'6');self.assertIn(b['exact_text'],d['text']);self.assertFalse(b['human_legal_approval'])
    def test_all_seven_stages_have_real_bases(self):
        stages=self.framework['stages'];self.assertEqual(len(stages),7);self.assertEqual(len({s['id'] for s in stages}),7)
        for s in stages:
            self.assertTrue(s['limits']);self.assertTrue(s['basis'])
            for b in s['basis']:self.assertTrue(self.db.doc(b)['text'])
    def test_special_procedure_before_general_exceptions(self):
        s=next(x for x in self.framework['stages'] if x['id']=='procedure');self.assertIn('O1601:3',s['basis']);self.assertIn('O1702:33',s['basis']);self.assertIn('U02:23',s['basis']);self.assertIn('O1613:26',s['basis'])
    def test_no_automatic_punishment_or_criminal_standard(self):
        s=next(x for x in self.framework['stages'] if x['id']=='merits');self.assertIn('不自行生成特定證明程度',s['limits']);self.assertIn('全部等同行政罰',s['limits'])
    def test_defects_and_cure_not_automatic(self):
        s=next(x for x in self.framework['stages'] if x['id']=='effect');self.assertIn('不能一見違法即宣告自始無效',s['limits']);self.assertIn('一律可先做再追認',s['limits'])
    def test_remedies_require_identity_and_target(self):
        s=next(x for x in self.framework['stages'] if x['id']=='remedies');self.assertIn('申復不等於申訴或訴願',s['limits']);self.assertIn('所有案件導向行政訴訟',s['limits'])
    def test_new_law_sources_indexed_without_fallback(self):
        r=self.db.query(source='O1701',articles=['92'],full=True);self.assertEqual({x['source_id'] for x in r['articles']['records']},{'O1701'});self.assertIn('對外直接發生法律效果',r['articles']['records'][0]['text'])
    def test_uncollected_article_remains_missing(self):
        r=self.db.query(source='O1701',articles=['11']);self.assertEqual(r['missing_requested_articles'],['11']);self.assertFalse(r['articles']['records'])
    def test_gender_33_source_versions_not_merged(self):
        r=self.db.query(law='性平法',articles=['33']);self.assertIn('O1702',{x['source_id'] for x in r['articles']['records']});self.assertIn('U02',{x['source_id'] for x in r['articles']['records']})
    def test_admin_notes_searchable(self):
        r=self.db.query(query='行政法核心',all_results=True);self.assertTrue(any(x['note_id'].startswith('ALN') for x in r['reading_notes']['records']))
    def test_eight_admin_notes_are_not_human_approved(self):
        notes=[n for k,n in self.db.notes.items() if k.startswith('ALN')];self.assertEqual(len(notes),8)
        for n in notes:
            self.assertFalse(n['human_legal_approval']);self.assertFalse(n['case_facts_included']);self.assertTrue(n['limits'])
    def test_admin_views_generated_from_single_definition(self):
        self.assertEqual(load('wiki/_index/admin-framework.json'),self.framework);self.assertTrue((ROOT/'wiki/admin-framework.md').exists())
    def test_framework_is_a_build_dependency(self):
        m=load('wiki/_index/manifest.json');serialized=json.dumps(m);self.assertIn('knowledge/admin-law-framework.json',serialized);self.assertIn('sources/admin-framework/O1701.json',serialized)
    def test_wiki_queries_remain_read_only(self):
        with patch.object(Path,'write_text',side_effect=AssertionError('no writes')),patch.object(Path,'write_bytes',side_effect=AssertionError('no writes')):
            r=self.db.query(query='行政法核心');self.assertTrue(r['read_only']);self.assertFalse(r['case_memory'])
    def test_later_circular_still_only_supplement(self):
        r=self.db.query(relation_id='CR-041',full=True)['relation'];self.assertEqual(r['relation_type'],'supplements');self.assertIn('併案',r['scope'])

if __name__ == '__main__':unittest.main()
